"""Shared source-language semantics for the portable PLW kernel.

The module centralizes path/import resolution that used to be duplicated across
``core.shared_graph`` and ``codebase.file_scanner``.  It also provides the
minimal Python AST frontend needed for PLW to map its own implementation.

It is deliberately stdlib-only and does not perform code execution.
"""

from __future__ import annotations

import ast
import json
import os
import re
from typing import Any, Dict, Iterable, List, Optional, Set

JS_SOURCE_EXTENSIONS = (".ts", ".tsx", ".js", ".jsx")
PYTHON_SOURCE_EXTENSIONS = (".py",)
SOURCE_EXTENSIONS = JS_SOURCE_EXTENSIONS
EXPERIMENTAL_SOURCE_EXTENSIONS = JS_SOURCE_EXTENSIONS + PYTHON_SOURCE_EXTENSIONS
JS_RESOLUTION_EXTENSIONS = JS_SOURCE_EXTENSIONS
PYTHON_RESOLUTION_EXTENSIONS = PYTHON_SOURCE_EXTENSIONS


_TOOL_IMPLEMENTATION_ROOT = os.path.abspath(os.path.dirname(__file__))

def is_tool_implementation_path(path: str) -> bool:
    """Return True when *path* belongs to this PLW implementation tree.

    The experimental Python frontend is intentionally capable of mapping PLW
    itself, but ordinary/global scans must not silently absorb the tool
    implementation into the user's corpus.  Self-hosting callers opt in
    explicitly at the graph/analyzer boundary.
    """
    candidate = os.path.abspath(str(path))
    try:
        return os.path.commonpath([candidate, _TOOL_IMPLEMENTATION_ROOT]) == _TOOL_IMPLEMENTATION_ROOT
    except ValueError:
        return False

_EXPLICIT_INTERNAL_CORPUS_ROOTS = (
    os.path.join(_TOOL_IMPLEMENTATION_ROOT, "fixtures_min"),
)

def _is_within(path: str, root: str) -> bool:
    try:
        return os.path.commonpath([os.path.abspath(path), os.path.abspath(root)]) == os.path.abspath(root)
    except ValueError:
        return False

def source_path_allowed(
    path: str,
    *,
    include_tool_source: bool = False,
    scan_root: Optional[str] = None,
) -> bool:
    """Apply the product/self-host ownership boundary to one source path.

    Internal fixture corpora remain scannable when they are the explicit scan
    root.  This keeps regression/demo targets usable without letting a broad
    repository scan absorb PLW's own implementation.
    """
    if include_tool_source or not is_tool_implementation_path(path):
        return True
    if scan_root:
        scan_abs = os.path.abspath(str(scan_root))
        if any(_is_within(scan_abs, corpus_root) for corpus_root in _EXPLICIT_INTERNAL_CORPUS_ROOTS):
            return True
    return False


def normalize_path(value: str) -> str:
    normalized = os.path.normpath(value).replace("\\", "/")
    if normalized.startswith("./"):
        normalized = normalized[2:]
    return normalized


def source_language(path: str) -> str:
    return "python" if str(path).endswith(PYTHON_SOURCE_EXTENSIONS) else "javascript"


def source_extensions(*, include_python: bool = False) -> tuple[str, ...]:
    """Return the active source-extension contract.

    Stable/default callers see the F85 TS/JS boundary. Python is exposed only
    through an explicit experimental/self-host path.
    """
    return EXPERIMENTAL_SOURCE_EXTENSIONS if include_python else SOURCE_EXTENSIONS


def is_source_file(filename: str, *, include_python: bool = False) -> bool:
    if filename.endswith(".d.ts"):
        return False
    return filename.endswith(source_extensions(include_python=include_python))


def strip_js_comments(content: str) -> str:
    content = re.sub(r"//.*$", "", content, flags=re.MULTILINE)
    return re.sub(r"/\*[\s\S]*?\*/", "", content)


def classify_js_import_nature(stmt: str) -> str:
    stmt_clean = " ".join(stmt.strip().split())
    if re.search(r"^(?:import|export)\s+type\b", stmt_clean):
        return "type_only"
    brace_match = re.search(r"\{([^}]+)\}", stmt_clean)
    if brace_match:
        raw_items = brace_match.group(1).split(",")
        specifiers = [s.strip() for s in raw_items if s.strip()]
        if specifiers and all(re.match(r"^type\s+[A-Za-z0-9_$]", s) for s in specifiers):
            return "type_only"
    return "runtime"


def resolve_relative_import_path(base_file: str, import_path: str) -> str:
    """Resolve slash-form relative imports against an importer path.

    Python relative imports are normalized to ``./foo`` / ``../foo`` by the
    AST frontend before reaching this helper.
    """
    if not import_path.startswith("."):
        return normalize_path(import_path)

    base_dir = os.path.dirname(base_file)
    parts = base_dir.split("/") if base_dir else []
    for segment in import_path.split("/"):
        if segment == "..":
            if parts:
                parts.pop()
        elif segment and segment != ".":
            parts.append(segment)
    return normalize_path("/".join(parts))


def candidate_targets(resolved_base: str, language: str = "javascript") -> List[str]:
    candidates: List[str] = []
    seen: Set[str] = set()

    def add(candidate: str) -> None:
        candidate = normalize_path(candidate)
        if candidate and candidate not in seen:
            seen.add(candidate)
            candidates.append(candidate)

    add(resolved_base)

    if language == "python":
        if not resolved_base.endswith(PYTHON_RESOLUTION_EXTENSIONS):
            add(resolved_base + ".py")
            add(f"{resolved_base}/__init__.py")
        return candidates

    if not any(resolved_base.endswith(ext) for ext in JS_RESOLUTION_EXTENSIONS):
        for ext in JS_RESOLUTION_EXTENSIONS:
            add(resolved_base + ext)
        for ext in JS_RESOLUTION_EXTENSIONS:
            add(f"{resolved_base}/index{ext}")
    return candidates


def python_module_candidates(raw_import: str, roots: Iterable[str]) -> List[str]:
    """Return workspace-anchored candidates for an absolute Python module."""
    candidates: List[str] = []
    seen: Set[str] = set()

    def add(candidate: str) -> None:
        candidate = normalize_path(candidate)
        if candidate and candidate not in seen:
            seen.add(candidate)
            candidates.append(candidate)

    for candidate in candidate_targets(raw_import, "python"):
        add(candidate)
    if not os.path.isabs(raw_import):
        for root in roots:
            root_norm = normalize_path(str(root) or ".")
            if root_norm in ("", "."):
                continue
            anchored = normalize_path(os.path.join(root_norm, raw_import))
            for candidate in candidate_targets(anchored, "python"):
                add(candidate)
    return candidates

def strip_jsonc_comments(text: str) -> str:
    text = re.sub(r"/\*.*?\*/", "", text, flags=re.S)
    text = re.sub(r"(^\s*)//.*", r"\1", text, flags=re.M)
    return re.sub(r",(\s*[}\]])", r"\1", text)


def load_alias_rules(roots: Iterable[str]) -> List[Dict[str, Any]]:
    """Read TS/JS compilerOptions.paths aliases from nearby config files."""
    roots = list(roots)
    config_candidates: List[str] = []
    seen_configs: Set[str] = set()
    search_dirs: List[str] = []

    for root in roots + ["."]:
        curr = normalize_path(root) if root else "."
        while curr:
            if curr not in search_dirs:
                search_dirs.append(curr)
            if curr in (".", ""):
                break
            parent = normalize_path(os.path.dirname(curr))
            if parent == curr:
                break
            curr = parent
    if "." not in search_dirs:
        search_dirs.append(".")

    config_names = (
        "tsconfig.json",
        "jsconfig.json",
        "tsconfig.base.json",
        "tsconfig.app.json",
    )
    for directory in search_dirs:
        for config_name in config_names:
            cfg = normalize_path(os.path.join(directory, config_name))
            if cfg not in seen_configs:
                seen_configs.add(cfg)
                config_candidates.append(cfg)

    rules: List[Dict[str, Any]] = []
    for cfg in config_candidates:
        if not os.path.isfile(cfg):
            continue
        try:
            with open(cfg, "r", encoding="utf-8", errors="ignore") as handle:
                data = json.loads(strip_jsonc_comments(handle.read()))
        except Exception:
            continue

        compiler_options = data.get("compilerOptions", {}) or {}
        base_url = compiler_options.get("baseUrl")
        paths = compiler_options.get("paths", {}) or {}
        if not paths:
            continue

        config_dir = os.path.dirname(cfg) or "."
        alias_base = normalize_path(os.path.join(config_dir, base_url)) if base_url else normalize_path(config_dir)

        for pattern, targets in paths.items():
            if not isinstance(targets, list):
                continue
            for target in targets:
                if not isinstance(target, str):
                    continue
                if pattern.endswith("/*"):
                    prefix = pattern[:-1]
                    target_base = target[:-1] if target.endswith("/*") else target
                    full_base = normalize_path(os.path.join(alias_base, target_base)) if alias_base and alias_base != "." else normalize_path(target_base)
                    rules.append({
                        "type": "wildcard",
                        "prefix": prefix,
                        "base": full_base,
                        "source": cfg,
                    })
                else:
                    full_target = normalize_path(os.path.join(alias_base, target)) if alias_base and alias_base != "." else normalize_path(target)
                    rules.append({
                        "type": "exact",
                        "pattern": pattern,
                        "target": full_target,
                        "source": cfg,
                    })

    rules.sort(
        key=lambda rule: (
            len(rule.get("prefix", rule.get("pattern", ""))),
            rule.get("source", ""),
        ),
        reverse=True,
    )
    return rules


def alias_candidates(raw_import: str, alias_rules: List[Dict[str, Any]]) -> List[str]:
    candidates: List[str] = []
    seen: Set[str] = set()
    for rule in alias_rules:
        candidate: Optional[str] = None
        if rule.get("type") == "exact" and raw_import == rule.get("pattern"):
            candidate = rule.get("target")
        elif rule.get("type") == "wildcard":
            prefix = rule.get("prefix", "")
            if prefix and raw_import.startswith(prefix):
                rest = raw_import[len(prefix):]
                base = rule.get("base", "")
                candidate = normalize_path(os.path.join(base, rest)) if base else normalize_path(rest)
        if candidate and candidate not in seen:
            seen.add(candidate)
            candidates.append(candidate)
    return candidates


def _python_relative_module(level: int, module: Optional[str]) -> str:
    # Preserve an explicit relative marker; normalize_path intentionally strips
    # ``./`` and therefore must not be used for the semantic identity here.
    prefix = "../" * max(0, level - 1) + "./"
    suffix = (module or "").replace(".", "/")
    return prefix + suffix if suffix else prefix


def parse_python_imports(content: str) -> List[Dict[str, Any]]:
    """Parse Python imports using the stdlib AST without executing the file."""
    try:
        tree = ast.parse(content)
    except (SyntaxError, ValueError):
        return []

    results: List[Dict[str, Any]] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                results.append({
                    "raw_import": alias.name.replace(".", "/"),
                    "import_nature": "runtime",
                    "statement": f"import {alias.name}",
                    "symbols": [alias.asname or alias.name.split(".")[0]],
                    "semantic_usages": [],
                    "language": "python",
                    "is_relative": False,
                })
        elif isinstance(node, ast.ImportFrom):
            if node.level:
                module_base = _python_relative_module(node.level, node.module)
                if node.module:
                    raw_imports = [module_base]
                else:
                    raw_imports = [
                        module_base.rstrip("/") + "/" + alias.name.replace(".", "/")
                        for alias in node.names
                        if alias.name != "*"
                    ]
                if not raw_imports:
                    raw_imports = [module_base]
            else:
                module = (node.module or "").replace(".", "/")
                # ``from pkg import submodule`` may resolve either pkg/__init__.py
                # or pkg/submodule.py. Emit the package first and submodules as
                # additional candidates so graph construction can pick what exists.
                raw_imports = [module] if module else []
                if module:
                    for alias in node.names:
                        if alias.name != "*":
                            raw_imports.append(f"{module}/{alias.name.replace('.', '/')}")

            for raw_import in dict.fromkeys(raw_imports):
                if not raw_import:
                    continue
                results.append({
                    "raw_import": raw_import,
                    "import_nature": "runtime",
                    "statement": f"from {'.' * node.level}{node.module or ''} import ...",
                    "symbols": [alias.asname or alias.name for alias in node.names],
                    "semantic_usages": [],
                    "language": "python",
                    "is_relative": bool(node.level),
                })
    return results


__all__ = [
    "JS_RESOLUTION_EXTENSIONS",
    "JS_SOURCE_EXTENSIONS",
    "PYTHON_RESOLUTION_EXTENSIONS",
    "PYTHON_SOURCE_EXTENSIONS",
    "SOURCE_EXTENSIONS",
    "EXPERIMENTAL_SOURCE_EXTENSIONS",
    "is_tool_implementation_path",
    "source_path_allowed",
    "source_extensions",
    "alias_candidates",
    "candidate_targets",
    "classify_js_import_nature",
    "is_source_file",
    "load_alias_rules",
    "normalize_path",
    "parse_python_imports",
    "python_module_candidates",
    "resolve_relative_import_path",
    "source_language",
    "strip_js_comments",
    "strip_jsonc_comments",
]
