# Execution-Backed Scenario Evidence Workflow

**Load when:** F138 already accepted one exact `validation.result` and the agent must bind it into the selected F128 scenario evidence space.

**Provides:** read-only scenario binding with F137/F138 execution lineage, F129-style `OBSERVED`/`MISSING` semantics, requested/observed check accounting, and provenance v2.

## Canonical technical anchors

- scenario-bound evidence
- provenance/lineage binding
- content-addressed result identity
- trace-to-scenario association
- observed-vs-missing evidence accounting

This is similar to attaching a verified test/run artifact to the exact scenario that requested it. It is **not** validator execution, test rerun, proof-obligation coverage, postcondition proof, or truth commit.

## Epistemic gap

Before F139 the agent can know that F138 accepted exact runtime-result content, but still lacks a scenario-bound artifact answering which F128 scenario was observed, which selected scenarios remain missing, which requested checks were observed, and which F137/F138 lineage makes that observation execution-backed.

Use:

```bash
plw validation-scenario-bind <acceptance-id> <plan.json> <result.json> \
  --store-dir <dir> --json
```

The command is read-only. It re-verifies the F138 acceptance receipt, raw-result digest, plan/scenario/validator identity, outcome, and evidence IDs. It projects `F138_ACCEPTED_RUNTIME_RESULT` provenance without widening authority.

## Authority boundary

A successful binding does not mean proof obligations are covered. Validator `PASS` is not postcondition proof; validator `FAIL` is not runtime failure.

**Return to:** the root router before any execution, proof promotion, or truth claim.

**Related modules — load only when needed:** [Validation result evidence acceptance](validation-result-evidence-acceptance-workflow.md), [Validation proof-obligation coverage](validation-proof-obligation-workflow.md).

Next boundary: run `plw validation-coverage execution-backed <f139-binding.json> <obligations.json> --json` using the [Validation proof-obligation coverage workflow](validation-proof-obligation-workflow.md). F140 re-derives coverage read-only and still does not prove the postcondition.
