# Target codebase topology workflow

**Load when:** entering an unfamiliar target repository, structural ownership is not yet grounded, or `target_orientation.stage=TARGET_STRUCTURAL_ORIENTATION_READY` must be interpreted before task-specific tool selection.

**Provides:** a first-contact static map of file→import→file connectivity, entrypoint/test surfaces, dependency hubs, SCC/cycle surfaces, boundaries, unresolved imports, external imports, and the limits of those observations.

**Return to:** [root skill router](../SKILL.md).

## Why this comes first

Before choosing a specialized capability, establish the space in which the task exists.
The model may be able to read one file manually, but one file does not establish
reverse dependency closure, repository entrypoints, high fan-in hubs, cycle
surfaces, or unresolved import gaps.

Canonical technical anchors:

```text
directed dependency graph
import graph
graph reachability
fan-in / fan-out
strongly connected components
```

This is **static topology**, not a runtime call graph or execution trace.

## First-contact command

```bash
plw topology <target-root> --json
```

Default output is bounded. It includes counts and high-value structural surfaces
without dumping every edge into model context. When the exact file→import→file
edge list is genuinely needed:

```bash
plw topology <target-root> --full-edges --json
```

`--full-edges` is explicit because large repositories can make a full edge list
expensive to place in context.

## Interpretation order

Read the output in this order:

```text
inventory
  ↓
entrypoint/test surfaces
  ↓
high fan-in / high fan-out hubs
  ↓
cyclic SCCs
  ↓
unresolved import gaps
  ↓
boundary/external surfaces
  ↓
resolve the user's target node
```

Only after the target is grounded should task-specific evidence needs be mapped
to capabilities such as `impact`, `context`, geometry, or runtime validation.

## Proof boundary

```text
import edge
!= runtime call

entrypoint heuristic
!= proven execution root

static test file
!= executed coverage

high fan-in
!= semantic importance by itself

absence from resolved graph
!= irrelevance when unresolved imports remain
```

`reasoning_gaps` are therefore first-class. Unresolved imports mean graph
reachability is incomplete across those sites.

## Relationship to `work`

`plw work` reuses its canonical graph snapshot and returns the same
`target_orientation` without a second filesystem scan. Explicit `topology` is
for first-contact orientation; `work` adds the user task, target evidence,
semantic affordance, and skill handoff.

**Related modules — load only when needed:**
- Task-oriented work after structural orientation: [Adaptive agent workflow](adaptive-agent-workflow.md).
- Target blast radius after a node is resolved: [Code-change and session workflow](code-change-and-session-workflow.md).
- Output/proof-field interpretation: [Analysis output reference](analysis-output-reference.md).
