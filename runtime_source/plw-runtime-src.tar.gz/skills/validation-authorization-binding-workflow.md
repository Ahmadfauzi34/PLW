# Validation authorization binding workflow

**Load when:** one exact F132 validation request has been selected and an external principal/authority has approved that specific request.

**Provides:** F133 short-lived principal grant verification plus an `AUTHORIZED_BOUND` artifact for one exact `request_id`.

**Return to:** [root skill router](../SKILL.md).

## Boundary

F133 is deliberately split into two roles:

```text
host / approval authority
  -> issue_validation_request_authorization_assertion(...)

PLW/read-only verifier
  -> plw validation-authorization ...
  -> AUTHORIZED_BOUND
```

The CLI never issues its own grant. The host assertion is HMAC-sealed with the
same accountability trust store, short-lived, nonce-bearing, principal-bound,
and tied to:

```text
F132 request_id
+ request-set digest
+ scenario_id
+ validator_id
+ executor_id
+ operation_key
```

F133 semantically re-verifies the F132 request set before accepting the grant.
A checksum-valid forged request set or a grant copied to another request,
validator, executor, scenario, or operation key fails closed.

## Command

```bash
plw validation-authorization \
  <plan.json> <evidence.json> <obligations.json> <assertion.json> \
  --request-id <sha256:id> --validator-id <id> --executor-id <id> \
  [--store-dir <trust-store>] --json
```

The command is read-only. Assertion issuance is intentionally library/host only:

```python
issue_validation_request_authorization_assertion(...)
```

and must be exposed only after the host's approval ceremony.

## Proof boundary

```text
REQUESTED
  -> AUTHORIZED_BOUND

AUTHORIZED_BOUND
  != LEASED
  != ATTEMPT_REGISTERED
  != DISPATCH_PREPARED
  != RUNTIME_DISPATCHED
  != VALIDATOR_EXECUTED
  != EVIDENCE_RETURNED
  != POSTCONDITION_PROVEN
  != TRUTH
```

`handoff.may_dispatch` remains false. A later lease-binding checkpoint must
consume this exact authorization binding before any validator dispatch path can
be considered.

**Related modules — load only when needed:**

- [Validation execution request workflow](validation-execution-request-workflow.md) for F132 request semantics.
- [Atomic execution lease workflow](atomic-execution-lease-workflow.md) for the later single-use lease boundary.
- [Executor adapter reconciliation workflow](executor-adapter-reconciliation-workflow.md) for post-lease dispatch/reconciliation semantics.
