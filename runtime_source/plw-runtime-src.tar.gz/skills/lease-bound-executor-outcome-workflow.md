# Lease-Bound Executor Outcome Workflow — F122

**Load when:** an F121 lease has been acquired and the exact executor needs a durable attempt handoff, a terminal executor report must be recorded, or a missing/ambiguous executor outcome must be inspected without guessing success.

**Provides:** the F122 `LEASED -> ATTEMPT_REGISTERED -> terminal outcome` reference state machine, exact lease/executor/plan binding, crash-window semantics, idempotent recovery, and the boundary between an executor report and postcondition/truth proof.

**Return to:** [SKILL.md routing map](../SKILL.md#9-skill-module-routing-map).

**Related modules — load only when needed:** [atomic execution lease workflow](atomic-execution-lease-workflow.md) when the F121 lease or executor binding is unclear; [context and proof workflow](context-and-proof-workflow.md) when a terminal executor report must be settled against source/runtime/postcondition evidence; [tool-call and CLI workflow](tool-call-and-cli-workflow.md) for advanced invocation mechanics.

> F122 records what happened at the executor boundary. It does not execute the external plan, infer a missing terminal result, prove a postcondition, promote stable state, or commit truth.

## State machine

```text
F121 LEASED
  -> ATTEMPT_REGISTERED
       -> SUCCEEDED
       -> FAILED
       -> INDETERMINATE
```

`ATTEMPT_REGISTERED` is a durable pre-execution barrier. It proves that the exact executor claimed the one lease handoff; it does **not** prove that the external side effect actually started.

A registered attempt with no terminal receipt remains unresolved. This is intentional because two crash windows cannot be collapsed safely:

```text
attempt registration committed
  -> crash before external invocation

external effect happened
  -> crash before terminal receipt committed
```

In both cases the durable state is `ATTEMPT_REGISTERED` until separate evidence reconciles it. Never infer success or failure from time, lease expiry, process disappearance, or absence of a later report.

## Register one executor attempt

The executor adapter should claim the already-acquired F121 handoff immediately before invoking the exact bound plan:

```bash
plw action-outcome register \
  --store-dir /protected/workflow-store \
  --allow-state-change \
  --json < attempt-bundle.json
```

The bundle is exact and small:

```json
{
  "lease_id": "sha256:...",
  "executor_id": "executor.lifecycle-transition.v1",
  "attempt_key": "caller-generated-idempotency-key"
}
```

Registration revalidates the stored F121 lease, its issuer seal, active expiry, exact executor, and plan digest. `executor_outcomes.sqlite3` then enforces one attempt per lease plus unique attempt/idempotency identities in a `BEGIN IMMEDIATE` transaction.

The first successful registration may return `executor_handoff_claimed=true`. Idempotent recovery returns the same attempt receipt but never claims a second handoff. A changed attempt key for an already-registered lease is a conflict.

## Record one terminal executor observation

After the adapter obtains a terminal observation, report it separately:

```bash
plw action-outcome record \
  --store-dir /protected/workflow-store \
  --allow-state-change \
  --json < outcome-bundle.json
```

The terminal status is exactly one of:

```text
SUCCEEDED
FAILED
INDETERMINATE
```

The bundle carries the lease/attempt/executor identity, an observation kind, the raw bounded observation used only for digest verification, and optional content-addressed evidence ids. The durable receipt stores the observation digest rather than raw observation content.

Terminal reporting is idempotent for the exact same request. A conflicting second terminal report is rejected. An outcome may be recorded after the lease expires because lease expiry gates **start**, not completion/reporting of an attempt that was already registered while active.

## Interpret terminal status conservatively

`SUCCEEDED` means the bound executor reported terminal success. It does not by itself prove the intended postcondition or settle a higher-level claim.

`FAILED` means the bound executor reported terminal failure. It does not prove that no partial side effect happened.

`INDETERMINATE` is a first-class result for crash/reconciliation cases where the executor cannot establish a trustworthy terminal fact.

For all three:

```text
executor terminal report
  != postcondition proof
  != stable promotion
  != truth commit
```

Use the normal runtime/source proof machinery when the task requires stronger claims.

## Inspect without changing authority

```bash
plw action-outcome status sha256:<lease-id> \
  --store-dir /protected/workflow-store \
  --json
```

Inspection is read-only. It never claims the executor handoff and never manufactures a terminal result. `EXECUTOR_ATTEMPT_UNRESOLVED` is a valid proof state that requires reconciliation rather than retry-by-assumption.

## Reference-machine boundary

F122 deliberately defines a small universal ledger instead of embedding action-specific executor logic. Concrete runtime, patch, lifecycle, deployment, or repository adapters may use the same attempt/outcome contract while preserving their own domain evidence.

The portable reference machine therefore provides the coordinates and invariants for an executor without constraining every executor to one implementation.
