# Executor Adapter Reconciliation Workflow — F123

**Load when:** an F122 attempt is registered and a concrete executor adapter must prepare a dispatch, report an adapter observation, or reconcile an ambiguous crash window.

**Provides:** the F123 adapter protocol, durable dispatch-intent barrier, adapter/attempt/plan binding, reconciliation rules, and the boundary between adapter evidence, F122 terminal status, postcondition proof, and truth.

**Return to:** [PLW / HoTT Kernel agent router](../SKILL.md).

**Related modules — load only when needed:**
- [Atomic execution lease workflow](atomic-execution-lease-workflow.md) — when F121 lease binding or expiry semantics need review.
- [Lease-bound executor outcome workflow](lease-bound-executor-outcome-workflow.md) — when F122 attempt/terminal binding needs review.
- [Context and proof workflow](context-and-proof-workflow.md) — when a terminal report must be checked against behavioral or postcondition proof.

> F123 connects concrete host adapters to F122. It does not bundle a universal executor, retry ambiguous external effects, or claim generic exactly-once execution.

## 1. State model

```text
F121 LEASED
  -> F122 ATTEMPT_REGISTERED
  -> F123 DISPATCH_PREPARED
  -> host adapter invocation
  -> adapter observation
       | terminal: SUCCEEDED / FAILED / INDETERMINATE
       | nonterminal: PENDING / NOT_FOUND / UNKNOWN
  -> terminal observations may be forwarded to F122
```

`DISPATCH_PREPARED` is a durable intent only. It proves neither that the host call began nor that an external effect occurred.

The first dispatch preparation requires the F121 lease to remain active. Once a dispatch may have happened, lease expiry must not be used to infer absence of effects; later work is reconciliation only.

## 2. Concrete adapter contract

Host integrations implement `core.capability_executor_adapter.ExecutorAdapter`:

```python
adapter_id: str
executor_id: str

def dispatch(context): ...
def reconcile(context): ...
```

The context contains only exact binding/reference fields such as lease, attempt, dispatch, operation key, executor, adapter, and plan digest. The adapter remains responsible for resolving its domain-specific plan and evidence.

F123 deliberately does not require one execution technology. Runtime processes, patch engines, repository workers, deploy APIs, browser/UI capture, and other executors may implement the same contract.

## 3. Public reference-machine operations

Prepare one dispatch intent:

```bash
plw action-adapter prepare --store-dir <trust-store> --allow-state-change --json <<'JSON'
{
  "lease_id": "sha256:<lease>",
  "attempt_id": "sha256:<attempt>",
  "executor_id": "executor.id",
  "adapter_id": "adapter.id",
  "operation_key": "stable-operation-key-0001"
}
JSON
```

Record an observation returned by a concrete adapter:

```bash
plw action-adapter observe --store-dir <trust-store> --allow-state-change --json <<'JSON'
{
  "dispatch_receipt": {"...": "exact F123 dispatch receipt"},
  "dispatch_state": "ACKNOWLEDGED",
  "terminal_status": "SUCCEEDED",
  "observation_kind": "adapter_result",
  "observation": {"status_code": 0},
  "evidence_ids": []
}
JSON
```

Inspect read-only:

```bash
plw action-adapter status sha256:<lease> --store-dir <trust-store> --json
```

These CLI operations never invoke an arbitrary executable or shell. Actual adapter invocation is a host/library API and requires literal `allow_external_execution=True`.

## 4. Crash and replay rules

Never blindly call `dispatch()` again after recovering an already-prepared dispatch. The machine cannot know whether the prior process crashed before or after the external call.

```text
prepared -> crash before call       = unresolved
call -> crash before observation    = unresolved
adapter timeout/exception           = unresolved
PENDING / NOT_FOUND / UNKNOWN       = unresolved
```

Use `reconcile_executor_adapter()` when the adapter has a status-query mechanism. `NOT_FOUND` does not generically prove that no side effect happened.

An operation key makes local dispatch intent idempotent; it does not magically make the external provider exactly-once.

## 5. Observation and terminal forwarding

F123 stores only bounded/content-addressed observation evidence, not arbitrary raw adapter payload in its durable receipt.

A terminal adapter observation may be forwarded into the existing F122 outcome ledger:

```text
adapter SUCCEEDED     -> F122 SUCCEEDED
adapter FAILED        -> F122 FAILED
adapter INDETERMINATE -> F122 INDETERMINATE
```

But the meanings remain narrow:

```text
SUCCEEDED     != postcondition proven
FAILED        != no partial side effect proven
INDETERMINATE = terminal uncertainty explicitly preserved
```

A nonterminal reconciliation (`PENDING`, `NOT_FOUND`, `UNKNOWN`) does not manufacture an F122 terminal result. A terminal reconciliation uses the explicit `RESOLVED` state, and the durable store permits at most one terminal adapter observation per dispatch even if competing terminal reports race before F122 forwarding completes.

## 6. Authority boundaries

F123 has three distinct effects:

```text
prepare dispatch intent      = local durable bridge state
invoke concrete adapter      = host external effect, explicit only
record/reconcile observation = evidence bookkeeping, may forward F122 status
```

None of them by themselves authorize stable promotion or truth commit.

For proof of intended behavior or postconditions after a terminal executor report, load [Context and proof workflow](context-and-proof-workflow.md).

For the lease boundary, load [Atomic execution lease workflow](atomic-execution-lease-workflow.md).

For the attempt/outcome ledger, load [Lease-bound executor outcome workflow](lease-bound-executor-outcome-workflow.md).
