# F86–F105 Historical Simplification Decisions

**Load when:** replaying historical experiments, validating old manifests, or investigating why a current invariant exists.

**Provides:** the bounded rationale and evidence trail behind the retired rule3 and the current simplification hold.

**Return to:** [current capability workflow governance](../capability-governance-workflow.md) or the [SKILL.md routing map](../../SKILL.md#9-skill-module-routing-map).

**Related modules — load only when needed:** none by default. Historical evidence must not fan out into normal-session instructions.

> Historical evidence is not current execution authority.

### F86 Stable Rebase + Experimental Reattach

Gunakan F85 sebagai stable baseline. Self-host/simplification adalah overlay dormant-by-default. Jalur normal tidak mengaktifkan Python atau metadata ownership eksperimen; self-host hanya aktif secara eksplisit (`include_tool_source=True`) dan `plw simplify` memakai jalur tersebut. Jalankan `fixture_check.py` untuk proof lane stable dan `experimental_fixture_check.py` untuk proof lane overlay.

### F87 Intra-Function Frontier

When self-hosting on F87+, inspect `execution_lane` before acting on a candidate.
`experimental_overlay` may be tested locally; `stable_lane_shadow` must be deferred
to selective promotion. For `terminal_temporary_inline`, the witness only proves
adjacent local assignment/return shape. It does not prove debug/trace line-event
identity. Track detector/reference-machine growth separately from target LOC gain.

### F88 Rule Engine Compression

F88 is behavior-preserving compression of the experimental reference machine.
Do not interpret it as a new simplification rule. Candidate construction must go
through the canonical envelope, recommendation authority stays bounded, and detector
metrics come from the shared registry. When extending the analyzer after F88,
measure both target simplification gain and reference-machine LOC/cognitive cost;
do not reintroduce bespoke candidate envelopes unless a proof contract truly needs
new fields.

### F89 Stable-Shadow Promotion

F89 clears the shadow queue only through an explicit promotion checkpoint. After
F89, `defer_stable_lane_requires_selective_promotion` should have count zero. Do
not interpret that as total debt zero: the remaining queue is intentionally
architectural/API/high-proof/no-positive-gain debt. The next action should be debt
adjudication, not another automatic refactor pass.



### F90 architectural debt adjudication
Jangan memperlakukan remaining `plw simplify` debt sebagai queue patch. Baca `adjudication` pada candidate.
`KEEP` berarti abstraction saat ini lebih mahal/tidak punya positive net gain, bukan bahwa debt tidak relevan.
`DEFER` memerlukan proof surface/owner yang lebih bounded. `NEUTRAL_OWNER_CANDIDATE` memerlukan owner proof terpisah.
`API_PROOF_CANDIDATE` tidak boleh dihapus sebelum caller/compatibility contract terbukti.
Manifest current: `experiments/f90_architectural_debt_adjudication.json`.

### F93 simplification hold
Current default is `SIMPLIFICATION_HOLD_REACHED`. Jangan membuka detector/simplification patch baru hanya karena remaining candidate count > 0.
Resume hanya ketika salah satu `resume_condition` di `experiments/f93_post_promotion_stop_decision.json` benar-benar terpenuhi. Untuk kerja berikutnya, prefer external-target validation agar reusable value reference machine dapat diukur di luar self-host PLW.

### F94 external generalization probe
External probe harus memakai bahasa yang memang didukung simplification analyzer. Jangan menghitung `0 candidate` pada Angular/TypeScript sebagai evidence kebersihan selama analyzer masih Python-AST-only. Current F94 evidence: representative Python slice dari `Mutant-lab-agent` menghasilkan recognition reuse tetapi 0 realized local-safe gain; maka `STOP_NEW_DETECTOR_CAPABILITY` dan F93 HOLD tetap aktif. Probe source disimpan sebagai `.py.txt` agar reproduktif tanpa ikut self-host scan.

### F97 Development Rule
Treat F97 as development overlay on F85 stable. `getScannerScript` has bounded sandbox behavioral proof but is not patched in the external repository. The second TS/JS rule must continue to consume the F96 lexical substrate; do not add another filesystem scan, masking engine, or lexer for each rule. Economics status is `REUSE_PROVEN_BUT_NOT_AMORTIZED`, not ROI/break-even.


### F98 Yield Rule
Untuk economics frontend, bedakan **reuse capability** dari **real yield**. F98 memakai 20/20 Git-blob-exact TypeScript sources (812 LOC) tanpa mengubah analyzer: rule1 menghasilkan satu proven 1-LOC candidate, rule2 nol candidate. Jangan menambah rule3 hanya karena marginal implementation rule2 lebih murah; minta generalization yield pada corpus independen terlebih dahulu. Snapshot corpus harus disimpan sebagai `.ts.txt` agar target evidence tidak mengkontaminasi self-host debt.


### F99 Generalization Rule
When frontend economics are uncertain, test unchanged rules on an independent corpus selected before candidate measurement. F99 uses 12/12 Git-blob-exact files from official `angular/angular` (755 LOC) and finds zero candidates for both existing rules. Combined F98+F99 yield is 1 candidate / 1,567 LOC. Treat this as evidence to freeze rule expansion, not proof that the rules are universally useless. No new rule/lexer/scanner is justified until either a materially larger independent yield appears or the existing +340 LOC frontend cost is compressed.


### F100 Large-Corpus Authority Rule
A remote source audit must not be mislabeled as local analyzer execution. F100 pins eight direct production TypeScript blobs from `bitwarden/clients` and applies the exact F99 lexical predicates through connector-backed content inspection, while leaving `core/simplification_analyzer.py` byte-identical. Record pinned blob identity, selection scope, and audit authority. Zero candidates strengthen the freeze-expansion decision but are corpus evidence only. Do not add rule3. Next target is F101 frontend cost compression.

### F101 Frontend Cost Compression Rule
Dua rule TS/JS harus berbagi satu prepared non-code mask per canonical SharedGraph source. Jangan mengembalikan pola satu masking pass per rule. F101 mengurangi analyzer 1525→1448 LOC (-77) dan mask work F98 40→20 pass tanpa menambah rule/scanner atau mengubah candidate semantics. Treat compressed frontend as **reuse-only/frozen**: rule3 tetap tertutup sampai explicit F102 reopen condition terbukti. Compression bukan proof bahwa detector benar secara universal dan bukan alasan memutasi target eksternal.



### F102 Frontend Freeze / Reopen Rule
Rule3 tidak boleh dibuat hanya karena ada ide pattern baru. Pertama penuhi shadow-prototype gate di `experiments/f102_frontend_freeze_reopen_contract.json`: pre-implementation dossier, >=2 independent repositories, >=4 verified occurrences total dengan >=2 per repo, reuse primitive frontend F101, no new lexer/scanner, no second mask pass, dan estimated marginal implementation <=77 LOC F101 compression credit. Ini anti-one-off policy, bukan statistical significance. Setelah prototype pun acceptance terpisah dan harus memenuhi proof compatibility + incremental break-even. Acceptance tidak pernah otomatis mengotorisasi external mutation atau stable promotion.


### F103 Rule3 Dossier Rule
F103 membuka shadow-prototype gate tetapi belum mengimplementasikan rule3. Proposal yang diizinkan untuk F104 adalah `js_terminal_const_expression_passthrough`, dengan evidence 2 repo independen / 4 occurrence / minimum 2 per repo dan estimated runtime upper bound 54 LOC <= 77 LOC compression credit. Tetap gunakan one SharedGraph snapshot + one `_mask_js_noncode`; jangan menambah lexer/scanner atau mask pass kedua. Explicit type annotations, comments antara assignment-return, function/class/arrow/object/array literals, destructuring, dan multi-declarator harus ditolak pada prototype awal. Prototype gate tidak sama dengan acceptance: actual marginal machine cost dan proven rediscovery/gain harus diukur di F104 sebelum economics gate dapat dinilai.

### F104 Rule3 Shadow Prototype / Cost Rule
F104 mengimplementasikan `js_terminal_const_expression_passthrough` hanya sebagai **shadow prototype**, bukan accepted rule. Prototype memakai SharedGraph snapshot + single `_mask_js_noncode` pass yang sama; tidak boleh menambah lexer/scanner, mask pass kedua, atau runtime module baru. Measured marginal analyzer cost = +73 LOC terhadap F103 (1448→1521), masih <= 77 LOC prototype budget F102, dan 4/4 pre-implementation dossier occurrences ditemukan ulang. Namun acceptance economics gagal: proven target gain 4 LOC < effective machine cost 73 LOC. Karena itu recommendation harus tetap `shadow_rule3_requires_acceptance_economics_and_target_proof`; external mutation dan stable promotion tetap tidak berizin. F105 harus memilih recovery economics (yield tambahan preselected atau compression) atau retire shadow, bukan memperluas rule3.

### F105 Rule3 Retirement Rule
F105 proves that a technically correct shadow capability may still be removed. The rule3 implementation was compressed from +73 to +36 LOC while preserving 4/4 dossier occurrences, old-rule projections, and one mask/file, but proven target gain remained only 4 LOC. Because `4 >= 36` is false, the shadow detector is retired from current runtime while dossier/prototype/compression evidence remains replayable. Retirement removes runtime/context cost; it must not erase historical evidence or imply that the prototype never worked.
