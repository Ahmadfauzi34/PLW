# Evidence-Driven Capability Selection Workflow

**Load when:** F138.4 returned `EVIDENCE_NEEDS_DERIVED` and the agent needs to know which PLW capabilities can add information for those explicit evidence classes.

**Provides:** read-only `capability_selection`: per-need candidates, expected information gain, coverage role, exact skill path, and uncovered needs. Matching uses machine-readable `evidence_class`, not task keywords.

Use `plw capability-match "<task>" <root> --target <file> --json` when the stage is needed independently. `plw work` derives the same projection from its single graph snapshot.

Coverage labels are not success claims. `PARTIAL_STATIC` and `PREPARATORY` do not satisfy a runtime/postcondition need. `BINDS_EXTERNAL_OBSERVATION` requires an observation produced elsewhere. If PLW cannot directly cover a need, keep it in `uncovered_needs`; never force a command merely to produce a recommendation.

`candidate_capabilities` are information sources for agent reasoning, not actions. The agent must inspect the candidate's `expected_information_gain`, `does_not_prove`, `state_change`, and `skill_path` before choosing any call.

**Return to:** `SKILL.md` after candidate projection; read the exact candidate skill only if the agent decides that capability is justified.

**Related modules — load only when needed:** [Evidence-need derivation](evidence-need-derivation-workflow.md), [Semantic affordance](semantic-affordance-workflow.md), [Tool-call and CLI](tool-call-and-cli-workflow.md).
