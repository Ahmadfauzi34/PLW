# Targeted validation scenario planning workflow

**Load when:** F127 has identified affected UI/code surfaces and the agent needs a bounded set of known render/validation scenarios before mutation or external validation.

**Provides:** F128 deterministic scenario selection from the current F125 identity plus a caller-supplied catalog, with explicit variation coverage, omission reasons, and recovery paths.

**Return to:** [root skill router](../SKILL.md).

## Command

```bash
plw validation-plan <snapshot.json> <project-root> \
  --focus <ui-id> --constraints <query.json> \
  --scenario-catalog <catalog.json> --max-scenarios 8 --json
```

All F127 options remain available, including optional read-only F126 `--lease-id/--store-dir` provenance. The command does not render, test, dispatch a runtime, or mutate source.

## Catalog contract

```json
{
  "schema_version": "validation-scenario-catalog-v1",
  "scenarios": [
    {
      "scenario": {
        "code_revision": "rev",
        "route": "/login",
        "viewport": [390, 844],
        "ui_state": "modal-open",
        "data_fixture": "anonymous"
      },
      "coverage": {
        "ui_ids": ["login.submit"],
        "component_files": ["src/app/login.component.ts"]
      }
    }
  ]
}
```

Catalog coverage is caller-declared planning metadata. It is not runtime presence proof. F128 never invents a missing mobile/desktop/state/data scenario.

## Selection

The exact current F125 scenario is the anchor. Other candidates are eligible only when they use the same code revision and have explicit target coverage or are a known same-route variation. Selection is bounded by `--max-scenarios` (1–64), deterministic, and reports variation coverage for viewport, UI state, and data fixture.

Every omitted candidate keeps a reason and recovery instruction. `omitted != irrelevant`; stale revision candidates remain visible but are not selected.

## Proof boundary

```text
validation plan             != validation result
selected scenario           != rendered-surface proof
catalog coverage            != runtime presence proof
same-route variation        != impacted-surface proof
omitted scenario            != irrelevant scenario
F128                        != runtime/mutation/truth authority
```

**Related modules — load only when needed:**

- For F127 geometric evidence and UI→topology projection, load [Targeted geometric impact projection workflow](geometric-impact-projection-workflow.md).
- For runtime capture provenance, load [Runtime geometry capture provenance workflow](runtime-geometry-capture-workflow.md).
- After an external validator returns evidence, bind it with [Scenario-bound validation evidence workflow](scenario-validation-evidence-workflow.md) before settling behavior/postconditions.
