# Angular semantic ownership workflow

**Load when:** an agent must map an Angular selector/template/binding to its source owner before UI/runtime/geometry work.

**Provides:** F124 static ownership anchors over the canonical SharedGraph snapshot.

**Return to:** [root skill router](../SKILL.md).

## Contract

Use `plw angular-anchors <root> --json` or narrow with `--file` / `--selector`.
The analyzer reuses `core.shared_graph` source bytes and may read only exact
`templateUrl` / `styleUrl(s)` resources declared by a proven Angular component.
It never scans HTML/CSS directories and refuses resource reads outside the scan
root.

Authority classes:

```text
EXACT       exact source/resource bytes observed (resource digest, decorator import)
STRUCTURAL  relation follows from @angular/core import + @Component/class metadata
UNRESOLVED  dynamic expression, unavailable resource, or unsupported static form
```

F124 emits no `INFERRED` ownership anchor. An unresolved anchor is not irrelevant.

Useful ownership surfaces:

```text
@Component owner
  -> selector
  -> template | templateUrl
  -> styleUrl | styleUrls | styles
  -> component imports
  -> @Input/@Output and input()/output()/model()
  -> lifecycle hooks
  -> host/template binding -> class-member witness
```

External template/style content is content-addressed in the result; raw resource
text is not returned. `--no-resources` keeps only declaration ownership and does
not read those resources.

## Proof boundary

```text
static selector ownership
  != rendered DOM identity
static template ownership
  != geometry
binding witness
  != behavior/postcondition proof
resource digest
  != runtime freshness
```

F124 is read-only: no source mutation, runtime/browser execution, repository
mutation, workflow authority, stable promotion, or truth commit.

**Related modules — load only when needed:**

- For scenario geometry and UI↔code mapping after static ownership is established, load [Geometry and correspondence workflow](geometry-correspondence-workflow.md).
- If source/claim completeness is unclear, load [context and proof workflow](context-and-proof-workflow.md).
- For code changes after ownership is established, load [code-change and session workflow](code-change-and-session-workflow.md).
- For command/tool-call mechanics, load [tool-call and CLI workflow](tool-call-and-cli-workflow.md).
