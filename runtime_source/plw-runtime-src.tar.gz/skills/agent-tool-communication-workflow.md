# Agent–Tool Communication Contract

**Load when:** `work.agent_decision_frame` is present, a `skill_handoff` must be interpreted, or legacy `work_status=ready` could be confused with readiness to edit/execute.

**Provides:** the F139.1 decision-frame contract: orchestration status, target/evidence state, capability projection without action ranking, action readiness, task-postcondition status, proof scope, READ-vs-CALL handoff semantics, repeat guards, and inline delivery of the critical skill contract.

**Return to:** `SKILL.md` after the next agent decision is clear; load the candidate capability skill only if the agent actually chooses that information source.

## Read this first

`work_status` is retained for compatibility and describes the **reference pack**, not permission to act. Use:

```text
agent_decision_frame.orchestration_status
agent_decision_frame.action_readiness
agent_decision_frame.task_postcondition_status
```

A `proof_gate` that is satisfied for current-source/reference claims does not prove the user's requested task postcondition.

## Handoff types

```text
READ_SKILL_ONLY
```

means the named orchestration stage has already run inside `work`. Do not call it again merely because `skill_handoff.capability` names that stage. Observe `stage_completed`, `do_not_repeat_stage`, and `repeat_condition`.

```text
CALL_CAPABILITY_AFTER_READ
```

means the capability has not been executed by the orchestrator; the agent may consider calling it only after reading the contract and deciding its information gain is justified.

## Inline skill delivery

When an exact skill handoff exists, F139.1 attaches:

```text
inline_contract.delivery_status = INLINE_CRITICAL_CONTRACT_ATTACHED
load_when
provides
return_to
critical_rules
```

This prevents the critical semantic contract from disappearing merely because the model skipped a filesystem Markdown read. The full skill remains available for detailed workflow rules.

## Capability ranking boundary

Compact `work` output intentionally omits `aggregate_score`. Candidate order reflects coverage/information role only:

```text
ranking_is_not_recommendation = true
action_priority_computed = false
```

`PREPARATORY`, `PARTIAL_STATIC`, or `BINDS_EXTERNAL_OBSERVATION` are evidence roles, not action recommendations or success claims.

## Stop conditions

If target state is `AMBIGUOUS` or `UNRESOLVED`, `action_readiness=NOT_READY`; gather target evidence before repeating resolution or selecting a specialized capability.

If a task requests a postcondition and it has not been observed/proven, `task_postcondition_status=UNPROVEN` even when the bounded reference pack itself is ready.

**Related modules — load only when needed:** [Adaptive agent workflow](adaptive-agent-workflow.md), [Target resolution](target-resolution-workflow.md), [Evidence-need derivation](evidence-need-derivation-workflow.md), [Evidence-driven capability selection](evidence-driven-capability-selection-workflow.md), [Semantic affordance](semantic-affordance-workflow.md).
