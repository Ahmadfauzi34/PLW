# Target Resolution & Structural Relevance

**Load when:** topology is available but the user task is not yet grounded to one or more exact graph nodes, or `skill_handoff.capability=resolve-target`.

**Provides:** bounded task-seeded candidate ranking plus graph evidence: exact/explicit target identity, file/path/content hints, direct imports/importers, fan-in/out, affected entrypoints, and statically reachable tests. Task similarity is retrieval evidence only; it never proves semantic ownership.

Use:

```bash
plw resolve-target "<task>" <root> --json
plw resolve-target "<task>" <root> --target src/exact/file.ts --json
```

Interpret resolution states:

- `RESOLVED`: one structurally supported target is sufficiently separated.
- `MULTI_TARGET_RESOLVED`: caller explicitly grounded more than one exact target.
- `AMBIGUOUS`: inspect candidate evidence or supply an explicit target; do not guess.
- `UNRESOLVED`: widen source/path/symbol evidence; do not choose a specialized capability from task wording alone.

Authority boundary:

```text
task text -> retrieval seed
candidate + graph neighborhood -> structural relevance evidence
structural relevance != semantic ownership
structural relevance != behavioral correctness
structural relevance != capability necessity
```

A resolved target is input to evidence-gap derivation; it is not permission to edit, execute, or commit truth.

**Return to:** `SKILL.md` before any state-changing action. When target resolution is grounded, continue to adaptive work/evidence-gap reasoning.

**Related modules — load only when needed:** [Target topology](target-codebase-topology-workflow.md), [Adaptive work](adaptive-agent-workflow.md), [Semantic affordance](semantic-affordance-workflow.md), [Context/proof](context-and-proof-workflow.md).
