# Geometry snapshot and UI-code correspondence workflow

**Load when:** runtime/UI geometry must be tied back to Angular code owners without merging geometry into SharedGraph.

**Provides:** F125 scenario-identified GeometrySnapshot validation plus evidence-classed UI↔Angular correspondence.

**Return to:** [root skill router](../SKILL.md).

## Contract

Use:

```bash
plw ui-reference <snapshot.json> <project-root> --json
```

The snapshot is supplied by a runtime/browser/adapter outside this analyzer. F125
never launches a browser or interprets a screenshot. It validates bounded geometry
and combines it with the current F124 Angular ownership sidecar in one read-only
reference query.

Required scenario identity:

```text
code_revision + route + viewport + ui_state + data_fixture
```

Bind the runtime capture to the current static state with:

```text
static_context.graph_content_signature
static_context.angular_ownership_digest
```

If either is missing or stale, geometry remains usable but final correspondence is
`UNRESOLVED`.

Runtime nodes may provide explicit owner evidence:

```text
owner.component_id       -> EXACT relation when the F124 component exists
owner.component_selector -> STRUCTURAL relation only when selector ownership is unique
```

No tag-name, CSS-class, filename, text, or naming-similarity fallback is used.


## Practical UI mapper

For agent-first UI work, prefer the derived mapper instead of reading raw geometry by hand:

```bash
plw ui map <snapshot.json> <project-root> --json
plw ui inspect <snapshot.json> <ui-id> <project-root> --json
```

`ui map` keeps GeometrySnapshot and Correspondence as the canonical authorities, but adds a bounded agent-facing view containing:

```text
parent/child hierarchy
bbox + z-index + visibility
automatic non-ancestor overlap detection
viewport overflow
parent-boundary extension candidates
optional interactive minimum-gap warnings
component/template/style owner mapping
```

It deliberately ignores ordinary ancestor↔descendant box overlap, because containment is expected in normal DOM layout. Overlap between independent/sibling rendered surfaces is reported with exact intersection area/ratios and a z-index front hint when available.

To avoid making every agent write its own DOM scraper, generate a read-only browser expression:

```bash
plw ui capture-script <project-root> --revision <REV> --state <UI_STATE> --fixture <DATA_FIXTURE>
```

Evaluate the emitted JavaScript in the target page (for example through a Playwright/browser adapter) and save the returned object as JSON. The expression captures DOM hierarchy, bounding boxes, visibility, z-index, opacity, affine transform, DOM path, viewport, route, and the nearest custom-element selector. It embeds the current `graph_content_signature` and `angular_ownership_digest` so the returned snapshot can be freshness-bound to the codebase. The command itself does **not** launch a browser.

For agent tool calls, the same operations are available through the existing public capability without adding another proof command:

```text
surface=plw mode=ui-reference arguments=["map", ...]
surface=plw mode=ui-reference arguments=["inspect", ...]
surface=plw mode=ui-reference arguments=["capture-script", ...]
```


## Scenario + responsive mapping (UI Mapper V2)

When two or more GeometrySnapshots belong to the **same code revision**, map them together instead of reasoning about each layout independently:

```bash
plw ui scenarios mobile.json desktop.json modal-open.json --root <project-root> --json
```

The derived `ui-scenario-map-v2` exposes observed scenario axes (`route × viewport × ui_state × data_fixture`), conditional elements, owner consensus, responsive groups, normalized geometry variation, and issue patterns that are persistent versus scenario-specific. Stable `data-plw-ui-id`, DOM `id`, or `data-testid` anchors are marked separately from structural DOM-path identities.

This is **same-revision responsive mapping**, not regression classification. A large geometry shift between mobile and desktop can be legitimate. Cross-revision comparison is rejected here and belongs to the later geometry-diff layer. Coverage is observed-only unless an external scenario catalog defines expected combinations.

For agent calls:

```text
surface=plw mode=ui-reference arguments=["scenarios", "mobile.json", "desktop.json", "--root", "...", "--json"]
```

## Proof classes

```text
EXACT       explicit component_id matches the current bound F124 state
STRUCTURAL  explicit selector maps uniquely in the current bound F124 state
UNRESOLVED  stale/missing static binding, ambiguous/missing owner, or conflicting claim
```

F125 emits no `INFERRED` correspondence and grants no mutation authority.

## Geometry boundary

A validated payload proves only that its values satisfy the snapshot schema. It
does not prove that the capture process was truthful or fresh unless separate
runtime provenance does so. Elements may legitimately extend outside the viewport;
F125 records intersection/containment facts rather than treating them as failures.

```text
payload validated         != runtime attested
rendered                   != geometrically correct
static owner               != runtime instance
correspondence             != behavior/postcondition proof
correspondence             != mutation authority
```

Raw DOM text and raw `dom_path` are not retained; a supplied DOM path is reduced to
a digest. Geometry, Angular ownership, and correspondence remain separate
canonical authorities inside the returned reference state.

**Related modules — load only when needed:**

- To evaluate explicit overlap/containment/spacing constraints or project selected UI surfaces to topology, load [Targeted geometric impact projection workflow](geometric-impact-projection-workflow.md).

- Establish static Angular anchors first with [Angular semantic ownership workflow](angular-semantic-ownership-workflow.md).
- To bind this snapshot to a verified F123 capture receipt, load [Runtime geometry capture provenance workflow](runtime-geometry-capture-workflow.md).
- For generic runtime execution/adapter reconciliation, load [Executor adapter reconciliation workflow](executor-adapter-reconciliation-workflow.md).
- For code mutation after proof is sufficient, load [Code-change and session workflow](code-change-and-session-workflow.md).

## Cross-revision Geometry Diff (UI Mapper V3)

Use V3 only when baseline and candidate represent the **same exact rendered scenario** apart from `code_revision`:

```bash
plw ui diff baseline.json candidate.json --root <candidate-root> --min-gap 8 --json
```

If the baseline source tree is still available, add `--baseline-root <baseline-root>` to recover baseline code ownership as well. V3 reports geometry change facts such as `MOVED`, `RESIZED`, `APPEARED`, `DISAPPEARED`, `Z_ORDER_CHANGED`, newly introduced overlap/viewport/spacing/parent-boundary issues, and resolved layout issues.

Do **not** compare different routes, viewports, UI states, or data fixtures. Those differences belong to V2 scenario mapping. V3 intentionally does not declare every geometry change a bug or regression; it produces evidence for the later UI Bug Hunter.

Agent surface remains the existing capability:

```text
surface=plw mode=ui-reference arguments=["diff", "baseline.json", "candidate.json", "--root", "...", "--json"]
```

## UI Bug Hunter V1

Use Bug Hunter only after a candidate GeometrySnapshot exists. A baseline is optional but strongly improves the evidence class:

```bash
plw ui hunt candidate.json --root <candidate-root> --min-gap 8 --json

plw ui hunt candidate.json \
  --baseline baseline.json \
  --root <candidate-root> \
  --baseline-root <baseline-root> \
  --min-gap 8 \
  --json
```

When a verified `runtime-ui-reference` JSON is available, add `--runtime-reference <file>` so the hunter can distinguish a merely observed candidate from one reproduced under adapter-bound runtime capture provenance.

Lifecycle is evidence-graded and intentionally stops before proof:

```text
DISCOVERED   geometry issue exists in candidate snapshot
SUPPORTED    exact-scenario baseline shows the issue was introduced
REPRODUCED   candidate snapshot is bound to EXACT runtime capture provenance
BOUND        REPRODUCED + all affected UI nodes have EXACT/STRUCTURAL code ownership
PROVEN       unavailable in V1
```

Movement/resize/z-order change alone is emitted as a `risk_signal`, not as a bug. Bug candidates include overlap/occlusion, viewport escape, containment risk, interaction spacing, UI-tree integrity issues, and cross-revision disappearance/visibility loss of interactive elements.

For agent calls:

```text
surface=plw mode=ui-reference arguments=["hunt", "candidate.json", "--baseline", "baseline.json", "--root", "...", "--json"]
```

Proof boundary:

```text
DISCOVERED != bug proven
SUPPORTED  != bug proven
REPRODUCED != postcondition proven
BOUND      != postcondition proven
geometry change alone != bug
```


## Cross-Domain UI Diagnosis + Targeted Reproduction

After `plw ui hunt` has produced bug candidates, use diagnosis when the agent needs to know **where to inspect next** rather than merely whether geometry is suspicious:

```bash
plw ui diagnose candidate.json \
  --baseline baseline.json \
  --root <candidate-root> \
  --runtime-reference runtime-ui-reference.json \
  --json
```

The diagnosis reuses the current SharedGraph and F127 UI→topology projection. It adds bounded component impact, declared template/style owners, direct dependency/consumer context, structural cause candidates, and an exact-scenario reproduction plan. Filename/service-role heuristics only rank **structural candidates**; they are never causal proof.

For agent calls:

```text
surface=plw mode=ui-reference arguments=["diagnose", "candidate.json", "--baseline", "baseline.json", "--root", "...", "--json"]
```

Boundary:

```text
topology proximity != root cause
structural candidate != causal owner
reproduction plan != browser execution
BOUND bug candidate != postcondition proof
```


## Targeted runtime reproduction

After `plw ui diagnose` has produced an exact-scenario reproduction plan, PLW can explicitly execute one Chromium/Chrome runtime and recapture geometry:

```bash
plw ui reproduce diagnosis.json \
  --root <candidate-root> \
  --url http://localhost:4200 \
  --candidate-id <candidate-id> \
  --setup-js setup.js \
  --out observed.json \
  --json
```

For a bounded local/static reproduction without application navigation, use `--html-file rendered.html`. That mode is labeled `INJECTED_DOCUMENT`; it is **not** equivalent to navigating the real application route. `--url` is the normal dev-server/application path when the environment permits navigation.

The runner launches Chromium through CDP, applies the diagnosed viewport, optional state-setup JavaScript, evaluates PLW's existing geometry capture expression, and compares the fresh snapshot with the candidate's expected symptom. Results are `REPRODUCED`, `NOT_REPRODUCED`, or `UNRESOLVED`. Layout/template/render owners may become `RUNTIME_BOUND_OWNER` when the symptom is reproduced, while topology/state-service candidates remain `STRUCTURAL_ONLY` until separate causal evidence exists.

Agent calls require explicit external-execution acknowledgement:

```text
surface=plw
mode=ui-reference
arguments=["reproduce", "diagnosis.json", "--root", "...", "--url", "...", "--json"]
allow_external_execution=true
```

Without literal `allow_external_execution=true`, the agent surface rejects the call before a browser is launched. This acknowledgement does not authorize source mutation or truth commit.

Boundary:

```text
REPRODUCED != root cause proven
RUNTIME_BOUND_OWNER != causal owner
INJECTED_DOCUMENT != real application navigation
external browser execution != source mutation
```

## Counterfactual causal isolation (UI Root-Cause Probe V1)

After an exact symptom has been reproduced, PLW can generate a bounded probe skeleton from the structural candidates already produced by `diagnose`:

```bash
plw ui probe-plan diagnosis.json --candidate-id <id> --out probes.json --json
```

`probe-plan` is read-only. Each probe must then be filled with one narrow browser-side `intervention.javascript` that changes only the suspected candidate mechanism. Examples include a narrowly scoped CSS override for a style owner or an application test hook that toggles one state/service outcome. The plan itself does not authorize execution and never mutates repository source.

Execute the probes against the **same exact scenario**:

```bash
plw ui isolate diagnosis.json probes.json \
  --root <candidate-root> \
  --url http://localhost:4200 \
  --candidate-id <id> \
  --json
```

For bounded local HTML, `--html-file` is also supported. The exact diagnosed symptom must first reproduce. Each intervention is then run in a fresh Chromium session and classified as:

```text
SYMPTOM_SENSITIVE  -> COUNTERFACTUAL_SUPPORT
SYMPTOM_PERSISTS   -> NO_SUPPORT
runtime unresolved -> INCONCLUSIVE
```

An intervention that is not bound to one of the diagnosis structural candidates is reported as `UNBOUND_COUNTERFACTUAL_SIGNAL`, even if it removes the symptom. This prevents arbitrary DOM manipulation from being promoted into candidate-specific causal evidence.

Agent calls that execute isolation require literal external execution acknowledgement:

```text
surface=plw
mode=ui-reference
arguments=["isolate", "diagnosis.json", "probes.json", "--root", "...", "--url", "...", "--json"]
allow_external_execution=true
```

Hard boundary:

```text
COUNTERFACTUAL_SUPPORT != unique root cause
symptom sensitivity != causal sufficiency
structural proximity != causality
counterfactual probe != postcondition proof
counterfactual probe != source mutation
```

Use the result to **rank which candidate deserves deeper inspection or a bounded fix proposal**, not to claim that the candidate is the only cause.


## Bounded fix proposal + exact-scenario post-fix verification

Only after causal isolation reports candidate-bound `COUNTERFACTUAL_SUPPORT`, build a bounded fix plan:

```bash
plw ui fix-plan diagnosis.json isolation.json --out fix-plan.json --json
```

The plan is read-only. It names the supported structural path, role, exact scenario, affected UI IDs, and a narrow change contract; it does **not** write or generate a repository patch. Candidates with only `NO_SUPPORT`, unbound intervention signals, or unresolved baseline reproduction are excluded.

After an agent/user applies the smallest justified source change externally, recapture the same scenario:

```bash
plw ui verify-fix diagnosis.json fix-plan.json \
  --root <post-fix-root> --url http://localhost:4200 --json
```

`--html-file` remains available for bounded injected-document verification. A successful V1 result requires: the original symptom is `NOT_REPRODUCED`, affected UI nodes still exist and remain visible, and no new `CRITICAL` mapped issue involves those nodes. Therefore hiding/deleting the affected button does not count as a successful fix.

States:

```text
FIX_VERIFIED      symptom cleared + bounded affected-UI integrity preserved
FIX_FAILED        original symptom still reproduces
FIX_SCOPE_UNSAFE  symptom cleared but affected UI was hidden/removed or new critical local issue appeared
FIX_UNRESOLVED    browser/scenario verification could not be established
```

Agent-surface `verify-fix` launches a browser and requires literal `allow_external_execution=true`; `fix-plan` does not.

Boundary:

```text
COUNTERFACTUAL_SUPPORT != complete root-cause proof
FIX_VERIFIED           != full regression proof
exact-scenario clear   != global codebase safety
fix-plan               != mutation authority
PLW fix planning       != source mutation
```
