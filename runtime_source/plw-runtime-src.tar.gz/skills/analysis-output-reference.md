# Analysis Output Reference

**Load when:** interpreting `steer`, `xsteer`, topology, context, cache, memory, fiber, or `xanalyze` JSON.

**Provides:** field-level semantics, proof limits, thresholds, and the safe next action for PLW analysis outputs.

**Return to:** [SKILL.md routing map](../SKILL.md#9-skill-module-routing-map).

**Related modules — load only when needed:** [context and proof workflow](context-and-proof-workflow.md) when an output exposes evidence debt or a blocked claim; [tool-call and CLI workflow](tool-call-and-cli-workflow.md) when interpretation selects another command.

> On-demand lookup reference; open the relevant output family rather than reading end to end.

## Output families

### `steer` / `xsteer`

| Field | Jika Nilai Ini | Maka Lakukan |
|---|---|---|
| `drift_interpretation` | `"none"` | Topologi stabil, lanjutkan |
| `drift_interpretation` | `"medium"/"high"` | Jalankan `establish` dulu |
| `reasoning_strategy` | `component_localized_traversal` | Perubahan terisolasi per komponen |
| `reasoning_strategy` | `conservative_edit` | Setiap perubahan berdampak luas |
| `reasoning_strategy` | `bridge_building` | Cari relation witness; jangan hubungkan hanya untuk menurunkan β₀ |
| `reasoning_budget` | `"low"` | Analisis minimal cukup |
| `reasoning_budget` | `"high"` | Analisis mendalam diperlukan |
| `regrounding_needed` | `true` | Re-scan codebase, pemahaman outdated |
| `consolidation_candidate` | `true` | Jalankan bagian [Memory consolidation](code-change-and-session-workflow.md#memory-consolidation) |

### `memory betti_breakdown`

| Field | Interpretasi | Action |
|---|---|---|
| `beta_0` tinggi | Banyak semantic component | Reason per komponen; bridge hanya dengan relation witness |
| `beta_1_reasoning` > 0 | Undirected reasoning cycle rank | Audit diamond, parallel edge, atau loop; jangan langsung sebut circular reasoning |
| `directed_reasoning_cycle_witness_count` > 0 | Ada path reasoning berarah yang kembali | INVESTIGASI witness path |
| `directed_reasoning_cycle_witnesses` | Saksi node dan edge type | Gunakan sebagai provenance keputusan |
| `directed_reasoning_cycle_witness_semantics` | Witness DFS terdeduplikasi, bukan semua elementary cycle | Jangan tafsirkan count sebagai enumerasi lengkap |
| `beta_1_structural` > 0 | Structural association cycle rank | Sinyal struktur, bukan circular reasoning |
| `beta_1_is_not_directed_cycle_count=true` | Batas interpretasi eksplisit | Jangan menyamakan Betti dengan directed cycle |

### Codebase `hott.manifold` cycles

Codebase Betti memakai model `dependency_multigraph_1_complex`. Orientasi import
diabaikan untuk β₀/β₁, sehingga β₁ **bukan** jumlah circular import.

| Field | Interpretasi | Action |
|---|---|---|
| `topological_model.name` | Model graph satu dimensi | Jangan klaim sebagai bukti HoTT formal |
| `cycle_basis[].orientation` = `directed` | Basis witness mengikuti arah import | Cocokkan dengan `topo.circular` |
| `cycle_basis[].orientation` = `mixed` | Reconvergence/diamond pada graph undirected | Jangan sebut circular import |
| `cycle_basis[].closed_path` | Saksi file/edge untuk β₁ | Gunakan sebagai semantic context LLM |
| `cycle_basis_complete` = `true` | Jumlah witness sama dengan β₁ | Evidence lengkap untuk basis yang dipilih |

### `topo.test_reachability`

| Field | Interpretasi | Action |
|---|---|---|
| `model.not_runtime_coverage` = `true` | Hanya static import topology | Jangan klaim statement/branch coverage |
| `source_test_witnesses` | Path test → source dependency | Pakai untuk memilih test context |
| `testless_components` | Source island tanpa test file | Prioritaskan component-level test |
| `high_influence_without_test_path` | File berpengaruh tanpa test witness | Naikkan kehati-hatian sebelum edit |
| `static_test_reachability_ratio` | Rasio source yang reachable secara statis | Gunakan sebagai sinyal, bukan coverage score |

### `context`

| Field | Interpretasi | Action |
|---|---|---|
| `selection.mode=query_graph` | Seed berasal dari query path/symbol/finding | Periksa confidence dan selection signals |
| `selection.mode=explicit_target_graph` | Target menjadi base projection tunggal | Gunakan untuk pekerjaan pada file yang sudah diketahui |
| `score_components` | `L`, proximity, centrality, finding severity | Audit alasan file dipilih; jangan anggap skor sebagai probabilitas benar |
| `quotient_graph` | `G/P` berdasarkan boundary SharedGraph | Gunakan untuk memahami hubungan modul secara ringkas |
| `graph_content_signature` | Hash seluruh semantic SharedGraph stabil | Context/evidence lama stale jika signature berubah |
| `budget.token_count_is_estimate=true` | Estimasi `ceil(chars/4)` | Jangan samakan dengan tokenizer model tertentu |
| `optimizer_additional_filesystem_scans=0` | Analyzer dan optimizer memakai snapshot sama | Hindari scan/read source berulang yang tidak diperlukan |
| `memory_context.selected_count` | Memory evidence yang benar-benar masuk budget | Perlakukan sebagai observasi dan verifikasi ke source |
| `memory_scope.scope_id` | Identitas project scope runtime | Pastikan tidak berubah/tercampur antar proyek |
| `memory_retrieval.claim_boundary` | Projection lexical/path exact untuk predicate terdeklarasi, bukan semantic relevance proof | Jangan klaim semantic match yang tidak dihitung |
| `memory_retrieval.projection.source_store_loads` | `1` pada cold/changed snapshot, `0` pada exact warm hit | Pastikan satu request tidak membaca canonical store berulang kali |
| `memory_retrieval.projection.snapshot_consistent` | Semua candidate berasal dari snapshot/signature yang sama | Gunakan signature sebagai provenance selection |
| `memory_retrieval.projection.candidate_count` | Ukuran subspace yang benar-benar dirangking | Bandingkan dengan `snapshot_memory_count`, bukan total token prompt |
| `memory_retrieval.projection.graph_hops_evaluated` | Jumlah tetangga topologis (1-2 hop) yang dievaluasi | Verifikasi neighborhood expansion graph |
| `memory_retrieval.projection.target_witness_satisfied` | Minimal satu exact/path target memory menutup slot saat diwajibkan | Audit explicit-target coverage tanpa mengalahkan query utama |
| `memory_retrieval.projection.rank_vector.target_hop_distance` | Jarak topologis ke target (`0` direct, `1` 1-hop, `2` 2-hop, `3` unrelated) | Gunakan untuk validasi ranking proximity graph |
| `memory_retrieval.projection.omitted_semantic_relevance_proven=false` | Omission hanya di luar predicate reference machine | Jangan menyatakan record teromit pasti tidak relevan |
| `budget.allocation.source_grounding_satisfied` | Current source excerpt masuk pada mode source | Harus `true` sebelum memakai memory evidence |
| `budget.allocation.memory_max_fraction` | Cap memory terhadap hard budget | Nilai default `0.35`; source harus didahulukan |
| `budget.allocation.current_source_precedes_memory` | Urutan prompt saat memory disertakan | Pastikan source card muncul lebih dahulu |

### `graph_cache`

| Field | Interpretasi | Action |
|---|---|---|
| `status=hit` | Semua source snapshot dipakai ulang | Lanjut; `files_read` harus 0 |
| `status=partial` | Add/change/delete terdeteksi | Audit counter invalidasi, hasil graph sudah dirakit ulang |
| `status=miss/refreshed` | Semua source dibaca | Normal untuk build awal atau forced refresh |
| `status=recovered` | Cache invalid/rusak berhasil dibangun ulang | Periksa `recovery_reason` |
| `status=write_failed` | Analisis sukses tetapi snapshot tidak tersimpan | Periksa permission folder tool |
| `contains_source_content=true` | Cache menyimpan salinan source | Jaga lokal dan jangan commit |
| `stat_trust_boundary` | Batas validitas fingerprint cepat | Pakai refresh bila metadata stat tak tepercaya |

### `analyzer_cache`

| Field | Interpretasi | Action |
|---|---|---|
| `status=hit` | Semua analyzer yang diminta dipakai ulang | `executed_count` harus 0 |
| `status=partial` | Sebagian evidence tersedia | Audit daftar reuse dan eksekusi |
| `status=stale` | Source snapshot, graph, atau engine tidak lagi cocok | Jalankan request normal atau `cache refresh` |
| `status=invalidated` | Graph atau engine analyzer berubah | Periksa `invalidation_reasons`; hasil sudah dihitung ulang |
| `status=recovered` | Entry rusak berhasil dihitung ulang | Periksa `recovery_reason` |
| `status=write_failed` | Analisis sukses tetapi evidence tidak tersimpan | Periksa permission folder tool |
| `contains_full_source_content=false` | Tidak ada snapshot source penuh | Evidence turunan tetap dapat sensitif dan harus lokal |
| `analyzers_reused/executed` | Provenance per analyzer | Pastikan LLM tahu bukti reused atau fresh |

### `memory_retrieval.projection.cache`

| Field | Interpretasi | Action |
|---|---|---|
| `status=hit` | Store SHA, scope, schema, dan engine identik | `canonical_store_load_count` harus 0 |
| `status=partial` | Canonical store berubah tetapi sebagian record identik | Audit `entries_reused/rebuilt/removed` |
| `status=miss/refreshed` | Projection dibangun penuh dari canonical snapshot | Normal pada build pertama/forced refresh |
| `status=recovered` | Cache derived rusak dan berhasil dihitung ulang | Periksa `recovery_reason`; canonical tetap authority |
| `status=write_failed` | Recall sukses tetapi projection tidak tersimpan | Periksa permission; jangan anggap recall gagal |
| `storage_model=content_addressed_memory_recall_cells_v1` | Manifest predicate merujuk pack immutable | Jangan menganggap manifest sebagai salinan canonical penuh |
| `cell_packs_written/reused/removed` | Luas invalidasi fisik | Satu mutation normal harus menyentuh satu partisi lalu GC pack lama |
| `query_pack_reads/query_memory_materialized` | Working set retrieval aktual | Bandingkan dengan `cell_pack_count/snapshot_memory_count` |
| `full_projection_rewrite_avoided=true` | Partial update tidak menulis projection monolitik | Audit juga `manifest_bytes_written + cell_bytes_written` |
| `canonical_recovery_pending=true` | Primary hilang dan backup tersedia | Cache tidak boleh hit; canonical recovery harus dijalankan |
| `contains_full_memory_content=true` | Cache memuat record memory penuh | Jaga lokal, Git-ignore, dan owner-only |
| `cache_can_restore_canonical_store=false` | Cache bukan backup atau source of truth | Jangan gunakan untuk merekonstruksi state canonical |
| `integrity_boundary` | SHA-256 mendeteksi stale/kerusakan lokal | Bukan bukti anti-tamper eksternal |

### `memory analyze`

Default output memakai filtration `semantic_associations`: batch-order provenance
dan analyzer evidence historis tidak ikut membentuk Betti/archetype. Audit
lifecycle seluruh store melalui `store_by_evidence_status`; jumlah
`by_evidence_status` hanya untuk vertex yang benar-benar masuk semantic graph.

| Field | Threshold | Interpretasi |
|---|---|---|
| `betti_numbers.beta_0/beta_1/beta_2` | exact integer | Koordinat default semantic filtration; β₂=0 untuk model 1-complex |
| `memory_health_score` | > 0.7 | Structural finding pressure rendah; bukan correctness score |
| `memory_health_score` | 0.4 - 0.7 | Structural finding pressure sedang |
| `memory_health_score` | < 0.4 | Structural finding pressure tinggi; audit witness sebelum bertindak |
| `memory_health_model.not_correctness_or_truth_score` | `true` | Jangan menilai kualitas/kebenaran memory dari scalar ini |
| `memory_archetype` | `memory_tree` | Terintegrasi hanya pada semantic filtration, bukan karena urutan batch |
| `memory_archetype` | `memory_modular` | Eksplorasi per komponen; bridge hanya jika relasi terbukti |
| `memory_archetype` | `memory_fragmented_cyclic` | Fragmentasi + cycles, waspada |
| `memory_stats.historical_memories_excluded` | > 0 | Ada evidence historis yang disimpan untuk audit tetapi tidak memengaruhi topology kini |
| `memory_stats.provenance_associations_excluded` | > 0 | Ada provenance edge yang sengaja bukan semantic relation |

Gunakan `memory stats` untuk audit pertumbuhan journal. Field
`provenance_retention.hot_history_bounded=true` membuktikan jumlah record detail
`observation_batch` tidak melewati policy limit. `total_batch_occurrences` tetap
menghitung run retained + archived, sedangkan
`archived_detail_recoverable=false` berarti checkpoint hanya mempertahankan
aggregate dan sequence commitment—jangan mengarang ID/path event lama dari
checkpoint tersebut.

### `fiber status`

| Field | Interpretasi |
|---|---|
| `active_memories_count` | Jumlah memori di context window |
| `total_importance` | Total bobot memori aktif |
| `avg_importance` | Rata-rata relevansi |
| `section.memories_count` | Jumlah memori di benang merah |
| `descent_log_count` | Berapa kali memori diturunkan |

**Decision:**
- IF `active_memories_count` > 15: descend yang tidak relevan
- IF `avg_importance` < 0.5: lift memori yang lebih relevan
- IF `section.memories_count` == 0: tambah memori ke section

### `xanalyze`

| Field | Interpretasi |
|---|---|
| `memory_store_result.stored_count` | Jumlah findings yang disimpan ke memory |
| `memory_store_result.reused_count` | Findings identik yang memperbarui node lama |
| `memory_store_result.revised_count` | Logical finding sama dengan evidence/severity/hash baru |
| `memory_store_result.resolved_count` | Finding lama tidak ada pada analyzer snapshot lengkap kini |
| `memory_store_result.orphaned_count` | Source evidence tidak ada pada snapshot file kini |
| `memory_store_result.stale_count` | Analyzer gagal sehingga evidence lama belum tervalidasi pada snapshot kini |
| `memory_store_result.duplicate_input_count` | Evidence duplikat dalam batch yang dikuotienkan |
| `memory_store_result.batch_order_is_semantic_edge=false` | Urutan batch disimpan sebagai provenance event, bukan association semantic |
| `memory_store_result.provenance_event_records_added` | `1` untuk record detail baru; `0` bila batch steady-state dicoalesce |
| `memory_store_result.provenance_event_coalesced` | Run identik berturut-turut menambah `occurrence_count`, bukan panjang event list |
| `memory_store_result.provenance_event_records_compacted` | Record detail lama yang dipindahkan ke aggregate checkpoint pada transaksi ini |
| `memory_store_result.provenance_retention.hot_history_bounded` | Harus `true`; default maksimal 128 observation records |
| `memory_store_result.provenance_retention.archived_detail_recoverable` | Selalu `false`; archive mempertahankan count/digest, bukan payload lama |
| `memory_store_result.graph_content_signature` | Snapshot penuh yang menjadi dasar evidence |
| `consolidation_signal.consolidation_candidate` | Apakah perlu konsolidasi |
| `analysis_summary.health_score` | Kesehatan codebase |
| `analysis_summary.archetype` | Bentuk topologis codebase |

---
