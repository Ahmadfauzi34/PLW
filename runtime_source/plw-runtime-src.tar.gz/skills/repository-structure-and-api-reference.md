# Repository Structure & API Reference

**Load when:** locating implementation files, REST endpoints, or understanding repository layout.

**Provides:** portable-package boundaries, module ownership, durable/generated-data locations, and REST endpoint purposes.

**Return to:** [SKILL.md routing map](../SKILL.md#9-skill-module-routing-map).

**Related modules — load only when needed:** [tool-call and CLI workflow](tool-call-and-cli-workflow.md) to inspect or verify a located component; [atomic execution lease workflow](atomic-execution-lease-workflow.md) for the F121 trust-store component; [code-change and session workflow](code-change-and-session-workflow.md) before editing it.

> On-demand lookup reference; repository location does not imply mutation authority.

## Repository structure

`tools/ai_studio_tool/` adalah batas distribusi portabel. Angular/REST demo
berada di luar folder ini dan hanya boleh bergantung pada kernel, tidak sebaliknya.

```
tools/ai_studio_tool/
|- README.md                         # Product architecture and checkpoint record
|- SKILL.md                          # Canonical always-read agent router
├── skills/                         # On-demand operational agent modules
│   ├── adaptive-agent-workflow.md
│   ├── context-and-proof-workflow.md
│   ├── code-change-and-session-workflow.md
│   ├── external-corpus-audit-workflow.md
│   ├── analysis-output-reference.md
│   ├── tool-call-and-cli-workflow.md
│   ├── repository-structure-and-api-reference.md
│   ├── capability-governance-workflow.md
│   ├── atomic-execution-lease-workflow.md
│   └── history/
│       └── f86-f105-simplification-decisions.md
│
├── plw_cli.py                       # Zero-Bloat Native Command Layer (plw)
├── agent_tool.py                     # JSON tool-call adapter; no shell execution
├── setup_plw.sh                     # Non-root wrappers: plw + hott + plw-call
├── hott_kernel.py                   # Unified Kernel CLI & API Entrypoint
├── tools_schema_compact.json        # Default canonical tool surface (1 tool)
├── tools_schema.json                # Legacy compatibility declarations
├── fixture_check.py                 # Self-contained portable regression
├── fixtures_min/                    # Minimal TS/JS invariant fixtures
│
├── core/                            # Shared Foundation (Layer 0)
│   ├── shared_graph.py              # Canonical graph representation
│   ├── graph_cache.py               # Persistent snapshot + incremental invalidation
│   ├── analyzer_cache.py            # Persistent evidence + signature invalidation
│   ├── analyzer_registry.py         # Registry & lifecycle management
│   ├── synthesizer.py               # Invariant encoder & decoder steering
│   ├── context_optimizer.py         # Query-directed quotient context + budget
│   ├── adaptive_work.py             # Deterministic one-call evidence router
│   ├── context_accountability.py    # Content-addressed audit ledger
│   ├── decision_lineage.py          # Explicit causal decision ancestry + audit trace
│   ├── outcome_reconciliation.py    # Delayed downstream strategy-cost attribution
│   ├── capability_contracts.py      # Exact, bounded fail-closed validators
│   ├── accountability_provenance.py # Issuer-authenticated accountability seals
│   ├── capability_lifecycle.py      # F106 legal lifecycle transitions
│   ├── capability_workflow.py       # F107/F108 advisory envelope and renderer
│   ├── capability_relevance.py      # F109/F111 typed relevance and audit
│   ├── capability_delivery.py       # F112 delivery accountability
│   ├── capability_accountability_chain.py # F113 verified audit chain
│   ├── capability_action_proposal.py      # F114 proposal-only boundary
│   ├── capability_action_authority.py     # Signed principal grant assertion
│   ├── capability_action_authorization.py # F116 authorization receipt
│   ├── capability_action_gate.py          # F117 execution-eligibility gate
│   ├── capability_action_dry_run.py       # F118 no-effect plan
│   ├── capability_action_preflight.py     # F119 fresh current-state check
│   ├── capability_action_lease.py         # F121 atomic nonce-pair lease
│   ├── safety.py                    # Cycle prevention & Betti validation
│   ├── deprecation.py               # Standalone deprecation handlers
│   └── __init__.py                  # Core exports
│
├── data/codebase/cache/             # Source snapshots + analyzer evidence; Git-ignored
│
├── codebase/                        # Codebase Intelligence Domain (Layer 1)
│   ├── topology_analyzers.py        # Circular deps, risk evaluation
│   ├── performance_analyzers.py     # Async waterfall, deopt, GC, cache
│   ├── hott_analyzers.py            # Isomorphism, sheaf, homotopy, manifold
│   ├── targeted_queries.py          # Impact, outline, and brief queries
│   └── __init__.py                  # Codebase domain exports
│
├── memory/                          # Topological Memory Domain (Layer 2)
│   ├── store.py                     # CRUD, associations, retrieval
│   ├── runtime.py                   # Project scope, lock, atomic JSON, recovery
│   ├── retrieval.py                 # Single-snapshot inverted recall projection
│   ├── retrieval_cache.py           # Content-addressed recall cells + manifest
│   ├── provenance.py                # Bounded observation journal + checkpoint
│   ├── graph.py                     # Memory graph & adjacency builder
│   ├── analyzers.py                 # Memory fragmentation, hub, manifold, Betti
│   ├── betti.py                     # Edge-type-aware Betti breakdown
│   ├── consolidation.py             # Memory colimit & tag consolidation
│   ├── compact.py                   # Quotient forgetting & archiving
│   ├── bridge.py                    # Semantic bridging & homotopy extension
│   ├── synthesizer.py               # Memory steering, fingerprint, drift
│   ├── kan_extension.py             # Left (Lan) & Right (Ran) completions
│   └── __init__.py                  # Memory domain exports
│
├── context/                         # Fibration Context Window Domain (Layer 3)
│   ├── fibration.py                 # Fiber state lifecycle (init, lift, descend)
│   ├── section.py                   # Narrative section continuity
│   ├── transport.py                 # Parallel transport & decay factor
│   ├── compatibility.py             # Fiber-memory compatibility check
│   └── __init__.py                  # Context domain exports
│
├── bridge/                          # Cross-Domain Integration (Layer 4)
│   ├── xanalyze.py                  # Selective auto-store from code findings
│   ├── xsteer.py                    # Unified cross-domain steering
│   ├── xcontext.py                  # Memory-augmented file context
│   └── __init__.py                  # Bridge domain exports
│
├── data/runtime/scopes/             # Project-scoped memory/fiber state; Git-ignored
│
```

---

## Host adapters are outside the portable API

The portable package exposes Python CLI/API surfaces; it does not own an
Express/Angular server. A host repository may adapt the kernel to HTTP without
becoming a tool dependency. The F120 reference corpus uses this bounded adapter:

| Host endpoint | Kernel operation |
|---|---|
| `GET /api/python-info` | verify Python plus configured `hott_kernel.py` |
| `GET /api/topology` | `analyze <corpus> --cache-mode off --output graph` |
| `GET /api/impact?file=<path>` | `impact <target> <corpus>` |
| `GET /api/outline?file=<path>` | `outline <target> <corpus>` |
| `GET /api/brief?file=<path>` | `brief <target> <corpus>` |

Former standalone-analyzer host routes are not portable contracts. The F120
adapter returns HTTP 410 with the consolidated replacements instead of invoking
deleted scripts. See the [external corpus audit workflow](external-corpus-audit-workflow.md)
before using or changing a host adapter.

---
