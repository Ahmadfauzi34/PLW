# Capability Workflow Governance — F106–F119

**Load when:** handling capability lifecycle, workflow relevance, accountability, delivery, chain queries, proposals, authorization, gates, dry-runs, or freshness preflight.

**Provides:** the ordered F106–F119 state/authority chain, validation requirements, and boundaries that keep advisory readiness separate from execution.

**Return to:** [SKILL.md routing map](../SKILL.md#9-skill-module-routing-map).

**Related modules — load only when needed:** [atomic execution lease workflow](atomic-execution-lease-workflow.md) after an F119 preflight is ready for the explicit F121 handoff; [context and proof workflow](context-and-proof-workflow.md) when a workflow claim requires current source/runtime evidence; [F86–F105 simplification decisions](history/f86-f105-simplification-decisions.md) only when replaying the historical reason for the current simplification state.

> This module owns the no-effect parent chain through F119. Load the F121 lease module only for the explicit state-changing nonce-pair handoff.
> F120 remains an orthogonal external-corpus audit and is not an authority-chain step.

## Current operational chain

```text
F106 lifecycle evaluation
  -> F107 advisory envelope
  -> F108 context-pack integration
  -> F109 typed relevance trigger
  -> F111 relevance accountability
  -> F112 delivery accountability
  -> F113 verified chain query
  -> F114 action proposal boundary
  -> F116 single-proposal authorization receipt
  -> F117 authorized action gate
  -> F118 deterministic executor dry-run
  -> F119 signed current-state preflight
  -> F121 atomic single-use executor lease (separate module)
```

F110 is the fixture fast-lane and is orthogonal to the governance chain.

### F106 Capability Lifecycle Rule
Use `core.capability_lifecycle.evaluate_transition` for experimental capability lifecycle decisions. Legal order is `FROZEN → DOSSIER_QUALIFIED → SHADOW_PROTOTYPE → ECONOMICS_REVIEW → ACCEPTED | RETIRED`; state skips and missing evidence fail closed. Lifecycle acceptance is **not** source truth, runtime proof, external-patch authorization, or stable promotion. Those remain separate authorities. The F103-F105 history must replay to `RETIRED`: dossier/prototype/economics-review advance, `ACCEPTED` fails because 4 LOC gain < 36 LOC cost, and `RETIRED` passes only while historical evidence is preserved. Do not wire lifecycle evaluation to automatic mutation without a separate workflow-adapter proof.

### F107 Lifecycle Workflow Adapter Rule
Use `core.capability_workflow.build_decision_envelope` when an agent needs a compact answer to “what may I legally do next?”. Treat the envelope as advisory context only. `allowed_targets` means lifecycle evidence is sufficient to **propose** that transition; it does not execute the transition. Read `blocked_targets` for missing proof conditions. `INVALID_STATE` must fail closed. Every adapter authorization remains false; external mutation, runtime execution, truth commit, and stable promotion require separate authorities.

### F108 Workflow Context-Pack Rule
Use `capability_workflow_context` only on an explicitly capability-relevant context request. The input must contain `relevant=true` plus an authentic F107 advisory envelope. The context renderer must fail closed on schema/policy mismatch, missing authorization keys, or any authorization value that is not literal `False`. Do not render raw lifecycle evidence; use the digest and compact decision fields. Ordinary/no-workflow and `relevant=false` context must remain unchanged. Workflow guidance is advisory and budget-droppable: current source grounding has priority, and inclusion never grants transition execution, runtime execution, external patch, stable promotion, or truth-commit authority.

### F109 Workflow Relevance Trigger Rule
For tool-generated workflow relevance, use `core.capability_relevance`: never infer `relevant=true` from query text, keywords, embeddings, or similarity scores. A request must be explicitly typed, reason-allowlisted, evidence-referenced, capability/state/evidence-digest bound to an authentic F107 envelope, and advisory-only with literal `False` authorizations. Denied relevance must be an exact prompt no-op. A granted relevance decision only requests F108 context; it does not guarantee inclusion and grants no transition/runtime/patch/stable/truth authority. Manual F108 explicit relevance remains backward compatible.

### F110 Fixture Fast-Lane Rule
For iterative agent work, use `python fixture_fast.py` instead of repeatedly invoking historical fixture batches. The runner shares one immutable current-root simplification snapshot per process, but temporary/mutated corpora must remain fresh analyses. Fast-lane PASS is an iteration signal only: it does not authorize release, stable promotion, external mutation, or truth commit. Full fixture and kernel smoke lanes remain release/change-impact gates.

### F111 Workflow Relevance Accountability Rule
Use `build_relevance_accountability` / `record_relevance_accountability` only when an F109 relevance decision needs an audit artifact. Do not auto-write the ledger during ordinary relevance evaluation or context construction. The audit must bind the exact request digest and workflow evidence digest, omit raw query/evidence/evidence-ref values, and carry the canonical relevance issuer seal in addition to its content hash. Recompute supplied decisions before recording; mismatch or an unsigned generic ledger record fails closed. Ledger availability never changes relevance, prompt content, lifecycle legality, execution, patch, promotion, or truth authority.


### F112 Workflow Delivery Accountability Rule
A workflow delivery audit is valid only when it points to a schema-exact, issuer-sealed F111 `capability_workflow_relevance` accountability id and its request/capability/state/evidence bindings still match the delivered workflow context. Normalize actual delivery to `INCLUDED`, `BUDGET_OMITTED`, `DENIED`, or `INVALID`; bind the final context by digest, never by storing raw prompt/source. Metadata and context marker must agree, and the F112 record requires its own delivery issuer seal. Delivery accountability has zero execution, transition, patch, stable-promotion, truth, relevance, or inclusion authority.

### F113 Workflow Accountability Chain Query Rule

Use `plw accountability-chain <sha256:decision-id>` when an agent needs to audit the workflow path from an F111 relevance decision to one or more F112 delivery outcomes. The start id may be either record. Treat the result as **read-only provenance metadata**: exact schema/policy, internal decision-id/path identity, issuer seals, and parent/child bindings are revalidated. A content hash alone is never issuer identity. The chain grants no relevance, delivery, transition, runtime, patch, stable-promotion, or truth authority.

### F114 Workflow Action Proposal Boundary Rule

Treat an F114 action proposal as **intent metadata, not permission and not execution**. Build it only from an explicit typed request bound to a verified F113 chain whose selected F112 delivery outcome is `INCLUDED`; do not create proposals from `BUDGET_OMITTED`, `DENIED`, or `INVALID` workflow delivery. Revalidate capability, lifecycle state, workflow evidence digest, and require the proposed lifecycle target to appear in the advisory envelope's `allowed_targets`. Literal `caller_declared_intent=true` is required; query text, keyword matches, similarity scores, or inferred intent must never substitute for it. A ready proposal must still report separate authorization required with `granted=false`, and it grants no transition execution, runtime execution, patch, stable promotion, or truth-commit authority.

### F116 Workflow Action Authorization Receipt Rule

Treat an F116 authorization receipt as **permission evidence for exactly one F114 proposal, not as execution evidence**. `build_authorization_request` does not mint permission: it must receive a separately issued, signed, principal-bound assertion with a nonce and maximum 900-second TTL. Recompute F114 and verify exact proposal/accountability/capability/state/evidence/action bindings plus the assertion signature and freshness. Receipt creation still executes no transition/runtime/patch/promotion/truth effect. Production must supply the provenance key from a protected authority service; the mode-0600 store key is a local reference-machine fallback, not isolation from malicious code running under the same OS identity.


### F117 Authorized Action Gate Contract Rule

Treat F117 as the final **verification gate before a separate executor**, not as the executor itself. Build the gate request from one content-addressed F116 authorization receipt plus the same bounded authorization/proposal requests; require literal `caller_requests_execution_gate=true`. Recompute F116 authorization against the current advisory envelope, verify the stored receipt contract and all capability/state/evidence/action bindings, and fail closed on unknown fields or digest drift. An open gate may report executor handoff `eligible=true`, but `execution_started=false` and every transition/runtime/patch/stable/truth effect remains false. Query text, timing, similarity, receipt existence, or truthy substitutes cannot open the gate.

### F118 Authorized Action Executor Dry-Run Contract Rule

Treat F118 as a deterministic **execution-plan preview, never as execution evidence**. Build it from one issuer-sealed F117 gate and the same bounded request chain. All top-level and nested maps are exact-schema contracts; missing effect maps, extra authority keys, malformed JSON-like values, or digest drift fail closed. The plan digest must bind the gate, authorization, proposal, workflow evidence, principal, assertion, expiry, and nonce—not only the action tuple. A ready plan remains `DRY_RUN_ONLY`, ends at `STOP_BEFORE_SIDE_EFFECT`, and leaves every effect false.

### F119 Authority Provenance and Preflight Freshness Rule

Before any executor handoff, call `issue_preflight_freshness_assertion` only from the trusted workflow-state provider after it reads the current canonical envelope. The signed assertion is bound to one exact F118 record/request and expires within 30 seconds. `evaluate_action_preflight` rebuilds the full F111–F118 chain against that envelope and verifies the stored dry-run issuer seal. A ready F119 preflight remains no-effect eligibility; advance only through the F121 atomic lease.

### F121 Atomic Execution Lease Transition

When—and only when—the F119 record and every parent remain valid, load [Atomic execution lease workflow](atomic-execution-lease-workflow.md). F121 is the state-changing CAS boundary: it consumes both nonces in one trust-store transaction and may authorize one named, allowlisted executor start. It does not execute or prove the bound action.
