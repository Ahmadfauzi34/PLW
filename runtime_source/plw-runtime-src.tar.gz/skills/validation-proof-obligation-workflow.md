# Validation proof-obligation coverage workflow

**Load when:** either F129 has bound validator evidence or F139 has bound one F138-accepted runtime result into the exact F128 scenario space, and the agent needs a fresh obligation-coverage derivation before any postcondition claim.

**Provides:** the existing F130/F131 coverage machinery plus F140 execution-backed re-derivation over F139 provenance v2, same-observation witness groups, provenance-specific obligations, full-artifact coverage digests, bounded next-evidence requests, and a strict boundary between coverage and truth.

**Return to:** [root skill router](../SKILL.md).

## Command

```bash
# Legacy F129/F130/F131 path
plw validation-coverage <plan.json> <evidence.json> <obligations.json> [--store-dir <trust-store>] --json

# F140 execution-backed path
plw validation-coverage execution-backed <f139-binding.json> <obligations.json> --json
```

Both paths are read-only projectors. The F140 path first verifies the self-contained F139 binding digest/structure and then freshly re-derives coverage; it never reopens runtime state, reruns a validator, dispatches work, mutates source, or commits truth.

## Obligation set

```json
{
  "schema_version": "validation-proof-obligation-set-v2",
  "validation_plan_digest": "sha256:...",
  "obligations": [
    {"obligation_id": "save-visible", "scenario_id": "sha256:...", "requirement": "SCENARIO_OBSERVED"},
    {"obligation_id": "no-overlap-check", "scenario_id": "sha256:...", "requirement": "CHECK_OBSERVED", "check_id": "constraint-1", "witness_scope": "SAME_OBSERVATION", "witness_group_id": "render-proof"},
    {"obligation_id": "sealed-receipt", "scenario_id": "sha256:...", "requirement": "F123_RECEIPT_VERIFIED"},
    {"obligation_id": "exact-runtime-provenance", "scenario_id": "sha256:...", "requirement": "F123_PROVENANCE_VERIFIED", "witness_scope": "SAME_OBSERVATION", "witness_group_id": "render-proof"},
    {"obligation_id": "validator-consistency", "scenario_id": "sha256:...", "requirement": "CONSISTENT_SCENARIO_OUTCOME"}
  ]
}
```

Every obligation targets one exact F128-selected `scenario_id`. Unknown/unselected scenarios fail closed instead of widening the plan.

`SCENARIO_ANY` (the default) lets each obligation use any matching observation.
`SAME_OBSERVATION` requires every obligation with the same scenario and
`witness_group_id` to share at least one observation ID. Individually covered
facts split across different observations remain `PARTIAL`; they are not
silently composed into a nonexistent witness. If any member of a
`SAME_OBSERVATION` group is incomplete, an individually `COVERED` sibling is
downgraded to global `PARTIAL` while its `individual_coverage_status` remains
visible. Legacy v1 obligation sets remain accepted with `SCENARIO_ANY` semantics.

`F123_RECEIPT_VERIFIED` is intentionally weaker than
`F123_PROVENANCE_VERIFIED`: the former proves a sealed receipt exists; the latter
requires that receipt's `validation.result` digest to match the exact evidence
observation.

## F140 execution-backed obligation set

F140 accepts `validation-proof-obligation-set-v3`, which preserves all v2 requirements and adds two explicit provenance requirements:

```json
{
  "schema_version": "validation-proof-obligation-set-v3",
  "validation_plan_digest": "sha256:...",
  "obligations": [
    {"obligation_id": "scenario", "scenario_id": "sha256:...", "requirement": "SCENARIO_OBSERVED"},
    {"obligation_id": "result-lineage", "scenario_id": "sha256:...", "requirement": "EXECUTION_PROVENANCE_VERIFIED"}
  ]
}
```

`EXECUTION_RECEIPT_VERIFIED` requires an F138 acceptance receipt verified inside F139. `EXECUTION_PROVENANCE_VERIFIED` requires the stronger F139 provenance-v2 conjunction: receipt verified, exact result content bound, execution lineage bound, and runtime result observed.

F123-specific requirements remain literal. F140 **does not** silently satisfy `F123_RECEIPT_VERIFIED` or `F123_PROVENANCE_VERIFIED` with F137/F138 provenance. If the intended obligation is execution-backed provenance, declare the v3 execution requirement explicitly.

## Coverage states

- `COVERED`: the requested evidence shape is present.
- `PARTIAL`: relevant evidence exists, but the requested provenance obligation is not verified.
- `MISSING`: the requested evidence shape has not been returned.
- `CONFLICTING`: evidence exists but disagrees for the explicit consistency/check obligation.

`next_evidence_requests` tells the consumer what exact scenario/check/provenance
evidence is still needed. Recovery text depends on both requirement and current
status, so a conflict is preserved and adjudicated rather than treated like
missing evidence. It is a recovery reference, not an execution order.

The projector first recomputes the complete F129 digest and derived structure.
Its v2 `proof_obligation_coverage_digest` covers the entire coverage artifact,
including `next_evidence_requests`, authority, proof boundaries, and recovery.
`verify_validation_proof_coverage_integrity()` checks only that self-contained
checksum envelope. `verify_validation_proof_coverage()` is the semantic verifier:
it requires the F129 binding and obligation set, re-projects coverage, and
requires the supplied coverage digest to match that fresh derivation. Both
digests remain unkeyed integrity checks, not issuer authentication.

## Proof boundary

```text
obligation COVERED          != claim truth
complete coverage           != postcondition proof
validator PASS              != correctness proof
missing obligation          != validator failure
conflicting obligation      != auto-resolved truth
F123 receipt verified       != matching evidence content
F123 provenance verified    != pixel/behavior truth
same-observation covered    != postcondition proof
coverage digest             != issuer authentication
coverage checksum valid      != semantically derived coverage
F130/F131                   != execution/mutation/truth authority
F139 execution provenance   != F123 provenance by relabeling
F140 complete coverage      != postcondition proof
F140                        != runtime dispatch/mutation/truth authority
```

**Related modules — load only when needed:**

- To bind raw validator evidence first, load [Scenario-bound validation evidence workflow](scenario-validation-evidence-workflow.md).
- To inspect the bounded scenario plan, load [Targeted validation scenario planning workflow](scenario-validation-planning-workflow.md).
- After F140 execution-backed coverage is complete, the next boundary is postcondition proof assembly; do not promote coverage directly to truth.
- To settle a behavior/postcondition claim after coverage review, load [Context and proof workflow](context-and-proof-workflow.md).
