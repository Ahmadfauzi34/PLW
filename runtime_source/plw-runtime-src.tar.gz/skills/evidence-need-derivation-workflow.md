# Evidence-Need Derivation Workflow

**Load when:** `target_resolution` is `RESOLVED` or `MULTI_TARGET_RESOLVED` and the task still lacks an explicit statement of what evidence is required.

**Provides:** target-grounded `known`, `unknown`, and `evidence_needed` records. Canonical anchors are epistemic-gap analysis, evidence requirements, static-vs-runtime evidence boundaries, and test reachability versus assertion coverage.

Use `plw evidence-needs "<task>" <root> --target <file> --json` when you need the stage independently. `plw work` already derives the same stage from its single graph snapshot.

Treat each `evidence_needed` row as a requirement, not as a command recommendation. This stage must not choose `impact`, runtime validation, geometry, or any other PLW capability. Capability matching belongs to F138.5.

Fail closed: if target resolution is ambiguous or unresolved, the result is `EVIDENCE_NEED_BLOCKED_TARGET_UNRESOLVED` with an empty evidence-needs set. Resolve the target first.

Static reachability is not behavioral coverage; a reachable test is not proof that its assertions cover the requested behavior. Import presence is not an external API contract. Task wording is not a postcondition witness.

**Return to:** `SKILL.md` after the evidence requirements are explicit.

**Related modules — load only when needed:** [Target resolution](target-resolution-workflow.md), [Target topology](target-codebase-topology-workflow.md), [Semantic affordance](semantic-affordance-workflow.md).
