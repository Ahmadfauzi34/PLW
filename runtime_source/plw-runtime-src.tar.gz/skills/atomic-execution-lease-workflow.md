# Atomic Execution Lease Workflow — F121

**Load when:** acquiring or inspecting the single-use lease that follows an issuer-sealed F119 preflight, or diagnosing nonce replay, executor allowlist, crash recovery, or lease-store failures.

**Provides:** the F121 eligibility → atomic compare-and-swap → executor-start handoff contract, including its state effects and its strict separation from actual action execution.

**Return to:** [SKILL.md routing map](../SKILL.md#9-skill-module-routing-map).

**Related modules — load only when needed:** [capability workflow governance](capability-governance-workflow.md) when any F106–F119 parent binding is unclear; [tool-call and CLI workflow](tool-call-and-cli-workflow.md) when invoking `plw action-lease`; [context and proof workflow](context-and-proof-workflow.md) when the claimed action outcome still lacks runtime/source evidence.

> A winning lease authorizes one allowlisted executor to start one exact plan. It is not evidence that the executor started, completed, or produced the intended result.

## State machine

```text
F119 preflight ready
  -> F121 eligibility revalidation (read-only)
  -> atomic nonce-pair CAS
       UNCONSUMED -> LEASED_TO_ONE_EXECUTOR
  -> later lease-bound executor adapter (not implemented by F121)
```

The CAS is one SQLite `BEGIN IMMEDIATE` transaction with unique constraints on the authorization nonce, freshness nonce, and idempotency key. Both nonces are claimed together or neither is claimed. A pre-commit crash rolls back both. Once committed, expiry does not make either nonce reusable.

Effective expiry is the earliest of the requested TTL, authorization expiry, and freshness expiry. It is checked again after the transaction lock is acquired; a request that expires while waiting for the lock commits no nonce claim.

## Acquire a lease

The trusted host must configure a narrow executor allowlist:

```bash
export PLW_EXECUTOR_ALLOWLIST='executor.lifecycle-transition.v1'
```

Then pass one JSON object on stdin containing the complete F114–F119 request chain, current envelope, F119 record id, executor id, and a caller-generated idempotency key:

```bash
plw action-lease acquire \
  --store-dir /protected/workflow-store \
  --allow-state-change \
  --json < lease-bundle.json
```

Through `plw-call`, also set literal top-level `allow_state_change: true`. The CLI flag and tool-call acknowledgement are independent proof boundaries. Neither authorizes source mutation or runtime execution outside the exact signed action chain.

Do not expose a caller-selectable parallel lease database. The canonical database is always `execution_leases.sqlite3` inside the same accountability/provenance trust store that verifies the F111–F119 records. Choosing another signed trust store is a host-security decision, not a request field.

## Interpret acquisition results

- `AUTHORIZED_ACTION_LEASE_ACQUIRED`: this call alone won the CAS and may hand the exact plan to the named executor.
- `AUTHORIZED_ACTION_LEASE_RECOVERED_NO_SECOND_START`: the same idempotency key recovered the committed receipt, but the retry receives no second start grant.
- `AUTHORIZED_ACTION_LEASE_REJECTED`: no start grant. Inspect `failed_conditions`; nonce conflicts, allowlist failures, stale assertions, and binding drift fail closed.

Only `executor_start` may be true on the winning response. `transition_execution`, `runtime_execution`, `external_patch`, `stable_promotion`, and `truth_commit` remain false, and every corresponding effect remains false.

The portable receipt contains nonce digests, not raw nonce values. It is content-addressed and issuer-sealed. The SQLite store retains raw nonces only to enforce uniqueness inside the protected trust domain.

## Inspect without regranting

```bash
plw action-lease status sha256:<lease-id> \
  --store-dir /protected/workflow-store \
  --json
```

Inspection verifies the stored receipt, executor binding, and expiry. It is read-only and always returns `executor_start_authorized=false`; an audit query cannot become a second execution handoff.

## Stop conditions

Do not acquire or use a lease when any of these are unresolved:

- the F119 record or any parent issuer seal fails verification;
- the current envelope differs from the freshness assertion;
- the executor is absent from the protected allowlist;
- either assertion has expired;
- the authorization or freshness nonce is already consumed;
- the trust-store path, key ownership, or database integrity is uncertain;
- the requested operation is broader than the exact dry-run plan.

F121 supplies a portable reference transaction, not same-OS hostile-code isolation. Production must keep the provenance key, allowlist, and trust store behind the authority service boundary.
