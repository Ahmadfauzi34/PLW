# Runtime geometry capture provenance workflow

**Load when:** an F125 GeometrySnapshot must be proven as the exact payload reported by a previously prepared F123 runtime adapter dispatch.

**Provides:** F126 adapter-observation binding plus one-call runtime UI reference composition; no browser/runtime execution is added to PLW.

**Return to:** [root skill router](../SKILL.md).

## Contract

Use the generic F123 adapter for execution/reconciliation. A geometry-capable host adapter should report the canonical observation built by:

```python
build_geometry_capture_adapter_result(snapshot)
```

Its F123 observation kind is:

```text
runtime.geometry.capture
```

After the adapter observation is durable, query:

```bash
plw runtime-ui-reference <lease-id> <snapshot.json> <project-root> --store-dir <trust-store> --json
```

This command is read-only. It rebuilds a deterministic capture-payload digest from the normalized F125 state, reconstructs the F126 observation mapping, reads the verified F123 receipt, and compares them.

## Proof result

```text
EXACT
  F123 observation exists
  + kind = runtime.geometry.capture
  + dispatch = ACKNOWLEDGED
  + adapter terminal = SUCCEEDED
  + F122 terminal = SUCCEEDED
  + observation digest matches this GeometrySnapshot

UNRESOLVED
  any required binding is absent, stale, conflicting, nonterminal, failed,
  indeterminate, or points to a different snapshot
```

The capture digest neutralizes only `capture.adapter_observation_id`, because that ID is created after the observation is recorded. F126 binds the receipt ID in the outer provenance envelope; a later embedded ID claim may match it without changing the capture payload digest, while a conflicting claim fails closed.

## Authority boundary

```text
verified adapter observation != truthful pixels
adapter SUCCEEDED            != geometry correctness
capture provenance           != behavior proof
capture provenance           != postcondition proof
capture provenance           != redispatch authority
capture provenance           != mutation/truth authority
```

F126 does not bundle Playwright, Selenium, a browser, screenshot recognition, or a concrete runtime adapter. Consumers remain free to provide any adapter satisfying F123 plus the F126 observation contract.

**Related modules — load only when needed:**

- To evaluate explicit geometry constraints and project verified surfaces to bounded topology impact, load [Targeted geometric impact projection workflow](geometric-impact-projection-workflow.md).

- To execute/reconcile the host capture, load [Executor adapter reconciliation workflow](executor-adapter-reconciliation-workflow.md).
- To inspect geometry/correspondence without runtime provenance, load [Geometry and correspondence workflow](geometry-correspondence-workflow.md).
- To inspect the static Angular owner anchors, load [Angular semantic ownership workflow](angular-semantic-ownership-workflow.md).
- For behavior/postcondition proof after capture, load [Context and proof workflow](context-and-proof-workflow.md).
