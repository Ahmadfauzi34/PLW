# Semantic Affordance and Skill Handoff Workflow

**Load when:** target-codebase topology is already established and a PLW-local name remains semantically opaque, `work.semantic_orientation` is unfamiliar, or `work.skill_handoff.required_read=true`.

**Provides:** canonical technical anchors for PLW-local vocabulary, predictive information-gain contracts, expected outcome families, proof limits, and the rule that turns a machine-selected handoff into an exact next `.md` read.

**Return to:** [SKILL.md routing map](../SKILL.md#9-skill-module-routing-map).

**Related modules — load only when needed:** [target codebase topology workflow](target-codebase-topology-workflow.md) when first-contact structural orientation is missing; [adaptive agent workflow](adaptive-agent-workflow.md) for the default `work` path; [tool-call and CLI workflow](tool-call-and-cli-workflow.md) for syntax/safety; [analysis output reference](analysis-output-reference.md) when a returned field is unclear.

## Why this exists

An unfamiliar model may know `RAII`, `WAL`, graph reachability, provenance, leases,
and reconciliation from pretraining while knowing nothing about PLW-local terms.
Do not require the model to infer a private ontology from names such as
`validation-result` or `geometric-impact`.

F138.1 maps:

```text
PLW local term
  -> canonical technical concepts
  -> nearest known abstractions
  -> important differences
  -> current epistemic gap
  -> expected information gain
  -> possible outcome family
  -> exact skill read
```

This is a semantic adapter, not execution authority.

## Default-path contract

First-contact reasoning begins with `plw topology`; capability semantics come after the target structure is grounded. `plw work` reuses that graph state and returns:

```text
target_orientation
semantic_orientation
skill_handoff
```

Read `semantic_orientation` before deciding that manual reasoning is equivalent
to a PLW capability. It describes information PLW can establish that may not be
present in local context.

When:

```text
skill_handoff.required_read = true
```

read **exactly** `skill_handoff.skill_path` before choosing or invoking the next
specialized capability. Do not substitute memory of the command name for the
module. The handoff remains documentation routing only; it does not authorize a
state change, runtime execution, source mutation, or truth commit.

A specialized bounded task signal or a preferred proof transition can make the
read required. General `understand` work may return a recommended but not
required read.

## Predictive semantics, not predicted results

The agent does not need the exact future output before a call. It needs the
space of possible results and their meaning:

```text
PossibleFuture(call) = {known decision families}
```

For example, `validation-result` exposes `ACCEPTED | REJECTED | UNRESOLVED`.
These are outcome classes, not a prediction that a specific call will succeed.

## Canonical-anchor rule

Prefer established technical vocabulary. A custom PLW concept should be
represented as:

```text
CustomConcept = KnownTechnicalConcepts + explicit delta
```

Example:

```text
validation-dispatch
  similar to: durable intent / outbox-style coordination / single assignment
  different from: runtime dispatch / redo log
```

Similarity never transfers authority. `similar to WAL` does not imply PLW is a
redo log; `similar to a lease` does not imply runtime execution rights.

## Read-only introspection

Use this only when the default work output is insufficient:

```bash
plw semantic describe validation-result --json
plw semantic route "button overlaps modal on mobile" --json
```

`describe` answers what a named capability means, why it can be useful, its
possible result family, proof limits, and which skill to read.

`route` maps bounded task signals to one primary capability and skill path.
Neither command executes the described capability.

## Stop condition

F138.1 succeeds when an unfamiliar agent can state, **before the next tool call**:

```text
1. what information it currently lacks;
2. which familiar technical concepts describe the candidate capability;
3. what information the capability could add;
4. what it still cannot prove;
5. which exact skill module must be read before use.
```

If those five points cannot be stated, do not treat the command name alone as a
reason to invoke or skip the capability.
