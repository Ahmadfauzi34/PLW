# Full-Stack Validated State Workflow

**Load when:** F141 postcondition proof exists and the task requires a bounded full-stack state across topology, geometry, correspondence, and execution-backed behavior.

**Provides:** F142 composition of separate authority receipts into `VALIDATED | REJECTED | UNRESOLVED | CONFLICTING | STALE` with exact revision/scenario/freshness compatibility.

**Return to:** [SKILL.md routing map](../SKILL.md#9-skill-module-routing-map).

**Related modules — load only when needed:** [postcondition proof assembly](postcondition-proof-assembly-workflow.md), [geometry correspondence](geometry-correspondence-workflow.md), [runtime geometry capture](runtime-geometry-capture-workflow.md), [geometric impact](geometric-impact-projection-workflow.md), and [scenario evidence](scenario-validation-evidence-workflow.md).

## Boundary

F142 never merges authority domains:

```text
TopologyAuthority
!= GeometryAuthority
!= CorrespondenceAuthority
!= BehaviorAuthority
!= PostconditionAuthority
```

F142 performs compatibility + composition only. `VALIDATED` is not source-mutation attestation, stable promotion, or truth commit. Behavior and F141 are provenance-related and are never counted as independent votes.

## Command

```bash
plw fullstack-state <root> <f139-binding.json> <f141-proof.json> <fullstack-spec.json> \
  --current-revision REV \
  --geometry-impact geometric-impact.json \
  --ui-reference ui-reference.json \
  --json
```

Repeat `--geometry-impact` and `--ui-reference` for multiple scenarios. The composition spec must exactly cover F141's scenario scope. Each scenario declares whether geometry/correspondence are required, explicit required geometric constraint IDs, minimum correspondence proof class (`EXACT` or `STRUCTURAL`), and whether exact runtime geometry capture is required.

## Compatibility checks

F142 freshly scans topology from `<root>` and checks current `graph_content_signature` against UI↔code correspondence. Geometry `scenario_id` must be the canonical digest of `(code_revision, route, viewport, ui_state, data_fixture)`. Behavior/F141/Geometry must reference the same scenario identity and candidate revision.

Precedence is fail-closed:

```text
STALE       revision/topology freshness mismatch
CONFLICTING incompatible authority identities or F141 conflict
REJECTED    explicit postcondition or geometric constraint failure
UNRESOLVED  required authority/evidence is missing or below proof policy
VALIDATED   all required authorities compatible, fresh, and satisfied
```

## Authority result

A F142 receipt stores references/digests and compatibility state, not copies of merged graphs. It always retains:

```text
authorities_merged = false
graphs_merged = false
evidence_voting_used = false
source_mutation_attested = false
stable_promoted = false
truth_committed = false
```
