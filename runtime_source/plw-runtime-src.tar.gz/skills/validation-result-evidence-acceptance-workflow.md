# Validation result evidence-acceptance workflow

**Load when:** one F137 runtime observation is terminal and the exact canonical `validation.result` payload must be accepted, rejected, or kept unresolved before scenario evidence/proof coverage is updated.

**Provides:** F138 digest/content binding, request/scenario/validator lineage checks, durable acceptance receipt, replay rules, and the runtime-vs-validator outcome boundary.

**Return to:** [root skill router](../SKILL.md).

## Contract

```text
F137 RESOLVED runtime observation
  + exact validation.result payload
  + exact F132 request set
        ↓
F138 ACCEPTED | REJECTED | UNRESOLVED
```

F138 never invokes a validator or runtime. `runtime_terminal_status=SUCCEEDED`
means the runtime returned a result; it does **not** mean validator outcome PASS.
A canonical validator FAIL may therefore be accepted evidence.

Acceptance requires all of the following:

- the F137 observation receipt verifies and is terminal `SUCCEEDED`;
- `observation_kind == validation.result`;
- the supplied result digest equals the F137 `observation_digest`;
- F137 `evidence_ids` equal the canonical result evidence IDs;
- the supplied F132 request-set digest equals the request-set bound through F134–F137;
- exactly one F132 `request_id` matches the execution lineage;
- scenario, validator, executor, operation key, and validation-plan identity remain exact.

Runtime terminal `FAILED` or `INDETERMINATE` is `UNRESOLVED`, never validator FAIL.
Malformed, substituted, or digest-mismatched content is `REJECTED`.

## Durable state

```text
validation_result_evidence_acceptance_v1
feature: evidence_acceptance:v1
```

One runtime observation can have at most one accepted result. Exact replay
recovers the same signed receipt; changed content is rejected. Raw validator
result content is not retained in SQLite—only digests, lineage, validator
outcome, and evidence IDs.

## CLI

```bash
plw validation-result accept <runtime-observation-id> result.json request-set.json \
  --allow-state-change --store-dir DIR --json
plw validation-result status <runtime-observation-id> --store-dir DIR --json
```

## Semantic affordance

Canonical technical anchors: **artifact attestation**, **content-addressed
integrity**, **provenance verification**, and **lineage binding**. This workflow
is similar to verifying a signed/content-addressed artifact, but it is not a test
runner, validator execution surface, proof-completion step, or truth commit.

Use it when a runtime result exists but exact returned content is not yet
admissible evidence for the request. Expected information gain is content,
scenario, validator/executor, and execution-lineage binding. The possible result
family is `ACCEPTED | REJECTED | UNRESOLVED`.

## Proof boundary

```text
runtime SUCCEEDED != validator PASS
validator FAIL != runtime failure
accepted evidence != proof-obligation coverage
accepted evidence != postcondition proof
accepted evidence != truth
```

The next checkpoint binds accepted F138 content back into scenario-bound F129-style evidence.

**Related modules — load only when needed:**
- Parent runtime state: [Validation runtime dispatch workflow](validation-runtime-dispatch-workflow.md).
- Existing scenario evidence: [Scenario-bound validation evidence workflow](scenario-validation-evidence-workflow.md).
- Coverage after scenario binding: [Validation proof-obligation coverage workflow](validation-proof-obligation-workflow.md).
