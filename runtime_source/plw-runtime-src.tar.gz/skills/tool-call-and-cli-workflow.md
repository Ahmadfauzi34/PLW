# Tool-Call and CLI Workflow

**Load when:** choosing an explicit tool-call/CLI command, validating graph/cycle safety, checking archetype strategy, or verifying a change.

**Provides:** adaptive and advanced JSON invocation surfaces, CLI commands, state-change acknowledgement rules, safety invariants, verification entrypoints, and archetype-to-strategy mappings.

**Return to:** [SKILL.md routing map](../SKILL.md#9-skill-module-routing-map).

**Related modules — load only when needed:** [adaptive agent workflow](adaptive-agent-workflow.md) for the default one-call path; [atomic execution lease workflow](atomic-execution-lease-workflow.md) for F121 acquisition/status semantics; [analysis output reference](analysis-output-reference.md) to interpret returned fields; [code-change and session workflow](code-change-and-session-workflow.md) when a safe command transition leads to a mutation.

> On-demand reference. A command listing is not execution authorization.

## Default adaptive invocation

For ordinary repository work, prefer one adaptive call:

```bash
plw work "<task>" <project-root> --target <file> --goal auto --depth auto
```

For a function-call host, send one JSON object to `plw-call`/`agent_tool.py`.
The canonical schema is `tools_schema_compact.json`:

```json
{
  "mode": "work",
  "task": "explain the impact of changing the cache service",
  "scan_root": "/workspace/project",
  "target_files": "src/cache.service.ts"
}
```

Use `mode=capabilities` only for uncommon discovery. For an explicit advanced
operation, set `surface` to `kernel` or `plw`, set `mode` to the packaged
command, and pass only argv values after that command in `arguments`. The
adapter never invokes a shell. Supply bounded `stdin` only for an operation
whose native CLI reads standard input, such as `compact-output` or
`action-lease acquire`. Advanced calls
default to 300 seconds; set `timeout_seconds` from 1 through 3600 for a larger
corpus instead of changing the command or authority model.

Advanced operations that can change canonical local memory, fiber, baseline,
cache, or lease state require literal `allow_state_change=true`. Ordinary `work` may write
configured derived caches and proof-accountability provenance; its
`state_effect_contract` reports that explicitly. Neither path receives
source-mutation, external-runtime, workflow-execution, promotion, or
truth-commit authority.

See [adaptive agent workflow](adaptive-agent-workflow.md) for routing goals,
depth selection, call-reduction telemetry, and stop conditions.

## Safety invariants

### Directed reasoning-cycle safety

```
directed_reasoning_cycle_witness_count HARUS = 0 untuk safe bridge

JIKALAU directed_reasoning_cycle_witness_count > 0:
  → STOP operasi saat ini
  → Jalankan: memory betti_breakdown
  → Identifikasi directed witness
  → Hapus edge yang membentuk cycle (gunakan bridge --unsafe hanya jika perlu)

JIKALAU hanya β₁_reasoning > 0:
  → Audit reconvergence/diamond dan parallel association
  → JANGAN klaim circular reasoning tanpa directed witness
```

### Automatic cycle prevention

Bridge dengan `assoc_type="inferential"` atau `"causal"` akan **otomatis ditolak** jika membentuk cycle:
```json
{"status": "rejected", "reason": "would_create_reasoning_cycle"}
```
Command `memory associate` memakai directed reachability check yang sama untuk
tipe reasoning dan mengembalikan `error_code=would_create_reasoning_cycle`.
**JANGAN** override dengan `--unsafe` kecuali benar-benar diperlukan.

### Automatic fiber compatibility

Memori yang tidak punya tag overlap dengan fiber aktif akan **otomatis ditolak** saat lift:
```json
{"skipped_incompatible": N}
```
Ini mencegah confabulation (memori tidak konsisten masuk konteks).

### Selective filtering (`xanalyze`)

Hanya findings berikut yang disimpan ke memory:
- ✅ High severity findings
- ✅ Cross-analyzer correlations
- ✅ Critical medium findings (circular, entrypoint, change_risk)
- ❌ Low/info findings (transient, tidak disimpan)

### Healthy fragmentation

**TIDAK semua komponen perlu dihubungkan.** β₀ tinggi bisa jadi valid:
- `db_perf`, `ui_design` → healthy silos, biarkan terisolasi
- Bridge HANYA jika ada shared context meaningful
- JANGAN bridge antar domain yang tidak berhubungan (confabulation risk)

---

## CLI command reference

Gunakan Native Command Layer (`plw`) untuk mencegah Context Bloat.

### Codebase Analysis (Zero-Bloat)
```bash
plw work "<task>" . --target <file>
plw context "<query>" . --budget 1000
plw kan <file>
plw check
plw steer
plw impact <file>
plw brief <file>
```

### Memory Operations
```bash
plw memory store <episodic|semantic|procedural> "<content>" [--tags t1,t2] [--importance 0.8]
plw memory recall [--query q] [--type t] [--tags t1,t2] [--limit 20]
plw memory get <memory_id>
plw memory associate <from_id> <to_id> <type> [--strength 0.7]
plw memory consolidate <id1,id2,...> --content "<pattern>"
plw memory consolidate_auto
plw memory compact --consolidated
plw memory bridge <from> <to> [type]
```

### Memory Topology
```bash
hott_kernel.py memory analyze --output summary
hott_kernel.py memory analyze --include-historical --include-provenance --output summary  # audit only
hott_kernel.py memory steer --output summary
hott_kernel.py memory establish
hott_kernel.py memory drift
hott_kernel.py memory betti_breakdown
hott_kernel.py memory stats
```

`memory stats` adalah jalur inspeksi bounded provenance. Default policy menahan
128 record observation detail dan 256 namespace archive. Kebijakan ini hanya
berlaku pada `observation_batch`; consolidation event tetap exact karena
merupakan perubahan semantic yang eksplisit.

### Fiber Operations
```bash
plw fiber init "<task>" "<focus>"
plw fiber lift [--query q] [--max 10]
plw fiber descend --all
plw fiber status
```

### Cross-Domain
```bash
hott_kernel.py xanalyze src --output summary [--no-store]
hott_kernel.py xsteer src --output summary
hott_kernel.py xcontext <file>
```

### Atomic Action Lease

```bash
plw action-lease acquire --store-dir <protected-store> --allow-state-change --json < lease-bundle.json
plw action-lease status sha256:<lease-id> --store-dir <protected-store> --json
```

Acquisition additionally requires `PLW_EXECUTOR_ALLOWLIST`; `plw-call` requires
literal top-level `allow_state_change: true`. Status is read-only. Load the
[atomic execution lease workflow](atomic-execution-lease-workflow.md) before
interpreting a lease as an executor handoff.

### Tool Invocation Ergonomics & Self-Healing Contract
- **Interchangeable Parameter Aliases**: Argumen fleksibel dinormalisasi otomatis (misal `--target-file` / `--target-files` / `--targets`, `--budget-tokens` / `--budget_tokens`, `--max-hops` / `--max_hops`).
- **Self-Healing Error Diagnostics**: Jika dipanggil dengan mode yang salah atau tidak terdaftar, kernel mengembalikan error terstruktur `unknown_mode` beserta `valid_modes` dan `suggested_fix` tanpa melempar silent exception.
- **Anti-Churn Finding Identity**: `_stable_finding_subject` dihitung berbasis koordinat struktural (`analyzer`, `type`, `scope`), sehingga pembaruan teks observasi merevisi record yang ada (*in-place revision*) tanpa menciptakan duplikasi memori.

### Verification
```bash
python3 tools/ai_studio_tool/fixture_check.py
```

---

## Archetype-to-strategy mapping

### Codebase Archetypes

| Archetype | Strategy | Karakteristik |
|---|---|---|
| `tree_like` | hierarchical_traversal | Hirarkis, top-down aman |
| `modular` | isolated_analysis | Terfragmentasi, perubahan lokal |
| `sparse_cyclic` | cycle_aware_traversal | Ada cycles, waspada |
| `mixed_cyclic` | path_enumeration | Moderate cycles, petakan jalur |
| `dense_mesh` | conservative_edit | Sangat terhubung, hati-hati |
| `fragmented_sparse_cyclic` | component_localized_traversal | Terfragmentasi + cycles, isolasi per komponen |
| `fragmented_cyclic` | component_boundary_mapping | Petakan boundary komponen |

### Memory Archetypes

| Archetype | Strategy | Karakteristik |
|---|---|---|
| `memory_tree` | hierarchical_recall | Terintegrasi, recall mudah |
| `memory_modular` | isolated_exploration | Terfragmentasi, eksplorasi per klaster |
| `memory_sparse_cyclic` | cycle_aware_recall | Association cycle rank; cek witness sebelum menyebut loop |
| `memory_mixed_cyclic` | path_enumeration | Petakan association path dan arah edge |
| `memory_dense_mesh` | conservative_recall | Sangat terhubung, filtering ketat |
| `memory_fragmented_sparse_cyclic` | component_localized_recall | Reason per komponen; hubungkan hanya dengan witness |
| `memory_fragmented_cyclic` | component_mapping | Petakan komponen, validasi cross-component |

---
