# Validation execution lease workflow

**Load when:** one exact F133 `AUTHORIZED_BOUND` request must advance to a durable single-use validation lease.

**Provides:** F134 lease request/eligibility/acquisition/inspection semantics, replay rules, expiry, and the boundary before validation-attempt registration.

**Return to:** [root skill router](../SKILL.md).

## Contract

F134 is the first state-changing boundary in the validation branch:

```text
F132 REQUESTED
  -> F133 AUTHORIZED_BOUND
  -> F134 VALIDATION_EXECUTION_LEASE_ACQUIRED
       != attempt registered
       != adapter dispatch
       != validator/runtime execution
       != evidence returned
       != postcondition proven
       != truth
```

Acquisition re-verifies the complete F132/F133 semantic chain, then atomically
consumes one `validation_authorization_binding_digest` in
`validation_execution_leases.sqlite3`. The effective lease expiry is capped by
the F133 authorization expiry and the F134 TTL (maximum 30 seconds).

Exact replay of the same idempotency key returns the original signed lease
receipt with `VALIDATION_EXECUTION_LEASE_RECOVERED_NO_SECOND_ATTEMPT`; recovery
does not grant a second downstream attempt. A different idempotency key cannot
consume the same F133 authorization binding or assertion again.

CLI:

```text
plw validation-lease acquire <plan> <evidence> <obligations> <assertion> \
  --request-id ID --validator-id ID --executor-id ID \
  --idempotency-key KEY --allow-state-change --json

plw validation-lease status <lease-id> --store-dir DIR --json
```

`acquire` changes local durable coordination state and therefore requires
literal state-change acknowledgement on the agent surface. `status` is
read-only and never regrants attempt or dispatch authority.

Crash/replay boundary:

```text
lease committed != attempt registered
lease recovered != second attempt authorized
lease expired != authorization binding reusable
```

Do not infer an attempt from lease existence. The next contract must register a
durable attempt against the exact lease before any adapter/runtime dispatch.

**Related modules — load only when needed:**
- Previous principal-grant boundary: [Validation authorization binding workflow](validation-authorization-binding-workflow.md).
- Generic capability lease semantics: [Atomic execution lease workflow](atomic-execution-lease-workflow.md).
- Proof/postcondition settlement: [Context and proof workflow](context-and-proof-workflow.md).
