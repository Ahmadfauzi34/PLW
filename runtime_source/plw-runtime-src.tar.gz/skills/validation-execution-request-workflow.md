# Validation execution request workflow

**Load when:** F131 coverage has unresolved obligations and the agent must turn those gaps into exact validator work without conflating request, authorization, dispatch, execution, returned evidence, or proof.

**Provides:** F132 semantic re-derivation plus bounded `REQUESTED` validator handoffs.

**Return to:** [root skill router](../SKILL.md).

## Command

```bash
plw validation-request <plan.json> <evidence.json> <obligations.json> \
  --validator-id <id> --executor-id <id> [--store-dir <trust-store>] --json
```

F132 does **not** accept a coverage artifact as authority. It rebuilds the F129
binding from the supplied evidence, re-projects F131 coverage from the exact
obligation set, and emits work only for obligations whose global coverage is not
`COVERED`.

`SAME_OBSERVATION` obligations in one scenario/group become one correlated
request. Other obligations remain independent recovery units. Conflicts become
`ADJUDICATE_CONFLICT`; missing/partial evidence becomes bounded collection work.

Each request binds:

```text
exact F128 scenario identity
+ F129 binding digest
+ obligation-set digest
+ freshly re-derived F131 coverage digest
+ validator_id
+ executor_id
+ obligation/witness-group set
+ requested UI/component/constraint surface
+ expected scenario-validation-observation-v1 result contract
```

The handoff includes a deterministic `request_id` and `operation_key`, but:

```text
REQUESTED
!= AUTHORIZED
!= LEASED
!= ATTEMPT-REGISTERED
!= DISPATCHED
!= EXECUTED
!= EVIDENCE-RETURNED
!= POSTCONDITION-PROVEN
!= TRUTH
```

`validator_id` and `executor_id` select intended work targets; they do not grant
permission. `handoff.may_dispatch` is always false in F132. A host that executes
this work must separately bind the exact `request_id` through the established
authorization/lease/attempt/adapter path and then return canonical F129 evidence.

`verify_validation_execution_requests()` is semantic, not checksum-only: it
rebuilds the request set from F128 + F129 + obligations and requires exact digest
identity. A self-consistent forged request set therefore is not trusted merely
because its digest was recomputed.

**Related modules — load only when needed:**

- For coverage semantics, load [Validation proof-obligation coverage workflow](validation-proof-obligation-workflow.md).
- For evidence return/provenance, load [Scenario-bound validation evidence workflow](scenario-validation-evidence-workflow.md).
- For execution authority boundaries, load [Atomic execution lease workflow](atomic-execution-lease-workflow.md) and [Executor adapter reconciliation workflow](executor-adapter-reconciliation-workflow.md).
