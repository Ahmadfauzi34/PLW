# Context and Proof Workflow

**Load when:** building context, evaluating claims, compacting/recovering outputs, or reasoning about proof transitions.

**Provides:** evidence-role semantics, proof obligations, valid proof transitions, runtime-output custody, and policy-memory boundaries.

**Return to:** [SKILL.md routing map](../SKILL.md#9-skill-module-routing-map).

**Related modules — load only when needed:** [analysis output reference](analysis-output-reference.md) when a returned field is unclear; [code-change and session workflow](code-change-and-session-workflow.md) when a settled proof transition becomes an edit or runtime-validation task.

> On-demand reference. Do not preload it for unrelated tasks.

## Protocol map

### Query-directed context

Daripada membaca banyak file yang membebani token dan history LLM, pakailah CLI `plw` sebagai reference/proof boundary yang memproyeksikan evidence sesuai budget, authority, dan proof obligation. Jangan menyamakan ranking tinggi dengan proof completeness.

```bash
STEP 1: Hasilkan context yang sesuai budget
  → plw context "<pertanyaan developer>" . --budget 1000

STEP 2: Periksa output "PLW Context Pack"
  → Baca `evidence_roles`/baris `WHY`, Truth Floor, file terpilih, dan topology
  → Bedakan proof-due evidence dari relevance-selected evidence sebelum membuat claim

STEP 3: Gunakan Kan Extension khusus untuk modul baru/isolated
  → plw kan src/users/user.service.ts
  → Memprediksi relasi dan memberikan hint standar arsitektur (limit/colimit).
```

### Evidence-role interpretation

Setelah `plw context`, baca `evidence_roles` sebelum menafsirkan daftar file sebagai "yang penting":

```text
source.proof_due_paths
source.explicit_target_paths
source.selected_by_relevance_paths
memory.proof_due_ids
memory.continuity_ids
optional_enrichment.kan_targets
```

Gunakan semantics berikut:

- `proof_due_source` = source authority yang **wajib sekarang** karena evidence debt/relevance transition;
- `explicit_target` = caller memilih source tersebut secara langsung;
- `selected_by_relevance` = bounded ranking memilih source tersebut, tetapi selection ini bukan proof obligation/completeness;
- `proof_due_memory` = historical/continuity witness yang diwajibkan claim; source saat ini tetap precedence;
- `memory_continuity` = historical context, bukan current-state truth;
- `optional_enrichment` = advisory derived context; tidak boleh membayar hard Truth Floor.

DILARANG mengubah `selected_by_relevance` menjadi "semua file lain tidak relevan".
DILARANG menganggap file yang masuk karena proof debt sekadar hasil scoring. Jika exact logic diperlukan, lakukan targeted recovery/source read sebagai valid transition; jangan menaikkan budget secara refleks sebelum allocator/recovery path dicoba.

### Linux command-output boundary

Jika primitive Linux memang lebih tepat, pertahankan command familiar agent tetapi normalisasi stdout sebelum masuk reasoning context:

```bash
# Search: semua match tetap ada, prefix berulang boleh dipadatkan
rg -n "FooService" src | plw compact-output --command 'rg -n FooService src'

# Test/build: hanya noise identik berurutan yang boleh dipadatkan
npm test | plw compact-output --command 'npm test'

# Source/diff: tetap exact meski over-budget
git diff | plw compact-output --command 'git diff'

# Jika detail mentah dibutuhkan kembali
plw recover-output sha256:<id>

# Audit apakah compaction memicu recovery/rerun pressure
plw output-telemetry
```

BACA telemetry: `hard_truncation_applied` harus `false`. Untuk search, `matches_omitted` harus `0`. Jika `within_budget=false`, jangan menganggap output aman dipotong; pilih query yang lebih targeted atau recover raw evidence. `output-telemetry.pressure` hanya review cue dan `automatic_action` harus `none`.

### Context liability

Setelah `plw context` atau `plw compact-output`, baca field `accountability`:

```text
responsible_role
evidence_debt
recovery_obligation
ledger.id
```

Jika evidence debt relevan terhadap claim correctness:

```bash
plw accountability sha256:<decision-id>
# lalu recover targeted source/output yang diwajibkan ledger
```

DILARANG mengubah `FILES_OMITTED`, omitted source line, memory yang tidak masuk,
atau output yang diexternalize menjadi kesimpulan bahwa evidence tersebut tidak
ada/tidak relevan. Optimizer bertanggung jawab atas keputusan filtering; agent
bertanggung jawab mengikuti recovery obligation sebelum mengandalkan area yang
difilter.

### Proactive truth delivery

Omitted evidence berarti **belum tepat untuk projection sebelumnya**, bukan tidak
penting. Saat bekerja dalam fiber/task aktif, `plw context` otomatis memakai
`fiber_id` sebagai truth scope. Scope eksplisit juga dapat diberikan:

```bash
plw context "<query>" . --truth-scope <task-id>
```

Baca `truth_delivery`:

```text
status
proactive_targets
due_targets
delivered_targets
delivery_status
ledger.id
```

Jika `delivery_status=delivered`, evidence lama telah dipromosikan karena task
sekarang melewati boundary yang membuat debt itu relevan. Jika
`delivery_status=delivery_incomplete`, JANGAN lanjut membuat correctness claim
pada target yang belum delivered; bayar recovery obligation terlebih dahulu.

PLW hanya boleh memicu automatic delivery dari evidence yang memiliki witness
transisi: explicit target re-entry, direct graph boundary dari target aktif, atau
path/filename re-entry yang kuat. Jangan menggunakan embedding similarity saja
sebagai alasan untuk menyatakan debt jatuh tempo. Automatic delivery tidak boleh
menaikkan hard budget.

Jika tidak ada fiber/scope stabil, cross-boundary proactive delivery harus tetap
nonaktif (`scope_required_for_cross_boundary_delivery`) agar debt antar-task tidak
tercampur.

### Claim-aware proof obligations

Setelah `plw context`, baca `claim_obligations` sebelum menyusun jawaban/claim:

```text
requested_claims
allowed_claims
blocked_claims
proof_obligations[]
required_transitions[]
ledger.id
```

Aturan minimum:

- `dependency_structure`: gunakan current graph witness; absence hanya berlaku
  pada scope resolved relative-import graph yang dinyatakan output.
- `static_behavior`: butuh exact current-source line.
- `static_test_structure`: boleh memakai `topo.test_reachability`, tetapi jangan
  mengubahnya menjadi statement/branch coverage atau hasil test runtime.
- `runtime_test_result` / `runtime_behavior`: jalankan validasi runtime targeted;
  source, analyzer, dan domain memory tidak boleh menjadi substitusi.
- `architecture_invariant`: gunakan analyzer current snapshot yang diwajibkan.
- `historical_rationale`: gunakan memory continuity yang memenuhi Truth Floor;
  current source tetap precedence untuk keadaan code sekarang.

Jika blocked claim ada, jangan melakukan paraphrase yang menyamarkan kekurangan
evidence. Baca `proof_transitions` dan pilih candidate dengan witness kind yang
cocok. `preferred_transition` adalah hint biaya/risiko ordinal, bukan izin eksekusi.

### Proof transitions

Untuk claim yang blocked:

```text
claim_obligations.blocked_claims
        ↓
proof_transitions.candidates[]
        ↓
cek authority_domain + side_effect_class
        ↓
pilih transition paling sempit
        ↓
execute di authority yang sesuai
        ↓
re-evaluate Truth Floor + Claim Obligations
```

Aturan:
- `auto_execute_allowed=false` selalu dihormati; registry adalah reference machine.
- `recover_exact_memory` hanya sah untuk continuity/history, bukan runtime truth.
- `recover_static_test_analyzer_witness` hanya membuktikan static reachability.
- `obtain_runtime_validation` dieksekusi oleh agent/host shell; output lalu masuk
  `plw compact-output` agar exact raw evidence tetap recoverable.
- jangan menganggap transition selesai sebagai proof; validation pass pada claim
  gate berikutnya yang mengubah status.
- raw Bash tetap escape hatch, bukan default jika transition PLW yang lebih sempit
  tersedia.

Inspection command:

```bash
plw transitions "<claim/query>" . --target <file> --json
```

### Transition-outcome memory

Pisahkan **truth memory** dari **policy experience**. Setelah claim gate benar-benar menerima hasil transition, outcome boleh dicatat sebagai pengalaman strategi. Gunakan `plw transition-memory --json` untuk inspeksi.

Aturan keras:
- outcome memory tidak boleh dipakai sebagai source/runtime/history witness;
- outcome memory tidak boleh mengubah `valid/invalid` transition;
- outcome memory tidak boleh melunasi `claim_obligations`;
- graph drift boleh mempertahankan strategy experience, tetapi wajib menggugurkan proof witness yang snapshot-bound;
- pada policy v1, `attempts/settlement_rate/proof_progress` hanya advisory dan **tidak mengubah ranking**;
- jangan menyalin raw query, raw command, raw output, atau raw target path ke policy memory.

Ini adalah data training/policy untuk MDP di masa depan, bukan authority of truth.

### Shadow policy

Gunakan `shadow_policy` hanya sebagai pembanding strategi terhadap ranking deterministic.

Aturan keras:
- input action set harus berasal dari `proof_transitions.candidates[]`;
- shadow policy tidak boleh menambah/menghapus valid transition;
- `policy_probability` adalah action preference, bukan truth confidence;
- shadow policy tidak boleh execute, settle claim, atau commit proof state;
- divergence terhadap deterministic ranking dicatat, bukan langsung diikuti;
- bila `state_conditioned_prior` belum ada, shadow tetap one-step/contextual-bandit-like;
- bila prior state-conditioned tersedia, ia boleh dipakai sebagai strategy prior, tetapi **belum full MDP** karena Markov sufficiency abstraction belum terbukti dan belum ada long-horizon value optimization;
- deterministic registry ranking tetap authoritative sampai shadow evaluation cukup kuat.

Inspection:

```bash
plw transitions "<claim/query>" . --target <file> --json
```

Baca `shadow_policy.action_distribution`, `shadow_preferred_transition`, dan `diverges_from_deterministic`.

### Proof state and state-conditioned policy memory

Gunakan `proof_state.state_class_id` sebagai state untuk generalisasi **strategi**, dan `proof_state.state_instance_id` untuk provenance exact snapshot/scope. Jangan menukar keduanya.

Aturan keras:
- state class tidak boleh menyimpan raw query, raw target path, atau raw truth scope;
- state instance boleh mengikat graph snapshot/scope melalui fingerprint, tetapi tetap bukan truth witness;
- transition state-action intent hanya boleh dibuat untuk candidate yang sudah valid dari Proof Transition Registry;
- runtime attestation boleh membawa source-state binding sebagai policy provenance; binding itu tidak menambah authority runtime evidence;
- `P_hat(S'|S,A)` adalah empirical observed frequency dari **explicit validated attempts**, **bukan truth confidence**;
- validation rejection harus ikut outcome model; absence of attempt tidak boleh dihitung sebagai failure;
- `markov_sufficiency_proven=false` sampai ada validation khusus bahwa abstraction cukup untuk Markov property;
- state-transition model tidak boleh ikut canonical memory recall, Truth Floor settlement, atau claim proof;
- Shadow Policy boleh memakai state-conditioned prior hanya untuk advisory strategy ranking.

Inspection:

```bash
plw transitions "<claim/query>" . --target <file> --json
plw transition-model --state-class sha256:<id> --json
```

### Proof-constrained Q/value policy memory

`plw q-values` mengekspos empirical `Q_hat(S,A)` / `V_hat(S)` untuk **strategy selection only**. Reward harus proof-first: validated proof progress/evidence gain mendominasi, sementara token/context saving, compute, rerun/recovery, dan mutation risk hanya bounded secondary adjustment.

Aturan keras:
- validation rejection tidak boleh menjadi reward positif walaupun token saving sangat besar;
- Q/value bukan truth confidence, bukan proof status, dan tidak dapat settle claim;
- hanya candidate yang sudah valid dari Proof Transition Registry boleh menerima Q prior;
- telemetry biaya hanya fingerprint/metrics privacy-bounded; jangan simpan raw command/stdout di policy memory;
- `markov_sufficiency_proven=false` dan `bellman_optimality_proven=false` pada V1;
- Shadow Policy boleh memakai Q prior untuk comparison/advisory ranking; deterministic registry tetap authoritative.

Inspection:

```bash
plw q-values --state-class sha256:<id> --json
plw transitions "<claim/query>" . --target <file> --json
```

### Delayed outcome-cost reconciliation

Setelah sebuah transition settle, jangan menganggap cost snapshot final. Gunakan `plw reconcile-outcomes` untuk mengatribusikan recovery/rerun yang muncul kemudian kembali ke transition/output representation asal. Q/value policy memakai delta ini sebagai **strategy cost only**.

Aturan keras:
- baseline settlement tidak boleh dimutasi;
- delayed recovery/rerun menurunkan strategy value, bukan truth confidence;
- delta harus non-negative dan idempotent (`current - baseline`), bukan counter yang ditambah setiap pembacaan;
- command-output custodian/decision harus ditautkan bila exact `evidence_id` tersedia;
- raw command, stdout, query, target, dan scope tetap tidak boleh masuk reconciliation;
- jangan mengklaim context re-expansion atau cross-command semantic causality sampai ada scoped causal linkage yang eksplisit.

```bash
plw reconcile-outcomes --json
plw q-values --state-class sha256:<id> --json
```
