# Targeted geometric impact projection workflow

**Load when:** one rendered UI surface or an explicit geometric constraint must be related back to Angular owners and topology impact without validating the whole UI.

**Provides:** F127 focused geometry facts, explicit overlap/containment/min-gap constraint evidence, and bounded UI→Angular→SharedGraph impact projection.

**Return to:** [root skill router](../SKILL.md).

## Command

```bash
plw geometric-impact <snapshot.json> <project-root> \
  --focus <ui-id> \
  --constraints <query.json> \
  --proximity 12 \
  --json
```

Optional verified runtime provenance can be composed in the same read-only call:

```bash
plw geometric-impact <snapshot.json> <project-root> \
  --focus <ui-id> \
  --lease-id <sha256:lease-id> --store-dir <trust-store> \
  --json
```

The command never dispatches an adapter or browser. `--lease-id` only asks F126 to bind an already-recorded capture receipt.

## Constraint query

Constraint intent is never guessed from layout. Declare it explicitly:

```json
{
  "schema_version": "geometric-impact-query-v1",
  "focus_ui_ids": ["login.submit"],
  "proximity_px": 12,
  "constraints": [
    {"kind": "inside_viewport", "subject_ui_id": "login.submit"},
    {"kind": "inside_parent", "subject_ui_id": "login.submit"},
    {"kind": "no_overlap", "subject_ui_id": "login.submit", "other_ui_id": "login.footer"},
    {"kind": "min_gap", "subject_ui_id": "login.submit", "other_ui_id": "login.footer", "min_px": 12}
  ]
}
```

Supported constraint kinds are `inside_viewport`, `inside_parent`, `no_overlap`, and `min_gap`.

`SATISFIED` / `VIOLATED` means only that the supplied F125 rectangles satisfy the caller-declared geometric constraint. It is not a behavior or product-correctness verdict.

## Targeted relation rule

Pairwise scanning is performed only around explicit `--focus` surfaces. Ancestor/descendant pairs are excluded from automatic peer-overlap discovery because nested rectangles normally overlap by containment; an explicit constraint can still evaluate such a pair.

Every selection reports:

```text
selected UI ids
omitted geometry node count
why the selection was bounded
how to recover/expand it
```

Omission is never interpreted as irrelevance.

## Impact projection

Only `EXACT` or `STRUCTURAL` F125 correspondence can project to code. F127 then resolves the component file in the existing SharedGraph and returns a bounded topology brief:

```text
UI surface
  → F125 correspondence
  → F124 component owner
  → component/template/style anchors
  → SharedGraph target
  → direct upstream/downstream
  → bounded transitive impact counts/items
```

Full topology remains recoverable with `plw impact <component-file> <project-root> --json` instead of duplicating an unbounded graph into every geometric query.

## Proof boundary

```text
overlap fact                 != visual bug
constraint violation         != behavior failure
topology projection          != geometric effect proof
F126 exact capture binding   != truthful pixels
structural owner mapping     != runtime component instance
omitted surface              != irrelevant surface
F127 result                  != mutation authority
F127 result                  != truth commit
```

**Related modules — load only when needed:**

- For raw snapshot/correspondence semantics, load [Geometry and correspondence workflow](geometry-correspondence-workflow.md).
- For runtime capture provenance, load [Runtime geometry capture provenance workflow](runtime-geometry-capture-workflow.md).
- For static Angular owner details, load [Angular semantic ownership workflow](angular-semantic-ownership-workflow.md).
- For full topology of one projected component, use `plw impact` and load [Analysis output reference](analysis-output-reference.md) only if fields need interpretation.
- To turn projected surfaces into a bounded known scenario set before validation, load [Targeted validation scenario planning workflow](scenario-validation-planning-workflow.md).
