# External Corpus Audit Workflow

**Load when:** running, auditing, or validating the portable PLW tool against a repository outside the `ai_studio_tool` package.

**Provides:** commit-pinned corpus identity, native-versus-static proof separation, target-resolution rules, perturbation checks, and a reproducible integration handoff.

**Return to:** [SKILL.md routing map](../SKILL.md#9-skill-module-routing-map).

**Related modules — load only when needed:** [code-change and session workflow](code-change-and-session-workflow.md) before modifying the portable tool, or before a separately authorized corpus mutation; [context and proof workflow](context-and-proof-workflow.md) when a claim cannot yet be settled; [tool-call and CLI workflow](tool-call-and-cli-workflow.md) when command semantics or release gates are unclear.

> An external corpus is evidence input, not part of the portable tool. PLW output never supplies repository-write or merge authority.

## Proof state before analysis

Record these facts before drawing conclusions:

| Proof cell | Required witness |
|---|---|
| Corpus identity | repository URL, default branch, exact commit SHA |
| Local state | clean/dirty status and applicable repository instructions |
| Native baseline | install/build/test/lint commands with exit status |
| Tool identity | tool commit or artifact digest and enabled analyzers |
| CI state | exact workflow/status result, or an explicit `not configured` witness |
| Mutation authority | direct user/host authorization, kept separate from PLW records |

Do not identify a moving branch name as the audited snapshot. The branch is a
discovery route; the commit SHA is the corpus identity.

## Valid transition chain

```text
pin source snapshot
  -> run native baseline
  -> run cache-off static analysis
  -> classify claims by proof authority
  -> perturb or inspect suspicious findings
  -> make a bounded change only if authorized
  -> rerun native + tool-specific gates
  -> integrate through a reviewable branch/PR
  -> record the merged commit and final evidence
```

Native failures and PLW findings are different proof surfaces. A static
`await_in_loop`, dependency cycle, or risk score is a hypothesis about source;
it is not proof that a runtime request failed. Conversely, a passing build does
not prove the dependency graph or every analyzer finding is correct.

## Running the portable tool against a corpus

Keep the dependency direction one-way:

```text
external corpus or adapter -> ai_studio_tool/hott_kernel.py
ai_studio_tool -X-> corpus-specific source or framework dependency
```

Reference commands:

```bash
python3 <tool-root>/hott_kernel.py analyze <corpus-root> --cache-mode off --output summary
python3 <tool-root>/hott_kernel.py impact <target> <corpus-root> --cache-mode off --output full
python3 <tool-root>/hott_kernel.py brief <target> <corpus-root> --cache-mode off --output full
```

Use `--cache-mode off` for the first attested snapshot so cache reuse cannot be
mistaken for a fresh source read. A later cache-mode comparison may be added as
a separate claim.

## Target-resolution contract

Targeted queries resolve in this order:

1. exact graph vertex;
2. one unique root-relative suffix match;
3. explicit failure.

Zero matches return `file_not_found_in_graph`. Multiple suffix matches return
`ambiguous_file_target` plus bounded candidates. Never choose one ambiguous
basename heuristically. The response must expose the canonical target and
`target_resolution` witness when resolution succeeds.

## Finding validation

For a suspicious finding, inspect the exact source span and at least one
neighboring control/dependency boundary. When a cheap perturbation exists,
construct both a positive and a negative fixture. Example: an `await` inside a
loop must remain detected while an `await` immediately after the closing brace
must not be classified as loop-contained.

Classify the result:

- `confirmed_source_finding` — source and analyzer witness agree;
- `runtime_confirmed` — an external execution witness settles the behavior;
- `false_positive` — a bounded counterexample disproves the analyzer claim;
- `unsettled` — evidence is insufficient; do not force PASS/FAIL.

Fix analyzer generality in the portable tool, not by teaching it one corpus
path. Preserve intentional corpus defects when they are reference signals;
repair the harness that makes those signals observable.

## Integration and final state

Before merge, require the corpus's native gates plus the smallest PLW fixtures
covering every changed analyzer/query boundary. If CI exists, wait for its exact
head-SHA result. Merge only under separately established repository authority.

The final audit record should contain:

- base and merged corpus SHAs;
- PR URL/number and CI conclusion;
- before/after native outcomes;
- before/after graph signature and bounded finding counts;
- tool files changed and regression fixtures added;
- unresolved findings and why they remain corpus evidence;
- explicit statement that static evidence, runtime proof, and mutation
  authority were not collapsed.

After the external audit is settled, return to the root router. Use the
[analysis output reference](analysis-output-reference.md) only if a returned
field still needs interpretation.
