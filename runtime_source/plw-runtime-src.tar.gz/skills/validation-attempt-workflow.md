# Validation attempt registration workflow

**Load when:** an exact F134 lease needs its first durable validation attempt, or a caller needs to recover/inspect an attempt after losing a response.

**Provides:** F135 registration, replay, crash recovery, and the boundary before dispatch intent.

**Return to:** [root skill router](../SKILL.md).

## Contract

F135 binds one attempt to the durable F134 lease, including authorization binding,
assertion, request, request set, scenario, validator, executor, and operation key.
The persisted lease is the authority witness; do not trust a caller-supplied
`lease_acquired` or `attempt_registration_authorized` boolean.

```text
LEASED -> ATTEMPT_REGISTERED
attempt registered != dispatch intent != runtime execution
```

Both tables share `validation_execution_leases.sqlite3`. `BEGIN IMMEDIATE`
serializes registration; the exact signed lease and attempt rows are checked
inside that transaction. The versioned F135 table has unique lease and attempt
keys and a foreign key to the lease. F134 schema version 1 remains readable.

## Commands

```bash
plw validation-attempt register <lease-id> --attempt-key <key> \
  --validator-id <validator> --executor-id <executor> \
  --store-dir <dir> --allow-state-change --json

plw validation-attempt status <lease-id> --store-dir <dir> --json
```

Register requires CLI acknowledgement; the agent JSON surface separately requires
literal `allow_state_change=true`. Status and library eligibility are read-only.

## Recovery decisions

- Before commit: a failed/exited process leaves no attempt; a valid lease may retry.
- After commit but before response: inspect or replay the exact request to recover
  the same `attempt_id`. Do not create another attempt key as a recovery strategy.
- First registration requires an active lease, rechecked before commit.
- Exact recovery of an existing attempt works after lease/grant expiry; it does
  not extend the lease or grant dispatch authority.
- A different key on the same lease, or the same key on another lease, is rejected.
- Row/receipt/parent mismatches remain errors; do not repair them by copying a
  different signed receipt or resealing caller fields.

`VALIDATION_ATTEMPT_REGISTERED` proves durable registration only.
`VALIDATION_ATTEMPT_RECOVERED_NO_NEW_AUTHORITY` recovers an existing record.
Both have `dispatch_authorized=false`, `dispatch_state_authority=false`,
`dispatch_state=UNKNOWN_TO_F135`, and `truth_committed=false`. The next boundary is `VALIDATION_DISPATCH_INTENT`.

Run `python validation_attempt_reference_check.py` for the standalone reference
machine. E58 and `python fixture_fast.py` include the same suite. It compares
125 length-three traces and probes real process exits and a 12-process race.
This is bounded validation under a trusted local store/key, not an exactly-once
external effect guarantee or power-loss proof.

**Related modules — load only when needed:**
- Parent authority and lease expiry: [Validation execution lease workflow](validation-execution-lease-workflow.md).
- Generic attempt pattern, with its own distinct scope: [Lease-bound executor outcome workflow](lease-bound-executor-outcome-workflow.md).
- Future dispatch/reconciliation design reference: [Executor adapter reconciliation workflow](executor-adapter-reconciliation-workflow.md).
