# Postcondition proof assembly workflow

**Load when:** F139 execution-backed scenario evidence and fresh F140 execution-backed obligation coverage exist, and the agent must decide whether an explicit postcondition is actually supported.

**Provides:** read-only assembly of exact change identity, caller-asserted current revision, verified F139 evidence, freshly verified F140 coverage, scenario expectations, and critical check expectations into `PROVEN`, `DISPROVEN`, `UNRESOLVED`, `CONFLICTING`, or `STALE`.

**Return to:** [root skill router](../SKILL.md).

## Command

```bash
plw postcondition-proof \
  f139-binding.json \
  f140-coverage.json \
  obligations.json \
  postcondition-spec.json \
  --current-revision <revision> \
  --json
```

## Required specification

Use `postcondition-proof-spec-v1`. Bind the exact `validation_plan_digest`, a content-addressed `change_id`, `candidate_revision`, the exact obligation IDs, expected outcome for every obligation scenario, and expected outcome for every `CHECK_OBSERVED` obligation.

A validator's overall `PASS` is insufficient when a critical check has a different expected/observed outcome. Missing expected check outcomes are `UNRESOLVED`, not implicitly PASS.

## State semantics

```text
PROVEN       all declared obligations covered; revision fresh; every required scenario/check expectation matches
DISPROVEN    complete applicable evidence contradicts at least one declared expectation
UNRESOLVED   coverage/spec/evidence is incomplete
CONFLICTING  preserved evidence has incompatible outcomes; no winner selected
STALE        current revision assertion differs from candidate revision
```

## Authority boundary

```text
PROVEN
!= source mutation attestation
!= proof that the candidate change is currently applied
!= stable promotion
!= truth commit
```

`--current-revision` is a caller assertion, not VCS/source attestation. F141 executes no validator/runtime and mutates no source.

**Related modules — load only when needed:** [Execution-backed scenario evidence workflow](execution-backed-scenario-evidence-workflow.md); [Validation proof-obligation workflow](validation-proof-obligation-workflow.md).
