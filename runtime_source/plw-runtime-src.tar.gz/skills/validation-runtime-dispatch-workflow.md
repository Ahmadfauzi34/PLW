# Validation runtime dispatch and reconciliation workflow

**Load when:** one F136 dispatch intent must cross the host/runtime boundary or an ambiguous handoff must be reconciled.

**Provides:** F137 durable handoff claim, host adapter protocol, append-only runtime observations, terminal/nonterminal reconciliation, and no-blind-retry semantics.

**Return to:** [root skill router](../SKILL.md).

Library adapters implement `dispatch(context)` and `reconcile(context)` with exact `validator_id`/`executor_id`. External invocation requires literal `allow_external_execution=True`; the CLI never loads arbitrary executables.

```text
DISPATCH_INTENT_PREPARED
  -> HANDOFF_CLAIMED
  -> host dispatch / crash ambiguity
  -> PENDING | NOT_FOUND | UNKNOWN | RESOLVED
```

Recovered `HANDOFF_CLAIMED` state is never dispatched again blindly. It requires `reconcile()`.

`PENDING`, `NOT_FOUND`, and `UNKNOWN` remain unresolved. `RESOLVED` may carry `SUCCEEDED`, `FAILED`, or `INDETERMINATE`. Runtime terminal status is still **not** evidence acceptance, postcondition proof, or truth.

Observations are append-only and store bounded digests rather than raw observation payloads.

**Related modules — load only when needed:**
- [Validation dispatch-intent workflow](validation-dispatch-intent-workflow.md)
- [Scenario validation evidence workflow](scenario-validation-evidence-workflow.md)
