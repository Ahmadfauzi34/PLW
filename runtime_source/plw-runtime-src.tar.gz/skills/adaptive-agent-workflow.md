# Adaptive Agent Work Workflow

**Load when:** structural orientation of the target repository is already available (explicit `plw topology` or `work.target_orientation`) and the agent is starting task-specific repository work, or repeated context/impact/outline calls would inspect the same target.

**Provides:** the default one-call `work` contract, deterministic routing rules, observable adaptation, call-reduction telemetry, and escalation conditions for explicit CLI operations.

**Return to:** [SKILL.md routing map](../SKILL.md#9-skill-module-routing-map).

**Related modules — load only when needed:** [target codebase topology workflow](target-codebase-topology-workflow.md) when the repository is unfamiliar or structural orientation is missing; [semantic affordance workflow](semantic-affordance-workflow.md) when predictive semantics or a required skill handoff is returned; [context and proof workflow](context-and-proof-workflow.md) when the proof gate reports recovery; [tool-call and CLI workflow](tool-call-and-cli-workflow.md) when an uncommon explicit operation is required; [analysis output reference](analysis-output-reference.md) when a returned field is unclear; [external corpus audit workflow](external-corpus-audit-workflow.md) when `scan_root` is another repository.

> Operational module. Adaptive routing selects evidence only. It never executes runtime commands, mutates source or an external repository, grants workflow authority, or commits truth.

## Default call

On first contact with an unfamiliar repository, establish structural orientation first:

```bash
plw topology /path/to/repo --json
```

Then use one adaptive request before composing several narrow calls:

```bash
plw work "assess the change impact of the auth refresh path" /path/to/repo \
  --target src/auth/refresh.ts \
  --goal auto \
  --depth auto
```

For a JSON function-call host, send the same task to `agent_tool.py`/`plw-call`:

```json
{
  "mode": "work",
  "task": "assess the change impact of the auth refresh path",
  "scan_root": "/path/to/repo",
  "target_files": "src/auth/refresh.ts",
  "goal": "auto",
  "depth": "auto"
}
```

The work pack first returns `target_orientation` from the same canonical graph snapshot; no second filesystem scan is required. It then returns `semantic_orientation` and `skill_handoff`. These are
prospective semantics for an agent that has never seen PLW before: canonical
technical concepts, the current epistemic gap, expected information gain,
possible result families, proof limits, and the exact next skill module.

Read `agent_decision_frame` before interpreting legacy `work_status`. If `skill_handoff.required_read=true`, its critical contract is attached inline; read the full `skill_handoff.skill_path` when detailed workflow rules are needed before choosing or invoking the next specialized capability. The handoff is mandatory
documentation routing, not execution authority. See the
[semantic affordance workflow](semantic-affordance-workflow.md).

The work pack shares one canonical graph and one routed analyzer result across:

- target-codebase structural orientation;
- query-directed context;
- analysis summary when the goal requires it;
- one combined outline/impact brief per explicit target;
- bounded findings selected for the routed goal;
- claim obligations, proof state, and the preferred valid recovery transition.

The claim classifier runs before analysis, so standard depth executes only the
goal-specific analyzer subset once. Deep depth executes the complete registered
analyzer set once. The same claim classification is checked again at the proof
gate and `routing_consistency.stable` exposes any route drift.

`call_reduction` reports the equivalent separate surfaces, avoided follow-up calls, canonical graph-build count, and graph reuse. Treat these values as execution telemetry for the tool call, not proof that the repository behavior is correct.

Like the existing context path, `work` may update configured local derived graph/analyzer caches and bounded proof-accountability provenance. The returned `state_effect_contract` makes that distinction explicit. It does not authorize canonical memory/fiber changes or any source/repository mutation; use `cache_mode=off` when derived graph/analyzer cache writes are not wanted.

## Adaptive routing

Prefer an explicit `goal` when the task contract already supplies one:

| Goal | Evidence emphasis |
|---|---|
| `understand` | bounded source context and target brief |
| `change` | context, target blast radius, test reachability, and relevant risks |
| `architecture` | topology, boundaries, cycles, entrypoints, and HoTT observations |
| `performance` | async, deopt, allocation/GC, cache, and target risk observations |
| `runtime` | current source plus runtime claim obligations and attestation recovery path |
| `history` | current source precedence plus scoped memory continuity |
| `auto` | claim obligations first, then bounded task signals, then `understand` as the safe default |

Automatic selection is routing metadata only. Task terms must never turn workflow relevance on, satisfy a claim, authorize mutation, or substitute for runtime evidence.

Depth controls evidence breadth, not authority:

- `quick`: context and target brief; omit the broad analysis projection when unnecessary;
- `standard`: add analysis summary and a bounded goal-specific finding projection;
- `deep`: allow all analyzer families, a larger still-bounded finding projection,
  and the full context/proof objects instead of the standard compact-recoverable projection;
- `auto`: choose `quick` for a simple understand/history request and `standard` otherwise.

Standard/quick results retain the exact bounded `context_block`, source witness
hashes, proof statuses, ledger recovery pointers, and any preferred transition.
Fields omitted from that response projection are not treated as irrelevant;
request `depth=deep` only when their full diagnostic metadata is actually needed.

## Adaptive stop and escalation

Stop after one call only when `agent_decision_frame` shows the information needed by the task is sufficient for the next decision. `work_status=ready` means the reference pack is ready; it is not action readiness. Do not call `impact` and `outline` again when `target_evidence` already contains their combined brief.

When `work_status=recovery_required`, follow only the returned valid transition. Common examples:

- runtime claim without an admissible attestation → execute the exact runtime command outside PLW, preserve its output and exit code, then attest it explicitly;
- unresolved or ambiguous target → correct the target from returned candidates; never guess a basename;
- evidence omitted by budget → recover the named evidence unit or make one targeted context call;
- unusual memory/fiber/governance operation → use the explicit advanced invocation surface.

Use `mode=capabilities` only when an unusual operation cannot be selected from the schema or this module. Capability discovery should not become a compulsory call before ordinary work.

## Advanced invocation boundary

`agent_tool.py` accepts `surface=kernel|plw`, an explicit `mode`, and a bounded `arguments` array. It launches only the packaged PLW entrypoint without a shell. Operations that can change local memory, fiber, baseline, or cache state fail closed unless `allow_state_change` is literal `true`.

That acknowledgement is limited to local tool state. It does not authorize source changes, external repository mutation, external runtime execution, workflow transition execution, stable promotion, or truth commit.
