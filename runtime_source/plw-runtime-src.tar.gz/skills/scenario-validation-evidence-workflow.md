# Scenario-bound validation evidence workflow

**Load when:** F128 selected scenarios have been validated externally and returned evidence must be bound back to the exact plan/scenario identities.

**Provides:** F129 bounded evidence normalization, exact F128 plan binding, missing/unplanned/conflicting preservation, F131 receipt-versus-content provenance verification, a complete binding digest, and recovery paths.

**Return to:** [root skill router](../SKILL.md).

## Command

```bash
plw validation-evidence <plan.json> <evidence.json> [--store-dir <trust-store>] --json
```

The command never starts a validator, runtime, browser, or mutation. `--store-dir` reads one exact claimed F123 adapter observation receipt and verifies both its seal and its content binding.

## Evidence bundle

```json
{
  "schema_version": "scenario-validation-evidence-bundle-v1",
  "validation_plan_digest": "sha256:...",
  "observations": [
    {
      "scenario_id": "sha256:...",
      "validator_id": "playwright.layout.v1",
      "validator_run_ref": "run-42",
      "outcome": "PASS",
      "checks": [
        {"check_id": "constraint-1", "outcome": "PASS", "evidence_ids": ["sha256:..."]}
      ],
      "evidence_ids": ["sha256:..."],
      "provenance": {
        "lease_id": "sha256:...",
        "adapter_observation_id": "sha256:..."
      }
    }
  ]
}
```

`PASS`, `FAIL`, and `INDETERMINATE` are validator-local outcomes. They are never promoted automatically to global behavior/postcondition truth.

## Binding states

- `OBSERVED`: one or more observations exist and their top-level outcomes agree.
- `MISSING`: the selected F128 scenario has no returned evidence. Missing is not failure.
- `CONFLICTING`: returned validator outcomes disagree. F129 keeps every observation and chooses no winner.
- `UNPLANNED`: evidence names a scenario not selected by this F128 plan. It is preserved as recoverable reference evidence.

Requested F128 constraint IDs are compared with observed check IDs. Missing checks remain explicit and are not converted into failures.

## Optional F123 provenance

Before recording a validator result through F123, build this canonical
`validation.result` payload (the public helper is
`build_validation_observation_payload`):

```json
{
  "schema_version": "scenario-validation-observation-v1",
  "validation_plan_digest": "sha256:...",
  "scenario_id": "sha256:...",
  "validator_id": "playwright.layout.v1",
  "validator_run_ref": "run-42",
  "outcome": "PASS",
  "checks": [],
  "evidence_ids": []
}
```

Provenance is intentionally excluded from that payload because the receipt does
not exist until after recording. When evidence later carries both `lease_id` and
`adapter_observation_id`, F129 distinguishes:

- `receipt_verified=true`: the exact sealed receipt exists and verifies;
- `content_bound=true` / `verified=true`: its kind is `validation.result` and
  its recorded digest equals the canonical payload for this exact plan,
  scenario, validator result, checks, and evidence IDs;
- `F123_RECEIPT_VERIFIED_ONLY`: the receipt is real but its kind or payload does
  not match this evidence observation. A receipt replayed from another scenario
  therefore cannot satisfy exact provenance.

Without the trust store the claim remains `CLAIMED_UNVERIFIED`. Content-bound
provenance still does not prove truthful pixels, behavior, or postconditions.

## Binding integrity

`validation_evidence_binding_digest` uses the declared
`scenario-validation-evidence-binding-full-core-v2` policy and covers the full
F129 artifact. Consumers must recompute it and revalidate derived row/summary
state before projection. This unkeyed digest detects stale/tampered content; it
does **not** authenticate who issued the binding.

## Proof boundary

```text
F128 selected scenario      != executed validation
F129 OBSERVED               != postcondition proof
validator PASS              != global correctness
validator FAIL              != global behavior failure
missing evidence            != validation failure
conflicting evidence        != auto-resolved truth
F123 receipt                != pixel/behavior truth
F123 receipt                != matching evidence content
F129 digest                 != issuer authentication
F129                        != execution/mutation/truth authority
```

**Related modules — load only when needed:**

- To create the bounded scenario plan, load [Targeted validation scenario planning workflow](scenario-validation-planning-workflow.md).
- To inspect adapter/reconciliation provenance, load [Executor adapter reconciliation workflow](executor-adapter-reconciliation-workflow.md).
- To project returned evidence onto explicit obligations, load [Validation proof-obligation coverage workflow](validation-proof-obligation-workflow.md).
- To settle a behavior/postcondition claim after evidence review, load [Context and proof workflow](context-and-proof-workflow.md).
