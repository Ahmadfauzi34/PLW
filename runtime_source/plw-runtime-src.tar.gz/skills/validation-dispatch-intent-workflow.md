# Validation dispatch-intent workflow

**Load when:** one exact F135 attempt needs one durable pre-runtime dispatch intent.

**Provides:** F136 single-assignment intent, exact recovery, and the boundary before runtime dispatch.

**Return to:** [root skill router](../SKILL.md).

`plw validation-dispatch prepare` writes local coordination state only. One attempt owns at most one `dispatch_key`; exact replay recovers the same receipt. F136 may prepare an intent after F134 expiry because it grants no runtime authority and does not revive the lease.

```text
ATTEMPT_REGISTERED -> DISPATCH_INTENT_PREPARED
intent != runtime dispatch != validator result != evidence acceptance != truth
```

Machine state remains `runtime_dispatch_state=UNKNOWN_TO_F136` with `runtime_dispatch_authorized=false`.

**Related modules — load only when needed:**
- [Validation attempt workflow](validation-attempt-workflow.md)
- [Validation runtime dispatch workflow](validation-runtime-dispatch-workflow.md)
