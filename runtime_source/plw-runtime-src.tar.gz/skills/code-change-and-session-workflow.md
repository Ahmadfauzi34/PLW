# Code-Change and Session Workflow

**Load when:** editing/refactoring code, investigating performance, adding features, consolidating memory, or managing a work session.

**Provides:** pre-change evidence checks, bounded mutation paths, session/fiber operations, and post-change validation/settlement.

**Return to:** [SKILL.md routing map](../SKILL.md#9-skill-module-routing-map).

**Related modules — load only when needed:** [context and proof workflow](context-and-proof-workflow.md) for unresolved evidence or claims; [tool-call and CLI workflow](tool-call-and-cli-workflow.md) for command choice, graph safety, or release verification.

> On-demand reference. Mutation authority remains governed by `SKILL.md`.

## Before editing a file

```bash
STEP 1: Brief Check
  → plw brief <file>
  → BACA: change_risk_level, downstream_count, affected_entrypoints

  IF change_risk_level == "low" AND downstream_count < 3:
    → Langsung edit, tidak perlu analisis tambahan
  IF change_risk_level == "medium":
    → Lanjut STEP 2
  IF change_risk_level == "high":
    → WAJIB lanjut STEP 2 + STEP 3

STEP 2: Impact Drill-Down
  → plw impact <file>
  → BACA: downstream[], affected_entrypoints[], circular_references[]

  IF circular_references tidak kosong:
    → Waspadai cascade effect, refactor bertahap
```

## Before refactoring

```bash
STEP 1: Steering Check
  → plw steer

STEP 2: Targeted Risk
  → plw impact <target_file>
  → Pastikan tidak ada circular_references

STEP 3: Execute + Verify
  → Lakukan perubahan
  → python3 tools/ai_studio_tool/fixture_check.py
```

## Performance investigation

```
STEP 1: Full Performance Scan
  → hott_kernel.py analyze src --analyzers perf.async,perf.deopt,perf.gc,perf.cache --output findings

STEP 2: Prioritize
  → high: Address SEGERA
  → medium: Schedule perbaikan
  → low: Monitor

STEP 3: Cross-Reference dengan Topology
  → hott_kernel.py synthesize src --output summary
  → BACA: correlations[]
  IF orphan_with_issues: file bisa dihapus tanpa dampak
  IF circular_with_deopt: refactor critical diperlukan
```

## Adding a feature

```
STEP 1: Understand Architecture
  → hott_kernel.py analyze src --analyzers topo.entrypoint,topo.orphan --output findings

STEP 2: Identify Integration Point
  → hott_kernel.py outline <existing_related_file> src

STEP 3: Assess Impact Location
  → hott_kernel.py brief <target_file> src --output summary

STEP 4: Store Experience
  → hott_kernel.py xanalyze src --output summary
  (auto-store findings ke memory untuk pembelajaran masa depan)
```

## Memory consolidation

```
STEP 1: Check Trigger
  → hott_kernel.py memory steer --output summary
  → IF consolidation_candidate == true: lanjut

STEP 2: Explore Candidates
  → hott_kernel.py memory unconsolidated_tags

STEP 3: Auto Consolidate
  → hott_kernel.py memory consolidate_auto --min-group-size 3

STEP 4: Compact (Quotient Forgetting)
  → hott_kernel.py memory compact --consolidated --dry-run  (preview)
  → hott_kernel.py memory compact --consolidated            (execute)

STEP 5: Bridge (Connect Semantic Islands)
  → hott_kernel.py memory bridge_candidates --min-shared-tags 1
  → hott_kernel.py memory bridge_auto --min-shared-tags 1

STEP 6: Verify
  → hott_kernel.py memory betti_breakdown
  → PASTIKAN: directed_reasoning_cycle_witness_count == 0
  → JIKA β₁_reasoning > 0: bedakan diamond/parallel path dari directed loop
  → hott_kernel.py memory establish
```

## Fiber context management

```
STEP 1: Initialize Fiber
  → hott_kernel.py fiber init "<task>" "<focus>"

STEP 2: Lift Relevant Memories
  → hott_kernel.py fiber lift --query "<topik>" --max 5
  → hott_kernel.py fiber lift --tags "<domain_tag>" --max 5

STEP 3: Start Section (Benang Merah)
  → hott_kernel.py fiber section_start "<name>" "<narrative>"
  → hott_kernel.py fiber section_add <memory_id>

STEP 4: Monitor Fiber
  → hott_kernel.py fiber status

STEP 5: Descend (Saat Selesai)
  → hott_kernel.py fiber descend --all --reason "task_completed"

STEP 6: Switch Context (Jika Pindah Task)
  → hott_kernel.py fiber switch "<new_task>" "<new_focus>"
```

---

## Agent-loop integration

### Session start
```
1. hott_kernel.py xsteer src --output summary
2. BACA: drift, consolidation_candidate, archetype
3. IF drift != "none": establish baseline
4. IF consolidation_candidate: jalankan bagian `Memory consolidation`
```

### Before an edit
```
1. hott_kernel.py context "<task>" src --target <file> --output prompt
2. hott_kernel.py brief <file> src --output summary  (jika perlu drill-down)
3. Baca blok `[PROJECT MEMORY EVIDENCE]` yang sudah dibudgetkan
4. hott_kernel.py xcontext <file> hanya jika perlu inspeksi memory lebih luas
5. Keputusan berdasarkan graph evidence + risk + memory context terverifikasi
```

### After a major change
```
1. hott_kernel.py xanalyze src --output summary
2. hott_kernel.py establish src
3. python3 tools/ai_studio_tool/fixture_check.py
4. IF consolidation_candidate: jalankan bagian `Memory consolidation`
```

### Before session end
```
1. hott_kernel.py fiber descend --all --reason "session_end"
2. hott_kernel.py memory steer --output summary
3. Simpan insight penting ke memory:
   hott_kernel.py memory store semantic "<insight>" --tags "session_learnings"
```

## Causal lineage and downstream cost

- Carry causal lineage explicitly when a follow-up is caused by a prior projection/transition. Use `--lineage sha256:<id>` on `plw context`, `plw transitions`, `compact-output`, or `recover-output` when the parent decision is known. Never infer causality from query similarity, command similarity, or timing alone. `plw lineage <id>` is an audit/reference trace, not truth evidence.
- Account for downstream token cost only through proved links. Context re-expansion may debit an earlier strategy return only when it is an explicit descendant in decision lineage. Missing lineage means causal attribution remains unknown; do not invent responsibility.

## Runtime proof settlement

Untuk claim runtime seperti “tests pass sekarang?” atau “apakah behavior ini benar-benar berjalan?”, jangan gunakan memory/static analyzer sebagai substitusi. Workflow wajib:

```text
external execution
→ plw compact-output
→ plw attest-runtime (output-id + exit code + claim + target + scope + snapshot)
→ plw context / claim gate ulang
→ jika claim settled: transition outcome dicatat sebagai policy memory
```

Attestation bukan proof conclusion. Ia hanya witness `current_runtime_observation` yang sah untuk scope/snapshot/target tersebut. Baca `exit_code` dan exact output/recovery sebelum menyimpulkan PASS/FAIL atau behavior.
