"""Counterfactual UI causal-isolation probes.

This is a practical consumer of Cross-Domain Diagnosis + Targeted Runtime
Reproduction. It reruns the exact diagnosed scenario under explicit browser-side
interventions bound to structural candidates and reports whether the expected UI
symptom is sensitive to each intervention.

COUNTERFACTUAL_SUPPORT is evidence that an intervention changed the symptom. It
is not root-cause proof: interventions can be broad, correlated, or affect a
shared downstream mechanism. Source is never mutated by this module.
"""
from __future__ import annotations

import os
from pathlib import Path
import tempfile
from typing import Any, Dict, List, Mapping, Optional, Sequence

from ui.common import canonical_ui_digest
from ui.reproduce import (
    UIReproductionError,
    execute_targeted_ui_reproduction,
    _select_diagnosis,
)

UI_CAUSAL_PROBE_PLAN_SCHEMA_VERSION = "ui-causal-probe-plan-v1"
UI_CAUSAL_ISOLATION_SCHEMA_VERSION = "ui-causal-isolation-v1"
MAX_PROBES = 24
MAX_INLINE_JS_BYTES = 128 * 1024


class UICausalProbeError(RuntimeError):
    pass


def _structural_candidates(selected: Mapping[str, Any]) -> List[Mapping[str, Any]]:
    structural = selected.get("structural_context") if isinstance(selected.get("structural_context"), Mapping) else {}
    return [row for row in structural.get("structural_cause_candidates", []) or [] if isinstance(row, Mapping)]


def _path_key(path: str) -> str:
    return os.path.normcase(os.path.normpath(str(path)))


def build_ui_causal_probe_plan(
    diagnosis: Mapping[str, Any],
    *,
    candidate_id: Optional[str] = None,
    max_candidates: int = 12,
) -> Dict[str, Any]:
    if isinstance(max_candidates, bool) or not isinstance(max_candidates, int) or not 1 <= max_candidates <= MAX_PROBES:
        raise UICausalProbeError(f"max_candidates must be between 1 and {MAX_PROBES}")
    try:
        selected = _select_diagnosis(diagnosis, candidate_id)
    except UIReproductionError as exc:
        raise UICausalProbeError(str(exc)) from exc

    rows = []
    for index, candidate in enumerate(_structural_candidates(selected)[:max_candidates], start=1):
        path = str(candidate.get("path") or "")
        role = str(candidate.get("role") or "structural_candidate")
        if role == "style_owner":
            suggested = "apply a narrowly scoped CSS/DOM style override that changes only the suspected layout mechanism"
        elif role in {"layout_state_owner", "state_owner", "service_dependency"}:
            suggested = "use an application/runtime hook to toggle only the suspected state or service outcome"
        elif role in {"template_owner", "render_owner"}:
            suggested = "use a DOM/runtime intervention that isolates the suspected rendered structure without mutating source"
        else:
            suggested = "supply the smallest browser-side intervention that selectively changes this candidate's effect"
        rows.append({
            "probe_id": f"probe-{index}",
            "structural_path": path,
            "role": role,
            "structural_score": candidate.get("structural_score"),
            "suggested_intervention": suggested,
            "intervention": {
                "javascript": None,
                "required": True,
            },
        })

    plan = {
        "schema_version": UI_CAUSAL_PROBE_PLAN_SCHEMA_VERSION,
        "candidate_id": selected.get("candidate_id"),
        "category": selected.get("category"),
        "scenario": (selected.get("targeted_reproduction") or {}).get("minimum_scenario"),
        "probes": rows,
        "instructions": {
            "baseline_requirement": "the exact diagnosed symptom must reproduce before interventions are interpreted",
            "intervention_scope": "change one candidate mechanism at a time; do not mutate repository source",
            "positive_result": "symptom disappears or no longer matches the expected observation",
            "negative_result": "symptom remains reproduced under the intervention",
        },
        "authority": {
            "executes_browser": False,
            "mutates_source": False,
            "root_cause_proven": False,
            "truth_committed": False,
        },
        "proof_boundary": {
            "counterfactual_support_is_root_cause_proof": False,
            "topology_proximity_is_causality": False,
            "generated_plan_is_execution_authority": False,
        },
    }
    plan["probe_plan_digest"] = canonical_ui_digest({k: v for k, v in plan.items() if k != "probe_plan_digest"})
    return plan


def _load_inline_js(probe: Mapping[str, Any]) -> str:
    intervention = probe.get("intervention") if isinstance(probe.get("intervention"), Mapping) else {}
    js = intervention.get("javascript")
    if not isinstance(js, str) or not js.strip():
        raise UICausalProbeError(f"probe {probe.get('probe_id') or '?'} has no intervention.javascript")
    if len(js.encode("utf-8")) > MAX_INLINE_JS_BYTES:
        raise UICausalProbeError(f"probe {probe.get('probe_id') or '?'} intervention exceeds {MAX_INLINE_JS_BYTES} bytes")
    return js


def _read_optional_setup(path: Optional[str]) -> str:
    if not path:
        return ""
    try:
        raw = Path(path).read_bytes()
    except OSError as exc:
        raise UICausalProbeError(f"base setup unavailable: {type(exc).__name__}") from exc
    if len(raw) > MAX_INLINE_JS_BYTES:
        raise UICausalProbeError(f"base setup exceeds {MAX_INLINE_JS_BYTES} bytes")
    try:
        return raw.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise UICausalProbeError("base setup must be UTF-8") from exc


def execute_ui_causal_isolation(
    diagnosis: Mapping[str, Any],
    probe_plan: Mapping[str, Any],
    *,
    angular_ownership: Mapping[str, Any],
    candidate_id: Optional[str] = None,
    url: Optional[str] = None,
    html_file: Optional[str] = None,
    base_setup_js_file: Optional[str] = None,
    browser: Optional[str] = None,
    timeout_seconds: int = 20,
    min_gap_px: float = 0.0,
    max_nodes: int = 5000,
) -> Dict[str, Any]:
    try:
        selected = _select_diagnosis(diagnosis, candidate_id or probe_plan.get("candidate_id"))
    except UIReproductionError as exc:
        raise UICausalProbeError(str(exc)) from exc
    plan_candidate = probe_plan.get("candidate_id")
    if plan_candidate and plan_candidate != selected.get("candidate_id"):
        raise UICausalProbeError("probe plan candidate_id does not match selected diagnosis candidate")
    probes = [row for row in probe_plan.get("probes", []) or [] if isinstance(row, Mapping)]
    if not probes:
        raise UICausalProbeError("probe plan contains no probes")
    if len(probes) > MAX_PROBES:
        raise UICausalProbeError(f"probe plan exceeds {MAX_PROBES} probes")

    known = {_path_key(str(row.get("path") or "")): row for row in _structural_candidates(selected) if row.get("path")}
    base_setup = _read_optional_setup(base_setup_js_file)
    baseline = execute_targeted_ui_reproduction(
        diagnosis,
        angular_ownership=angular_ownership,
        candidate_id=str(selected.get("candidate_id")),
        url=url,
        html_file=html_file,
        setup_js_file=base_setup_js_file,
        browser=browser,
        timeout_seconds=timeout_seconds,
        min_gap_px=min_gap_px,
        max_nodes=max_nodes,
    )

    result: Dict[str, Any] = {
        "schema_version": UI_CAUSAL_ISOLATION_SCHEMA_VERSION,
        "candidate_id": selected.get("candidate_id"),
        "category": selected.get("category"),
        "baseline_reproduction": {
            "state": baseline.get("reproduction_state"),
            "reason": baseline.get("reason"),
            "reproduction_digest": baseline.get("reproduction_digest"),
        },
        "scenario": baseline.get("requested_scenario"),
        "probes": [],
        "summary": {},
        "authority": {
            "browser_executed_by_plw": True,
            "counterfactual_support_observed": False,
            "root_cause_proven": False,
            "postcondition_proven": False,
            "source_mutated": False,
            "stable_promoted": False,
            "truth_committed": False,
        },
        "proof_boundary": {
            "counterfactual_support_is_root_cause_proof": False,
            "symptom_sensitivity_is_unique_causality": False,
            "structural_candidate_is_causal_owner": False,
            "source_repository_is_not_mutated": True,
        },
    }

    if baseline.get("reproduction_state") != "REPRODUCED":
        result["isolation_state"] = "UNRESOLVED_BASELINE"
        result["reason"] = "baseline_symptom_not_reproduced"
        result["summary"] = {"probe_count": 0, "counterfactual_support_count": 0, "no_support_count": 0, "inconclusive_count": 0}
        result["isolation_digest"] = canonical_ui_digest({k: v for k, v in result.items() if k != "isolation_digest"})
        return result

    rows: List[Dict[str, Any]] = []
    with tempfile.TemporaryDirectory(prefix="plw-ui-causal-probe-", ignore_cleanup_errors=True) as tmp:
        tmpdir = Path(tmp)
        for index, probe in enumerate(probes, start=1):
            probe_id = str(probe.get("probe_id") or f"probe-{index}")
            structural_path = str(probe.get("structural_path") or "")
            bound = known.get(_path_key(structural_path)) if structural_path else None
            js = _load_inline_js(probe)
            setup = "\n".join(part for part in (base_setup, f"/* PLW causal probe: {probe_id} */\n{js}") if part.strip())
            setup_path = tmpdir / f"{index:02d}.js"
            setup_path.write_text(setup, encoding="utf-8")
            observed = execute_targeted_ui_reproduction(
                diagnosis,
                angular_ownership=angular_ownership,
                candidate_id=str(selected.get("candidate_id")),
                url=url,
                html_file=html_file,
                setup_js_file=str(setup_path),
                browser=browser,
                timeout_seconds=timeout_seconds,
                min_gap_px=min_gap_px,
                max_nodes=max_nodes,
            )
            state = str(observed.get("reproduction_state") or "UNRESOLVED")
            if state == "NOT_REPRODUCED":
                probe_state = "SYMPTOM_SENSITIVE"
                evidence = "COUNTERFACTUAL_SUPPORT" if bound else "UNBOUND_COUNTERFACTUAL_SIGNAL"
            elif state == "REPRODUCED":
                probe_state = "SYMPTOM_PERSISTS"
                evidence = "NO_SUPPORT"
            else:
                probe_state = "INCONCLUSIVE"
                evidence = "INCONCLUSIVE"
            rows.append({
                "probe_id": probe_id,
                "structural_path": structural_path or None,
                "structural_candidate_bound": bool(bound),
                "role": (bound or {}).get("role") if isinstance(bound, Mapping) else probe.get("role"),
                "structural_score": (bound or {}).get("structural_score") if isinstance(bound, Mapping) else probe.get("structural_score"),
                "probe_state": probe_state,
                "causal_evidence_state": evidence,
                "runtime_reproduction_state": state,
                "runtime_reason": observed.get("reason"),
                "reproduction_digest": observed.get("reproduction_digest"),
                "root_cause_proven": False,
            })

    support = [row for row in rows if row["causal_evidence_state"] == "COUNTERFACTUAL_SUPPORT"]
    no_support = [row for row in rows if row["causal_evidence_state"] == "NO_SUPPORT"]
    inconclusive = [row for row in rows if row["causal_evidence_state"] in {"INCONCLUSIVE", "UNBOUND_COUNTERFACTUAL_SIGNAL"}]
    ranked = sorted(
        rows,
        key=lambda row: (
            0 if row["causal_evidence_state"] == "COUNTERFACTUAL_SUPPORT" else 1 if row["causal_evidence_state"] == "NO_SUPPORT" else 2,
            -int(row.get("structural_score") or 0),
            str(row.get("structural_path") or row.get("probe_id")),
        ),
    )
    result.update({
        "isolation_state": "COUNTERFACTUAL_SUPPORT_FOUND" if support else ("NO_COUNTERFACTUAL_SUPPORT" if no_support and not inconclusive else "INCONCLUSIVE"),
        "reason": "one_or_more_bound_interventions_removed_expected_symptom" if support else ("tested_interventions_did_not_remove_expected_symptom" if no_support and not inconclusive else "probe_results_are_incomplete_or_unbound"),
        "probes": rows,
        "ranked_candidates": ranked,
        "summary": {
            "probe_count": len(rows),
            "counterfactual_support_count": len(support),
            "no_support_count": len(no_support),
            "inconclusive_count": len(inconclusive),
        },
    })
    result["authority"]["counterfactual_support_observed"] = bool(support)
    result["isolation_digest"] = canonical_ui_digest({k: v for k, v in result.items() if k != "isolation_digest"})
    return result


__all__ = [
    "UI_CAUSAL_PROBE_PLAN_SCHEMA_VERSION",
    "UI_CAUSAL_ISOLATION_SCHEMA_VERSION",
    "UICausalProbeError",
    "build_ui_causal_probe_plan",
    "execute_ui_causal_isolation",
]
