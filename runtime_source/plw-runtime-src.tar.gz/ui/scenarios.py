"""Scenario/responsive projection for PLW UI Mapper V2.

Consumes multiple normalized GeometrySnapshot states from one code revision and
builds a bounded cross-scenario map for agent reasoning.  It does not claim
regression, execute a browser, merge topology with geometry, mutate source, or
commit truth.  Detailed cross-revision regression classification belongs to a
later geometry-diff layer.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

from codebase.geometry_correspondence import normalize_geometry_snapshot
from ui.mapper import UIMapperError, build_ui_map
from ui.common import canonical_ui_digest, finite_number, node_bbox, snapshot_node_index

UI_SCENARIO_MAP_SCHEMA_VERSION = "ui-scenario-map-v2"
DEFAULT_MAX_SCENARIOS = 32
MAX_SCENARIOS = 128
DEFAULT_MAX_ELEMENTS = 500
MAX_ELEMENTS = 50_000
DEFAULT_MAX_ISSUE_PATTERNS = 200
MAX_ISSUE_PATTERNS = 5_000



def _normalizednode_bbox(node: Mapping[str, Any], scenario: Mapping[str, Any]) -> Dict[str, float]:
    box = node_bbox(node)
    viewport = scenario.get("viewport") if isinstance(scenario.get("viewport"), Mapping) else {}
    width = max(finite_number(viewport.get("width")), 1.0)
    height = max(finite_number(viewport.get("height")), 1.0)
    return {
        "x": box["x"] / width,
        "y": box["y"] / height,
        "width": box["width"] / width,
        "height": box["height"] / height,
    }


def _identity_quality(ui_id: str) -> str:
    if ui_id.startswith(("plw:", "id:", "testid:")):
        return "STABLE_ANCHOR"
    if ui_id.startswith("dom:"):
        return "STRUCTURAL_PATH"
    return "CALLER_DEFINED"


def _issue_signature(issue: Mapping[str, Any]) -> str:
    kind = str(issue.get("kind") or "UNKNOWN")
    ui_ids = sorted(str(value) for value in (issue.get("ui_ids") or []) if isinstance(value, str))
    return f"{kind}|{'|'.join(ui_ids)}"


def _max_range(values: Iterable[float]) -> float:
    vals = list(values)
    return max(vals) - min(vals) if vals else 0.0


def _responsive_class(samples: Sequence[Mapping[str, Any]]) -> Tuple[str, float]:
    """Heuristic responsive variation only; never a regression verdict."""
    visible = [sample for sample in samples if sample.get("visible") is True]
    if len(visible) < 2:
        return "INSUFFICIENT_VISIBLE_SAMPLES", 0.0
    boxes = [sample.get("normalized_bbox", {}) for sample in visible]
    variation = max(
        _max_range(finite_number(box.get(axis)) for box in boxes)
        for axis in ("x", "y", "width", "height")
    )
    if variation <= 0.02:
        return "RELATIVELY_STABLE", variation
    if variation <= 0.15:
        return "RESPONSIVE_VARIATION", variation
    return "MAJOR_LAYOUT_SHIFT", variation


def _scenario_key(scenario: Mapping[str, Any]) -> str:
    viewport = scenario.get("viewport") if isinstance(scenario.get("viewport"), Mapping) else {}
    return (
        f"{scenario.get('route')}|{int(finite_number(viewport.get('width')))}x{int(finite_number(viewport.get('height')))}|"
        f"{scenario.get('ui_state')}|{scenario.get('data_fixture')}"
    )


def _responsive_group_key(scenario: Mapping[str, Any]) -> Tuple[str, str, str]:
    return (
        str(scenario.get("route") or ""),
        str(scenario.get("ui_state") or ""),
        str(scenario.get("data_fixture") or ""),
    )


def _owner_consensus(samples: Sequence[Mapping[str, Any]]) -> Dict[str, Any]:
    owners = [sample.get("code_owner") for sample in samples if isinstance(sample.get("code_owner"), Mapping)]
    if not owners:
        return {"status": "UNRESOLVED", "owner": None}
    digests = Counter(canonical_ui_digest(owner) for owner in owners)
    winner, count = digests.most_common(1)[0]
    owner = next(dict(value) for value in owners if canonical_ui_digest(value) == winner)
    return {
        "status": "CONSISTENT" if len(digests) == 1 else "CONFLICTING",
        "owner": owner,
        "observed_owner_variants": len(digests),
        "support_count": count,
    }


def build_ui_scenario_map(
    snapshots: Sequence[Mapping[str, Any]],
    *,
    ui_references: Optional[Sequence[Optional[Mapping[str, Any]]]] = None,
    angular_ownership: Optional[Mapping[str, Any]] = None,
    min_gap_px: float = 0.0,
    max_elements: int = DEFAULT_MAX_ELEMENTS,
    max_issues: int = 100,
    max_scenarios: int = DEFAULT_MAX_SCENARIOS,
    max_issue_patterns: int = DEFAULT_MAX_ISSUE_PATTERNS,
) -> Dict[str, Any]:
    if not isinstance(snapshots, Sequence) or isinstance(snapshots, (str, bytes)):
        raise UIMapperError("snapshots must be a sequence")
    if len(snapshots) < 2:
        raise UIMapperError("scenario mapping requires at least two snapshots")
    if isinstance(max_scenarios, bool) or not isinstance(max_scenarios, int) or not 2 <= max_scenarios <= MAX_SCENARIOS:
        raise UIMapperError(f"max_scenarios must be between 2 and {MAX_SCENARIOS}")
    if len(snapshots) > max_scenarios:
        raise UIMapperError(f"snapshot count exceeds max_scenarios={max_scenarios}")
    if isinstance(max_elements, bool) or not isinstance(max_elements, int) or not 1 <= max_elements <= MAX_ELEMENTS:
        raise UIMapperError(f"max_elements must be between 1 and {MAX_ELEMENTS}")
    if isinstance(max_issue_patterns, bool) or not isinstance(max_issue_patterns, int) or not 1 <= max_issue_patterns <= MAX_ISSUE_PATTERNS:
        raise UIMapperError(f"max_issue_patterns must be between 1 and {MAX_ISSUE_PATTERNS}")
    if ui_references is not None and len(ui_references) != len(snapshots):
        raise UIMapperError("ui_references length must match snapshots")

    normalized = [normalize_geometry_snapshot(dict(snapshot)) for snapshot in snapshots]
    revisions = sorted({str(item["scenario"]["code_revision"]) for item in normalized})
    if len(revisions) != 1:
        raise UIMapperError(
            "UI Mapper V2 scenario mapping requires one code_revision; cross-revision comparison belongs to geometry diff"
        )
    scenario_ids = [str(item["scenario_id"]) for item in normalized]
    if len(set(scenario_ids)) != len(scenario_ids):
        raise UIMapperError("duplicate scenario_id in scenario set")

    references = list(ui_references) if ui_references is not None else [None] * len(normalized)
    maps = [
        build_ui_map(
            snapshots[index],
            ui_reference=references[index],
            angular_ownership=angular_ownership,
            min_gap_px=min_gap_px,
            max_elements=max_elements,
            max_issues=max_issues,
        )
        for index in range(len(normalized))
    ]

    scenario_rows: List[Dict[str, Any]] = []
    scenario_by_id: Dict[str, Dict[str, Any]] = {}
    map_by_id: Dict[str, Mapping[str, Any]] = {}
    element_samples: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    issue_occurrences: Dict[str, Dict[str, Any]] = {}

    for snapshot, ui_map in zip(normalized, maps):
        sid = str(snapshot["scenario_id"])
        scenario = dict(snapshot["scenario"])
        row = {
            "scenario_id": sid,
            "scenario_key": _scenario_key(scenario),
            "route": scenario["route"],
            "viewport": scenario["viewport"],
            "ui_state": scenario["ui_state"],
            "data_fixture": scenario["data_fixture"],
            "geometry_snapshot_digest": snapshot["geometry_snapshot_digest"],
            "ui_map_digest": ui_map["ui_map_digest"],
            "node_count": ui_map["summary"]["node_count"],
            "visible_node_count": ui_map["summary"]["visible_node_count"],
            "issue_count": ui_map["summary"]["issue_count"],
            "issues_by_kind": ui_map["summary"]["issues_by_kind"],
        }
        scenario_rows.append(row)
        scenario_by_id[sid] = row
        map_by_id[sid] = ui_map
        elements = ui_map.get("hierarchy", {}).get("elements", [])
        for element in elements:
            if not isinstance(element, Mapping) or not isinstance(element.get("ui_id"), str):
                continue
            ui_id = str(element["ui_id"])
            node = snapshot_node_index(snapshot).get(ui_id)
            if node is None:
                continue
            geometry = node.get("geometry") if isinstance(node.get("geometry"), Mapping) else {}
            element_samples[ui_id].append({
                "scenario_id": sid,
                "scenario_key": row["scenario_key"],
                "viewport": scenario["viewport"],
                "visible": geometry.get("visible"),
                "bbox": node_bbox(node),
                "normalized_bbox": _normalizednode_bbox(node, scenario),
                "z_index": geometry.get("z_index"),
                "parent_ui_id": node.get("parent_ui_id"),
                "code_owner": element.get("code_owner"),
            })
        for issue in ui_map.get("issues", []):
            if not isinstance(issue, Mapping):
                continue
            signature = _issue_signature(issue)
            state = issue_occurrences.setdefault(signature, {
                "signature": signature,
                "kind": issue.get("kind"),
                "ui_ids": sorted(issue.get("ui_ids") or []),
                "max_severity": issue.get("severity"),
                "scenario_ids": [],
            })
            state["scenario_ids"].append(sid)
            severity_rank = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "INFO": 4}
            if severity_rank.get(str(issue.get("severity")), 99) < severity_rank.get(str(state.get("max_severity")), 99):
                state["max_severity"] = issue.get("severity")

    all_sids = set(scenario_ids)
    element_rows: List[Dict[str, Any]] = []
    for ui_id in sorted(element_samples)[:max_elements]:
        samples = sorted(element_samples[ui_id], key=lambda row: row["scenario_key"])
        present = {str(sample["scenario_id"]) for sample in samples}
        visible_count = sum(1 for sample in samples if sample.get("visible") is True)
        responsive_class, normalized_variation = _responsive_class(samples)
        parent_values = sorted({str(sample.get("parent_ui_id")) for sample in samples if sample.get("parent_ui_id")})
        z_values = sorted({str(sample.get("z_index")) for sample in samples if sample.get("z_index") is not None})
        element_rows.append({
            "ui_id": ui_id,
            "identity_quality": _identity_quality(ui_id),
            "presence_class": "ALWAYS_PRESENT" if present == all_sids else "CONDITIONAL",
            "visibility_class": (
                "ALWAYS_VISIBLE" if visible_count == len(scenario_ids)
                else "NEVER_VISIBLE" if visible_count == 0
                else "CONDITIONAL_VISIBLE"
            ),
            "present_in_scenario_ids": sorted(present),
            "missing_from_scenario_ids": sorted(all_sids - present),
            "responsive_class": responsive_class,
            "max_normalized_geometry_variation": normalized_variation,
            "parent_variants": parent_values,
            "z_index_variants": z_values,
            "owner_consensus": _owner_consensus(samples),
            "samples": samples,
        })

    omitted_elements = max(0, len(element_samples) - len(element_rows))
    issue_rows: List[Dict[str, Any]] = []
    for row in issue_occurrences.values():
        occurrences = set(str(value) for value in row["scenario_ids"])
        issue_rows.append({
            **row,
            "scenario_ids": sorted(occurrences),
            "presence_class": "PERSISTENT" if occurrences == all_sids else "SCENARIO_SPECIFIC",
            "missing_from_scenario_ids": sorted(all_sids - occurrences),
        })
    severity_rank = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "INFO": 4}
    issue_rows.sort(key=lambda row: (severity_rank.get(str(row.get("max_severity")), 99), str(row.get("kind")), row.get("ui_ids", [])))
    total_issue_patterns = len(issue_rows)
    issue_rows = issue_rows[:max_issue_patterns]

    groups: Dict[Tuple[str, str, str], List[Dict[str, Any]]] = defaultdict(list)
    for row in scenario_rows:
        groups[_responsive_group_key(row)].append(row)
    responsive_groups = []
    for (route, ui_state, fixture), rows in sorted(groups.items()):
        viewport_keys = {
            (int(finite_number(row["viewport"].get("width"))), int(finite_number(row["viewport"].get("height"))))
            for row in rows
        }
        if len(viewport_keys) < 2:
            continue
        group_sids = {str(row["scenario_id"]) for row in rows}
        varying = [
            element["ui_id"]
            for element in element_rows
            if len(group_sids.intersection(element["present_in_scenario_ids"])) >= 2
            and element["responsive_class"] in {"RESPONSIVE_VARIATION", "MAJOR_LAYOUT_SHIFT"}
        ]
        responsive_groups.append({
            "route": route,
            "ui_state": ui_state,
            "data_fixture": fixture,
            "scenario_ids": sorted(group_sids),
            "viewports": [
                {"width": width, "height": height}
                for width, height in sorted(viewport_keys)
            ],
            "responsive_element_count": len(varying),
            "responsive_ui_ids": varying[:50],
            "responsive_ui_ids_omitted": max(0, len(varying) - 50),
        })

    routes = sorted({str(row["route"]) for row in scenario_rows})
    states = sorted({str(row["ui_state"]) for row in scenario_rows})
    fixtures = sorted({str(row["data_fixture"]) for row in scenario_rows})
    viewports = sorted({
        (int(finite_number(row["viewport"].get("width"))), int(finite_number(row["viewport"].get("height"))))
        for row in scenario_rows
    })
    conditional_count = sum(1 for row in element_rows if row["presence_class"] == "CONDITIONAL")
    major_shift_count = sum(1 for row in element_rows if row["responsive_class"] == "MAJOR_LAYOUT_SHIFT")
    scenario_specific_issues = sum(1 for row in issue_rows if row["presence_class"] == "SCENARIO_SPECIFIC")

    result: Dict[str, Any] = {
        "schema_version": UI_SCENARIO_MAP_SCHEMA_VERSION,
        "code_revision": revisions[0],
        "scenario_count": len(scenario_rows),
        "scenario_axes": {
            "routes": routes,
            "viewports": [{"width": width, "height": height} for width, height in viewports],
            "ui_states": states,
            "data_fixtures": fixtures,
            "observed_combinations": len(scenario_rows),
            "coverage_is_observed_only": True,
        },
        "scenarios": sorted(scenario_rows, key=lambda row: row["scenario_key"]),
        "elements": element_rows,
        "responsive_groups": responsive_groups,
        "issue_patterns": issue_rows,
        "summary": {
            "unique_ui_id_count": len(element_samples),
            "returned_ui_id_count": len(element_rows),
            "omitted_ui_id_count": omitted_elements,
            "conditional_ui_id_count": conditional_count,
            "major_layout_shift_count": major_shift_count,
            "issue_pattern_count": total_issue_patterns,
            "returned_issue_pattern_count": len(issue_rows),
            "omitted_issue_pattern_count": max(0, total_issue_patterns - len(issue_rows)),
            "scenario_specific_issue_pattern_count": scenario_specific_issues,
            "responsive_group_count": len(responsive_groups),
        },
        "agent_brief": {
            "interpretation": "cross-scenario rendered-layout map for one code revision",
            "conditional_ui_ids": [row["ui_id"] for row in element_rows if row["presence_class"] == "CONDITIONAL"][:30],
            "major_shift_ui_ids": [row["ui_id"] for row in element_rows if row["responsive_class"] == "MAJOR_LAYOUT_SHIFT"][:30],
            "scenario_specific_issues": [
                {"kind": row["kind"], "ui_ids": row["ui_ids"], "scenario_ids": row["scenario_ids"]}
                for row in issue_rows if row["presence_class"] == "SCENARIO_SPECIFIC"
            ][:30],
            "next_action": "inspect scenario-specific geometry/owners; do not label responsive differences as regressions without cross-revision evidence",
        },
        "authority": {
            "geometry_authority": "codebase.geometry_correspondence.GeometrySnapshot",
            "correspondence_authority": "codebase.geometry_correspondence.UIAngularCorrespondence when provided",
            "scenario_map_is_derived_view": True,
            "responsive_classification_is_heuristic": True,
            "cross_revision_regression_claimed": False,
            "browser_executed": False,
            "source_mutated": False,
            "truth_committed": False,
        },
    }
    result["scenario_map_digest"] = canonical_ui_digest({
        "code_revision": result["code_revision"],
        "scenarios": result["scenarios"],
        "elements": result["elements"],
        "responsive_groups": result["responsive_groups"],
        "issue_patterns": result["issue_patterns"],
    })
    return result


__all__ = [
    "UI_SCENARIO_MAP_SCHEMA_VERSION",
    "DEFAULT_MAX_SCENARIOS",
    "MAX_SCENARIOS",
    "build_ui_scenario_map",
]
