"""Small neutral helpers shared by practical UI mapper consumers."""
from __future__ import annotations

import hashlib
import json
import math
from typing import Any, Dict, Mapping


def canonical_ui_digest(value: Any) -> str:
    encoded = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    return f"sha256:{hashlib.sha256(encoded).hexdigest()}"


def finite_number(value: Any, default: float = 0.0) -> float:
    if isinstance(value, bool):
        return default
    try:
        out = float(value)
    except (TypeError, ValueError):
        return default
    return out if math.isfinite(out) else default


def snapshot_node_index(snapshot: Mapping[str, Any]) -> Dict[str, Mapping[str, Any]]:
    return {
        str(row.get("ui_id")): row
        for row in snapshot.get("nodes", []) or []
        if isinstance(row, Mapping) and isinstance(row.get("ui_id"), str)
    }


def node_bbox(node: Mapping[str, Any]) -> Dict[str, float]:
    geometry = node.get("geometry") if isinstance(node.get("geometry"), Mapping) else {}
    box = geometry.get("bbox") if isinstance(geometry.get("bbox"), Mapping) else {}
    return {key: finite_number(box.get(key)) for key in ("x", "y", "width", "height")}


__all__ = ["canonical_ui_digest", "finite_number", "snapshot_node_index", "node_bbox"]
