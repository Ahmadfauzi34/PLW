"""Cross-revision GeometrySnapshot diff for PLW UI Mapper V3.

Compares one exact rendered scenario across two code revisions.  It derives
layout change facts from GeometrySnapshot/UI Map authorities without claiming
that every change is a bug.  Bug classification belongs to the later UI Bug
Hunter layer.
"""
from __future__ import annotations

import math
from collections import Counter
from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple

from codebase.geometry_correspondence import normalize_geometry_snapshot
from ui.common import canonical_ui_digest, finite_number, node_bbox, snapshot_node_index
from ui.mapper import UIMapperError, build_ui_map

UI_GEOMETRY_DIFF_SCHEMA_VERSION = "ui-geometry-diff-v3"
DEFAULT_MOVE_THRESHOLD_PX = 2.0
DEFAULT_SIZE_THRESHOLD_PX = 2.0
DEFAULT_MAX_CHANGES = 500
MAX_CHANGES = 10_000



def _scenario_identity(scenario: Mapping[str, Any]) -> Dict[str, Any]:
    viewport = scenario.get("viewport") if isinstance(scenario.get("viewport"), Mapping) else {}
    return {
        "route": str(scenario.get("route") or ""),
        "viewport": {
            "width": finite_number(viewport.get("width")),
            "height": finite_number(viewport.get("height")),
            "device_scale_factor": finite_number(viewport.get("device_scale_factor"), 1.0),
        },
        "ui_state": str(scenario.get("ui_state") or ""),
        "data_fixture": str(scenario.get("data_fixture") or ""),
    }




def _center(box: Mapping[str, Any]) -> Tuple[float, float]:
    return (
        finite_number(box.get("x")) + finite_number(box.get("width")) / 2.0,
        finite_number(box.get("y")) + finite_number(box.get("height")) / 2.0,
    )


def _owner_index(ui_map: Mapping[str, Any]) -> Dict[str, Mapping[str, Any]]:
    result: Dict[str, Mapping[str, Any]] = {}
    hierarchy = ui_map.get("hierarchy") if isinstance(ui_map.get("hierarchy"), Mapping) else {}
    for row in hierarchy.get("elements", []) or []:
        if isinstance(row, Mapping) and isinstance(row.get("ui_id"), str) and isinstance(row.get("code_owner"), Mapping):
            result[str(row["ui_id"])] = row["code_owner"]
    return result


def _issue_signature(issue: Mapping[str, Any]) -> str:
    kind = str(issue.get("kind") or "UNKNOWN")
    ui_ids = sorted(str(value) for value in issue.get("ui_ids", []) or [] if isinstance(value, str))
    return f"{kind}|{'|'.join(ui_ids)}"


def _issue_index(ui_map: Mapping[str, Any]) -> Dict[str, Mapping[str, Any]]:
    return {
        _issue_signature(row): row
        for row in ui_map.get("issues", []) or []
        if isinstance(row, Mapping)
    }


def _change_severity(kind: str, *, interactive: bool = False) -> str:
    if kind in {"NEW_OVERLAP", "NEW_OUTSIDE_VIEWPORT"}:
        return "HIGH" if interactive else "MEDIUM"
    if kind in {"NEW_INTERACTIVE_GAP", "NEW_EXTENDS_PARENT_BOUNDS", "Z_ORDER_CHANGED"}:
        return "MEDIUM" if interactive else "LOW"
    if kind in {"DISAPPEARED", "VISIBILITY_CHANGED"}:
        return "MEDIUM" if interactive else "LOW"
    return "INFO"


def _interactive_ids(ui_map: Mapping[str, Any]) -> set[str]:
    hierarchy = ui_map.get("hierarchy") if isinstance(ui_map.get("hierarchy"), Mapping) else {}
    return {
        str(row.get("ui_id"))
        for row in hierarchy.get("elements", []) or []
        if isinstance(row, Mapping) and row.get("interactive") is True and isinstance(row.get("ui_id"), str)
    }


def _validate_threshold(name: str, value: Any) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(float(value)) or float(value) < 0:
        raise UIMapperError(f"{name} must be a finite non-negative number")
    return float(value)


def build_ui_geometry_diff(
    baseline_snapshot: Mapping[str, Any],
    candidate_snapshot: Mapping[str, Any],
    *,
    baseline_ui_reference: Optional[Mapping[str, Any]] = None,
    candidate_ui_reference: Optional[Mapping[str, Any]] = None,
    baseline_angular_ownership: Optional[Mapping[str, Any]] = None,
    candidate_angular_ownership: Optional[Mapping[str, Any]] = None,
    min_gap_px: float = 0.0,
    move_threshold_px: float = DEFAULT_MOVE_THRESHOLD_PX,
    size_threshold_px: float = DEFAULT_SIZE_THRESHOLD_PX,
    max_changes: int = DEFAULT_MAX_CHANGES,
) -> Dict[str, Any]:
    move_threshold_px = _validate_threshold("move_threshold_px", move_threshold_px)
    size_threshold_px = _validate_threshold("size_threshold_px", size_threshold_px)
    min_gap_px = _validate_threshold("min_gap_px", min_gap_px)
    if isinstance(max_changes, bool) or not isinstance(max_changes, int) or not 1 <= max_changes <= MAX_CHANGES:
        raise UIMapperError(f"max_changes must be between 1 and {MAX_CHANGES}")

    baseline = normalize_geometry_snapshot(dict(baseline_snapshot))
    candidate = normalize_geometry_snapshot(dict(candidate_snapshot))
    base_revision = str(baseline["scenario"]["code_revision"])
    cand_revision = str(candidate["scenario"]["code_revision"])
    if base_revision == cand_revision:
        raise UIMapperError("UI Mapper V3 requires different baseline and candidate code_revision values")

    base_identity = _scenario_identity(baseline["scenario"])
    cand_identity = _scenario_identity(candidate["scenario"])
    if base_identity != cand_identity:
        raise UIMapperError("cross-revision geometry diff requires the exact same route, viewport, ui_state, and data_fixture")

    base_map = build_ui_map(
        baseline_snapshot,
        ui_reference=baseline_ui_reference,
        angular_ownership=baseline_angular_ownership,
        min_gap_px=min_gap_px,
        max_elements=50_000,
        max_issues=2_000,
    )
    cand_map = build_ui_map(
        candidate_snapshot,
        ui_reference=candidate_ui_reference,
        angular_ownership=candidate_angular_ownership,
        min_gap_px=min_gap_px,
        max_elements=50_000,
        max_issues=2_000,
    )

    base_nodes = snapshot_node_index(baseline)
    cand_nodes = snapshot_node_index(candidate)
    base_owners = _owner_index(base_map)
    cand_owners = _owner_index(cand_map)
    interactive = _interactive_ids(base_map) | _interactive_ids(cand_map)
    all_ids = sorted(set(base_nodes) | set(cand_nodes))

    element_changes: List[Dict[str, Any]] = []
    changed_ids: set[str] = set()
    counters: Counter[str] = Counter()

    def add(kind: str, ui_id: str, details: Mapping[str, Any]) -> None:
        counters[kind] += 1
        changed_ids.add(ui_id)
        element_changes.append({
            "kind": kind,
            "severity": _change_severity(kind, interactive=ui_id in interactive),
            "ui_id": ui_id,
            "identity_quality": (
                "STABLE_ANCHOR" if ui_id.startswith(("plw:", "id:", "testid:"))
                else "STRUCTURAL_PATH" if ui_id.startswith("dom:")
                else "CALLER_DEFINED"
            ),
            "interactive": ui_id in interactive,
            "details": dict(details),
            "candidate_code_owner": dict(cand_owners[ui_id]) if ui_id in cand_owners else None,
            "baseline_code_owner": dict(base_owners[ui_id]) if ui_id in base_owners else None,
        })

    for ui_id in all_ids:
        b = base_nodes.get(ui_id); c = cand_nodes.get(ui_id)
        if b is None:
            add("APPEARED", ui_id, {"candidate_bbox": node_bbox(c or {})})
            continue
        if c is None:
            add("DISAPPEARED", ui_id, {"baseline_bbox": node_bbox(b)})
            continue
        bg = b.get("geometry") if isinstance(b.get("geometry"), Mapping) else {}
        cg = c.get("geometry") if isinstance(c.get("geometry"), Mapping) else {}
        bb = node_bbox(b); cb = node_bbox(c)
        bx, by = _center(bb); cx, cy = _center(cb)
        dx = cx - bx; dy = cy - by
        distance = math.hypot(dx, dy)
        if distance > move_threshold_px:
            add("MOVED", ui_id, {"delta_x_px": dx, "delta_y_px": dy, "distance_px": distance, "baseline_bbox": bb, "candidate_bbox": cb})
        dw = cb["width"] - bb["width"]; dh = cb["height"] - bb["height"]
        if abs(dw) > size_threshold_px or abs(dh) > size_threshold_px:
            add("RESIZED", ui_id, {"delta_width_px": dw, "delta_height_px": dh, "baseline_bbox": bb, "candidate_bbox": cb})
        if bg.get("visible") != cg.get("visible"):
            add("VISIBILITY_CHANGED", ui_id, {"baseline_visible": bg.get("visible"), "candidate_visible": cg.get("visible")})
        if bg.get("z_index") != cg.get("z_index"):
            add("Z_ORDER_CHANGED", ui_id, {"baseline_z_index": bg.get("z_index"), "candidate_z_index": cg.get("z_index")})
        if b.get("parent_ui_id") != c.get("parent_ui_id"):
            add("REPARENTED", ui_id, {"baseline_parent_ui_id": b.get("parent_ui_id"), "candidate_parent_ui_id": c.get("parent_ui_id")})

    base_issues = _issue_index(base_map)
    cand_issues = _issue_index(cand_map)
    introduced = sorted(set(cand_issues) - set(base_issues))
    resolved = sorted(set(base_issues) - set(cand_issues))
    issue_changes: List[Dict[str, Any]] = []
    issue_kind_map = {
        "OVERLAP": "NEW_OVERLAP",
        "OUTSIDE_VIEWPORT": "NEW_OUTSIDE_VIEWPORT",
        "EXTENDS_PARENT_BOUNDS": "NEW_EXTENDS_PARENT_BOUNDS",
        "INTERACTIVE_GAP": "NEW_INTERACTIVE_GAP",
    }
    for signature in introduced:
        issue = cand_issues[signature]
        kind = issue_kind_map.get(str(issue.get("kind")), "NEW_LAYOUT_ISSUE")
        ui_ids = [str(value) for value in issue.get("ui_ids", []) or []]
        counters[kind] += 1
        changed_ids.update(ui_ids)
        issue_changes.append({
            "change": "INTRODUCED",
            "kind": kind,
            "source_issue_kind": issue.get("kind"),
            "severity": issue.get("severity"),
            "ui_ids": ui_ids,
            "details": issue.get("details"),
        })
    for signature in resolved:
        issue = base_issues[signature]
        ui_ids = [str(value) for value in issue.get("ui_ids", []) or []]
        counters["RESOLVED_LAYOUT_ISSUE"] += 1
        changed_ids.update(ui_ids)
        issue_changes.append({
            "change": "RESOLVED",
            "kind": "RESOLVED_LAYOUT_ISSUE",
            "source_issue_kind": issue.get("kind"),
            "severity": issue.get("severity"),
            "ui_ids": ui_ids,
            "details": issue.get("details"),
        })

    severity_rank = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "INFO": 4}
    element_changes.sort(key=lambda row: (severity_rank.get(str(row.get("severity")), 99), str(row.get("kind")), str(row.get("ui_id"))))
    issue_changes.sort(key=lambda row: (0 if row.get("change") == "INTRODUCED" else 1, severity_rank.get(str(row.get("severity")), 99), str(row.get("source_issue_kind")), row.get("ui_ids", [])))
    total_changes = len(element_changes) + len(issue_changes)
    combined = ([{"scope": "ELEMENT", **row} for row in element_changes] + [{"scope": "ISSUE", **row} for row in issue_changes])
    combined.sort(key=lambda row: (severity_rank.get(str(row.get("severity")), 99), str(row.get("scope")), str(row.get("kind")), str(row.get("ui_id") or row.get("ui_ids"))))
    returned = combined[:max_changes]

    result: Dict[str, Any] = {
        "schema_version": UI_GEOMETRY_DIFF_SCHEMA_VERSION,
        "baseline_revision": base_revision,
        "candidate_revision": cand_revision,
        "scenario_identity": base_identity,
        "baseline": {
            "scenario_id": baseline["scenario_id"],
            "geometry_snapshot_digest": baseline["geometry_snapshot_digest"],
            "ui_map_digest": base_map["ui_map_digest"],
        },
        "candidate": {
            "scenario_id": candidate["scenario_id"],
            "geometry_snapshot_digest": candidate["geometry_snapshot_digest"],
            "ui_map_digest": cand_map["ui_map_digest"],
        },
        "summary": {
            "baseline_node_count": len(base_nodes),
            "candidate_node_count": len(cand_nodes),
            "changed_ui_id_count": len(changed_ids),
            "total_change_count": total_changes,
            "returned_change_count": len(returned),
            "omitted_change_count": max(0, total_changes - len(returned)),
            "changes_by_kind": dict(sorted(counters.items())),
            "introduced_issue_count": len(introduced),
            "resolved_issue_count": len(resolved),
        },
        "changes": returned,
        "introduced_issues": [row for row in issue_changes if row["change"] == "INTRODUCED"],
        "resolved_issues": [row for row in issue_changes if row["change"] == "RESOLVED"],
        "agent_brief": {
            "interpretation": "cross-revision geometry diff for one exact rendered scenario",
            "highest_priority_changes": returned[:20],
            "candidate_ui_ids": sorted(changed_ids)[:50],
            "next_action": "inspect introduced layout issues and changed stable-anchor UI IDs; a geometry change is not automatically a bug",
        },
        "authority": {
            "geometry_authority": "codebase.geometry_correspondence.GeometrySnapshot",
            "correspondence_authority": "UIAngularCorrespondence when provided",
            "geometry_diff_is_derived_view": True,
            "exact_scenario_identity_required": True,
            "cross_revision_regression_claimed": False,
            "bug_proven": False,
            "browser_executed": False,
            "source_mutated": False,
            "truth_committed": False,
        },
    }
    result["geometry_diff_digest"] = canonical_ui_digest({
        "baseline": result["baseline"],
        "candidate": result["candidate"],
        "scenario_identity": result["scenario_identity"],
        "summary": result["summary"],
        "changes": result["changes"],
    })
    return result


__all__ = [
    "UI_GEOMETRY_DIFF_SCHEMA_VERSION",
    "DEFAULT_MOVE_THRESHOLD_PX",
    "DEFAULT_SIZE_THRESHOLD_PX",
    "build_ui_geometry_diff",
]
