"""Practical UI mapping consumers for PLW geometry/correspondence authorities."""
from ui.mapper import (
    UI_MAP_SCHEMA_VERSION,
    build_browser_capture_script,
    build_ui_map,
    inspect_ui_element,
)
from ui.scenarios import (
    UI_SCENARIO_MAP_SCHEMA_VERSION,
    build_ui_scenario_map,
)
from ui.diff import (
    UI_GEOMETRY_DIFF_SCHEMA_VERSION,
    build_ui_geometry_diff,
)
from ui.bug_hunter import (
    UI_BUG_HUNTER_SCHEMA_VERSION,
    build_ui_bug_hunt,
)
from ui.diagnose import (
    UI_CROSS_DOMAIN_DIAGNOSIS_SCHEMA_VERSION,
    build_cross_domain_ui_diagnosis,
)
from ui.reproduce import (
    UI_TARGETED_REPRODUCTION_SCHEMA_VERSION,
    UIReproductionError,
    execute_targeted_ui_reproduction,
)
from ui.causal_probe import (
    UI_CAUSAL_PROBE_PLAN_SCHEMA_VERSION,
    UI_CAUSAL_ISOLATION_SCHEMA_VERSION,
    UICausalProbeError,
    build_ui_causal_probe_plan,
    execute_ui_causal_isolation,
)
from ui.fix import (
    UI_BOUNDED_FIX_PLAN_SCHEMA_VERSION,
    UI_POST_FIX_VERIFICATION_SCHEMA_VERSION,
    UIFixError,
    build_bounded_ui_fix_plan,
    verify_bounded_ui_fix,
)

__all__ = [
    "UI_MAP_SCHEMA_VERSION",
    "UI_SCENARIO_MAP_SCHEMA_VERSION",
    "UI_GEOMETRY_DIFF_SCHEMA_VERSION",
    "UI_BUG_HUNTER_SCHEMA_VERSION",
    "UI_CROSS_DOMAIN_DIAGNOSIS_SCHEMA_VERSION",
    "UI_TARGETED_REPRODUCTION_SCHEMA_VERSION",
    "UI_CAUSAL_PROBE_PLAN_SCHEMA_VERSION",
    "UI_CAUSAL_ISOLATION_SCHEMA_VERSION",
    "UIReproductionError",
    "UICausalProbeError",
    "build_browser_capture_script",
    "build_ui_map",
    "inspect_ui_element",
    "build_ui_scenario_map",
    "build_ui_geometry_diff",
    "build_ui_bug_hunt",
    "build_cross_domain_ui_diagnosis",
    "execute_targeted_ui_reproduction",
    "build_ui_causal_probe_plan",
    "execute_ui_causal_isolation",
    "UI_BOUNDED_FIX_PLAN_SCHEMA_VERSION",
    "UI_POST_FIX_VERIFICATION_SCHEMA_VERSION",
    "UIFixError",
    "build_bounded_ui_fix_plan",
    "verify_bounded_ui_fix",
]
