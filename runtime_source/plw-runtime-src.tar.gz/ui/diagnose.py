"""Cross-domain UI diagnosis and targeted reproduction planning.

This module is a practical consumer of existing PLW authorities.  It combines
UI Bug Hunter candidates with F127 UI→topology projection and emits bounded
structural cause candidates plus a minimum exact-scenario reproduction plan.
It does not prove causality, execute a browser, mutate source, or upgrade a bug
candidate to PROVEN.
"""
from __future__ import annotations

import os
from typing import Any, Dict, List, Mapping, Optional, Sequence

from fullstack.geometric_impact import build_targeted_geometric_impact
from ui.bug_hunter import build_ui_bug_hunt
from ui.common import canonical_ui_digest

UI_CROSS_DOMAIN_DIAGNOSIS_SCHEMA_VERSION = "ui-cross-domain-diagnosis-v1"
DEFAULT_MAX_STRUCTURAL_CANDIDATES = 24
MAX_STRUCTURAL_CANDIDATES = 200

_ROLE_TOKENS = (
    ("layout_state_owner", ("modal", "overlay", "layout", "responsive", "breakpoint", "viewport")),
    ("state_owner", ("state", "store", "facade", "signal", "session", "context")),
    ("service_dependency", ("service", "manager", "controller", "coordinator")),
    ("style_system", ("theme", "token", "style", "css", "scss")),
    ("navigation_owner", ("router", "route", "navigation")),
)


def _runtime_capture(runtime_reference: Optional[Mapping[str, Any]]) -> Optional[Mapping[str, Any]]:
    if not isinstance(runtime_reference, Mapping):
        return None
    nested = runtime_reference.get("runtime_capture")
    return nested if isinstance(nested, Mapping) else runtime_reference


def _basename_role(path: str) -> Optional[str]:
    name = os.path.basename(str(path)).lower()
    for role, tokens in _ROLE_TOKENS:
        if any(token in name for token in tokens):
            return role
    return None


def _bounded(values: Sequence[str], limit: int = 16) -> Dict[str, Any]:
    ordered = sorted(dict.fromkeys(str(v) for v in values if isinstance(v, str) and v))
    return {
        "items": ordered[:limit],
        "total_count": len(ordered),
        "omitted_count": max(0, len(ordered) - limit),
    }


def _projection_by_file(impact: Mapping[str, Any]) -> Dict[str, Mapping[str, Any]]:
    projection = impact.get("impact_projection") if isinstance(impact.get("impact_projection"), Mapping) else {}
    result: Dict[str, Mapping[str, Any]] = {}
    for row in projection.get("projections", []) or []:
        if isinstance(row, Mapping) and isinstance(row.get("component_file"), str):
            result[str(row["component_file"])] = row
    return result


def _candidate_component_files(candidate: Mapping[str, Any]) -> List[str]:
    binding = candidate.get("code_binding") if isinstance(candidate.get("code_binding"), Mapping) else {}
    result: List[str] = []
    for row in binding.get("owners", []) or []:
        if not isinstance(row, Mapping):
            continue
        owner = row.get("owner") if isinstance(row.get("owner"), Mapping) else {}
        path = owner.get("component_file")
        if isinstance(path, str) and path not in result:
            result.append(path)
    return result


def _structural_candidates(
    candidate: Mapping[str, Any],
    projections: Mapping[str, Mapping[str, Any]],
    *,
    max_candidates: int,
) -> List[Dict[str, Any]]:
    rows: Dict[str, Dict[str, Any]] = {}

    def add(path: str, *, role: str, score: int, reason: str, evidence: Optional[Mapping[str, Any]] = None) -> None:
        if not isinstance(path, str) or not path:
            return
        existing = rows.get(path)
        item = {
            "path": path,
            "role": role,
            "structural_score": score,
            "reason": reason,
            "causality_proven": False,
        }
        if evidence:
            item["evidence"] = dict(evidence)
        if existing is None or int(existing.get("structural_score", 0)) < score:
            rows[path] = item

    for component_file in _candidate_component_files(candidate):
        projection = projections.get(component_file)
        add(
            component_file,
            role="render_owner",
            score=100,
            reason="UI correspondence binds an affected rendered node to this component file",
        )
        if not isinstance(projection, Mapping):
            continue
        for resource in projection.get("layout_resources", []) or []:
            if not isinstance(resource, Mapping):
                continue
            template = resource.get("template") if isinstance(resource.get("template"), Mapping) else {}
            template_path = template.get("resolved_path")
            if isinstance(template_path, str):
                add(template_path, role="template_owner", score=96, reason="declared template resource for affected component")
            for style in resource.get("styles", []) or []:
                if isinstance(style, Mapping) and isinstance(style.get("resolved_path"), str):
                    add(str(style["resolved_path"]), role="style_owner", score=98, reason="declared style resource for affected component")

        topology = projection.get("topology") if isinstance(projection.get("topology"), Mapping) else {}
        for path in topology.get("direct_upstream", {}).get("items", []) if isinstance(topology.get("direct_upstream"), Mapping) else []:
            role = _basename_role(str(path))
            add(
                str(path),
                role=role or "direct_dependency",
                score=82 if role else 50,
                reason=(
                    "affected component directly imports a dependency whose filename suggests state/layout ownership"
                    if role else "affected component directly imports this dependency"
                ),
            )

    ordered = sorted(rows.values(), key=lambda row: (-int(row["structural_score"]), row["path"]))
    return ordered[:max_candidates]


def _reproduction_plan(candidate: Mapping[str, Any], scenario: Mapping[str, Any], root_hint: str) -> Dict[str, Any]:
    lifecycle = str(candidate.get("lifecycle_state") or "DISCOVERED")
    ui_ids = [str(v) for v in candidate.get("ui_ids", []) or []]
    route = str(scenario.get("route") or "/")
    viewport = scenario.get("viewport") if isinstance(scenario.get("viewport"), Mapping) else {}
    state = str(scenario.get("ui_state") or "default")
    fixture = str(scenario.get("data_fixture") or "default")
    revision = str(scenario.get("code_revision") or "")

    if lifecycle == "DISCOVERED":
        objective = "obtain independent support: exact-scenario baseline comparison and/or runtime-attested recapture"
    elif lifecycle == "SUPPORTED":
        objective = "reproduce the candidate under runtime-attested capture provenance using the exact same scenario"
    elif lifecycle == "REPRODUCED":
        objective = "resolve exact/structural UI→code ownership for all affected nodes before proposing a fix"
    else:
        objective = "inspect the bounded structural owner set; after a minimal fix, recapture this exact scenario before expanding validation"

    return {
        "objective": objective,
        "minimum_scenario": {
            "code_revision": revision,
            "route": route,
            "viewport": {
                "width": viewport.get("width"),
                "height": viewport.get("height"),
            },
            "ui_state": state,
            "data_fixture": fixture,
        },
        "focus_ui_ids": ui_ids,
        "capture_script_command": (
            f"plw ui capture-script {root_hint} --revision {revision} --state {state} --fixture {fixture}"
            if revision else None
        ),
        "expected_observation": {
            "category": candidate.get("category"),
            "source_issue_kind": candidate.get("source_issue_kind"),
            "ui_ids": ui_ids,
        },
        "expansion_policy": "start with the exact failing scenario; expand to adjacent responsive/state scenarios only after this scenario is reproduced or disproven",
        "browser_execution_performed_by_planner": False,
    }


def build_cross_domain_ui_diagnosis(
    candidate_snapshot: Mapping[str, Any],
    *,
    ui_reference: Mapping[str, Any],
    angular_ownership: Mapping[str, Any],
    shared_graph: Mapping[str, Any],
    baseline_snapshot: Optional[Mapping[str, Any]] = None,
    baseline_ui_reference: Optional[Mapping[str, Any]] = None,
    baseline_angular_ownership: Optional[Mapping[str, Any]] = None,
    runtime_reference: Optional[Mapping[str, Any]] = None,
    min_gap_px: float = 0.0,
    max_bug_candidates: int = 100,
    max_structural_candidates: int = DEFAULT_MAX_STRUCTURAL_CANDIDATES,
    root_hint: str = ".",
) -> Dict[str, Any]:
    if isinstance(max_structural_candidates, bool) or not isinstance(max_structural_candidates, int) or not 1 <= max_structural_candidates <= MAX_STRUCTURAL_CANDIDATES:
        raise ValueError(f"max_structural_candidates must be between 1 and {MAX_STRUCTURAL_CANDIDATES}")

    hunt = build_ui_bug_hunt(
        candidate_snapshot,
        candidate_ui_reference=ui_reference,
        candidate_angular_ownership=angular_ownership,
        baseline_snapshot=baseline_snapshot,
        baseline_ui_reference=baseline_ui_reference,
        baseline_angular_ownership=baseline_angular_ownership,
        runtime_reference=runtime_reference,
        min_gap_px=min_gap_px,
        max_candidates=max_bug_candidates,
    )

    focus_ui_ids: List[str] = []
    for candidate in hunt.get("candidates", []) or []:
        if not isinstance(candidate, Mapping):
            continue
        for ui_id in candidate.get("ui_ids", []) or []:
            if isinstance(ui_id, str) and ui_id not in focus_ui_ids:
                focus_ui_ids.append(ui_id)

    impact = build_targeted_geometric_impact(
        ui_reference,
        angular_ownership,
        shared_graph,
        focus_ui_ids=focus_ui_ids,
        proximity_px=max(0.0, float(min_gap_px)),
        runtime_capture=_runtime_capture(runtime_reference),
    )
    projections = _projection_by_file(impact)
    scenario = hunt.get("scenario") if isinstance(hunt.get("scenario"), Mapping) else {}

    diagnoses: List[Dict[str, Any]] = []
    for candidate in hunt.get("candidates", []) or []:
        if not isinstance(candidate, Mapping):
            continue
        component_files = _candidate_component_files(candidate)
        relevant_projection_rows = [dict(projections[path]) for path in component_files if path in projections]
        structural = _structural_candidates(candidate, projections, max_candidates=max_structural_candidates)
        affected_entrypoints: List[str] = []
        upstream: List[str] = []
        downstream: List[str] = []
        for row in relevant_projection_rows:
            topology = row.get("topology") if isinstance(row.get("topology"), Mapping) else {}
            for key, sink in (("affected_entrypoints", affected_entrypoints), ("direct_upstream", upstream), ("direct_downstream", downstream)):
                block = topology.get(key) if isinstance(topology.get(key), Mapping) else {}
                for value in block.get("items", []) or []:
                    if isinstance(value, str) and value not in sink:
                        sink.append(value)

        diagnoses.append({
            "candidate_id": candidate.get("candidate_id"),
            "category": candidate.get("category"),
            "severity": candidate.get("severity"),
            "lifecycle_state": candidate.get("lifecycle_state"),
            "ui_ids": candidate.get("ui_ids", []),
            "structural_context": {
                "component_files": component_files,
                "affected_entrypoints": _bounded(affected_entrypoints),
                "direct_dependencies": _bounded(upstream),
                "direct_consumers": _bounded(downstream),
                "topology_projections": relevant_projection_rows,
                "structural_cause_candidates": structural,
                "causal_owner_proven": False,
            },
            "targeted_reproduction": _reproduction_plan(candidate, scenario, root_hint),
            "next_action": candidate.get("next_action"),
            "proof_state": candidate.get("proof_state", "UNPROVEN"),
        })

    result: Dict[str, Any] = {
        "schema_version": UI_CROSS_DOMAIN_DIAGNOSIS_SCHEMA_VERSION,
        "scenario_id": hunt.get("scenario_id"),
        "scenario": hunt.get("scenario"),
        "candidate_revision": hunt.get("candidate_revision"),
        "baseline_revision": hunt.get("baseline_revision"),
        "summary": {
            "bug_candidate_count": len(diagnoses),
            "cross_domain_bound_candidate_count": sum(1 for row in diagnoses if row.get("structural_context", {}).get("component_files")),
            "runtime_reproduced": bool(hunt.get("summary", {}).get("runtime_reproduced")),
            "highest_severity": hunt.get("summary", {}).get("highest_severity"),
            "affected_component_files": sorted({path for row in diagnoses for path in row.get("structural_context", {}).get("component_files", [])}),
        },
        "bug_hunt": hunt,
        "geometric_topology_projection": impact,
        "diagnoses": diagnoses,
        "agent_brief": {
            "priority": diagnoses[:8],
            "instruction": "inspect high-scoring structural candidates as bounded hypotheses, not proven root causes; reproduce the exact scenario before broad validation",
        },
        "authority": {
            "geometry_authority": "GeometrySnapshot",
            "correspondence_authority": "UIAngularCorrespondence",
            "topology_authority": "core.shared_graph",
            "runtime_capture_authority": "F126 runtime capture when provided",
            "cross_domain_diagnosis_is_derived_view": True,
            "root_cause_proven": False,
            "bug_proven": False,
            "postcondition_proven": False,
            "source_mutated": False,
            "truth_committed": False,
        },
        "proof_boundary": {
            "topology_proximity_is_causality": False,
            "structural_candidate_is_root_cause": False,
            "reproduction_plan_executes_browser": False,
            "bound_bug_candidate_is_postcondition_proof": False,
        },
    }
    result["diagnosis_digest"] = canonical_ui_digest({
        "scenario_id": result["scenario_id"],
        "candidate_revision": result["candidate_revision"],
        "baseline_revision": result["baseline_revision"],
        "summary": result["summary"],
        "diagnoses": result["diagnoses"],
        "bug_hunt_digest": hunt.get("bug_hunt_digest"),
        "geometric_impact_digest": impact.get("geometric_impact_digest"),
    })
    return result


__all__ = [
    "UI_CROSS_DOMAIN_DIAGNOSIS_SCHEMA_VERSION",
    "build_cross_domain_ui_diagnosis",
]
