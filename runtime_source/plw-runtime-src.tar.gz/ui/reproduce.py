"""Targeted runtime reproduction for exact UI bug scenarios.

This module executes a bounded Chromium/Chrome session through the Chrome
DevTools Protocol (CDP), captures one fresh GeometrySnapshot using PLW's
existing browser capture expression, and compares the observed runtime symptom
with one exact cross-domain diagnosis candidate.

It intentionally separates symptom reproduction from causal proof:
REPRODUCED means the expected UI symptom was observed in a fresh browser
capture for the requested scenario. It does not prove that a structural cause
candidate caused the symptom, does not mutate source, and does not establish a
postcondition/truth claim.
"""
from __future__ import annotations

import base64
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import socket
import struct
import subprocess
import tempfile
import time
from typing import Any, Dict, Mapping, Optional, Sequence
from urllib.request import urlopen
from urllib.error import URLError

from codebase.geometry_correspondence import normalize_geometry_snapshot, build_ui_reference_state
from ui.common import canonical_ui_digest
from ui.mapper import build_browser_capture_script, build_ui_map

UI_TARGETED_REPRODUCTION_SCHEMA_VERSION = "ui-targeted-runtime-reproduction-v1"
DEFAULT_TIMEOUT_SECONDS = 20
MAX_TIMEOUT_SECONDS = 120
MAX_HTML_BYTES = 4 * 1024 * 1024
MAX_SETUP_JS_BYTES = 256 * 1024


class UIReproductionError(RuntimeError):
    pass


def _read_bounded(path: Optional[str], max_bytes: int, label: str) -> Optional[str]:
    if not path:
        return None
    target = Path(path)
    try:
        raw = target.read_bytes()
    except OSError as exc:
        raise UIReproductionError(f"{label} unavailable: {type(exc).__name__}") from exc
    if len(raw) > max_bytes:
        raise UIReproductionError(f"{label} exceeds {max_bytes} bytes")
    try:
        return raw.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise UIReproductionError(f"{label} must be UTF-8") from exc


def _find_browser(explicit: Optional[str] = None) -> str:
    if explicit:
        path = shutil.which(explicit) if os.path.sep not in explicit else explicit
        if path and Path(path).is_file():
            return str(path)
        raise UIReproductionError(f"browser executable unavailable: {explicit}")
    for name in ("chromium", "chromium-browser", "google-chrome", "google-chrome-stable", "chrome"):
        path = shutil.which(name)
        if path:
            return path
    raise UIReproductionError("no Chromium/Chrome executable found")


def _recv_exact(sock: socket.socket, count: int) -> bytes:
    chunks = []
    remaining = count
    while remaining:
        data = sock.recv(remaining)
        if not data:
            raise UIReproductionError("CDP websocket closed unexpectedly")
        chunks.append(data)
        remaining -= len(data)
    return b"".join(chunks)


class _WebSocket:
    """Minimal stdlib RFC6455 client sufficient for local Chromium CDP."""

    def __init__(self, url: str, timeout: float):
        if not url.startswith("ws://"):
            raise UIReproductionError("only local ws:// CDP endpoints are supported")
        rest = url[5:]
        hostport, _, path = rest.partition("/")
        host, sep, port_text = hostport.rpartition(":")
        if not sep:
            host, port_text = hostport, "80"
        self.sock = socket.create_connection((host, int(port_text)), timeout=timeout)
        self.sock.settimeout(timeout)
        key = base64.b64encode(os.urandom(16)).decode("ascii")
        request = (
            f"GET /{path} HTTP/1.1\r\nHost: {hostport}\r\nUpgrade: websocket\r\n"
            f"Connection: Upgrade\r\nSec-WebSocket-Key: {key}\r\nSec-WebSocket-Version: 13\r\n\r\n"
        ).encode("ascii")
        self.sock.sendall(request)
        response = b""
        while b"\r\n\r\n" not in response and len(response) < 65536:
            response += self.sock.recv(4096)
        head = response.split(b"\r\n\r\n", 1)[0].decode("latin-1", "replace")
        if " 101 " not in head.split("\r\n", 1)[0]:
            raise UIReproductionError(f"CDP websocket handshake failed: {head.splitlines()[0] if head else 'empty response'}")
        accept = None
        for line in head.split("\r\n")[1:]:
            if line.lower().startswith("sec-websocket-accept:"):
                accept = line.split(":", 1)[1].strip()
                break
        expected = base64.b64encode(hashlib.sha1((key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").encode("ascii")).digest()).decode("ascii")
        if accept != expected:
            raise UIReproductionError("CDP websocket handshake accept mismatch")

    def send_json(self, value: Mapping[str, Any]) -> None:
        payload = json.dumps(value, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        header = bytearray([0x81])
        length = len(payload)
        mask_bit = 0x80
        if length < 126:
            header.append(mask_bit | length)
        elif length < 65536:
            header.append(mask_bit | 126); header.extend(struct.pack("!H", length))
        else:
            header.append(mask_bit | 127); header.extend(struct.pack("!Q", length))
        mask = os.urandom(4); header.extend(mask)
        masked = bytes(byte ^ mask[i % 4] for i, byte in enumerate(payload))
        self.sock.sendall(bytes(header) + masked)

    def recv_json(self) -> Dict[str, Any]:
        while True:
            first = _recv_exact(self.sock, 2)
            opcode = first[0] & 0x0F
            masked = bool(first[1] & 0x80)
            length = first[1] & 0x7F
            if length == 126:
                length = struct.unpack("!H", _recv_exact(self.sock, 2))[0]
            elif length == 127:
                length = struct.unpack("!Q", _recv_exact(self.sock, 8))[0]
            mask = _recv_exact(self.sock, 4) if masked else None
            payload = _recv_exact(self.sock, length)
            if mask:
                payload = bytes(byte ^ mask[i % 4] for i, byte in enumerate(payload))
            if opcode == 0x8:
                raise UIReproductionError("CDP websocket closed")
            if opcode == 0x9:  # ping
                self._send_control(0xA, payload)
                continue
            if opcode != 0x1:
                continue
            try:
                value = json.loads(payload.decode("utf-8"))
            except (UnicodeDecodeError, json.JSONDecodeError) as exc:
                raise UIReproductionError("invalid JSON from CDP") from exc
            if isinstance(value, dict):
                return value

    def _send_control(self, opcode: int, payload: bytes) -> None:
        if len(payload) > 125:
            payload = payload[:125]
        mask = os.urandom(4)
        header = bytes([0x80 | opcode, 0x80 | len(payload)]) + mask
        masked = bytes(byte ^ mask[i % 4] for i, byte in enumerate(payload))
        self.sock.sendall(header + masked)

    def close(self) -> None:
        try:
            self.sock.close()
        except OSError:
            pass


class _CDP:
    def __init__(self, ws_url: str, timeout: float):
        self.ws = _WebSocket(ws_url, timeout)
        self.next_id = 1

    def call(self, method: str, params: Optional[Mapping[str, Any]] = None) -> Dict[str, Any]:
        call_id = self.next_id; self.next_id += 1
        self.ws.send_json({"id": call_id, "method": method, "params": dict(params or {})})
        while True:
            msg = self.ws.recv_json()
            if msg.get("id") != call_id:
                continue
            if "error" in msg:
                error = msg.get("error") or {}
                raise UIReproductionError(f"CDP {method} failed: {error.get('message') or error}")
            result = msg.get("result")
            return result if isinstance(result, dict) else {}

    def evaluate(self, expression: str) -> Any:
        result = self.call("Runtime.evaluate", {
            "expression": expression,
            "returnByValue": True,
            "awaitPromise": True,
            "userGesture": True,
        })
        exception = result.get("exceptionDetails")
        if exception:
            text = exception.get("text") if isinstance(exception, Mapping) else str(exception)
            raise UIReproductionError(f"browser JavaScript failed: {text}")
        remote = result.get("result") if isinstance(result.get("result"), Mapping) else {}
        return remote.get("value")

    def close(self) -> None:
        self.ws.close()


def _wait_devtools_port(user_dir: Path, proc: subprocess.Popen[Any], deadline: float) -> int:
    path = user_dir / "DevToolsActivePort"
    while time.monotonic() < deadline:
        if proc.poll() is not None:
            tail = ""
            try:
                if proc.stderr:
                    tail = proc.stderr.read()[-2000:]
            except Exception:
                pass
            raise UIReproductionError(f"browser exited before CDP became available: {tail.strip()}")
        if path.is_file():
            try:
                lines = path.read_text(encoding="utf-8").splitlines()
                if lines:
                    return int(lines[0].strip())
            except (OSError, ValueError):
                pass
        time.sleep(0.05)
    raise UIReproductionError("timed out waiting for Chromium CDP endpoint")


def _find_page_ws(port: int, deadline: float) -> str:
    url = f"http://127.0.0.1:{port}/json/list"
    while time.monotonic() < deadline:
        try:
            with urlopen(url, timeout=1.0) as response:
                items = json.loads(response.read().decode("utf-8"))
            if isinstance(items, list):
                for item in items:
                    if isinstance(item, Mapping) and item.get("type") == "page" and isinstance(item.get("webSocketDebuggerUrl"), str):
                        return str(item["webSocketDebuggerUrl"])
        except (URLError, OSError, ValueError, json.JSONDecodeError):
            pass
        time.sleep(0.05)
    raise UIReproductionError("timed out waiting for Chromium page target")


def _wait_ready(cdp: _CDP, deadline: float) -> None:
    while time.monotonic() < deadline:
        try:
            state = cdp.evaluate("document.readyState")
            if state in {"interactive", "complete"}:
                return
        except UIReproductionError:
            pass
        time.sleep(0.05)
    raise UIReproductionError("target page did not become ready before timeout")


def _scenario_compatible(expected: Mapping[str, Any], observed: Mapping[str, Any]) -> Dict[str, bool]:
    ev = expected.get("viewport") if isinstance(expected.get("viewport"), Mapping) else {}
    ov = observed.get("viewport") if isinstance(observed.get("viewport"), Mapping) else {}
    return {
        "code_revision": str(observed.get("code_revision") or "") == str(expected.get("code_revision") or ""),
        "route": str(observed.get("route") or "") == str(expected.get("route") or ""),
        "viewport_width": float(ov.get("width") or 0) == float(ev.get("width") or 0),
        "viewport_height": float(ov.get("height") or 0) == float(ev.get("height") or 0),
        "ui_state": str(observed.get("ui_state") or "") == str(expected.get("ui_state") or ""),
        "data_fixture": str(observed.get("data_fixture") or "") == str(expected.get("data_fixture") or ""),
    }


def _expected_observed(ui_map: Mapping[str, Any], expected: Mapping[str, Any]) -> bool:
    kind = str(expected.get("source_issue_kind") or "")
    ui_ids = sorted(str(v) for v in expected.get("ui_ids", []) or [])
    if kind == "DISAPPEARED":
        elements = ui_map.get("hierarchy", {}).get("elements", []) if isinstance(ui_map.get("hierarchy"), Mapping) else []
        present = {str(row.get("ui_id")) for row in elements if isinstance(row, Mapping)}
        return bool(ui_ids) and all(ui_id not in present for ui_id in ui_ids)
    if kind == "VISIBILITY_CHANGED":
        elements = ui_map.get("hierarchy", {}).get("elements", []) if isinstance(ui_map.get("hierarchy"), Mapping) else []
        by_id = {str(row.get("ui_id")): row for row in elements if isinstance(row, Mapping)}
        return bool(ui_ids) and all(ui_id in by_id and by_id[ui_id].get("geometry", {}).get("visible") is False for ui_id in ui_ids)
    for row in ui_map.get("issues", []) or []:
        if not isinstance(row, Mapping):
            continue
        if str(row.get("kind") or "") == kind and sorted(str(v) for v in row.get("ui_ids", []) or []) == ui_ids:
            return True
    return False


def _select_diagnosis(diagnosis: Mapping[str, Any], candidate_id: Optional[str]) -> Mapping[str, Any]:
    rows = [row for row in diagnosis.get("diagnoses", []) or [] if isinstance(row, Mapping)]
    if candidate_id:
        for row in rows:
            if row.get("candidate_id") == candidate_id:
                return row
        raise UIReproductionError("candidate_id not found in diagnosis")
    if not rows:
        raise UIReproductionError("diagnosis contains no bug candidates")
    return rows[0]


def execute_targeted_ui_reproduction(
    diagnosis: Mapping[str, Any],
    *,
    angular_ownership: Mapping[str, Any],
    candidate_id: Optional[str] = None,
    url: Optional[str] = None,
    html_file: Optional[str] = None,
    setup_js_file: Optional[str] = None,
    browser: Optional[str] = None,
    timeout_seconds: int = DEFAULT_TIMEOUT_SECONDS,
    min_gap_px: float = 0.0,
    max_nodes: int = 5000,
) -> Dict[str, Any]:
    if bool(url) == bool(html_file):
        raise UIReproductionError("provide exactly one of url or html_file")
    if isinstance(timeout_seconds, bool) or not isinstance(timeout_seconds, int) or not 1 <= timeout_seconds <= MAX_TIMEOUT_SECONDS:
        raise UIReproductionError(f"timeout_seconds must be between 1 and {MAX_TIMEOUT_SECONDS}")
    selected = _select_diagnosis(diagnosis, candidate_id)
    plan = selected.get("targeted_reproduction") if isinstance(selected.get("targeted_reproduction"), Mapping) else {}
    scenario = plan.get("minimum_scenario") if isinstance(plan.get("minimum_scenario"), Mapping) else {}
    viewport = scenario.get("viewport") if isinstance(scenario.get("viewport"), Mapping) else {}
    width = int(float(viewport.get("width") or 0)); height = int(float(viewport.get("height") or 0))
    if width <= 0 or height <= 0:
        raise UIReproductionError("diagnosis reproduction plan has invalid viewport")
    revision = str(scenario.get("code_revision") or "")
    if not revision:
        raise UIReproductionError("diagnosis reproduction plan has no code_revision")
    expected = plan.get("expected_observation") if isinstance(plan.get("expected_observation"), Mapping) else {}
    html = _read_bounded(html_file, MAX_HTML_BYTES, "html_file")
    setup_js = _read_bounded(setup_js_file, MAX_SETUP_JS_BYTES, "setup_js_file")
    executable = _find_browser(browser)
    start = time.monotonic(); deadline = start + timeout_seconds
    mode = "URL_NAVIGATION" if url else "INJECTED_DOCUMENT"
    proc: Optional[subprocess.Popen[Any]] = None
    cdp: Optional[_CDP] = None
    raw_snapshot: Optional[Dict[str, Any]] = None
    browser_error: Optional[str] = None

    with tempfile.TemporaryDirectory(prefix="plw-ui-reproduce-", ignore_cleanup_errors=True) as tmp:
        user_dir = Path(tmp) / "profile"; user_dir.mkdir()
        args = [
            executable, "--headless=new", "--disable-gpu", "--no-sandbox", "--disable-dev-shm-usage",
            "--remote-allow-origins=*", "--remote-debugging-port=0", f"--user-data-dir={user_dir}", "about:blank",
        ]
        try:
            proc = subprocess.Popen(args, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, text=True, start_new_session=True)
            port = _wait_devtools_port(user_dir, proc, deadline)
            ws = _find_page_ws(port, deadline)
            cdp = _CDP(ws, max(1.0, deadline - time.monotonic()))
            cdp.call("Page.enable"); cdp.call("Runtime.enable")
            cdp.call("Emulation.setDeviceMetricsOverride", {"width": width, "height": height, "deviceScaleFactor": 1, "mobile": False})
            if url:
                nav = cdp.call("Page.navigate", {"url": str(url)})
                if nav.get("errorText"):
                    raise UIReproductionError(f"browser navigation failed: {nav.get('errorText')}")
                _wait_ready(cdp, deadline)
            else:
                frame_tree = cdp.call("Page.getFrameTree")
                frame = frame_tree.get("frameTree", {}).get("frame", {}) if isinstance(frame_tree.get("frameTree"), Mapping) else {}
                frame_id = frame.get("id")
                if not frame_id:
                    raise UIReproductionError("browser main frame unavailable")
                cdp.call("Page.setDocumentContent", {"frameId": frame_id, "html": html or ""})
                _wait_ready(cdp, deadline)
            if setup_js:
                cdp.evaluate(setup_js)
            capture_script = build_browser_capture_script(
                code_revision=revision,
                graph_content_signature=angular_ownership.get("graph_content_signature"),
                angular_ownership_digest=angular_ownership.get("ownership_digest"),
                ui_state=str(scenario.get("ui_state") or "default"),
                data_fixture=str(scenario.get("data_fixture") or "default"),
                max_nodes=max_nodes,
            )
            value = cdp.evaluate(capture_script)
            if not isinstance(value, dict):
                raise UIReproductionError("browser capture did not return a GeometrySnapshot object")
            raw_snapshot = dict(value)
            # Injected-document mode simulates the diagnosed route without
            # pretending that browser navigation to that route occurred.
            if mode == "INJECTED_DOCUMENT":
                raw_snapshot.setdefault("scenario", {})["route"] = str(scenario.get("route") or "/")
                raw_snapshot.setdefault("capture", {})["source"] = "plw-browser-cdp-injected-document-v1"
            else:
                raw_snapshot.setdefault("capture", {})["source"] = "plw-browser-cdp-url-navigation-v1"
        except (UIReproductionError, OSError, ValueError, TimeoutError, socket.timeout) as exc:
            browser_error = str(exc)
        finally:
            if cdp is not None:
                cdp.close()
            if proc is not None:
                try:
                    os.killpg(proc.pid, signal.SIGTERM)
                except (ProcessLookupError, PermissionError):
                    pass
                try:
                    proc.wait(timeout=2)
                except subprocess.TimeoutExpired:
                    try:
                        os.killpg(proc.pid, signal.SIGKILL)
                    except (ProcessLookupError, PermissionError):
                        pass
                    proc.wait(timeout=2)
                time.sleep(0.05)

    elapsed_ms = int(round((time.monotonic() - start) * 1000))
    base: Dict[str, Any] = {
        "schema_version": UI_TARGETED_REPRODUCTION_SCHEMA_VERSION,
        "candidate_id": selected.get("candidate_id"),
        "category": selected.get("category"),
        "expected_observation": dict(expected),
        "requested_scenario": dict(scenario),
        "execution": {
            "browser_executed_by_plw": True,
            "browser_executable": executable,
            "execution_mode": mode,
            "url": str(url) if url else None,
            "html_file": str(html_file) if html_file else None,
            "setup_js_applied": bool(setup_js),
            "elapsed_ms": elapsed_ms,
        },
        "authority": {
            "runtime_symptom_observed": False,
            "root_cause_proven": False,
            "postcondition_proven": False,
            "source_mutated": False,
            "stable_promoted": False,
            "truth_committed": False,
        },
        "proof_boundary": {
            "reproduced_is_root_cause_proof": False,
            "runtime_bound_owner_is_causal_owner": False,
            "injected_document_is_real_application_navigation": False,
            "structural_candidate_is_causal_proof": False,
        },
    }
    if browser_error or raw_snapshot is None:
        base.update({
            "reproduction_state": "UNRESOLVED",
            "reason": "browser_execution_unresolved",
            "error": browser_error or "browser capture unavailable",
            "scenario_checks": {},
            "observed_geometry_snapshot": None,
            "runtime_bound_owners": [],
            "structural_only_candidates": selected.get("structural_context", {}).get("structural_cause_candidates", []),
        })
    else:
        try:
            geometry = normalize_geometry_snapshot(raw_snapshot)
            ui_ref = build_ui_reference_state(raw_snapshot, dict(angular_ownership))
            ui_map = build_ui_map(raw_snapshot, ui_reference=ui_ref, angular_ownership=angular_ownership, min_gap_px=min_gap_px, max_elements=50_000, max_issues=2_000)
            checks = _scenario_compatible(scenario, geometry.get("scenario", {}))
            compatible = all(checks.values())
            observed = compatible and _expected_observed(ui_map, expected)
            state = "REPRODUCED" if observed else ("NOT_REPRODUCED" if compatible else "UNRESOLVED")
            reason = "expected_runtime_symptom_observed" if observed else ("expected_runtime_symptom_not_observed" if compatible else "runtime_scenario_mismatch")
            runtime_bound = []
            structural_only = []
            structural = selected.get("structural_context", {}).get("structural_cause_candidates", [])
            runtime_roles = {"render_owner", "template_owner", "style_owner"}
            for row in structural if isinstance(structural, Sequence) else []:
                if not isinstance(row, Mapping):
                    continue
                item = dict(row)
                if observed and item.get("role") in runtime_roles:
                    item["evidence_state"] = "RUNTIME_BOUND_OWNER"
                    runtime_bound.append(item)
                else:
                    item["evidence_state"] = "STRUCTURAL_ONLY"
                    structural_only.append(item)
            base.update({
                "reproduction_state": state,
                "reason": reason,
                "scenario_checks": checks,
                "observed_geometry_snapshot": geometry,
                "observed_ui_map_digest": ui_map.get("ui_map_digest"),
                "observed_issue_summary": ui_map.get("summary"),
                "runtime_bound_owners": runtime_bound,
                "structural_only_candidates": structural_only,
            })
            base["authority"]["runtime_symptom_observed"] = observed
        except Exception as exc:
            base.update({
                "reproduction_state": "UNRESOLVED",
                "reason": "runtime_capture_assessment_failed",
                "error": f"{type(exc).__name__}: {exc}",
                "scenario_checks": {},
                "observed_geometry_snapshot": None,
                "runtime_bound_owners": [],
                "structural_only_candidates": selected.get("structural_context", {}).get("structural_cause_candidates", []),
            })

    base["reproduction_digest"] = canonical_ui_digest({
        "candidate_id": base.get("candidate_id"),
        "requested_scenario": base.get("requested_scenario"),
        "expected_observation": base.get("expected_observation"),
        "execution_mode": base.get("execution", {}).get("execution_mode"),
        "reproduction_state": base.get("reproduction_state"),
        "reason": base.get("reason"),
        "scenario_checks": base.get("scenario_checks"),
        "observed_geometry_snapshot_digest": (
            base.get("observed_geometry_snapshot", {}).get("geometry_snapshot_digest")
            if isinstance(base.get("observed_geometry_snapshot"), Mapping) else None
        ),
        "runtime_bound_owners": base.get("runtime_bound_owners"),
    })
    return base


__all__ = [
    "UI_TARGETED_REPRODUCTION_SCHEMA_VERSION",
    "UIReproductionError",
    "execute_targeted_ui_reproduction",
]
