"""UI Bug Hunter V1: practical geometry bug-candidate extraction.

Consumes GeometrySnapshot/UI Map and optional V3 exact-scenario cross-revision
geometry diff. It classifies actionable bug candidates, code ownership, and
provenance strength without turning geometry changes into automatic bug proof.
"""
from __future__ import annotations

from collections import Counter
from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple

from codebase.geometry_correspondence import normalize_geometry_snapshot
from ui.common import canonical_ui_digest
from ui.diff import build_ui_geometry_diff
from ui.mapper import UIMapperError, build_ui_map

UI_BUG_HUNTER_SCHEMA_VERSION = "ui-bug-hunter-v1"
DEFAULT_MAX_CANDIDATES = 100
MAX_CANDIDATES = 2000

_SEVERITY_RANK = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "INFO": 4}
_OWNER_PROOF = {"EXACT", "STRUCTURAL"}

_ISSUE_CLASS = {
    "OVERLAP": "OCCLUSION",
    "OUTSIDE_VIEWPORT": "VIEWPORT_ESCAPE",
    "VISIBLE_ZERO_SIZE": "ZERO_SIZE_VISIBLE_ELEMENT",
    "EXTENDS_PARENT_BOUNDS": "CONTAINMENT_RISK",
    "INTERACTIVE_GAP": "INTERACTION_SPACING",
    "MISSING_PARENT": "UI_TREE_INTEGRITY",
    "PARENT_CYCLE": "UI_TREE_INTEGRITY",
}


def _owner_index(ui_map: Mapping[str, Any]) -> Dict[str, Mapping[str, Any]]:
    hierarchy = ui_map.get("hierarchy") if isinstance(ui_map.get("hierarchy"), Mapping) else {}
    result: Dict[str, Mapping[str, Any]] = {}
    for row in hierarchy.get("elements", []) or []:
        if not isinstance(row, Mapping) or not isinstance(row.get("ui_id"), str):
            continue
        owner = row.get("code_owner")
        if isinstance(owner, Mapping):
            result[str(row["ui_id"])] = owner
    return result


def _interactive_index(ui_map: Mapping[str, Any]) -> Dict[str, bool]:
    hierarchy = ui_map.get("hierarchy") if isinstance(ui_map.get("hierarchy"), Mapping) else {}
    return {
        str(row.get("ui_id")): bool(row.get("interactive"))
        for row in hierarchy.get("elements", []) or []
        if isinstance(row, Mapping) and isinstance(row.get("ui_id"), str)
    }


def _issue_signature(kind: str, ui_ids: Sequence[str]) -> str:
    return f"{kind}|{'|'.join(sorted(str(value) for value in ui_ids))}"


def _runtime_binding(runtime_reference: Optional[Mapping[str, Any]], candidate_digest: str) -> Dict[str, Any]:
    if not isinstance(runtime_reference, Mapping):
        return {
            "provided": False,
            "exact": False,
            "reason": "runtime_reference_not_provided",
            "proof_class": None,
            "capture_binding_digest": None,
        }
    runtime = runtime_reference.get("runtime_capture") if isinstance(runtime_reference.get("runtime_capture"), Mapping) else runtime_reference
    digest_match = runtime.get("geometry_snapshot_digest") == candidate_digest
    exact = (
        runtime.get("proof_class") == "EXACT"
        and runtime.get("authority", {}).get("adapter_observation_provenance_bound") is True
        and digest_match
    )
    return {
        "provided": True,
        "exact": exact,
        "reason": runtime.get("reason") if digest_match else "runtime_reference_geometry_digest_mismatch",
        "proof_class": runtime.get("proof_class"),
        "capture_binding_digest": runtime.get("capture_binding_digest"),
        "adapter_observation_id": runtime.get("adapter_observation_id"),
        "geometry_snapshot_digest_match": digest_match,
    }


def _owner_binding(ui_ids: Sequence[str], owners: Mapping[str, Mapping[str, Any]]) -> Dict[str, Any]:
    rows: List[Dict[str, Any]] = []
    bound = 0
    for ui_id in ui_ids:
        owner = owners.get(str(ui_id))
        if not isinstance(owner, Mapping):
            rows.append({"ui_id": str(ui_id), "proof_class": "UNRESOLVED", "owner": None})
            continue
        proof = str(owner.get("proof_class") or "UNRESOLVED")
        if proof in _OWNER_PROOF:
            bound += 1
        rows.append({"ui_id": str(ui_id), "proof_class": proof, "owner": dict(owner)})
    return {
        "affected_ui_count": len(ui_ids),
        "bound_ui_count": bound,
        "all_bound": bool(ui_ids) and bound == len(ui_ids),
        "any_bound": bound > 0,
        "owners": rows,
    }


def _lifecycle(*, introduced: bool, runtime_exact: bool, owner_all_bound: bool) -> str:
    if runtime_exact and owner_all_bound:
        return "BOUND"
    if runtime_exact:
        return "REPRODUCED"
    if introduced:
        return "SUPPORTED"
    return "DISCOVERED"


def _candidate_id(scenario_id: str, category: str, ui_ids: Sequence[str]) -> str:
    return canonical_ui_digest({"scenario_id": scenario_id, "category": category, "ui_ids": sorted(ui_ids)})


def _next_action(lifecycle: str, category: str, owner_binding: Mapping[str, Any]) -> str:
    if lifecycle == "DISCOVERED":
        return "compare the exact scenario against a baseline revision or obtain runtime-attested capture before treating this as a regression"
    if lifecycle == "SUPPORTED":
        return "reproduce the exact scenario with runtime-attested geometry; use mapped owner resources to constrain inspection"
    if lifecycle == "REPRODUCED":
        return "resolve exact/structural code ownership for all affected UI nodes before proposing a layout mutation"
    if lifecycle == "BOUND":
        if category == "OCCLUSION":
            return "inspect mapped template/style and stacking/position owners; propose the smallest layout fix, then recapture the same scenario"
        if category == "INTERACTION_SPACING":
            return "inspect mapped layout/style owners and spacing tokens; propose the smallest spacing fix, then recapture the same scenario"
        return "inspect the mapped code owner and propose a bounded fix; validate by recapturing the exact scenario"
    return "inspect candidate evidence"


def build_ui_bug_hunt(
    candidate_snapshot: Mapping[str, Any],
    *,
    candidate_ui_reference: Optional[Mapping[str, Any]] = None,
    candidate_angular_ownership: Optional[Mapping[str, Any]] = None,
    baseline_snapshot: Optional[Mapping[str, Any]] = None,
    baseline_ui_reference: Optional[Mapping[str, Any]] = None,
    baseline_angular_ownership: Optional[Mapping[str, Any]] = None,
    runtime_reference: Optional[Mapping[str, Any]] = None,
    min_gap_px: float = 0.0,
    max_candidates: int = DEFAULT_MAX_CANDIDATES,
) -> Dict[str, Any]:
    if isinstance(max_candidates, bool) or not isinstance(max_candidates, int) or not 1 <= max_candidates <= MAX_CANDIDATES:
        raise UIMapperError(f"max_candidates must be between 1 and {MAX_CANDIDATES}")

    candidate = normalize_geometry_snapshot(dict(candidate_snapshot))
    candidate_map = build_ui_map(
        candidate_snapshot,
        ui_reference=candidate_ui_reference,
        angular_ownership=candidate_angular_ownership,
        min_gap_px=min_gap_px,
        max_elements=50_000,
        max_issues=2_000,
    )
    owners = _owner_index(candidate_map)
    interactive = _interactive_index(candidate_map)
    runtime = _runtime_binding(runtime_reference, candidate["geometry_snapshot_digest"])

    diff: Optional[Dict[str, Any]] = None
    introduced_signatures: set[str] = set()
    if baseline_snapshot is not None:
        diff = build_ui_geometry_diff(
            baseline_snapshot,
            candidate_snapshot,
            baseline_ui_reference=baseline_ui_reference,
            candidate_ui_reference=candidate_ui_reference,
            baseline_angular_ownership=baseline_angular_ownership,
            candidate_angular_ownership=candidate_angular_ownership,
            min_gap_px=min_gap_px,
            max_changes=10_000,
        )
        for row in diff.get("introduced_issues", []) or []:
            if isinstance(row, Mapping):
                introduced_signatures.add(_issue_signature(str(row.get("source_issue_kind") or "UNKNOWN"), row.get("ui_ids", []) or []))

    candidates: List[Dict[str, Any]] = []
    counts: Counter[str] = Counter()
    lifecycle_counts: Counter[str] = Counter()

    for issue in candidate_map.get("issues", []) or []:
        if not isinstance(issue, Mapping):
            continue
        kind = str(issue.get("kind") or "UNKNOWN")
        category = _ISSUE_CLASS.get(kind, "LAYOUT_ANOMALY")
        ui_ids = [str(value) for value in issue.get("ui_ids", []) or []]
        introduced = _issue_signature(kind, ui_ids) in introduced_signatures
        binding = _owner_binding(ui_ids, owners)
        lifecycle = _lifecycle(introduced=introduced, runtime_exact=runtime["exact"], owner_all_bound=binding["all_bound"])
        counts[category] += 1; lifecycle_counts[lifecycle] += 1
        severity = str(issue.get("severity") or "INFO")
        candidates.append({
            "candidate_id": _candidate_id(candidate["scenario_id"], category, ui_ids),
            "category": category,
            "source_issue_kind": kind,
            "severity": severity,
            "lifecycle_state": lifecycle,
            "ui_ids": ui_ids,
            "interactive_ui_ids": [ui_id for ui_id in ui_ids if interactive.get(ui_id)],
            "introduced_vs_baseline": introduced,
            "scenario_id": candidate["scenario_id"],
            "evidence": {
                "candidate_geometry_snapshot_digest": candidate["geometry_snapshot_digest"],
                "candidate_ui_map_digest": candidate_map["ui_map_digest"],
                "geometry_issue": dict(issue),
                "geometry_diff_digest": diff.get("geometry_diff_digest") if diff else None,
                "runtime_capture": runtime,
            },
            "code_binding": binding,
            "next_action": _next_action(lifecycle, category, binding),
            "proof_state": "UNPROVEN",
        })

    # Cross-revision element losses can be high-value bug candidates even when
    # they do not appear as a candidate-map spatial issue.
    if diff is not None:
        for row in diff.get("changes", []) or []:
            if not isinstance(row, Mapping) or row.get("scope") != "ELEMENT":
                continue
            kind = str(row.get("kind") or "")
            ui_id = str(row.get("ui_id") or "")
            if not ui_id or not bool(row.get("interactive")):
                continue
            details = row.get("details") if isinstance(row.get("details"), Mapping) else {}
            category = None
            if kind == "DISAPPEARED":
                category = "INTERACTIVE_ELEMENT_DISAPPEARED"
            elif kind == "VISIBILITY_CHANGED" and details.get("candidate_visible") is False:
                category = "INTERACTIVE_VISIBILITY_LOSS"
            if category is None:
                continue
            binding = _owner_binding([ui_id], owners)
            lifecycle = _lifecycle(introduced=True, runtime_exact=runtime["exact"], owner_all_bound=binding["all_bound"])
            counts[category] += 1; lifecycle_counts[lifecycle] += 1
            candidates.append({
                "candidate_id": _candidate_id(candidate["scenario_id"], category, [ui_id]),
                "category": category,
                "source_issue_kind": kind,
                "severity": "HIGH",
                "lifecycle_state": lifecycle,
                "ui_ids": [ui_id],
                "interactive_ui_ids": [ui_id],
                "introduced_vs_baseline": True,
                "scenario_id": candidate["scenario_id"],
                "evidence": {
                    "candidate_geometry_snapshot_digest": candidate["geometry_snapshot_digest"],
                    "candidate_ui_map_digest": candidate_map["ui_map_digest"],
                    "geometry_change": dict(row),
                    "geometry_diff_digest": diff.get("geometry_diff_digest"),
                    "runtime_capture": runtime,
                },
                "code_binding": binding,
                "next_action": _next_action(lifecycle, category, binding),
                "proof_state": "UNPROVEN",
            })

    candidates.sort(key=lambda row: (
        _SEVERITY_RANK.get(str(row.get("severity")), 99),
        {"BOUND": 0, "REPRODUCED": 1, "SUPPORTED": 2, "DISCOVERED": 3}.get(str(row.get("lifecycle_state")), 9),
        str(row.get("category")),
        str(row.get("candidate_id")),
    ))
    total = len(candidates)
    returned = candidates[:max_candidates]

    # Non-verdict change signals help an agent inspect why a bug candidate may
    # have appeared without turning movement/resize alone into a bug.
    risk_signals: List[Dict[str, Any]] = []
    if diff is not None:
        for row in diff.get("changes", []) or []:
            if not isinstance(row, Mapping) or row.get("scope") != "ELEMENT":
                continue
            if row.get("kind") in {"MOVED", "RESIZED", "Z_ORDER_CHANGED", "REPARENTED", "APPEARED"}:
                risk_signals.append(dict(row))
            if len(risk_signals) >= 50:
                break

    result: Dict[str, Any] = {
        "schema_version": UI_BUG_HUNTER_SCHEMA_VERSION,
        "scenario_id": candidate["scenario_id"],
        "scenario": candidate["scenario"],
        "candidate_revision": candidate["scenario"]["code_revision"],
        "baseline_revision": diff.get("baseline_revision") if diff else None,
        "summary": {
            "candidate_count": total,
            "returned_candidate_count": len(returned),
            "omitted_candidate_count": max(0, total - len(returned)),
            "by_category": dict(sorted(counts.items())),
            "by_lifecycle": dict(sorted(lifecycle_counts.items())),
            "highest_severity": returned[0]["severity"] if returned else None,
            "runtime_reproduced": runtime["exact"],
        },
        "candidates": returned,
        "risk_signals": risk_signals,
        "evidence_inputs": {
            "candidate_geometry_snapshot_digest": candidate["geometry_snapshot_digest"],
            "candidate_ui_map_digest": candidate_map["ui_map_digest"],
            "geometry_diff_digest": diff.get("geometry_diff_digest") if diff else None,
            "runtime_capture_binding_digest": runtime.get("capture_binding_digest"),
        },
        "agent_brief": {
            "highest_priority_candidates": returned[:12],
            "next_action": (
                "reproduce or bind the highest-priority candidate before editing; PROVEN is intentionally unreachable in Bug Hunter V1"
                if returned else "no mapped UI bug candidate in this exact scenario"
            ),
        },
        "authority": {
            "geometry_authority": "GeometrySnapshot",
            "correspondence_authority": "UIAngularCorrespondence when provided",
            "cross_revision_diff_authority": "UI Mapper V3 derived view when baseline provided",
            "runtime_capture_provenance_required_for_reproduced": True,
            "bug_hunter_is_derived_view": True,
            "bug_proven": False,
            "postcondition_proven": False,
            "source_mutated": False,
            "truth_committed": False,
        },
        "proof_boundary": {
            "discovered_is_bug_proof": False,
            "supported_is_bug_proof": False,
            "reproduced_is_postcondition_proof": False,
            "bound_is_postcondition_proof": False,
            "geometry_change_alone_is_bug": False,
            "proven_state_available_in_v1": False,
        },
    }
    result["bug_hunt_digest"] = canonical_ui_digest({
        "scenario_id": result["scenario_id"],
        "candidate_revision": result["candidate_revision"],
        "baseline_revision": result["baseline_revision"],
        "summary": result["summary"],
        "candidates": result["candidates"],
        "risk_signals": result["risk_signals"],
    })
    return result


__all__ = ["UI_BUG_HUNTER_SCHEMA_VERSION", "build_ui_bug_hunt"]
