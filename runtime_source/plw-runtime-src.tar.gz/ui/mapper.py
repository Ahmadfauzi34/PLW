"""Practical scenario-bound UI mapper for agent spatial reasoning.

This module consumes the existing GeometrySnapshot and optional UI↔Angular
correspondence state.  It does not replace those authorities.  Its job is to
turn precise geometry into a compact mental map and actionable layout findings:
hierarchy, viewport overflow, sibling/non-ancestor overlap, parent-boundary
extension, and optional interactive spacing warnings.
"""
from __future__ import annotations

import json
import math
from collections import defaultdict
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

from codebase.geometry_correspondence import normalize_geometry_snapshot
from ui.common import canonical_ui_digest

UI_MAP_SCHEMA_VERSION = "ui-map-v1"
CAPTURE_SCRIPT_VERSION = "plw-browser-ui-capture-v1"
DEFAULT_MAX_ELEMENTS = 200
DEFAULT_MAX_ISSUES = 100
MAX_ELEMENTS = 50000
MAX_ISSUES = 2000
MAX_PAIR_CHECKS = 250_000
_INTERACTIVE_TAGS = {"a", "button", "input", "select", "textarea", "summary", "option"}
_SEVERITY_ORDER = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "INFO": 4}


class UIMapperError(ValueError):
    pass


def _box(node: Mapping[str, Any]) -> Mapping[str, Any]:
    geometry = node.get("geometry") if isinstance(node.get("geometry"), Mapping) else {}
    return geometry.get("bbox") if isinstance(geometry.get("bbox"), Mapping) else {}


def _bounds(node: Mapping[str, Any]) -> Tuple[float, float, float, float]:
    box = _box(node)
    x = float(box.get("x", 0.0)); y = float(box.get("y", 0.0))
    w = float(box.get("width", 0.0)); h = float(box.get("height", 0.0))
    return x, y, x + w, y + h


def _rect_relation(a: Mapping[str, Any], b: Mapping[str, Any]) -> Dict[str, Any]:
    ax1, ay1, ax2, ay2 = _bounds(a); bx1, by1, bx2, by2 = _bounds(b)
    ow = max(0.0, min(ax2, bx2) - max(ax1, bx1))
    oh = max(0.0, min(ay2, by2) - max(ay1, by1))
    area = ow * oh
    aa = max(0.0, (ax2 - ax1) * (ay2 - ay1)); ba = max(0.0, (bx2 - bx1) * (by2 - by1))
    dx = max(bx1 - ax2, ax1 - bx2, 0.0); dy = max(by1 - ay2, ay1 - by2, 0.0)
    return {
        "overlap": area > 0.0,
        "overlap_width": ow,
        "overlap_height": oh,
        "overlap_area": area,
        "a_overlap_ratio": area / aa if aa > 0 else 0.0,
        "b_overlap_ratio": area / ba if ba > 0 else 0.0,
        "edge_gap_px": math.hypot(dx, dy),
        "a_contains_b": ax1 <= bx1 and ay1 <= by1 and ax2 >= bx2 and ay2 >= by2,
        "b_contains_a": bx1 <= ax1 and by1 <= ay1 and bx2 >= ax2 and by2 >= ay2,
    }


def _is_interactive(node: Mapping[str, Any]) -> bool:
    tag = str(node.get("tag_name") or "").lower()
    return tag in _INTERACTIVE_TAGS


def _node_indexes(nodes: Sequence[Mapping[str, Any]]) -> Tuple[Dict[str, Mapping[str, Any]], Dict[str, List[str]]]:
    by_id = {str(n.get("ui_id")): n for n in nodes if isinstance(n.get("ui_id"), str)}
    children: Dict[str, List[str]] = defaultdict(list)
    for node in nodes:
        ui_id = node.get("ui_id"); parent = node.get("parent_ui_id")
        if isinstance(ui_id, str) and isinstance(parent, str) and parent:
            children[parent].append(ui_id)
    for values in children.values():
        values.sort()
    return by_id, dict(children)


def _ancestor(ancestor: str, descendant: str, by_id: Mapping[str, Mapping[str, Any]]) -> bool:
    seen: set[str] = set(); current = by_id.get(descendant)
    while isinstance(current, Mapping):
        parent = current.get("parent_ui_id")
        if not isinstance(parent, str) or not parent or parent in seen:
            return False
        if parent == ancestor:
            return True
        seen.add(parent); current = by_id.get(parent)
    return False


def _depth(ui_id: str, by_id: Mapping[str, Mapping[str, Any]]) -> Tuple[int, bool]:
    seen: set[str] = set(); depth = 0; current = by_id.get(ui_id)
    while isinstance(current, Mapping):
        parent = current.get("parent_ui_id")
        if not isinstance(parent, str) or not parent:
            return depth, False
        if parent in seen or parent == ui_id:
            return depth, True
        seen.add(parent); depth += 1; current = by_id.get(parent)
    return depth, False


def _owner_index(ui_reference: Optional[Mapping[str, Any]], angular_ownership: Optional[Mapping[str, Any]]) -> Dict[str, Dict[str, Any]]:
    if not isinstance(ui_reference, Mapping):
        return {}
    corr = ui_reference.get("correspondence") if isinstance(ui_reference.get("correspondence"), Mapping) else {}
    mappings = corr.get("mappings") if isinstance(corr.get("mappings"), list) else []
    components: Dict[str, Mapping[str, Any]] = {}
    if isinstance(angular_ownership, Mapping):
        for row in angular_ownership.get("components", []) or []:
            if isinstance(row, Mapping) and isinstance(row.get("component_id"), str):
                components[str(row["component_id"])] = row
    result: Dict[str, Dict[str, Any]] = {}
    for row in mappings:
        if not isinstance(row, Mapping) or not isinstance(row.get("ui_id"), str):
            continue
        cid = row.get("component_id"); component = components.get(str(cid)) if cid else None
        resources: Dict[str, Any] = {"template": None, "styles": []}
        if isinstance(component, Mapping):
            template = component.get("template") if isinstance(component.get("template"), Mapping) else {}
            if template:
                resources["template"] = {k: template.get(k) for k in ("kind", "resolved_path", "proof_class", "content_proof_class") if template.get(k) is not None}
            for style in component.get("styles", []) or []:
                if isinstance(style, Mapping):
                    resources["styles"].append({k: style.get(k) for k in ("kind", "resolved_path", "proof_class", "content_proof_class") if style.get(k) is not None})
        result[str(row["ui_id"])] = {
            "proof_class": row.get("proof_class"),
            "reason": row.get("reason"),
            "component_id": cid,
            "component_file": row.get("component_file"),
            "component_class": row.get("component_class"),
            "component_selector": row.get("component_selector"),
            "resources": resources,
        }
    return result


def _issue(kind: str, severity: str, ui_ids: Sequence[str], details: Mapping[str, Any], *, candidate: bool = False) -> Dict[str, Any]:
    return {
        "kind": kind,
        "severity": severity,
        "ui_ids": list(ui_ids),
        "status": "CANDIDATE" if candidate else "DETECTED",
        "details": dict(details),
    }


def _overlap_severity(a: Mapping[str, Any], b: Mapping[str, Any], rel: Mapping[str, Any]) -> str:
    ratio = max(float(rel.get("a_overlap_ratio", 0.0)), float(rel.get("b_overlap_ratio", 0.0)))
    if (_is_interactive(a) or _is_interactive(b)) and ratio >= 0.5:
        return "CRITICAL"
    if _is_interactive(a) or _is_interactive(b) or ratio >= 0.25:
        return "HIGH"
    return "MEDIUM"


def _front_hint(a: Mapping[str, Any], b: Mapping[str, Any]) -> Optional[str]:
    ag = a.get("geometry") if isinstance(a.get("geometry"), Mapping) else {}
    bg = b.get("geometry") if isinstance(b.get("geometry"), Mapping) else {}
    az = ag.get("z_index"); bz = bg.get("z_index")
    if isinstance(az, (int, float)) and isinstance(bz, (int, float)) and az != bz:
        return str(a.get("ui_id")) if float(az) > float(bz) else str(b.get("ui_id"))
    return None


def _detect_issues(
    geometry: Mapping[str, Any],
    *,
    min_gap_px: float,
    max_issues: int,
) -> Tuple[List[Dict[str, Any]], Dict[str, Any]]:
    nodes = geometry.get("nodes") if isinstance(geometry.get("nodes"), list) else []
    scenario = geometry.get("scenario") if isinstance(geometry.get("scenario"), Mapping) else {}
    viewport = scenario.get("viewport") if isinstance(scenario.get("viewport"), Mapping) else {}
    vw = float(viewport.get("width", 0.0)); vh = float(viewport.get("height", 0.0))
    by_id, children = _node_indexes(nodes)
    issues: List[Dict[str, Any]] = []
    pair_checks = 0; pair_truncated = False

    for node in nodes:
        ui_id = str(node.get("ui_id")); g = node.get("geometry") if isinstance(node.get("geometry"), Mapping) else {}
        visible = g.get("visible") is True
        box = _box(node); w = float(box.get("width", 0.0)); h = float(box.get("height", 0.0))
        if visible and (w <= 0.0 or h <= 0.0):
            issues.append(_issue("VISIBLE_ZERO_SIZE", "MEDIUM", [ui_id], {"bbox": dict(box)}))
        if visible and not bool(g.get("fully_inside_viewport")):
            x1, y1, x2, y2 = _bounds(node)
            overflow = {"left": max(0.0, -x1), "top": max(0.0, -y1), "right": max(0.0, x2-vw), "bottom": max(0.0, y2-vh)}
            severity = "HIGH" if _is_interactive(node) else "MEDIUM"
            issues.append(_issue("OUTSIDE_VIEWPORT", severity, [ui_id], {"overflow": overflow, "bbox": dict(box)}))
        parent_id = node.get("parent_ui_id")
        if isinstance(parent_id, str) and parent_id:
            parent = by_id.get(parent_id)
            if parent is None:
                issues.append(_issue("MISSING_PARENT", "MEDIUM", [ui_id], {"parent_ui_id": parent_id}))
            else:
                rel = _rect_relation(node, parent)
                if not rel["b_contains_a"]:
                    issues.append(_issue("EXTENDS_PARENT_BOUNDS", "MEDIUM", [ui_id, parent_id], {"relation": rel}, candidate=True))
        _, cycle = _depth(ui_id, by_id)
        if cycle:
            issues.append(_issue("PARENT_CYCLE", "HIGH", [ui_id], {}, candidate=False))

    visible = [n for n in nodes if isinstance(n, Mapping) and (n.get("geometry") or {}).get("visible") is True and float(_box(n).get("width",0.0)) > 0 and float(_box(n).get("height",0.0)) > 0]
    visible.sort(key=lambda n: (_bounds(n)[0], _bounds(n)[1], str(n.get("ui_id"))))
    active: List[Mapping[str, Any]] = []
    for current in visible:
        cx1, _, _, _ = _bounds(current)
        active = [n for n in active if _bounds(n)[2] + min_gap_px > cx1]
        for other in active:
            pair_checks += 1
            if pair_checks > MAX_PAIR_CHECKS:
                pair_truncated = True; break
            aid = str(other.get("ui_id")); bid = str(current.get("ui_id"))
            if _ancestor(aid, bid, by_id) or _ancestor(bid, aid, by_id):
                continue
            rel = _rect_relation(other, current)
            if rel["overlap"]:
                issues.append(_issue("OVERLAP", _overlap_severity(other, current, rel), [aid, bid], {"relation": rel, "likely_front_ui_id": _front_hint(other,current)}))
            elif min_gap_px > 0.0 and other.get("parent_ui_id") == current.get("parent_ui_id") and _is_interactive(other) and _is_interactive(current) and float(rel["edge_gap_px"]) < min_gap_px:
                issues.append(_issue("INTERACTIVE_GAP", "LOW", [aid, bid], {"edge_gap_px": rel["edge_gap_px"], "minimum_gap_px": min_gap_px}, candidate=True))
        if pair_truncated:
            break
        active.append(current)

    issues.sort(key=lambda row: (_SEVERITY_ORDER.get(str(row.get("severity")), 99), str(row.get("kind")), row.get("ui_ids", [])))
    total = len(issues)
    by_kind: Dict[str, int] = defaultdict(int); by_severity: Dict[str, int] = defaultdict(int)
    for row in issues:
        by_kind[str(row["kind"])] += 1; by_severity[str(row["severity"])] += 1
    return issues[:max_issues], {
        "issue_count": total,
        "returned_issue_count": min(total, max_issues),
        "omitted_issue_count": max(0, total - max_issues),
        "pair_checks": pair_checks,
        "pair_check_truncated": pair_truncated,
        "issues_by_kind": dict(sorted(by_kind.items())),
        "issues_by_severity": dict(sorted(by_severity.items())),
    }


def build_ui_map(
    snapshot: Mapping[str, Any],
    *,
    ui_reference: Optional[Mapping[str, Any]] = None,
    angular_ownership: Optional[Mapping[str, Any]] = None,
    min_gap_px: float = 0.0,
    max_elements: int = DEFAULT_MAX_ELEMENTS,
    max_issues: int = DEFAULT_MAX_ISSUES,
) -> Dict[str, Any]:
    if isinstance(max_elements, bool) or not isinstance(max_elements, int) or not 1 <= max_elements <= MAX_ELEMENTS:
        raise UIMapperError(f"max_elements must be between 1 and {MAX_ELEMENTS}")
    if isinstance(max_issues, bool) or not isinstance(max_issues, int) or not 1 <= max_issues <= MAX_ISSUES:
        raise UIMapperError(f"max_issues must be between 1 and {MAX_ISSUES}")
    if isinstance(min_gap_px, bool) or not isinstance(min_gap_px, (int, float)) or not math.isfinite(float(min_gap_px)) or float(min_gap_px) < 0:
        raise UIMapperError("min_gap_px must be a finite non-negative number")

    geometry = normalize_geometry_snapshot(dict(snapshot))
    nodes = geometry["nodes"]; by_id, children = _node_indexes(nodes)
    owners = _owner_index(ui_reference, angular_ownership)
    roots = sorted(str(n["ui_id"]) for n in nodes if not n.get("parent_ui_id") or n.get("parent_ui_id") not in by_id)
    elements: List[Dict[str, Any]] = []
    for node in sorted(nodes, key=lambda n: (_depth(str(n["ui_id"]), by_id)[0], str(n["ui_id"])))[:max_elements]:
        ui_id = str(node["ui_id"]); depth, cycle = _depth(ui_id, by_id)
        elements.append({
            "ui_id": ui_id,
            "tag_name": node.get("tag_name"),
            "parent_ui_id": node.get("parent_ui_id"),
            "depth": depth,
            "parent_cycle": cycle,
            "children": children.get(ui_id, []),
            "child_count": len(children.get(ui_id, [])),
            "bbox": dict(_box(node)),
            "visible": node.get("geometry", {}).get("visible"),
            "z_index": node.get("geometry", {}).get("z_index"),
            "fully_inside_viewport": node.get("geometry", {}).get("fully_inside_viewport"),
            "interactive": _is_interactive(node),
            "code_owner": owners.get(ui_id),
        })
    issues, issue_summary = _detect_issues(geometry, min_gap_px=float(min_gap_px), max_issues=max_issues)
    correspondence = ui_reference.get("correspondence") if isinstance(ui_reference, Mapping) and isinstance(ui_reference.get("correspondence"), Mapping) else {}
    corr_summary = correspondence.get("summary") if isinstance(correspondence.get("summary"), Mapping) else {}
    result: Dict[str, Any] = {
        "schema_version": UI_MAP_SCHEMA_VERSION,
        "scenario_id": geometry["scenario_id"],
        "scenario": geometry["scenario"],
        "geometry_snapshot_digest": geometry["geometry_snapshot_digest"],
        "summary": {
            "node_count": len(nodes),
            "returned_element_count": len(elements),
            "omitted_element_count": max(0, len(nodes)-len(elements)),
            "root_count": len(roots),
            "visible_node_count": geometry["summary"].get("visible_node_count",0),
            "fully_inside_viewport_count": geometry["summary"].get("fully_inside_viewport_count",0),
            **issue_summary,
            "correspondence_exact": int(corr_summary.get("exact_count",0) or 0),
            "correspondence_structural": int(corr_summary.get("structural_count",0) or 0),
            "correspondence_unresolved": int(corr_summary.get("unresolved_count",0) or 0),
        },
        "hierarchy": {"roots": roots, "elements": elements},
        "issues": issues,
        "agent_brief": {
            "viewport": geometry["scenario"]["viewport"],
            "root_ui_ids": roots[:20],
            "highest_priority_issues": issues[:12],
            "next_action": "inspect exact affected ui_id(s), then use code_owner/correspondence before editing layout code" if issues else "no mapped collision/viewport issue detected in this scenario",
        },
        "authority": {
            "geometry_authority": "codebase.geometry_correspondence.GeometrySnapshot",
            "correspondence_authority": "codebase.geometry_correspondence.UIAngularCorrespondence" if ui_reference else None,
            "ui_map_is_derived_view": True,
            "browser_executed_by_mapper": False,
            "source_mutated": False,
            "truth_committed": False,
        },
    }
    result["ui_map_digest"] = canonical_ui_digest({
        "scenario_id": result["scenario_id"],
        "geometry_snapshot_digest": result["geometry_snapshot_digest"],
        "summary": result["summary"],
        "hierarchy": result["hierarchy"],
        "issues": result["issues"],
    })
    return result


def inspect_ui_element(ui_map: Mapping[str, Any], ui_id: str) -> Dict[str, Any]:
    hierarchy = ui_map.get("hierarchy") if isinstance(ui_map.get("hierarchy"), Mapping) else {}
    elements = hierarchy.get("elements") if isinstance(hierarchy.get("elements"), list) else []
    target = next((row for row in elements if isinstance(row, Mapping) and row.get("ui_id") == ui_id), None)
    if target is None:
        raise UIMapperError(f"ui_id not present in bounded map: {ui_id}")
    by_id = {str(row.get("ui_id")): row for row in elements if isinstance(row, Mapping) and isinstance(row.get("ui_id"), str)}
    path=[]; current: Optional[Mapping[str, Any]] = target; seen=set()
    while isinstance(current, Mapping):
        cid=str(current.get("ui_id")); path.append(cid); parent=current.get("parent_ui_id")
        if not isinstance(parent,str) or not parent or parent in seen: break
        seen.add(parent); current=by_id.get(parent)
    path.reverse()
    issues=[row for row in ui_map.get("issues",[]) if isinstance(row,Mapping) and ui_id in (row.get("ui_ids") or [])]
    return {
        "schema_version":"ui-inspect-v1",
        "scenario_id":ui_map.get("scenario_id"),
        "ui_id":ui_id,
        "hierarchy_path":path,
        "element":dict(target),
        "related_issues":issues,
        "ui_map_digest":ui_map.get("ui_map_digest"),
    }


def build_browser_capture_script(
    *,
    code_revision: str,
    graph_content_signature: Optional[str] = None,
    angular_ownership_digest: Optional[str] = None,
    ui_state: str = "default",
    data_fixture: str = "default",
    max_nodes: int = 5000,
) -> str:
    if not isinstance(code_revision,str) or not code_revision.strip():
        raise UIMapperError("code_revision is required")
    if not 1 <= int(max_nodes) <= 50000:
        raise UIMapperError("max_nodes must be between 1 and 50000")
    cfg={"code_revision":code_revision.strip(),"ui_state":str(ui_state or "default"),"data_fixture":str(data_fixture or "default"),"graph_content_signature":graph_content_signature,"angular_ownership_digest":angular_ownership_digest,"max_nodes":int(max_nodes),"capture_version":CAPTURE_SCRIPT_VERSION}
    config_json=json.dumps(cfg,ensure_ascii=False,separators=(",",":"))
    # Expression suitable for page.evaluate().  It reads geometry only and does not mutate DOM.
    return f'''(() => {{
  const config = {config_json};
  const all = [document.documentElement, ...Array.from(document.querySelectorAll("body, body *"))];
  const selected = all.slice(0, config.max_nodes);
  const idByElement = new Map();
  const used = new Map();
  function domPath(el) {{
    const parts=[]; let cur=el;
    while (cur && cur.nodeType===1 && cur!==document.documentElement) {{
      let part=cur.tagName.toLowerCase();
      if (cur.id) {{ part += "#" + cur.id; parts.unshift(part); break; }}
      const parent=cur.parentElement;
      if (parent) {{
        const same=Array.from(parent.children).filter(x=>x.tagName===cur.tagName);
        if (same.length>1) part += `:nth-of-type(${{same.indexOf(cur)+1}})`;
      }}
      parts.unshift(part); cur=parent;
    }}
    return "/" + parts.join("/");
  }}
  function unique(base) {{
    const n=(used.get(base)||0)+1; used.set(base,n); return n===1 ? base : `${{base}}~${{n}}`;
  }}
  for (const el of selected) {{
    const path=domPath(el);
    const explicit=el.getAttribute("data-plw-ui-id");
    const testid=el.getAttribute("data-testid");
    const base=explicit ? `plw:${{explicit}}` : (el.id ? `id:${{el.id}}` : (testid ? `testid:${{testid}}` : `dom:${{path}}`));
    idByElement.set(el, unique(base).slice(0,2048));
  }}
  function ownerSelector(el) {{
    let cur=el;
    while (cur && cur.nodeType===1) {{
      const tag=cur.tagName.toLowerCase();
      if (tag.includes("-")) return tag;
      cur=cur.parentElement;
    }}
    return null;
  }}
  function matrix(transform) {{
    if (!transform || transform === "none") return null;
    const m=transform.match(/^matrix\\(([-+0-9.eE]+),\\s*([-+0-9.eE]+),\\s*([-+0-9.eE]+),\\s*([-+0-9.eE]+),\\s*([-+0-9.eE]+),\\s*([-+0-9.eE]+)\\)$/);
    return m ? m.slice(1).map(Number) : null;
  }}
  const nodes=[];
  for (const el of selected) {{
    const rect=el.getBoundingClientRect(); const cs=getComputedStyle(el);
    const visible=cs.display!=="none" && cs.visibility!=="hidden" && cs.visibility!=="collapse" && Number(cs.opacity)>0 && rect.width>0 && rect.height>0;
    const z=cs.zIndex==="auto" ? null : Number(cs.zIndex);
    const parent=el.parentElement;
    nodes.push({{
      ui_id:idByElement.get(el),
      tag_name:el.tagName.toLowerCase(),
      parent_ui_id:parent && idByElement.has(parent) ? idByElement.get(parent) : null,
      dom_path:domPath(el),
      bbox:[rect.x,rect.y,rect.width,rect.height],
      visible,
      z_index:Number.isFinite(z) ? z : null,
      opacity:Number(cs.opacity),
      transform:matrix(cs.transform),
      owner:{{component_selector:ownerSelector(el)}}
    }});
  }}
  return {{
    schema_version:"geometry-snapshot-v1",
    scenario:{{
      code_revision:config.code_revision,
      route:(location.pathname + location.search + location.hash) || "/",
      viewport:{{width:window.innerWidth,height:window.innerHeight,device_scale_factor:window.devicePixelRatio||1}},
      ui_state:config.ui_state,
      data_fixture:config.data_fixture
    }},
    static_context:{{graph_content_signature:config.graph_content_signature,angular_ownership_digest:config.angular_ownership_digest}},
    capture:{{source:config.capture_version,captured_at:new Date().toISOString(),runtime_id:null}},
    nodes
  }};
}})()'''


__all__=["UI_MAP_SCHEMA_VERSION","CAPTURE_SCRIPT_VERSION","UIMapperError","build_ui_map","inspect_ui_element","build_browser_capture_script"]
