"""Bounded UI fix planning and exact-scenario post-fix verification.

This module consumes cross-domain diagnosis + causal-isolation evidence.
It never writes repository source.  A fix plan is only generated for a
structural candidate that has candidate-bound COUNTERFACTUAL_SUPPORT.
Post-fix verification reruns the exact diagnosed scenario and checks that the
expected symptom is gone without simply hiding/removing the affected UI nodes.
"""
from __future__ import annotations

from typing import Any, Dict, List, Mapping, Optional, Sequence

from codebase.geometry_correspondence import build_ui_reference_state
from ui.common import canonical_ui_digest
from ui.mapper import build_ui_map
from ui.reproduce import UIReproductionError, execute_targeted_ui_reproduction, _select_diagnosis

UI_BOUNDED_FIX_PLAN_SCHEMA_VERSION = "ui-bounded-fix-plan-v1"
UI_POST_FIX_VERIFICATION_SCHEMA_VERSION = "ui-post-fix-verification-v1"
MAX_FIX_PROPOSALS = 8


class UIFixError(RuntimeError):
    pass


def _candidate_rows(selected: Mapping[str, Any]) -> Dict[str, Mapping[str, Any]]:
    structural = selected.get("structural_context") if isinstance(selected.get("structural_context"), Mapping) else {}
    rows = structural.get("structural_cause_candidates", []) or []
    return {str(row.get("path")): row for row in rows if isinstance(row, Mapping) and row.get("path")}


def _guidance(role: str, category: str) -> List[str]:
    role = str(role or "structural_candidate")
    category = str(category or "UI_LAYOUT")
    if role == "style_owner":
        return [
            "change the smallest CSS/layout rule that controls the reproduced geometry",
            "preserve the affected UI nodes and their interaction semantics",
            "avoid unrelated selector/token changes unless new evidence requires them",
        ]
    if role == "template_owner":
        return [
            "change only the minimum rendered structure needed to remove the reproduced symptom",
            "preserve stable element identity when possible so correspondence remains valid",
            "do not delete an affected interactive element merely to clear the symptom",
        ]
    if role == "render_owner":
        return [
            "change only the component render/layout behavior implicated by the counterfactual probe",
            "preserve external component contracts unless separately justified",
        ]
    if role in {"layout_state_owner", "state_owner", "service_dependency"}:
        return [
            "change only the state/service behavior whose intervention changed the symptom",
            "do not treat topological proximity as sufficient justification for broader refactors",
            "reproduce the exact scenario after the change before expanding scope",
        ]
    return [
        f"make the smallest source change to this {role} consistent with the {category} evidence",
        "do not modify unrelated files without new evidence",
    ]


def build_bounded_ui_fix_plan(
    diagnosis: Mapping[str, Any],
    isolation: Mapping[str, Any],
    *,
    candidate_id: Optional[str] = None,
    max_proposals: int = 3,
) -> Dict[str, Any]:
    if isinstance(max_proposals, bool) or not isinstance(max_proposals, int) or not 1 <= max_proposals <= MAX_FIX_PROPOSALS:
        raise UIFixError(f"max_proposals must be between 1 and {MAX_FIX_PROPOSALS}")
    try:
        selected = _select_diagnosis(diagnosis, candidate_id or isolation.get("candidate_id"))
    except UIReproductionError as exc:
        raise UIFixError(str(exc)) from exc
    if isolation.get("candidate_id") and isolation.get("candidate_id") != selected.get("candidate_id"):
        raise UIFixError("isolation candidate_id does not match diagnosis")
    if isolation.get("baseline_reproduction", {}).get("state") != "REPRODUCED":
        raise UIFixError("fix planning requires a reproduced baseline symptom")

    known = _candidate_rows(selected)
    supported = []
    for row in isolation.get("ranked_candidates", []) or isolation.get("probes", []) or []:
        if not isinstance(row, Mapping):
            continue
        if row.get("causal_evidence_state") != "COUNTERFACTUAL_SUPPORT" or row.get("structural_candidate_bound") is False:
            continue
        path = str(row.get("structural_path") or "")
        if path and path in known:
            supported.append((row, known[path]))
    if not supported:
        raise UIFixError("no candidate-bound COUNTERFACTUAL_SUPPORT is available for bounded fix planning")

    scenario = (selected.get("targeted_reproduction") or {}).get("minimum_scenario") or isolation.get("scenario") or {}
    ui_ids = [str(v) for v in selected.get("ui_ids", []) or []]
    proposals: List[Dict[str, Any]] = []
    for index, (probe, structural) in enumerate(supported[:max_proposals], start=1):
        path = str(probe.get("structural_path") or structural.get("path") or "")
        role = str(probe.get("role") or structural.get("role") or "structural_candidate")
        proposals.append({
            "proposal_id": f"fix-{index}",
            "structural_path": path,
            "role": role,
            "counterfactual_evidence": "COUNTERFACTUAL_SUPPORT",
            "probe_id": probe.get("probe_id"),
            "structural_score": probe.get("structural_score", structural.get("structural_score")),
            "change_guidance": _guidance(role, str(selected.get("category") or "")),
            "scope_contract": {
                "allowed_primary_paths": [path],
                "additional_paths_require_new_evidence": True,
                "delete_or_hide_affected_ui_to_clear_symptom": False,
            },
            "post_fix_validation": {
                "exact_scenario": dict(scenario),
                "affected_ui_ids": ui_ids,
                "expected_symptom": (selected.get("targeted_reproduction") or {}).get("expected_observation"),
                "success_requires": [
                    "expected symptom is NOT_REPRODUCED in the exact scenario",
                    "affected UI nodes remain present and visible",
                    "no new CRITICAL issue involves the affected UI nodes",
                ],
            },
        })

    result: Dict[str, Any] = {
        "schema_version": UI_BOUNDED_FIX_PLAN_SCHEMA_VERSION,
        "candidate_id": selected.get("candidate_id"),
        "category": selected.get("category"),
        "scenario": dict(scenario),
        "affected_ui_ids": ui_ids,
        "isolation_digest": isolation.get("isolation_digest"),
        "proposals": proposals,
        "summary": {
            "proposal_count": len(proposals),
            "primary_target_paths": [row["structural_path"] for row in proposals],
        },
        "authority": {
            "source_mutated_by_plw": False,
            "patch_generated": False,
            "counterfactual_support_required": True,
            "fix_verified": False,
            "postcondition_proven": False,
            "truth_committed": False,
        },
        "proof_boundary": {
            "fix_plan_is_mutation_authority": False,
            "counterfactual_support_is_complete_root_cause_proof": False,
            "symptom_clearance_is_full_codebase_safety": False,
        },
    }
    result["fix_plan_digest"] = canonical_ui_digest({k: v for k, v in result.items() if k != "fix_plan_digest"})
    return result




def _raw_from_normalized_geometry(snapshot: Mapping[str, Any]) -> Dict[str, Any]:
    """Convert PLW normalized GeometrySnapshot back into mapper-compatible payload."""
    scenario = snapshot.get("scenario") if isinstance(snapshot.get("scenario"), Mapping) else {}
    viewport = scenario.get("viewport") if isinstance(scenario.get("viewport"), Mapping) else {}
    raw_nodes = []
    for row in snapshot.get("nodes", []) or []:
        if not isinstance(row, Mapping):
            continue
        geom = row.get("geometry") if isinstance(row.get("geometry"), Mapping) else {}
        box = geom.get("bbox") if isinstance(geom.get("bbox"), Mapping) else {}
        raw_nodes.append({
            "ui_id": row.get("ui_id"),
            "tag_name": row.get("tag_name"),
            "parent_ui_id": row.get("parent_ui_id"),
            "bbox": [box.get("x", 0), box.get("y", 0), box.get("width", 0), box.get("height", 0)],
            "visible": geom.get("visible", False),
            "z_index": geom.get("z_index"),
            "opacity": geom.get("opacity", 1),
            "transform": geom.get("transform"),
            "owner": dict(row.get("owner") or {}),
        })
    return {
        "schema_version": "geometry-snapshot-v1",
        "scenario": {
            "code_revision": scenario.get("code_revision"),
            "route": scenario.get("route"),
            "viewport": [viewport.get("width", 0), viewport.get("height", 0)],
            "ui_state": scenario.get("ui_state"),
            "data_fixture": scenario.get("data_fixture"),
        },
        "static_context": dict(snapshot.get("static_context") or {}),
        "capture": dict(snapshot.get("capture") or {}),
        "nodes": raw_nodes,
    }

def verify_bounded_ui_fix(
    diagnosis: Mapping[str, Any],
    fix_plan: Mapping[str, Any],
    *,
    angular_ownership: Mapping[str, Any],
    candidate_id: Optional[str] = None,
    proposal_id: Optional[str] = None,
    url: Optional[str] = None,
    html_file: Optional[str] = None,
    setup_js_file: Optional[str] = None,
    browser: Optional[str] = None,
    timeout_seconds: int = 20,
    min_gap_px: float = 0.0,
    max_nodes: int = 5000,
) -> Dict[str, Any]:
    try:
        selected = _select_diagnosis(diagnosis, candidate_id or fix_plan.get("candidate_id"))
    except UIReproductionError as exc:
        raise UIFixError(str(exc)) from exc
    if fix_plan.get("candidate_id") and fix_plan.get("candidate_id") != selected.get("candidate_id"):
        raise UIFixError("fix plan candidate_id does not match diagnosis")
    proposals = [row for row in fix_plan.get("proposals", []) or [] if isinstance(row, Mapping)]
    if not proposals:
        raise UIFixError("fix plan contains no proposals")
    proposal = None
    if proposal_id:
        proposal = next((row for row in proposals if row.get("proposal_id") == proposal_id), None)
        if proposal is None:
            raise UIFixError("proposal_id not found in fix plan")
    else:
        proposal = proposals[0]

    runtime = execute_targeted_ui_reproduction(
        diagnosis,
        angular_ownership=angular_ownership,
        candidate_id=str(selected.get("candidate_id")),
        url=url,
        html_file=html_file,
        setup_js_file=setup_js_file,
        browser=browser,
        timeout_seconds=timeout_seconds,
        min_gap_px=min_gap_px,
        max_nodes=max_nodes,
    )
    state = str(runtime.get("reproduction_state") or "UNRESOLVED")
    affected = [str(v) for v in selected.get("ui_ids", []) or []]
    presence: Dict[str, Any] = {}
    new_critical: List[Dict[str, Any]] = []
    scope_safe = False
    if state == "NOT_REPRODUCED" and isinstance(runtime.get("observed_geometry_snapshot"), Mapping):
        normalized = runtime["observed_geometry_snapshot"]
        raw = _raw_from_normalized_geometry(normalized)
        ui_ref = build_ui_reference_state(raw, dict(angular_ownership))
        ui_map = build_ui_map(raw, ui_reference=ui_ref, angular_ownership=angular_ownership, min_gap_px=min_gap_px, max_elements=50_000, max_issues=2_000)
        elements = (ui_map.get("hierarchy") or {}).get("elements", []) if isinstance(ui_map.get("hierarchy"), Mapping) else []
        by_id = {str(row.get("ui_id")): row for row in elements if isinstance(row, Mapping) and row.get("ui_id")}
        for ui_id in affected:
            row = by_id.get(ui_id)
            presence[ui_id] = {
                "present": row is not None,
                "visible": bool(row.get("visible")) if isinstance(row, Mapping) else False,
            }
        for issue in ui_map.get("issues", []) or []:
            if not isinstance(issue, Mapping) or str(issue.get("severity") or "").upper() != "CRITICAL":
                continue
            issue_ids = {str(v) for v in issue.get("ui_ids", []) or []}
            if issue_ids.intersection(affected):
                new_critical.append(dict(issue))
        scope_safe = all(row["present"] and row["visible"] for row in presence.values()) and not new_critical

    if state == "REPRODUCED":
        verification_state = "FIX_FAILED"
        reason = "expected_symptom_still_reproduced"
    elif state == "UNRESOLVED":
        verification_state = "FIX_UNRESOLVED"
        reason = "post_fix_runtime_unresolved"
    elif not scope_safe:
        verification_state = "FIX_SCOPE_UNSAFE"
        reason = "symptom_cleared_but_affected_ui_integrity_check_failed"
    else:
        verification_state = "FIX_VERIFIED"
        reason = "expected_symptom_cleared_and_bounded_ui_scope_remains_intact"

    result: Dict[str, Any] = {
        "schema_version": UI_POST_FIX_VERIFICATION_SCHEMA_VERSION,
        "candidate_id": selected.get("candidate_id"),
        "proposal_id": proposal.get("proposal_id"),
        "structural_path": proposal.get("structural_path"),
        "role": proposal.get("role"),
        "verification_state": verification_state,
        "reason": reason,
        "exact_scenario": runtime.get("requested_scenario"),
        "runtime_reproduction_state": state,
        "affected_ui_integrity": presence,
        "new_critical_issues_on_affected_ui": new_critical,
        "runtime_reproduction_digest": runtime.get("reproduction_digest"),
        "authority": {
            "browser_executed_by_plw": True,
            "source_mutated_by_plw": False,
            "exact_scenario_symptom_cleared": verification_state in {"FIX_VERIFIED", "FIX_SCOPE_UNSAFE"},
            "bounded_fix_verified": verification_state == "FIX_VERIFIED",
            "full_codebase_safe": False,
            "postcondition_proven": False,
            "stable_promoted": False,
            "truth_committed": False,
        },
        "proof_boundary": {
            "fix_verified_is_full_regression_proof": False,
            "exact_scenario_clearance_is_global_safety": False,
            "source_change_was_not_performed_by_plw": True,
        },
    }
    result["verification_digest"] = canonical_ui_digest({k: v for k, v in result.items() if k != "verification_digest"})
    return result


__all__ = [
    "UI_BOUNDED_FIX_PLAN_SCHEMA_VERSION",
    "UI_POST_FIX_VERIFICATION_SCHEMA_VERSION",
    "UIFixError",
    "build_bounded_ui_fix_plan",
    "verify_bounded_ui_fix",
]
