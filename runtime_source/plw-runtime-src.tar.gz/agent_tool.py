#!/usr/bin/env python3
"""JSON tool-call adapter for the portable PLW reference machine.

Ordinary agent work uses the typed ``work`` request and stays in-process.
Uncommon kernel/PLW operations remain reachable through a bounded argv array;
no shell is involved, and state-changing tool operations require a literal
``allow_state_change=true`` acknowledgement.
"""

from __future__ import annotations

import json
import os
import re
import subprocess
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

import hott_kernel


TOOL_CALL_SCHEMA_VERSION = "plw-agent-tool-call-v1"
TOOL_ROOT = Path(__file__).resolve().parent
PUBLIC_PLW_COMMANDS = (
    "topology",
    "resolve-target",
    "evidence-needs",
    "capability-match",
    "work",
    "semantic",
    "context",
    "transitions",
    "kan",
    "check",
    "steer",
    "brief",
    "impact",
    "outline",
    "compact-output",
    "recover-output",
    "attest-runtime",
    "output-telemetry",
    "transition-memory",
    "transition-model",
    "q-values",
    "reconcile-outcomes",
    "lineage",
    "simplify",
    "accountability",
    "accountability-chain",
    "action-lease",
    "action-outcome",
    "action-adapter",
    "angular-anchors",
    "ui-reference",
    "runtime-ui-reference",
    "geometric-impact",
    "validation-plan",
    "validation-evidence",
    "validation-coverage",
    "validation-request",
    "validation-authorization",
    "validation-lease",
    "validation-attempt",
    "validation-dispatch",
    "validation-runtime",
    "validation-result",
    "validation-scenario-bind",
    "postcondition-proof",
    "fullstack-state",
    "install",
    "memory",
    "fiber",
)

_KERNEL_STATE_MODES = {
    "establish",
    "memory_store",
    "memory_associate",
    "memory_consolidate",
    "memory_establish",
    "memory_compact",
    "memory_bridge",
    "memory_bridge_auto",
}
_MEMORY_READ_SUBCOMMANDS = {
    "get",
    "recall",
    "analyze",
    "stats",
    "steer",
    "drift",
    "betti_breakdown",
    "unconsolidated_tags",
    "bridge_candidates",
    "kan",
}
_FIBER_READ_SUBCOMMANDS = {"status", "section_status", "list_archives"}
_PLW_STATE_COMMANDS = {"attest-runtime", "install"}
_COMMAND_NAME = re.compile(r"^[a-z][a-z0-9_-]*$")


def _error(error_code: str, message: str, **details: Any) -> Dict[str, Any]:
    return {
        "schema_version": TOOL_CALL_SCHEMA_VERSION,
        "error": message,
        "error_code": error_code,
        **details,
    }


def _integer(value: Any, default: int, label: str) -> int | Dict[str, Any]:
    if value is None:
        return default
    if isinstance(value, bool):
        return _error("invalid_tool_argument", f"{label} must be an integer.", argument=label)
    try:
        return int(value)
    except (TypeError, ValueError):
        return _error("invalid_tool_argument", f"{label} must be an integer.", argument=label)


def _targets(value: Any) -> List[str] | Dict[str, Any]:
    if value is None:
        return []
    if isinstance(value, str):
        result = [item.strip() for item in value.split(",") if item.strip()]
    elif isinstance(value, list) and all(isinstance(item, str) for item in value):
        result = [item.strip() for item in value if item.strip()]
    else:
        return _error(
            "invalid_tool_argument",
            "target_files must be a comma-separated string or string array.",
            argument="target_files",
        )
    return result


def _configure_runtime(request: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    cache_mode = request.get("cache_mode")
    if cache_mode is not None:
        cache_error = hott_kernel._set_graph_cache_mode(str(cache_mode))
        if cache_error:
            return cache_error
    runtime_options = {
        "project_root": request.get("memory_project_root"),
        "scope": request.get("memory_scope"),
        "state_dir": request.get("memory_state_dir"),
    }
    if any(value is not None for value in runtime_options.values()):
        if not hott_kernel.MEMORY_RUNTIME_AVAILABLE:
            return _error(
                "memory_runtime_unavailable",
                "Memory runtime configuration is not available.",
            )
        hott_kernel.configure_memory_runtime(**runtime_options)
    return None


def _work(request: Dict[str, Any]) -> Dict[str, Any]:
    task = request.get("task")
    if not isinstance(task, str) or not task.strip():
        return _error("missing_work_task", "mode=work requires a non-empty task.")
    targets = _targets(request.get("target_files"))
    if isinstance(targets, dict):
        return targets
    budget = _integer(request.get("budget_tokens"), 1200, "budget_tokens")
    if isinstance(budget, dict):
        return budget
    max_hops = _integer(request.get("max_hops"), 2, "max_hops")
    if isinstance(max_hops, dict):
        return max_hops
    max_findings = _integer(request.get("max_findings"), 24, "max_findings")
    if isinstance(max_findings, dict):
        return max_findings
    proactive_truth = request.get("proactive_truth", True)
    if not isinstance(proactive_truth, bool):
        return _error(
            "invalid_tool_argument",
            "proactive_truth must be a literal boolean.",
            argument="proactive_truth",
        )
    runtime_error = _configure_runtime(request)
    if runtime_error:
        return runtime_error
    return hott_kernel.kernel_work(
        scan_root=str(request.get("scan_root") or "."),
        task=task,
        target_files=targets or None,
        goal=str(request.get("goal") or "auto"),
        depth=str(request.get("depth") or "auto"),
        budget_tokens=budget,
        max_hops=max_hops,
        detail=str(request.get("detail") or "source"),
        max_findings=max_findings,
        proactive_truth=proactive_truth,
        truth_scope=(
            str(request["truth_scope"])
            if request.get("truth_scope") is not None
            else None
        ),
    )


def _requires_state_acknowledgement(
    surface: str,
    mode: str,
    arguments: List[str],
) -> bool:
    if surface == "kernel":
        if mode in _KERNEL_STATE_MODES:
            if mode == "memory_bridge_auto" and "--dry-run" in arguments:
                return False
            if mode == "memory_compact" and ("--dry-run" in arguments or "--stats" in arguments):
                return False
            return True
        if mode == "cache":
            return bool(arguments and arguments[0] in {"refresh", "clear"})
        if mode == "xanalyze":
            return "--no-store" not in arguments
        if mode == "memory":
            return not arguments or arguments[0] not in _MEMORY_READ_SUBCOMMANDS
        if mode == "fiber":
            return not arguments or arguments[0] not in _FIBER_READ_SUBCOMMANDS
        return False

    if mode in _PLW_STATE_COMMANDS:
        return True
    if mode == "action-lease":
        return bool(arguments and arguments[0] == "acquire")
    if mode == "action-outcome":
        return bool(arguments and arguments[0] in {"register", "record"})
    if mode == "action-adapter":
        return bool(arguments and arguments[0] in {"prepare", "observe"})
    if mode == "validation-attempt":
        return bool(arguments and arguments[0] == "register")
    if mode == "validation-dispatch":
        return bool(arguments and arguments[0] == "prepare")
    if mode == "validation-runtime":
        return bool(arguments and arguments[0] in {"claim", "observe"})
    if mode == "validation-result":
        return bool(arguments and arguments[0] == "accept")
    if mode == "validation-lease":
        return bool(arguments and arguments[0] == "acquire")
    if mode == "reconcile-outcomes":
        return "--record" in arguments
    if mode == "compact-output":
        return "--no-store" not in arguments
    if mode == "memory":
        return not arguments or arguments[0] not in _MEMORY_READ_SUBCOMMANDS
    if mode == "fiber":
        return not arguments or arguments[0] not in _FIBER_READ_SUBCOMMANDS
    if mode == "xanalyze":
        return "--no-store" not in arguments
    return False


def _capabilities() -> Dict[str, Any]:
    return {
        "schema_version": TOOL_CALL_SCHEMA_VERSION,
        "mode": "capabilities",
        "preferred_entrypoint": {
            "mode": "work",
            "reason": "task work shares one graph across target orientation, target resolution, context, target briefs, proof gate, and predictive semantics",
        },
        "first_contact_entrypoint": {
            "mode": "topology",
            "reason": "map the unfamiliar target repository before selecting a specialized capability",
        },
        "semantic_bootstrap": {
            "first_contact_path": "topology maps the target repository; resolve-target grounds the task to graph nodes; evidence-needs derives unsupported claims; capability-match projects candidate information sources from those evidence classes",
            "default_path": "work returns agent_decision_frame first, then target_orientation + target_resolution + evidence_need_derivation + capability_selection + semantic_orientation + skill_handoff",
            "decision_frame_rule": "use agent_decision_frame.action_readiness and task_postcondition_status; legacy work_status only describes reference-pack readiness",
            "required_read_rule": "if skill_handoff.required_read=true, the critical skill contract is attached inline; read the full skill_path when detailed workflow rules are needed",
            "handoff_rule": "READ_SKILL_ONLY means the orchestration stage already ran; CALL_CAPABILITY_AFTER_READ means a later call may be considered after the agent decides it is justified",
            "introspection": {
                "describe": "surface=plw mode=semantic arguments=[describe,<command>,--json]",
                "route": "surface=plw mode=semantic arguments=[route,<task>,--json]",
            },
            "authority": "descriptive_and_documentation_routing_only",
        },
        "surfaces": {
            "kernel": list(hott_kernel.PUBLIC_KERNEL_MODES),
            "plw": list(PUBLIC_PLW_COMMANDS),
        },
        "advanced_invocation": {
            "shape": {"surface": "kernel|plw", "mode": "command", "arguments": ["argv-after-command"]},
            "shell_used": False,
            "state_change_requires_literal_acknowledgement": True,
            "timeout_seconds": {"default": 300, "minimum": 1, "maximum": 3600},
        },
        "ordinary_work_state_effects": {
            "local_derived_cache_or_provenance_may_change": True,
            "canonical_memory_or_fiber_change_authorized": False,
            "source_or_repository_change_authorized": False,
        },
        "authority": {
            "capability_listing_only": True,
            "execute_runtime": False,
            "mutate_source": False,
            "grant_workflow_authority": False,
        },
    }


def _advanced(request: Dict[str, Any], mode: str) -> Dict[str, Any]:
    surface = str(request.get("surface") or "kernel").strip().lower()
    if surface not in {"kernel", "plw"}:
        return _error(
            "invalid_tool_surface",
            "surface must be kernel or plw.",
            supported_surfaces=["kernel", "plw"],
        )
    allowed = (
        set(hott_kernel.PUBLIC_KERNEL_MODES)
        if surface == "kernel"
        else set(PUBLIC_PLW_COMMANDS)
    )
    if mode not in allowed or not _COMMAND_NAME.fullmatch(mode):
        return _error(
            "unknown_tool_mode",
            f"Unknown {surface} mode: {mode}",
            surface=surface,
            valid_modes=sorted(allowed),
            suggested_fix="Use mode=work for ordinary repository tasks or mode=capabilities for discovery.",
        )
    raw_arguments = request.get("arguments", [])
    if not isinstance(raw_arguments, list) or not all(isinstance(value, str) for value in raw_arguments):
        return _error(
            "invalid_tool_arguments",
            "arguments must be an array of strings placed after the selected mode.",
        )
    if len(raw_arguments) > 64 or any("\x00" in value or len(value) > 8192 for value in raw_arguments):
        return _error(
            "tool_arguments_out_of_bounds",
            "arguments exceeds the bounded tool-call contract.",
            maximum_items=64,
            maximum_item_characters=8192,
        )

    raw_stdin = request.get("stdin")
    if raw_stdin is not None and not isinstance(raw_stdin, str):
        return _error(
            "invalid_tool_stdin",
            "stdin must be a string when supplied.",
        )
    if isinstance(raw_stdin, str) and ("\x00" in raw_stdin or len(raw_stdin) > 1_048_576):
        return _error(
            "tool_stdin_out_of_bounds",
            "stdin exceeds the bounded tool-call contract.",
            maximum_characters=1_048_576,
        )
    timeout_seconds = _integer(request.get("timeout_seconds"), 300, "timeout_seconds")
    if isinstance(timeout_seconds, dict):
        return timeout_seconds
    if not 1 <= timeout_seconds <= 3600:
        return _error(
            "tool_timeout_out_of_bounds",
            "timeout_seconds must be between 1 and 3600.",
            minimum=1,
            maximum=3600,
        )

    state_change = _requires_state_acknowledgement(surface, mode, raw_arguments)
    if state_change and request.get("allow_state_change") is not True:
        return _error(
            "explicit_state_change_acknowledgement_required",
            "This PLW operation may change local tool state and requires allow_state_change=true.",
            surface=surface,
            mode=mode,
            source_mutation_authorized=False,
            runtime_execution_authorized=False,
        )

    external_execution = (
        surface == "plw" and mode == "ui-reference" and bool(raw_arguments)
        and raw_arguments[0].strip().lower() in {"reproduce", "reproduction", "runtime-reproduce", "runtime_reproduce", "isolate", "causal-isolate", "causal_isolate", "root-cause-probe", "root_cause_probe", "verify-fix", "verify_fix", "post-fix", "post_fix"}
    )
    if external_execution and request.get("allow_external_execution") is not True:
        return _error(
            "explicit_external_execution_acknowledgement_required",
            "This UI runtime operation launches an external browser and requires allow_external_execution=true.",
            surface=surface,
            mode=mode,
            source_mutation_authorized=False,
            runtime_execution_authorized=False,
        )

    executable = TOOL_ROOT / ("hott_kernel.py" if surface == "kernel" else "plw_cli.py")
    environment = os.environ.copy()
    for field, env_name in (
        ("cache_mode", "AI_STUDIO_GRAPH_CACHE"),
        ("memory_project_root", "AI_STUDIO_PROJECT_ROOT"),
        ("memory_scope", "AI_STUDIO_MEMORY_SCOPE"),
        ("memory_state_dir", "AI_STUDIO_STATE_DIR"),
    ):
        if request.get(field) is not None:
            environment[env_name] = str(request[field])
    try:
        completed = subprocess.run(
            [sys.executable, str(executable), mode, *raw_arguments],
            cwd=str(TOOL_ROOT),
            env=environment,
            input=raw_stdin,
            capture_output=True,
            text=True,
            timeout=timeout_seconds,
            check=False,
        )
    except subprocess.TimeoutExpired:
        return _error(
            "tool_call_timeout",
            f"The bounded PLW operation exceeded {timeout_seconds} seconds.",
            surface=surface,
            mode=mode,
            timeout_seconds=timeout_seconds,
        )
    stdout = completed.stdout
    try:
        result: Any = json.loads(stdout)
        output_format = "json"
    except json.JSONDecodeError:
        result = stdout
        output_format = "text"
    workflow_authority_granted = (
        surface == "plw"
        and mode == "action-lease"
        and completed.returncode == 0
        and isinstance(result, dict)
        and result.get("decision") == "AUTHORIZED_ACTION_LEASE_ACQUIRED"
        and result.get("lease_acquired") is True
        and result.get("executor_start_authorized") is True
    )
    executor_handoff_claimed = (
        surface == "plw"
        and mode == "action-outcome"
        and completed.returncode == 0
        and isinstance(result, dict)
        and result.get("decision") == "EXECUTOR_ATTEMPT_REGISTERED"
        and result.get("attempt_registered") is True
        and result.get("executor_handoff_claimed") is True
    )
    adapter_dispatch_prepared = (
        surface == "plw"
        and mode == "action-adapter"
        and completed.returncode == 0
        and isinstance(result, dict)
        and result.get("decision") == "ADAPTER_DISPATCH_PREPARED"
        and result.get("dispatch_prepared") is True
    )
    adapter_observation_recorded = (
        surface == "plw"
        and mode == "action-adapter"
        and completed.returncode == 0
        and isinstance(result, dict)
        and result.get("decision") == "ADAPTER_OBSERVATION_RECORDED"
        and result.get("observation_recorded") is True
    )
    cli_wrapper_install = (
        surface == "plw"
        and mode == "install"
        and completed.returncode == 0
        and isinstance(result, dict)
        and result.get("status") == "installed"
    )
    validation_authorization_bound = (
        surface == "plw"
        and mode == "validation-authorization"
        and completed.returncode == 0
        and isinstance(result, dict)
        and result.get("authorization_state") == "AUTHORIZED_BOUND"
        and isinstance(result.get("authority"), dict)
        and result["authority"].get("authorization_bound") is True
    )
    validation_attempt_registered = (
        surface == "plw" and mode == "validation-attempt"
        and completed.returncode == 0 and isinstance(result, dict)
        and result.get("decision") == "VALIDATION_ATTEMPT_REGISTERED"
        and result.get("attempt_registered") is True
    )
    validation_dispatch_intent_prepared = (
        surface == "plw" and mode == "validation-dispatch"
        and completed.returncode == 0 and isinstance(result, dict)
        and result.get("decision") == "VALIDATION_DISPATCH_INTENT_PREPARED"
        and result.get("dispatch_intent_prepared") is True
    )
    validation_runtime_handoff_claimed = (
        surface == "plw" and mode == "validation-runtime"
        and completed.returncode == 0 and isinstance(result, dict)
        and result.get("decision") == "VALIDATION_RUNTIME_HANDOFF_CLAIMED"
        and result.get("handoff_claimed") is True
    )
    validation_runtime_observation_recorded = (
        surface == "plw" and mode == "validation-runtime"
        and completed.returncode == 0 and isinstance(result, dict)
        and result.get("decision") == "VALIDATION_RUNTIME_OBSERVATION_RECORDED"
        and result.get("observation_recorded") is True
    )
    validation_result_evidence_accepted = (
        surface == "plw" and mode == "validation-result"
        and completed.returncode == 0 and isinstance(result, dict)
        and result.get("decision") in {
            "VALIDATION_RESULT_EVIDENCE_ACCEPTED",
            "VALIDATION_RESULT_EVIDENCE_ACCEPTED_RECOVERED",
        }
        and result.get("evidence_accepted") is True
    )
    execution_backed_evidence_bound = (
        surface == "plw" and mode == "validation-scenario-bind"
        and completed.returncode == 0 and isinstance(result, dict)
        and result.get("schema_version") == "execution-backed-scenario-evidence-binding-v1"
        and isinstance(result.get("execution_backed_evidence_binding_digest"), str)
    )
    execution_backed_proof_obligation_rederived = (
        surface == "plw" and mode == "validation-coverage"
        and completed.returncode == 0 and isinstance(result, dict)
        and result.get("schema_version") == "execution-backed-proof-obligation-coverage-v1"
        and isinstance(result.get("proof_obligation_coverage_digest"), str)
        and isinstance(result.get("authority"), dict)
        and result["authority"].get("F139_binding_digest_verified") is True
    )
    postcondition_proof_assembled = (
        surface == "plw" and mode == "postcondition-proof"
        and completed.returncode == 0 and isinstance(result, dict)
        and result.get("schema_version") == "postcondition-proof-assembly-v1"
        and isinstance(result.get("postcondition_proof_digest"), str)
    )
    postcondition_proven = (
        postcondition_proof_assembled
        and result.get("proof_state") == "PROVEN"
        and isinstance(result.get("authority"), dict)
        and result["authority"].get("postcondition_proven") is True
    )
    fullstack_state_composed = (
        surface == "plw" and mode == "fullstack-state"
        and completed.returncode == 0 and isinstance(result, dict)
        and result.get("schema_version") == "full-stack-validated-state-v1"
        and isinstance(result.get("full_stack_validated_state_digest"), str)
    )
    fullstack_validated = (
        fullstack_state_composed and result.get("composition_state") == "VALIDATED"
        and isinstance(result.get("authority"), dict)
        and result["authority"].get("truth_committed") is False
    )
    validation_execution_lease_acquired = (
        surface == "plw"
        and mode == "validation-lease"
        and completed.returncode == 0
        and isinstance(result, dict)
        and result.get("decision") == "VALIDATION_EXECUTION_LEASE_ACQUIRED"
        and result.get("lease_acquired") is True
    )
    return {
        "schema_version": TOOL_CALL_SCHEMA_VERSION,
        "mode": "invoke",
        "surface": surface,
        "operation": mode,
        "status": "completed" if completed.returncode == 0 else "tool_reported_nonzero",
        "tool_exit_code": completed.returncode,
        "output_format": output_format,
        "result": result,
        "stderr": completed.stderr,
        "state_change_acknowledged": state_change,
        "authority": {
            "tool_state_change_only": state_change and not workflow_authority_granted and not executor_handoff_claimed,
            "action_lease_executor_start": workflow_authority_granted,
            "action_outcome_executor_handoff": executor_handoff_claimed,
            "action_adapter_dispatch_intent": adapter_dispatch_prepared,
            "action_adapter_observation_recorded": adapter_observation_recorded,
            "cli_wrapper_install": cli_wrapper_install,
            "validation_authorization_binding": validation_authorization_bound,
            "validation_execution_lease": validation_execution_lease_acquired,
            "validation_attempt_registration": validation_attempt_registered,
            "validation_dispatch_intent": validation_dispatch_intent_prepared,
            "validation_runtime_handoff": validation_runtime_handoff_claimed,
            "validation_runtime_observation": validation_runtime_observation_recorded,
            "validation_result_evidence_acceptance": validation_result_evidence_accepted,
            "execution_backed_scenario_evidence_binding": execution_backed_evidence_bound,
            "execution_backed_proof_obligation_rederived": execution_backed_proof_obligation_rederived,
            "postcondition_proof_assembled": postcondition_proof_assembled,
            "postcondition_proven": postcondition_proven,
            "fullstack_state_composed": fullstack_state_composed,
            "fullstack_validated": fullstack_validated,
            "stable_promoted": False,
            "system_path_mutation": cli_wrapper_install and bool(result.get("system_location_requested")) if isinstance(result, dict) else False,
            "execute_external_runtime": external_execution and completed.returncode == 0,
            "external_execution_acknowledged": external_execution,
            "mutate_source": False,
            "mutate_external_repository": False,
            "grant_workflow_authority": workflow_authority_granted,
            "commit_truth": False,
        },
    }


def invoke(request: Dict[str, Any]) -> Dict[str, Any]:
    """Invoke one bounded reference-machine tool call."""
    if not isinstance(request, dict):
        return _error("invalid_tool_request", "Tool request must be a JSON object.")
    mode = request.get("mode", "work")
    if not isinstance(mode, str) or not mode.strip():
        return _error("invalid_tool_mode", "mode must be a non-empty string.")
    normalized_mode = mode.strip().lower()
    if normalized_mode == "work":
        return _work(request)
    if normalized_mode == "capabilities":
        return _capabilities()
    return _advanced(request, normalized_mode)


def main() -> int:
    try:
        request = json.load(sys.stdin)
    except json.JSONDecodeError as exc:
        result = _error("invalid_tool_json", f"stdin must contain one JSON object: {exc.msg}")
    else:
        result = invoke(request)
    print(json.dumps(result, indent=2, ensure_ascii=False))
    return 2 if result.get("error") else 0


if __name__ == "__main__":
    raise SystemExit(main())
