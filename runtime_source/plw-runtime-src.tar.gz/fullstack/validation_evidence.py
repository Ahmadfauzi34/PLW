"""Scenario-bound validation evidence binding over F128 plans.

F129 does not execute validators.  It validates a bounded external evidence
bundle, binds observations to exact selected F128 scenario identities, and
preserves missing, unplanned, indeterminate, and conflicting evidence without
collapsing any of those states into a postcondition or truth claim.
"""
from __future__ import annotations

import json
from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional, Sequence

from core.capability_contracts import is_sha256_id
from core.capability_executor_adapter import inspect_adapter_observation
from fullstack.reference_digest import canonical_reference_digest
from fullstack.validation_scenarios import (
    SCHEMA_VERSION as VALIDATION_PLAN_SCHEMA_VERSION,
    validation_plan_digest,
)

SCHEMA_VERSION = "scenario-validation-evidence-binding-v1"
EVIDENCE_SCHEMA_VERSION = "scenario-validation-evidence-bundle-v1"
MAX_EVIDENCE_BYTES = 1_048_576
MAX_OBSERVATIONS = 2048
MAX_CHECKS_PER_OBSERVATION = 4096
MAX_EVIDENCE_IDS = 32
MAX_TEXT = 2048
VALIDATOR_OUTCOMES = frozenset({"PASS", "FAIL", "INDETERMINATE"})
VALIDATION_OBSERVATION_SCHEMA_VERSION = "scenario-validation-observation-v1"
VALIDATION_OBSERVATION_KIND = "validation.result"
BINDING_DIGEST_POLICY = "scenario-validation-evidence-binding-full-core-v2"


class ValidationEvidenceError(ValueError):
    """Raised when F129 evidence input violates its bounded contract."""


def _text(value: Any, field: str, *, required: bool = False) -> Optional[str]:
    if value is None:
        if required:
            raise ValidationEvidenceError(f"{field} is required")
        return None
    if not isinstance(value, str):
        raise ValidationEvidenceError(f"{field} must be a string")
    value = value.strip()
    if required and not value:
        raise ValidationEvidenceError(f"{field} must be non-empty")
    if len(value) > MAX_TEXT:
        raise ValidationEvidenceError(f"{field} exceeds {MAX_TEXT} characters")
    return value or None


def _sha(value: Any, field: str, *, required: bool = False) -> Optional[str]:
    text = _text(value, field, required=required)
    if text is None:
        return None
    if not is_sha256_id(text):
        raise ValidationEvidenceError(f"{field} must be a sha256 id")
    return text


def _evidence_ids(value: Any, field: str) -> List[str]:
    if value is None:
        return []
    if not isinstance(value, list):
        raise ValidationEvidenceError(f"{field} must be an array")
    if len(value) > MAX_EVIDENCE_IDS:
        raise ValidationEvidenceError(f"{field} exceeds {MAX_EVIDENCE_IDS} entries")
    result: List[str] = []
    for index, item in enumerate(value):
        digest = _sha(item, f"{field}[{index}]", required=True)
        assert digest is not None
        if digest in result:
            raise ValidationEvidenceError(f"{field} contains duplicate evidence id")
        result.append(digest)
    return result


def load_validation_plan(path: str, *, max_bytes: int = MAX_EVIDENCE_BYTES) -> Dict[str, Any]:
    target = Path(path)
    try:
        raw = target.read_bytes()
    except OSError as exc:
        raise ValidationEvidenceError(f"validation plan unavailable: {type(exc).__name__}") from exc
    if len(raw) > max_bytes:
        raise ValidationEvidenceError(f"validation plan exceeds {max_bytes} bytes")
    try:
        payload = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValidationEvidenceError(f"validation plan is not valid bounded UTF-8 JSON: {type(exc).__name__}") from exc
    if not isinstance(payload, dict):
        raise ValidationEvidenceError("validation plan root must be a JSON object")
    return payload


def load_validation_evidence_bundle(path: str, *, max_bytes: int = MAX_EVIDENCE_BYTES) -> Dict[str, Any]:
    target = Path(path)
    try:
        raw = target.read_bytes()
    except OSError as exc:
        raise ValidationEvidenceError(f"validation evidence unavailable: {type(exc).__name__}") from exc
    if len(raw) > max_bytes:
        raise ValidationEvidenceError(f"validation evidence exceeds {max_bytes} bytes")
    try:
        payload = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValidationEvidenceError(f"validation evidence is not valid bounded UTF-8 JSON: {type(exc).__name__}") from exc
    if not isinstance(payload, dict):
        raise ValidationEvidenceError("validation evidence root must be a JSON object")
    return payload


def _normalize_check(value: Any, field: str) -> Dict[str, Any]:
    if not isinstance(value, Mapping):
        raise ValidationEvidenceError(f"{field} must be an object")
    allowed = {"check_id", "outcome", "evidence_ids"}
    unknown = sorted(set(value) - allowed)
    if unknown:
        raise ValidationEvidenceError(f"{field} contains unknown fields: {','.join(unknown)}")
    check_id = _text(value.get("check_id"), f"{field}.check_id", required=True)
    outcome = _text(value.get("outcome"), f"{field}.outcome", required=True)
    assert check_id is not None and outcome is not None
    outcome = outcome.upper()
    if outcome not in VALIDATOR_OUTCOMES:
        raise ValidationEvidenceError(f"{field}.outcome must be PASS, FAIL, or INDETERMINATE")
    return {
        "check_id": check_id,
        "outcome": outcome,
        "evidence_ids": _evidence_ids(value.get("evidence_ids"), f"{field}.evidence_ids"),
    }


def _normalize_provenance(value: Any, field: str) -> Dict[str, Optional[str]]:
    if value is None:
        return {"lease_id": None, "adapter_observation_id": None}
    if not isinstance(value, Mapping):
        raise ValidationEvidenceError(f"{field} must be an object")
    allowed = {"lease_id", "adapter_observation_id"}
    unknown = sorted(set(value) - allowed)
    if unknown:
        raise ValidationEvidenceError(f"{field} contains unknown fields: {','.join(unknown)}")
    lease_id = _sha(value.get("lease_id"), f"{field}.lease_id")
    observation_id = _sha(value.get("adapter_observation_id"), f"{field}.adapter_observation_id")
    if bool(lease_id) != bool(observation_id):
        raise ValidationEvidenceError(f"{field} must provide lease_id and adapter_observation_id together")
    return {"lease_id": lease_id, "adapter_observation_id": observation_id}


def normalize_validation_evidence_bundle(bundle: Mapping[str, Any]) -> Dict[str, Any]:
    if not isinstance(bundle, Mapping):
        raise ValidationEvidenceError("validation evidence bundle must be an object")
    allowed = {"schema_version", "validation_plan_digest", "observations"}
    unknown = sorted(set(bundle) - allowed)
    if unknown:
        raise ValidationEvidenceError("validation evidence bundle contains unknown fields: " + ",".join(unknown))
    if bundle.get("schema_version") != EVIDENCE_SCHEMA_VERSION:
        raise ValidationEvidenceError(f"unsupported evidence schema_version: {bundle.get('schema_version')}")
    plan_digest = _sha(bundle.get("validation_plan_digest"), "validation_plan_digest", required=True)
    observations = bundle.get("observations")
    if not isinstance(observations, list):
        raise ValidationEvidenceError("observations must be an array")
    if len(observations) > MAX_OBSERVATIONS:
        raise ValidationEvidenceError(f"observations exceeds {MAX_OBSERVATIONS}")
    normalized: List[Dict[str, Any]] = []
    seen_ids: set[str] = set()
    for index, item in enumerate(observations):
        field = f"observations[{index}]"
        if not isinstance(item, Mapping):
            raise ValidationEvidenceError(f"{field} must be an object")
        allowed_item = {
            "scenario_id", "validator_id", "validator_run_ref", "outcome",
            "checks", "evidence_ids", "provenance",
        }
        unknown_item = sorted(set(item) - allowed_item)
        if unknown_item:
            raise ValidationEvidenceError(f"{field} contains unknown fields: {','.join(unknown_item)}")
        scenario_id = _sha(item.get("scenario_id"), f"{field}.scenario_id", required=True)
        validator_id = _text(item.get("validator_id"), f"{field}.validator_id", required=True)
        run_ref = _text(item.get("validator_run_ref"), f"{field}.validator_run_ref")
        outcome = _text(item.get("outcome"), f"{field}.outcome", required=True)
        assert scenario_id is not None and validator_id is not None and outcome is not None
        outcome = outcome.upper()
        if outcome not in VALIDATOR_OUTCOMES:
            raise ValidationEvidenceError(f"{field}.outcome must be PASS, FAIL, or INDETERMINATE")
        checks_raw = item.get("checks", [])
        if not isinstance(checks_raw, list):
            raise ValidationEvidenceError(f"{field}.checks must be an array")
        if len(checks_raw) > MAX_CHECKS_PER_OBSERVATION:
            raise ValidationEvidenceError(f"{field}.checks exceeds {MAX_CHECKS_PER_OBSERVATION}")
        checks: List[Dict[str, Any]] = []
        check_ids: set[str] = set()
        for check_index, check in enumerate(checks_raw):
            normalized_check = _normalize_check(check, f"{field}.checks[{check_index}]")
            if normalized_check["check_id"] in check_ids:
                raise ValidationEvidenceError(f"{field}.checks contains duplicate check_id")
            check_ids.add(normalized_check["check_id"])
            checks.append(normalized_check)
        normalized_item = {
            "scenario_id": scenario_id,
            "validator_id": validator_id,
            "validator_run_ref": run_ref,
            "outcome": outcome,
            "checks": checks,
            "evidence_ids": _evidence_ids(item.get("evidence_ids"), f"{field}.evidence_ids"),
            "provenance": _normalize_provenance(item.get("provenance"), f"{field}.provenance"),
        }
        observation_id = canonical_reference_digest(normalized_item)
        if observation_id in seen_ids:
            raise ValidationEvidenceError(f"duplicate normalized observation: {observation_id}")
        seen_ids.add(observation_id)
        normalized.append({"observation_id": observation_id, **normalized_item})
    result = {
        "schema_version": EVIDENCE_SCHEMA_VERSION,
        "validation_plan_digest": plan_digest,
        "observations": normalized,
    }
    result["evidence_bundle_digest"] = canonical_reference_digest(result)
    return result


def _validation_observation_payload(
    validation_plan_digest: str,
    observation: Mapping[str, Any],
) -> Dict[str, Any]:
    """Canonical F123 payload for one normalized validator observation.

    Provenance is intentionally excluded: the adapter receipt does not exist
    until after this payload has been observed.  Every field that describes the
    validator result remains bound, including the exact scenario and checks.
    """
    return {
        "schema_version": VALIDATION_OBSERVATION_SCHEMA_VERSION,
        "validation_plan_digest": validation_plan_digest,
        "scenario_id": observation["scenario_id"],
        "validator_id": observation["validator_id"],
        "validator_run_ref": observation.get("validator_run_ref"),
        "outcome": observation["outcome"],
        "checks": observation.get("checks", []),
        "evidence_ids": observation.get("evidence_ids", []),
    }


def build_validation_observation_payload(
    validation_plan_digest: str,
    observation: Mapping[str, Any],
) -> Dict[str, Any]:
    """Build the exact payload a validator adapter must record in F123."""
    plan_digest = _sha(validation_plan_digest, "validation_plan_digest", required=True)
    assert plan_digest is not None
    observation_fields = {
        key: observation.get(key)
        for key in (
            "scenario_id", "validator_id", "validator_run_ref", "outcome",
            "checks", "evidence_ids", "provenance",
        )
        if key in observation
    }
    normalized = normalize_validation_evidence_bundle({
        "schema_version": EVIDENCE_SCHEMA_VERSION,
        "validation_plan_digest": plan_digest,
        "observations": [observation_fields],
    })["observations"][0]
    return _validation_observation_payload(plan_digest, normalized)


def validation_observation_payload_digest(
    validation_plan_digest: str,
    observation: Mapping[str, Any],
) -> str:
    """Return the content identity expected in the sealed F123 receipt."""
    return canonical_reference_digest(
        build_validation_observation_payload(validation_plan_digest, observation)
    )


def _verify_plan(plan: Mapping[str, Any]) -> str:
    if not isinstance(plan, Mapping) or plan.get("schema_version") != VALIDATION_PLAN_SCHEMA_VERSION:
        raise ValidationEvidenceError("validation plan must be an F128 validation-scenario-plan-v1 result")
    claimed = plan.get("validation_plan_digest")
    if not is_sha256_id(claimed):
        raise ValidationEvidenceError("validation plan digest is missing or invalid")
    actual = validation_plan_digest(plan)
    if actual != claimed:
        raise ValidationEvidenceError("validation plan digest does not match plan contents")
    selected = plan.get("selected_scenarios")
    if not isinstance(selected, list):
        raise ValidationEvidenceError("validation plan selected_scenarios must be an array")
    seen: set[str] = set()
    for index, row in enumerate(selected):
        if not isinstance(row, Mapping) or not is_sha256_id(row.get("scenario_id")):
            raise ValidationEvidenceError(f"selected_scenarios[{index}] has invalid scenario_id")
        scenario_id = str(row["scenario_id"])
        if scenario_id in seen:
            raise ValidationEvidenceError(f"validation plan has duplicate selected scenario_id: {scenario_id}")
        seen.add(scenario_id)
    return str(claimed)


def _provenance_status(
    provenance: Mapping[str, Any],
    observation: Mapping[str, Any],
    validation_plan_digest: str,
    *,
    store_dir: Optional[str],
) -> Dict[str, Any]:
    lease_id = provenance.get("lease_id")
    observation_id = provenance.get("adapter_observation_id")
    expected_digest = canonical_reference_digest(
        _validation_observation_payload(validation_plan_digest, observation)
    )
    status: Dict[str, Any] = {
        "class": "NONE",
        "receipt_verified": False,
        "content_bound": False,
        "verified": False,
        "reason": "no_F123_provenance_claim",
        "external_execution_proven": False,
        "expected_observation_digest": expected_digest,
        "recorded_observation_digest": None,
        "recorded_observation_kind": None,
    }
    if not lease_id and not observation_id:
        return status

    status.update({
        "class": "CLAIMED_UNVERIFIED",
        "reason": "store_dir_not_supplied",
        "lease_id": lease_id,
        "adapter_observation_id": observation_id,
    })
    if store_dir is None:
        return status

    inspected = inspect_adapter_observation(
        str(lease_id), str(observation_id), store_dir=store_dir,
    )
    receipt_verified = inspected.get("observation_found") is True
    recorded_digest = inspected.get("observation_digest") if receipt_verified else None
    recorded_kind = inspected.get("observation_kind") if receipt_verified else None
    kind_bound = receipt_verified and recorded_kind == VALIDATION_OBSERVATION_KIND
    content_bound = bool(kind_bound and recorded_digest == expected_digest)
    if content_bound:
        reason = "verified_F123_receipt_and_validation_observation_content"
        status_class = "F123_CONTENT_BOUND"
    elif receipt_verified and not kind_bound:
        reason = "F123_receipt_kind_is_not_validation_result"
        status_class = "F123_RECEIPT_VERIFIED_ONLY"
    elif receipt_verified:
        reason = "F123_receipt_content_digest_mismatch"
        status_class = "F123_RECEIPT_VERIFIED_ONLY"
    else:
        reason = str(inspected.get("error") or "adapter_observation_id_not_found")
        status_class = "CLAIMED_UNVERIFIED"
    status.update({
        "class": status_class,
        "receipt_verified": receipt_verified,
        "content_bound": content_bound,
        "verified": content_bound,
        "reason": reason,
        "recorded_observation_digest": recorded_digest,
        "recorded_observation_kind": recorded_kind,
    })
    return status


def validation_evidence_binding_digest(binding: Mapping[str, Any]) -> str:
    """Digest the complete F129 semantic artifact except its digest field."""
    if not isinstance(binding, Mapping):
        raise ValidationEvidenceError("validation evidence binding must be an object")
    core = dict(binding)
    core.pop("validation_evidence_binding_digest", None)
    try:
        return canonical_reference_digest({
            "artifact_type": SCHEMA_VERSION,
            "digest_policy": BINDING_DIGEST_POLICY,
            "artifact": core,
        })
    except (TypeError, ValueError) as exc:
        raise ValidationEvidenceError("validation evidence binding is not canonical JSON") from exc


def _binding_observation(
    value: Any,
    plan_digest: str,
    field: str,
) -> Dict[str, Any]:
    if not isinstance(value, Mapping):
        raise ValidationEvidenceError(f"{field} must be an object")
    allowed = {
        "observation_id", "scenario_id", "validator_id", "validator_run_ref",
        "outcome", "checks", "evidence_ids", "provenance", "provenance_status",
    }
    unknown = sorted(set(value) - allowed)
    missing = sorted(allowed - set(value))
    if unknown or missing:
        detail = ",".join(unknown or missing)
        kind = "unknown" if unknown else "missing"
        raise ValidationEvidenceError(f"{field} contains {kind} fields: {detail}")
    raw = {
        key: value.get(key)
        for key in (
            "scenario_id", "validator_id", "validator_run_ref", "outcome",
            "checks", "evidence_ids", "provenance",
        )
    }
    normalized = normalize_validation_evidence_bundle({
        "schema_version": EVIDENCE_SCHEMA_VERSION,
        "validation_plan_digest": plan_digest,
        "observations": [raw],
    })["observations"][0]
    for key, expected in normalized.items():
        if value.get(key) != expected:
            raise ValidationEvidenceError(f"{field}.{key} does not match normalized observation")

    provenance_status = value.get("provenance_status")
    if not isinstance(provenance_status, Mapping):
        raise ValidationEvidenceError(f"{field}.provenance_status must be an object")
    status_allowed = {
        "class", "receipt_verified", "content_bound", "verified", "reason",
        "external_execution_proven", "expected_observation_digest",
        "recorded_observation_digest", "recorded_observation_kind", "lease_id",
        "adapter_observation_id",
    }
    unknown_status = sorted(set(provenance_status) - status_allowed)
    if unknown_status:
        raise ValidationEvidenceError(
            f"{field}.provenance_status contains unknown fields: {','.join(unknown_status)}"
        )
    for key in ("receipt_verified", "content_bound", "verified", "external_execution_proven"):
        if not isinstance(provenance_status.get(key), bool):
            raise ValidationEvidenceError(f"{field}.provenance_status.{key} must be boolean")
    if provenance_status.get("external_execution_proven") is not False:
        raise ValidationEvidenceError(f"{field}.provenance_status widens external execution authority")
    if provenance_status.get("verified") != provenance_status.get("content_bound"):
        raise ValidationEvidenceError(f"{field}.provenance_status verified must mean content_bound")
    if provenance_status.get("content_bound") is True and provenance_status.get("receipt_verified") is not True:
        raise ValidationEvidenceError(f"{field}.provenance_status content binding lacks a verified receipt")
    status_class = provenance_status.get("class")
    reason = provenance_status.get("reason")
    if status_class not in {
        "NONE", "CLAIMED_UNVERIFIED", "F123_RECEIPT_VERIFIED_ONLY",
        "F123_CONTENT_BOUND",
    } or not isinstance(reason, str) or not reason:
        raise ValidationEvidenceError(f"{field}.provenance_status class/reason is invalid")
    expected_digest = canonical_reference_digest(
        _validation_observation_payload(plan_digest, normalized)
    )
    if provenance_status.get("expected_observation_digest") != expected_digest:
        raise ValidationEvidenceError(f"{field}.provenance_status expected digest mismatch")
    if provenance_status.get("content_bound") is True:
        if provenance_status.get("recorded_observation_digest") != expected_digest:
            raise ValidationEvidenceError(f"{field}.provenance_status recorded digest mismatch")
        if provenance_status.get("recorded_observation_kind") != VALIDATION_OBSERVATION_KIND:
            raise ValidationEvidenceError(f"{field}.provenance_status observation kind mismatch")
        if provenance_status.get("class") != "F123_CONTENT_BOUND":
            raise ValidationEvidenceError(f"{field}.provenance_status class mismatch")
    provenance = normalized["provenance"]
    claimed = bool(provenance.get("lease_id"))
    if claimed:
        if provenance_status.get("lease_id") != provenance.get("lease_id"):
            raise ValidationEvidenceError(f"{field}.provenance_status lease binding mismatch")
        if provenance_status.get("adapter_observation_id") != provenance.get("adapter_observation_id"):
            raise ValidationEvidenceError(f"{field}.provenance_status observation binding mismatch")
        receipt_verified = provenance_status.get("receipt_verified") is True
        content_bound = provenance_status.get("content_bound") is True
        expected_class = (
            "F123_CONTENT_BOUND" if content_bound
            else "F123_RECEIPT_VERIFIED_ONLY" if receipt_verified
            else "CLAIMED_UNVERIFIED"
        )
        if status_class != expected_class:
            raise ValidationEvidenceError(f"{field}.provenance_status class is inconsistent")
    else:
        if status_class != "NONE" or provenance_status.get("reason") != "no_F123_provenance_claim":
            raise ValidationEvidenceError(f"{field}.provenance_status no-claim classification mismatch")
        if provenance_status.get("receipt_verified") is not False:
            raise ValidationEvidenceError(f"{field}.provenance_status verifies an absent claim")
    if provenance_status.get("receipt_verified") is True:
        if not is_sha256_id(provenance_status.get("recorded_observation_digest")):
            raise ValidationEvidenceError(f"{field}.provenance_status recorded digest is invalid")
        if not isinstance(provenance_status.get("recorded_observation_kind"), str):
            raise ValidationEvidenceError(f"{field}.provenance_status recorded kind is invalid")
    elif (
        provenance_status.get("recorded_observation_digest") is not None
        or provenance_status.get("recorded_observation_kind") is not None
    ):
        raise ValidationEvidenceError(f"{field}.provenance_status has unverified recorded metadata")
    return dict(value)


def verify_validation_evidence_binding(
    binding: Mapping[str, Any],
) -> Dict[str, Mapping[str, Any]]:
    """Verify an F129 digest and all locally derivable structural invariants.

    The digest is an integrity checksum, not an issuer signature.  Callers can
    rely on exact content identity but must not infer authenticated origin.
    """
    if not isinstance(binding, Mapping) or binding.get("schema_version") != SCHEMA_VERSION:
        raise ValidationEvidenceError(
            f"validation evidence binding must be an F129 {SCHEMA_VERSION} result"
        )
    allowed_top = {
        "schema_version", "binding_digest_policy", "validation_plan_digest",
        "evidence_bundle_digest", "evidence_observation_ids", "scenario_bindings",
        "unplanned_observations", "summary", "authority", "proof_boundary",
        "recovery", "validation_evidence_binding_digest",
    }
    if set(binding) != allowed_top:
        raise ValidationEvidenceError("validation evidence binding does not match the exact F129 schema")
    if binding.get("binding_digest_policy") != BINDING_DIGEST_POLICY:
        raise ValidationEvidenceError("validation evidence binding digest policy is missing or unsupported")
    plan_digest = _sha(binding.get("validation_plan_digest"), "validation_plan_digest", required=True)
    evidence_digest = _sha(binding.get("evidence_bundle_digest"), "evidence_bundle_digest", required=True)
    claimed_digest = _sha(
        binding.get("validation_evidence_binding_digest"),
        "validation_evidence_binding_digest",
        required=True,
    )
    assert plan_digest is not None and evidence_digest is not None and claimed_digest is not None
    if validation_evidence_binding_digest(binding) != claimed_digest:
        raise ValidationEvidenceError("validation evidence binding digest does not match binding contents")

    rows = binding.get("scenario_bindings")
    unplanned = binding.get("unplanned_observations")
    evidence_order = binding.get("evidence_observation_ids")
    if not isinstance(rows, list):
        raise ValidationEvidenceError("scenario_bindings must be an array")
    if not isinstance(unplanned, list):
        raise ValidationEvidenceError("unplanned_observations must be an array")
    if not isinstance(evidence_order, list) or not all(is_sha256_id(item) for item in evidence_order):
        raise ValidationEvidenceError("evidence_observation_ids must be an array of sha256 ids")
    if len(evidence_order) != len(set(evidence_order)):
        raise ValidationEvidenceError("evidence_observation_ids contains duplicates")

    by_id: Dict[str, Mapping[str, Any]] = {}
    observations_by_id: Dict[str, Dict[str, Any]] = {}
    for index, row in enumerate(rows):
        field = f"scenario_bindings[{index}]"
        if not isinstance(row, Mapping):
            raise ValidationEvidenceError(f"{field} must be an object")
        allowed = {
            "scenario_id", "scenario", "binding_status", "observation_count",
            "validator_outcomes", "observation_ids", "observations",
            "requested_check_ids", "observed_check_ids", "missing_requested_check_ids",
            "unplanned_check_ids", "missing_evidence_is_failure",
            "validator_outcome_is_postcondition_proof",
        }
        if set(row) != allowed:
            raise ValidationEvidenceError(f"{field} does not match the exact F129 row schema")
        scenario_id = _sha(row.get("scenario_id"), f"{field}.scenario_id", required=True)
        assert scenario_id is not None
        if scenario_id in by_id:
            raise ValidationEvidenceError(f"duplicate scenario_id: {scenario_id}")
        observations = row.get("observations")
        if not isinstance(observations, list):
            raise ValidationEvidenceError(f"{field}.observations must be an array")
        checked = [
            _binding_observation(item, plan_digest, f"{field}.observations[{obs_index}]")
            for obs_index, item in enumerate(observations)
        ]
        for item in checked:
            if item["scenario_id"] != scenario_id:
                raise ValidationEvidenceError(f"{field} contains an observation for another scenario")
            if item["observation_id"] in observations_by_id:
                raise ValidationEvidenceError(f"duplicate bound observation_id: {item['observation_id']}")
            observations_by_id[item["observation_id"]] = item
        outcomes = sorted({str(item["outcome"]) for item in checked})
        observed_checks = sorted({
            str(check["check_id"])
            for item in checked
            for check in item["checks"]
        })
        requested = row.get("requested_check_ids")
        if not isinstance(requested, list) or requested != sorted(set(requested)) or not all(isinstance(item, str) for item in requested):
            raise ValidationEvidenceError(f"{field}.requested_check_ids must be sorted unique strings")
        expected_status = "MISSING" if not checked else "CONFLICTING" if len(outcomes) > 1 else "OBSERVED"
        derived = {
            "binding_status": expected_status,
            "observation_count": len(checked),
            "validator_outcomes": outcomes,
            "observation_ids": [item["observation_id"] for item in checked],
            "observed_check_ids": observed_checks,
            "missing_requested_check_ids": sorted(set(requested) - set(observed_checks)),
            "unplanned_check_ids": sorted(set(observed_checks) - set(requested)),
            "missing_evidence_is_failure": False,
            "validator_outcome_is_postcondition_proof": False,
        }
        for key, expected in derived.items():
            if row.get(key) != expected:
                raise ValidationEvidenceError(f"{field}.{key} does not match derived evidence")
        by_id[scenario_id] = row

    for index, item in enumerate(unplanned):
        field = f"unplanned_observations[{index}]"
        if not isinstance(item, Mapping):
            raise ValidationEvidenceError(f"{field} must be an object")
        observation_keys = {
            "observation_id", "scenario_id", "validator_id", "validator_run_ref",
            "outcome", "checks", "evidence_ids", "provenance", "provenance_status",
        }
        if set(item) != observation_keys | {"binding_status", "reason", "recover"}:
            raise ValidationEvidenceError(f"{field} does not match the exact unplanned row schema")
        checked = _binding_observation(
            {key: item.get(key) for key in observation_keys},
            plan_digest,
            field,
        )
        if checked["scenario_id"] in by_id:
            raise ValidationEvidenceError(f"{field} targets a selected scenario")
        if item.get("binding_status") != "UNPLANNED" or item.get("reason") != "scenario_id_not_selected_by_F128_plan":
            raise ValidationEvidenceError(f"{field} has invalid unplanned classification")
        if checked["observation_id"] in observations_by_id:
            raise ValidationEvidenceError(f"duplicate unplanned observation_id: {checked['observation_id']}")
        observations_by_id[checked["observation_id"]] = checked

    if set(evidence_order) != set(observations_by_id):
        raise ValidationEvidenceError("evidence_observation_ids does not enumerate every bound observation exactly once")
    ordered_raw = []
    for observation_id in evidence_order:
        item = observations_by_id[str(observation_id)]
        ordered_raw.append({
            key: item.get(key)
            for key in (
                "scenario_id", "validator_id", "validator_run_ref", "outcome",
                "checks", "evidence_ids", "provenance",
            )
        })
    normalized_bundle = normalize_validation_evidence_bundle({
        "schema_version": EVIDENCE_SCHEMA_VERSION,
        "validation_plan_digest": plan_digest,
        "observations": ordered_raw,
    })
    if normalized_bundle["evidence_bundle_digest"] != evidence_digest:
        raise ValidationEvidenceError("evidence_bundle_digest does not match bound observations")

    summary = binding.get("summary")
    expected_summary = {
        "selected_scenario_count": len(rows),
        "observed_scenario_count": sum(1 for row in rows if row["binding_status"] == "OBSERVED"),
        "missing_scenario_count": sum(1 for row in rows if row["binding_status"] == "MISSING"),
        "conflicting_scenario_count": sum(1 for row in rows if row["binding_status"] == "CONFLICTING"),
        "unplanned_observation_count": len(unplanned),
        "observation_count": len(observations_by_id),
        "verified_F123_receipt_count": sum(
            1 for item in observations_by_id.values()
            if item["provenance_status"].get("receipt_verified") is True
        ),
        "verified_F123_provenance_count": sum(
            1 for item in observations_by_id.values()
            if item["provenance_status"].get("content_bound") is True
        ),
    }
    if summary != expected_summary:
        raise ValidationEvidenceError("summary does not match derived F129 binding state")
    authority = binding.get("authority")
    expected_authority = {
        "F128_plan_identity_verified": True,
        "evidence_structure_validated": True,
        "validator_executed_by_binder": False,
        "runtime_dispatched_by_binder": False,
        "external_execution_proven": False,
        "mutation_authority": False,
        "postcondition_proven": False,
        "truth_committed": False,
    }
    if authority != expected_authority:
        raise ValidationEvidenceError("authority boundary is missing or widened")
    proof_boundary = binding.get("proof_boundary")
    expected_boundary = {
        "missing_evidence_is_validation_failure": False,
        "validator_PASS_is_postcondition_proof": False,
        "validator_FAIL_is_global_behavior_failure": False,
        "F123_receipt_is_pixel_or_behavior_truth": False,
        "F123_receipt_is_content_provenance": False,
        "unplanned_evidence_is_irrelevant": False,
        "conflicting_evidence_is_auto_resolved": False,
    }
    if proof_boundary != expected_boundary:
        raise ValidationEvidenceError("F123 receipt/content proof boundary is missing or widened")
    return by_id


def bind_validation_evidence(
    plan: Mapping[str, Any],
    evidence_bundle: Mapping[str, Any],
    *,
    store_dir: Optional[str] = None,
) -> Dict[str, Any]:
    """Bind external validator observations to exact F128 selected scenarios."""
    plan_digest = _verify_plan(plan)
    evidence = normalize_validation_evidence_bundle(evidence_bundle)
    if evidence["validation_plan_digest"] != plan_digest:
        raise ValidationEvidenceError("evidence validation_plan_digest does not match the F128 plan")

    selected = plan["selected_scenarios"]
    selected_by_id = {str(row["scenario_id"]): row for row in selected if isinstance(row, Mapping)}
    observed_by_scenario: Dict[str, List[Dict[str, Any]]] = defaultdict(list)
    unplanned: List[Dict[str, Any]] = []
    for observation in evidence["observations"]:
        row = {
            **observation,
            "provenance_status": _provenance_status(
                observation["provenance"],
                observation,
                plan_digest,
                store_dir=store_dir,
            ),
        }
        scenario_id = observation["scenario_id"]
        if scenario_id not in selected_by_id:
            unplanned.append({
                **row,
                "binding_status": "UNPLANNED",
                "reason": "scenario_id_not_selected_by_F128_plan",
                "recover": "produce a new F128 plan that selects this scenario or keep this evidence as unbound reference data",
            })
        else:
            observed_by_scenario[scenario_id].append(row)

    bindings: List[Dict[str, Any]] = []
    for selected_row in selected:
        scenario_id = str(selected_row["scenario_id"])
        observations = observed_by_scenario.get(scenario_id, [])
        outcomes = sorted({str(row["outcome"]) for row in observations})
        requested = selected_row.get("requested_validation") if isinstance(selected_row.get("requested_validation"), Mapping) else {}
        requested_checks = sorted({str(v) for v in requested.get("constraint_ids_if_applicable", []) if isinstance(v, str)})
        observed_checks = sorted({
            str(check["check_id"])
            for row in observations
            for check in row.get("checks", [])
            if isinstance(check, Mapping) and isinstance(check.get("check_id"), str)
        })
        if not observations:
            status = "MISSING"
        elif len(outcomes) > 1:
            status = "CONFLICTING"
        else:
            status = "OBSERVED"
        bindings.append({
            "scenario_id": scenario_id,
            "scenario": selected_row.get("scenario"),
            "binding_status": status,
            "observation_count": len(observations),
            "validator_outcomes": outcomes,
            "observation_ids": [row["observation_id"] for row in observations],
            "observations": observations,
            "requested_check_ids": requested_checks,
            "observed_check_ids": observed_checks,
            "missing_requested_check_ids": sorted(set(requested_checks) - set(observed_checks)),
            "unplanned_check_ids": sorted(set(observed_checks) - set(requested_checks)),
            "missing_evidence_is_failure": False,
            "validator_outcome_is_postcondition_proof": False,
        })

    summary = {
        "selected_scenario_count": len(bindings),
        "observed_scenario_count": sum(1 for row in bindings if row["binding_status"] == "OBSERVED"),
        "missing_scenario_count": sum(1 for row in bindings if row["binding_status"] == "MISSING"),
        "conflicting_scenario_count": sum(1 for row in bindings if row["binding_status"] == "CONFLICTING"),
        "unplanned_observation_count": len(unplanned),
        "observation_count": len(evidence["observations"]),
        "verified_F123_receipt_count": sum(
            1
            for binding in bindings
            for row in binding.get("observations", [])
            if row.get("provenance_status", {}).get("receipt_verified") is True
        ) + sum(
            1 for row in unplanned
            if row.get("provenance_status", {}).get("receipt_verified") is True
        ),
        "verified_F123_provenance_count": sum(
            1
            for binding in bindings
            for row in binding.get("observations", [])
            if row.get("provenance_status", {}).get("verified") is True
        ) + sum(
            1 for row in unplanned
            if row.get("provenance_status", {}).get("verified") is True
        ),
    }
    result: Dict[str, Any] = {
        "schema_version": SCHEMA_VERSION,
        "binding_digest_policy": BINDING_DIGEST_POLICY,
        "validation_plan_digest": plan_digest,
        "evidence_bundle_digest": evidence["evidence_bundle_digest"],
        "evidence_observation_ids": [
            row["observation_id"] for row in evidence["observations"]
        ],
        "scenario_bindings": bindings,
        "unplanned_observations": unplanned,
        "summary": summary,
        "authority": {
            "F128_plan_identity_verified": True,
            "evidence_structure_validated": True,
            "validator_executed_by_binder": False,
            "runtime_dispatched_by_binder": False,
            "external_execution_proven": False,
            "mutation_authority": False,
            "postcondition_proven": False,
            "truth_committed": False,
        },
        "proof_boundary": {
            "missing_evidence_is_validation_failure": False,
            "validator_PASS_is_postcondition_proof": False,
            "validator_FAIL_is_global_behavior_failure": False,
            "F123_receipt_is_pixel_or_behavior_truth": False,
            "F123_receipt_is_content_provenance": False,
            "unplanned_evidence_is_irrelevant": False,
            "conflicting_evidence_is_auto_resolved": False,
        },
        "recovery": {
            "missing": "execute the exact selected scenario through an external validator and return a new evidence bundle",
            "unplanned": "re-plan with F128 if the scenario should enter the bounded validation set",
            "conflicting": "retain all observations and investigate validator/run differences; F129 does not choose a winner",
            "provenance": "record the canonical validation.result payload through F123 and supply --store-dir so receipt integrity and exact content binding can be verified",
        },
    }
    result["validation_evidence_binding_digest"] = validation_evidence_binding_digest(result)
    return result


__all__ = [
    "SCHEMA_VERSION",
    "EVIDENCE_SCHEMA_VERSION",
    "MAX_EVIDENCE_BYTES",
    "MAX_OBSERVATIONS",
    "VALIDATOR_OUTCOMES",
    "VALIDATION_OBSERVATION_SCHEMA_VERSION",
    "VALIDATION_OBSERVATION_KIND",
    "BINDING_DIGEST_POLICY",
    "ValidationEvidenceError",
    "load_validation_plan",
    "load_validation_evidence_bundle",
    "normalize_validation_evidence_bundle",
    "build_validation_observation_payload",
    "validation_observation_payload_digest",
    "validation_evidence_binding_digest",
    "verify_validation_evidence_binding",
    "bind_validation_evidence",
]
