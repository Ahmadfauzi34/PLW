"""F126 runtime geometry-capture provenance bridge.

F123 owns durable adapter dispatch/observation provenance. F125 owns validation
of externally supplied rendered geometry. This module binds the two without
turning either layer into a browser/runtime executor and without merging their
authorities.

A capture is EXACT only when the latest verified F123 observation is a terminal
SUCCEEDED ``runtime.geometry.capture`` observation whose canonical observation
digest is reconstructed from the supplied F125 GeometrySnapshot. The adapter
receipt proves only that the bound adapter reported that exact capture payload;
it does not prove the geometry is correct, pixels are truthful, behavior is
correct, or a postcondition/truth claim has been established.
"""
from __future__ import annotations

from collections.abc import Mapping, Sequence
import hashlib
import json
from typing import Any, Dict, Protocol, runtime_checkable

from core.capability_contracts import is_sha256_id, safe_canonical_digest
from core.capability_executor_adapter import (
    ExecutorAdapter,
    inspect_adapter_dispatch,
)
from codebase.geometry_correspondence import (
    build_ui_reference_state,
    normalize_geometry_snapshot,
)

CAPTURE_OBSERVATION_SCHEMA_VERSION = "runtime-geometry-capture-observation-v1"
CAPTURE_REFERENCE_SCHEMA_VERSION = "runtime-ui-reference-v1"
CAPTURE_OBSERVATION_KIND = "runtime.geometry.capture"
CAPTURE_CONTRACT_VERSION = "runtime-geometry-capture-adapter-v1"


@runtime_checkable
class RuntimeGeometryCaptureAdapter(ExecutorAdapter, Protocol):
    """Marker protocol for host adapters that opt into the F126 capture contract.

    F126 does not invoke adapters itself. Concrete adapters still use the F123
    dispatch/reconciliation APIs and may run in any host/runtime implementation.
    The marker is documentation/type guidance rather than an execution gate.
    """

    capture_contract: str


def _digest(value: Any, *, max_bytes: int = 4 * 1024 * 1024) -> str:
    try:
        raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False).encode("utf-8")
    except (TypeError, ValueError, OverflowError, RecursionError, UnicodeError) as exc:
        raise ValueError("runtime geometry capture reference is not canonical JSON") from exc
    if len(raw) > max_bytes:
        raise ValueError("runtime geometry capture reference exceeds bounded canonical JSON")
    return "sha256:" + hashlib.sha256(raw).hexdigest()


def _capture_payload_digest(geometry: Mapping[str, Any]) -> str:
    capture = geometry.get("capture") if isinstance(geometry.get("capture"), Mapping) else {}
    capture_without_self_id = {
        "source": capture.get("source"),
        "captured_at": capture.get("captured_at"),
        "adapter_observation_id": None,
        "runtime_id": capture.get("runtime_id"),
    }
    return _digest({
        "schema_version": geometry.get("schema_version"),
        "scenario": geometry.get("scenario"),
        "static_context": geometry.get("static_context"),
        "capture": capture_without_self_id,
        "nodes": geometry.get("nodes"),
    })


def _capture_observation_from_geometry(geometry: Mapping[str, Any]) -> Dict[str, Any]:
    scenario = geometry.get("scenario") if isinstance(geometry.get("scenario"), Mapping) else {}
    summary = geometry.get("summary") if isinstance(geometry.get("summary"), Mapping) else {}
    static_context = geometry.get("static_context") if isinstance(geometry.get("static_context"), Mapping) else {}
    return {
        "schema_version": CAPTURE_OBSERVATION_SCHEMA_VERSION,
        "capture_contract": CAPTURE_CONTRACT_VERSION,
        "geometry_schema_version": geometry.get("schema_version"),
        "capture_payload_digest": _capture_payload_digest(geometry),
        "scenario_id": geometry.get("scenario_id"),
        "code_revision": scenario.get("code_revision"),
        "node_count": summary.get("node_count", 0),
        "graph_content_signature": static_context.get("graph_content_signature"),
        "angular_ownership_digest": static_context.get("angular_ownership_digest"),
    }


def build_geometry_capture_observation(snapshot: Mapping[str, Any]) -> Dict[str, Any]:
    """Build the exact bounded observation a concrete F123 adapter should report.

    The returned mapping contains no raw DOM, screenshot, text, or node list. Its
    digest binds the adapter observation to the deterministic F125 snapshot.
    """
    geometry = normalize_geometry_snapshot(dict(snapshot))
    return _capture_observation_from_geometry(geometry)


def build_geometry_capture_adapter_result(
    snapshot: Mapping[str, Any],
    *,
    evidence_ids: Sequence[str] | None = None,
) -> Dict[str, Any]:
    """Build a canonical successful F123 adapter return for one captured snapshot.

    This helper performs no dispatch and no external execution. A concrete host
    adapter may return this mapping from ``dispatch``/``reconcile`` after it has
    actually captured the supplied snapshot through its own runtime.
    """
    evidence = list(evidence_ids or [])
    if any(not is_sha256_id(item) for item in evidence):
        raise ValueError("evidence_ids must contain only sha256:<64-hex> identifiers")
    return {
        "dispatch_state": "ACKNOWLEDGED",
        "terminal_status": "SUCCEEDED",
        "observation_kind": CAPTURE_OBSERVATION_KIND,
        "observation": build_geometry_capture_observation(snapshot),
        "evidence_ids": evidence,
    }


def _unresolved_reason(checks: Mapping[str, bool], state_found: bool) -> str:
    if not state_found:
        return "adapter_dispatch_unavailable"
    order = (
        ("observation_present", "adapter_observation_missing"),
        ("observation_kind_match", "observation_kind_mismatch"),
        ("dispatch_acknowledged", "dispatch_not_acknowledged"),
        ("adapter_terminal_succeeded", "adapter_capture_not_succeeded"),
        ("f122_terminal_succeeded", "executor_outcome_not_succeeded"),
        ("observation_digest_match", "snapshot_observation_digest_mismatch"),
        ("embedded_observation_claim_compatible", "embedded_observation_id_mismatch"),
    )
    for key, reason in order:
        if not checks.get(key, False):
            return reason
    return "capture_provenance_unresolved"


def _bind_normalized_runtime_geometry_capture(
    geometry: Mapping[str, Any],
    lease_id: str,
    *,
    store_dir: str | None = None,
) -> Dict[str, Any]:
    expected_observation = _capture_observation_from_geometry(geometry)
    expected_digest = _digest(expected_observation)
    state = inspect_adapter_dispatch(lease_id, store_dir=store_dir)
    state_found = state.get("dispatch_found") is True
    receipt = state.get("observation_receipt") if isinstance(state.get("observation_receipt"), Mapping) else {}
    capture = geometry.get("capture") if isinstance(geometry.get("capture"), Mapping) else {}
    embedded_observation_id = capture.get("adapter_observation_id")
    observed_id = receipt.get("observation_id")

    checks = {
        "observation_present": bool(receipt),
        "observation_kind_match": receipt.get("observation_kind") == CAPTURE_OBSERVATION_KIND,
        "dispatch_acknowledged": receipt.get("dispatch_state") == "ACKNOWLEDGED",
        "adapter_terminal_succeeded": receipt.get("terminal_status") == "SUCCEEDED",
        "f122_terminal_succeeded": state.get("f122_terminal_status") == "SUCCEEDED",
        "observation_digest_match": receipt.get("observation_digest") == expected_digest,
        # F125's embedded observation id is optional. F126 adds the authoritative
        # binding outside the immutable geometry payload, avoiding a digest cycle.
        "embedded_observation_claim_compatible": (
            embedded_observation_id is None or embedded_observation_id == observed_id
        ),
    }
    exact = state_found and all(checks.values())
    reason = "exact_adapter_observation_binding" if exact else _unresolved_reason(checks, state_found)
    result = {
        "schema_version": "runtime-geometry-capture-binding-v1",
        "lease_id": lease_id,
        "attempt_id": state.get("attempt_id") if state_found else None,
        "dispatch_id": state.get("dispatch_id") if state_found else None,
        "executor_id": state.get("executor_id") if state_found else None,
        "adapter_id": state.get("adapter_id") if state_found else None,
        "operation_key": state.get("operation_key") if state_found else None,
        "adapter_observation_id": observed_id if state_found else None,
        "adapter_observation_digest": receipt.get("observation_digest") if state_found else None,
        "expected_observation_digest": expected_digest,
        "geometry_snapshot_digest": geometry.get("geometry_snapshot_digest"),
        "capture_payload_digest": expected_observation.get("capture_payload_digest"),
        "scenario_id": geometry.get("scenario_id"),
        "proof_class": "EXACT" if exact else "UNRESOLVED",
        "reason": reason,
        "checks": checks,
        "adapter_state_error": None if state_found else state.get("error"),
        "authority": {
            "adapter_observation_provenance_bound": exact,
            "external_capture_correctness_proven": False,
            "geometry_correctness_proven": False,
            "behavior_proven": False,
            "postcondition_proven": False,
            "mutation_authority": False,
            "truth_committed": False,
        },
        "proof_boundary": {
            "verified_adapter_receipt_is_external_ground_truth": False,
            "adapter_success_is_geometry_correctness": False,
            "capture_binding_is_behavior_proof": False,
            "capture_binding_authorizes_redispatch": False,
            "missing_or_conflicting_capture_remains_unresolved": not exact,
        },
    }
    result["capture_binding_digest"] = _digest({
        "lease_id": result["lease_id"],
        "dispatch_id": result["dispatch_id"],
        "adapter_observation_id": result["adapter_observation_id"],
        "adapter_observation_digest": result["adapter_observation_digest"],
        "expected_observation_digest": result["expected_observation_digest"],
        "capture_payload_digest": result["capture_payload_digest"],
        "geometry_snapshot_digest": result["geometry_snapshot_digest"],
        "proof_class": result["proof_class"],
        "reason": result["reason"],
    })
    return result


def bind_runtime_geometry_capture(
    snapshot: Mapping[str, Any],
    lease_id: str,
    *,
    store_dir: str | None = None,
) -> Dict[str, Any]:
    """Bind a supplied F125 snapshot to verified F123 observation provenance."""
    geometry = normalize_geometry_snapshot(dict(snapshot))
    return _bind_normalized_runtime_geometry_capture(geometry, lease_id, store_dir=store_dir)


def build_runtime_ui_reference_state(
    snapshot: Mapping[str, Any],
    angular_ownership: Dict[str, Any],
    lease_id: str,
    *,
    store_dir: str | None = None,
) -> Dict[str, Any]:
    """Compose F125 UI reference state with F123 capture provenance in one query."""
    ui_reference = build_ui_reference_state(dict(snapshot), angular_ownership)
    runtime_capture = _bind_normalized_runtime_geometry_capture(
        ui_reference["geometry"], lease_id, store_dir=store_dir,
    )
    result = {
        "schema_version": CAPTURE_REFERENCE_SCHEMA_VERSION,
        "scenario_id": ui_reference.get("scenario_id"),
        "ui_reference": ui_reference,
        "runtime_capture": runtime_capture,
        "proof_boundary": {
            "F123_adapter_provenance_is_F125_geometry_correctness": False,
            "F125_correspondence_is_runtime_component_instance_proof": False,
            "runtime_capture_binding_is_behavior_proof": False,
            "runtime_capture_binding_is_mutation_authority": False,
            "runtime_capture_binding_is_truth_commit": False,
            "authorities_merged": False,
        },
        "authority": {
            "execution_provenance_authority": "core.capability_executor_adapter",
            "rendered_space_authority": "codebase.geometry_correspondence.GeometrySnapshot",
            "static_angular_authority": "codebase.angular_semantics",
            "correspondence_authority": "codebase.geometry_correspondence.UIAngularCorrespondence",
            "capture_binding_authority": "fullstack.runtime_geometry_capture",
            "source_mutated": False,
            "runtime_executed_by_this_query": False,
            "truth_committed": False,
        },
    }
    result["runtime_reference_state_digest"] = _digest({
        "f125_reference_state_digest": ui_reference.get("reference_state_digest"),
        "capture_binding_digest": runtime_capture.get("capture_binding_digest"),
    })
    return result


__all__ = [
    "CAPTURE_OBSERVATION_SCHEMA_VERSION",
    "CAPTURE_REFERENCE_SCHEMA_VERSION",
    "CAPTURE_OBSERVATION_KIND",
    "CAPTURE_CONTRACT_VERSION",
    "RuntimeGeometryCaptureAdapter",
    "build_geometry_capture_observation",
    "build_geometry_capture_adapter_result",
    "bind_runtime_geometry_capture",
    "build_runtime_ui_reference_state",
]
