"""Cross-authority reference-state composition.

Modules here may connect existing authorities but must not silently merge or
replace their source-of-truth responsibilities.
"""


from fullstack.geometric_impact import (
    GeometricImpactError,
    build_targeted_geometric_impact,
    load_geometric_impact_query,
    normalize_geometric_impact_query,
)

from fullstack.validation_scenarios import (
    CATALOG_SCHEMA_VERSION as VALIDATION_SCENARIO_CATALOG_SCHEMA_VERSION,
    SCHEMA_VERSION as VALIDATION_SCENARIO_PLAN_SCHEMA_VERSION,
    ValidationScenarioError,
    build_targeted_validation_plan,
    load_validation_scenario_catalog,
    normalize_validation_scenario_catalog,
    validation_plan_digest,
)


from fullstack.validation_evidence import (
    BINDING_DIGEST_POLICY as VALIDATION_EVIDENCE_BINDING_DIGEST_POLICY,
    EVIDENCE_SCHEMA_VERSION as VALIDATION_EVIDENCE_BUNDLE_SCHEMA_VERSION,
    SCHEMA_VERSION as VALIDATION_EVIDENCE_BINDING_SCHEMA_VERSION,
    VALIDATION_OBSERVATION_KIND,
    VALIDATION_OBSERVATION_SCHEMA_VERSION,
    ValidationEvidenceError,
    bind_validation_evidence,
    build_validation_observation_payload,
    load_validation_evidence_bundle,
    load_validation_plan,
    normalize_validation_evidence_bundle,
    validation_evidence_binding_digest,
    validation_observation_payload_digest,
    verify_validation_evidence_binding,
)


from fullstack.proof_obligations import (
    COVERAGE_DIGEST_POLICY as VALIDATION_PROOF_COVERAGE_DIGEST_POLICY,
    OBLIGATION_SCHEMA_VERSION as VALIDATION_PROOF_OBLIGATION_SET_SCHEMA_VERSION,
    EXECUTION_OBLIGATION_SCHEMA_VERSION as EXECUTION_PROOF_OBLIGATION_SET_SCHEMA_VERSION,
    EXECUTION_COVERAGE_SCHEMA_VERSION,
    EXECUTION_COVERAGE_DIGEST_POLICY,
    SCHEMA_VERSION as VALIDATION_PROOF_COVERAGE_SCHEMA_VERSION,
    ProofObligationError,
    load_proof_obligation_set,
    normalize_proof_obligation_set,
    proof_obligation_coverage_digest,
    project_validation_proof_obligations,
    project_execution_backed_proof_obligations,
    execution_proof_obligation_coverage_digest,
    verify_execution_backed_proof_coverage_integrity,
    verify_execution_backed_proof_coverage,
    verify_validation_proof_coverage_integrity,
    verify_validation_proof_coverage,
)

from fullstack.validation_execution import (
    HANDOFF_SCHEMA_VERSION as VALIDATION_EXECUTION_HANDOFF_SCHEMA_VERSION,
    REQUEST_SCHEMA_VERSION as VALIDATION_EXECUTION_REQUEST_SCHEMA_VERSION,
    SCHEMA_VERSION as VALIDATION_EXECUTION_REQUEST_SET_SCHEMA_VERSION,
    ValidationExecutionError,
    build_validation_execution_requests,
    validation_execution_request_digest,
    validation_execution_request_set_digest,
    verify_validation_execution_requests,
)


from fullstack.validation_authorization import (
    ASSERTION_SCHEMA_VERSION as VALIDATION_AUTHORIZATION_ASSERTION_SCHEMA_VERSION,
    SCHEMA_VERSION as VALIDATION_AUTHORIZATION_BINDING_SCHEMA_VERSION,
    ValidationAuthorizationError,
    build_validation_authorization_binding,
    issue_validation_request_authorization_assertion,
    validation_authorization_binding_digest,
    verify_validation_authorization_binding,
    verify_validation_request_authorization_assertion,
)

from fullstack.validation_execution_store import (
    BASE_SCHEMA_VERSION as VALIDATION_EXECUTION_STORE_BASE_SCHEMA_VERSION,
    FEATURE_TABLE as VALIDATION_EXECUTION_STORE_FEATURE_TABLE,
    ValidationExecutionStoreError, validation_store_path, open_validation_store,
    register_store_feature, read_store_features,
)

from fullstack.validation_lease import (
    SCHEMA_VERSION as VALIDATION_EXECUTION_LEASE_REQUEST_SCHEMA_VERSION,
    LEASE_RECEIPT_SCHEMA as VALIDATION_EXECUTION_LEASE_RECEIPT_SCHEMA_VERSION,
    ValidationLeaseError,
    load_validation_execution_lease_receipt,
    build_validation_execution_lease_request,
    evaluate_validation_execution_lease,
    acquire_validation_execution_lease,
    inspect_validation_execution_lease,
)

from fullstack.validation_dispatch import (
    SCHEMA_VERSION as VALIDATION_DISPATCH_REQUEST_SCHEMA_VERSION,
    RECEIPT_SCHEMA_VERSION as VALIDATION_DISPATCH_RECEIPT_SCHEMA_VERSION,
    ValidationDispatchError, build_validation_dispatch_request,
    build_validation_dispatch_request_from_store, evaluate_validation_dispatch_intent,
    prepare_validation_dispatch_intent, inspect_validation_dispatch_intent,
    load_validation_dispatch_intent_receipt,
)

from fullstack.validation_runtime import (
    SCHEMA_VERSION as VALIDATION_RUNTIME_SCHEMA_VERSION,
    HANDOFF_RECEIPT_SCHEMA as VALIDATION_RUNTIME_HANDOFF_SCHEMA_VERSION,
    OBSERVATION_RECEIPT_SCHEMA as VALIDATION_RUNTIME_OBSERVATION_SCHEMA_VERSION,
    ValidationRuntimeError, ValidationRuntimeAdapter,
    claim_validation_runtime_handoff, record_validation_runtime_observation,
    load_validation_runtime_observation_receipt, inspect_validation_runtime,
    invoke_validation_runtime_adapter, reconcile_validation_runtime_adapter,
)

from fullstack.validation_result_evidence import (
    SCHEMA_VERSION as VALIDATION_RESULT_EVIDENCE_SCHEMA_VERSION,
    RECEIPT_SCHEMA_VERSION as VALIDATION_RESULT_EVIDENCE_RECEIPT_SCHEMA_VERSION,
    ValidationResultEvidenceError,
    load_validation_result_payload,
    load_validation_execution_request_set,
    evaluate_validation_result_evidence,
    accept_validation_result_evidence,
    inspect_validation_result_evidence,
    load_validation_result_evidence_acceptance_receipt,
)

from fullstack.execution_backed_evidence import (
    SCHEMA_VERSION as EXECUTION_BACKED_EVIDENCE_SCHEMA_VERSION,
    BINDING_DIGEST_POLICY as EXECUTION_BACKED_EVIDENCE_DIGEST_POLICY,
    ExecutionBackedEvidenceError,
    load_execution_backed_scenario_evidence,
    execution_backed_evidence_binding_digest,
    bind_execution_backed_scenario_evidence,
    verify_execution_backed_scenario_evidence,
)

from fullstack.runtime_geometry_capture import (
    CAPTURE_CONTRACT_VERSION,
    CAPTURE_OBSERVATION_KIND,
    CAPTURE_OBSERVATION_SCHEMA_VERSION,
    CAPTURE_REFERENCE_SCHEMA_VERSION,
    RuntimeGeometryCaptureAdapter,
    bind_runtime_geometry_capture,
    build_geometry_capture_adapter_result,
    build_geometry_capture_observation,
    build_runtime_ui_reference_state,
)

from .validation_attempt import (
    SCHEMA_VERSION as VALIDATION_ATTEMPT_REQUEST_SCHEMA_VERSION,
    RECEIPT_SCHEMA_VERSION as VALIDATION_ATTEMPT_RECEIPT_SCHEMA_VERSION,
    ValidationAttemptError, build_validation_attempt_request,
    evaluate_validation_attempt, register_validation_attempt, inspect_validation_attempt,
    load_validation_attempt_receipt,
)

__all__ = [
    "VALIDATION_EXECUTION_STORE_BASE_SCHEMA_VERSION", "VALIDATION_EXECUTION_STORE_FEATURE_TABLE",
    "ValidationExecutionStoreError", "validation_store_path", "open_validation_store",
    "register_store_feature", "read_store_features",
    "VALIDATION_RUNTIME_SCHEMA_VERSION", "VALIDATION_RUNTIME_HANDOFF_SCHEMA_VERSION",
    "VALIDATION_RUNTIME_OBSERVATION_SCHEMA_VERSION", "ValidationRuntimeError",
    "ValidationRuntimeAdapter", "claim_validation_runtime_handoff",
    "record_validation_runtime_observation", "load_validation_runtime_observation_receipt",
    "inspect_validation_runtime", "invoke_validation_runtime_adapter",
    "reconcile_validation_runtime_adapter",
    "VALIDATION_RESULT_EVIDENCE_SCHEMA_VERSION",
    "VALIDATION_RESULT_EVIDENCE_RECEIPT_SCHEMA_VERSION",
    "ValidationResultEvidenceError", "load_validation_result_payload",
    "load_validation_execution_request_set", "evaluate_validation_result_evidence",
    "accept_validation_result_evidence", "inspect_validation_result_evidence",
    "load_validation_result_evidence_acceptance_receipt",
    "VALIDATION_DISPATCH_REQUEST_SCHEMA_VERSION", "VALIDATION_DISPATCH_RECEIPT_SCHEMA_VERSION",
    "ValidationDispatchError", "build_validation_dispatch_request",
    "build_validation_dispatch_request_from_store", "evaluate_validation_dispatch_intent",
    "prepare_validation_dispatch_intent", "inspect_validation_dispatch_intent",
    "load_validation_dispatch_intent_receipt",
    "VALIDATION_ATTEMPT_REQUEST_SCHEMA_VERSION", "VALIDATION_ATTEMPT_RECEIPT_SCHEMA_VERSION",
    "ValidationAttemptError", "build_validation_attempt_request",
    "evaluate_validation_attempt", "register_validation_attempt", "inspect_validation_attempt",
    "load_validation_attempt_receipt",
    "VALIDATION_EXECUTION_LEASE_REQUEST_SCHEMA_VERSION",
    "VALIDATION_EXECUTION_LEASE_RECEIPT_SCHEMA_VERSION",
    "ValidationLeaseError", "load_validation_execution_lease_receipt",
    "build_validation_execution_lease_request",
    "evaluate_validation_execution_lease",
    "acquire_validation_execution_lease",
    "inspect_validation_execution_lease",
    "VALIDATION_AUTHORIZATION_BINDING_SCHEMA_VERSION",
    "VALIDATION_AUTHORIZATION_ASSERTION_SCHEMA_VERSION",
    "ValidationAuthorizationError",
    "build_validation_authorization_binding",
    "issue_validation_request_authorization_assertion",
    "validation_authorization_binding_digest",
    "verify_validation_authorization_binding",
    "verify_validation_request_authorization_assertion",
    "VALIDATION_EXECUTION_REQUEST_SET_SCHEMA_VERSION",
    "VALIDATION_EXECUTION_REQUEST_SCHEMA_VERSION",
    "VALIDATION_EXECUTION_HANDOFF_SCHEMA_VERSION",
    "ValidationExecutionError",
    "build_validation_execution_requests",
    "validation_execution_request_digest",
    "validation_execution_request_set_digest",
    "verify_validation_execution_requests",
    "VALIDATION_PROOF_OBLIGATION_SET_SCHEMA_VERSION",
    "EXECUTION_PROOF_OBLIGATION_SET_SCHEMA_VERSION",
    "EXECUTION_COVERAGE_SCHEMA_VERSION",
    "EXECUTION_COVERAGE_DIGEST_POLICY",
    "VALIDATION_PROOF_COVERAGE_SCHEMA_VERSION",
    "ProofObligationError",
    "load_proof_obligation_set",
    "normalize_proof_obligation_set",
    "proof_obligation_coverage_digest",
    "project_validation_proof_obligations",
    "project_execution_backed_proof_obligations",
    "execution_proof_obligation_coverage_digest",
    "verify_execution_backed_proof_coverage_integrity",
    "verify_execution_backed_proof_coverage",
    "verify_validation_proof_coverage_integrity",
    "verify_validation_proof_coverage",
    "VALIDATION_PROOF_COVERAGE_DIGEST_POLICY",
    "CAPTURE_CONTRACT_VERSION",
    "CAPTURE_OBSERVATION_KIND",
    "CAPTURE_OBSERVATION_SCHEMA_VERSION",
    "CAPTURE_REFERENCE_SCHEMA_VERSION",
    "RuntimeGeometryCaptureAdapter",
    "build_geometry_capture_observation",
    "build_geometry_capture_adapter_result",
    "bind_runtime_geometry_capture",
    "build_runtime_ui_reference_state",
    "GeometricImpactError",
    "build_targeted_geometric_impact",
    "load_geometric_impact_query",
    "normalize_geometric_impact_query",
    "VALIDATION_SCENARIO_CATALOG_SCHEMA_VERSION",
    "VALIDATION_SCENARIO_PLAN_SCHEMA_VERSION",
    "ValidationScenarioError",
    "build_targeted_validation_plan",
    "load_validation_scenario_catalog",
    "normalize_validation_scenario_catalog",
    "validation_plan_digest",
    "VALIDATION_EVIDENCE_BUNDLE_SCHEMA_VERSION",
    "VALIDATION_EVIDENCE_BINDING_SCHEMA_VERSION",
    "VALIDATION_EVIDENCE_BINDING_DIGEST_POLICY",
    "VALIDATION_OBSERVATION_KIND",
    "VALIDATION_OBSERVATION_SCHEMA_VERSION",
    "ValidationEvidenceError",
    "bind_validation_evidence",
    "build_validation_observation_payload",
    "load_validation_evidence_bundle",
    "load_validation_plan",
    "normalize_validation_evidence_bundle",
    "validation_evidence_binding_digest",
    "validation_observation_payload_digest",
    "verify_validation_evidence_binding",
    "EXECUTION_BACKED_EVIDENCE_SCHEMA_VERSION",
    "EXECUTION_BACKED_EVIDENCE_DIGEST_POLICY",
    "ExecutionBackedEvidenceError",
    "load_execution_backed_scenario_evidence",
    "execution_backed_evidence_binding_digest",
    "bind_execution_backed_scenario_evidence",
    "verify_execution_backed_scenario_evidence",
]

from fullstack.postcondition_proof import (
    SCHEMA_VERSION as POSTCONDITION_PROOF_SCHEMA_VERSION,
    SPEC_SCHEMA_VERSION as POSTCONDITION_PROOF_SPEC_SCHEMA_VERSION,
    DIGEST_POLICY as POSTCONDITION_PROOF_DIGEST_POLICY,
    PostconditionProofError,
    load_postcondition_spec,
    load_postcondition_coverage,
    normalize_postcondition_spec,
    postcondition_proof_digest,
    assemble_postcondition_proof,
    verify_postcondition_proof_integrity,
)

from fullstack.full_stack_validated_state import (
    SCHEMA_VERSION as FULL_STACK_VALIDATED_STATE_SCHEMA_VERSION,
    SPEC_SCHEMA_VERSION as FULL_STACK_VALIDATION_SPEC_SCHEMA_VERSION,
    DIGEST_POLICY as FULL_STACK_VALIDATED_STATE_DIGEST_POLICY,
    FullStackValidatedStateError,
    load_json_artifact as load_full_stack_json_artifact,
    normalize_full_stack_spec,
    full_stack_validated_state_digest,
    compose_full_stack_validated_state,
    verify_full_stack_validated_state_integrity,
)

__all__ += [
    "FULL_STACK_VALIDATED_STATE_SCHEMA_VERSION",
    "FULL_STACK_VALIDATION_SPEC_SCHEMA_VERSION",
    "FULL_STACK_VALIDATED_STATE_DIGEST_POLICY",
    "FullStackValidatedStateError",
    "load_full_stack_json_artifact",
    "normalize_full_stack_spec",
    "full_stack_validated_state_digest",
    "compose_full_stack_validated_state",
    "verify_full_stack_validated_state_integrity",
]
