"""F135 durable validation-attempt registration against the exact F134 lease.

One shared SQLite transaction verifies the parent and records its sole attempt.
Recovery is a read of an existing commitment, including after lease expiry; it
never authorizes dispatch. This module has no external executor dependency.
"""
from __future__ import annotations

import json
import os
import re
import sqlite3
import time
from collections.abc import Mapping
from typing import Any

from core.accountability_provenance import seal_payload, verify_payload
from core.capability_contracts import exact_keys, is_sha256_id, safe_canonical_digest
from fullstack import validation_execution_store as execution_store
from fullstack import validation_lease as lease_store

SCHEMA_VERSION = "validation-attempt-request-v1"
POLICY_VERSION = "single-lease-single-validation-attempt-v1"
RECEIPT_SCHEMA_VERSION = "validation-attempt-receipt-v1"
RECEIPT_ISSUER = "plw.fullstack.validation-attempt.v1"
TABLE_NAME = "validation_execution_attempts_v1"
_ATTEMPT_KEY = re.compile(r"[A-Za-z0-9][A-Za-z0-9._:-]{15,127}\Z")
_BINDING_KEYS = (
    "lease_id", "authorization_binding_digest", "authorization_assertion_digest",
    "request_id", "request_set_digest", "scenario_id", "validator_id",
    "executor_id", "operation_key",
)
_AUTHORIZATION_KEYS = frozenset({
    "attempt_registration", "adapter_dispatch", "runtime_execution",
    "evidence_acceptance", "postcondition", "truth",
})
_REQUEST_KEYS = frozenset(_BINDING_KEYS) | {
    "schema_version", "policy", "attempt_key", "caller_registers_validation_attempt",
    "authority", "authorizations",
}
_ROW_KEYS = ("attempt_id", "attempt_request_digest", "attempt_key", *_BINDING_KEYS,
             "lease_acquired_at_epoch", "lease_expires_at_epoch", "registered_at_epoch")
_BODY_KEYS = (frozenset(_ROW_KEYS) - {"attempt_id"}) | {
    "schema_version", "policy", "attempt_state", "authority_class", "scope",
}
_RECEIPT_KEYS = _BODY_KEYS | {"attempt_id", "provenance"}
_ROW_SELECT = ", ".join((*_ROW_KEYS, "receipt_json"))


class ValidationAttemptError(ValueError):
    """A malformed request or inconsistent durable parent/attempt."""


def build_validation_attempt_request(lease_receipt: Mapping[str, Any], attempt_key: str) -> dict:
    """Build a no-effect request; authority must come from the durable lease."""
    source = lease_receipt if isinstance(lease_receipt, Mapping) else {}
    return {
        "schema_version": SCHEMA_VERSION, "policy": POLICY_VERSION,
        **{key: source.get(key, "") for key in _BINDING_KEYS},
        "attempt_key": attempt_key,
        "caller_registers_validation_attempt": True,
        "authority": "validation_attempt_request_only",
        "authorizations": {key: False for key in sorted(_AUTHORIZATION_KEYS)},
    }


def _request(value: Any) -> dict:
    if not exact_keys(value, _REQUEST_KEYS):
        raise ValidationAttemptError("attempt_request_exact_schema")
    if value["schema_version"] != SCHEMA_VERSION or value["policy"] != POLICY_VERSION:
        raise ValidationAttemptError("attempt_request_version")
    if value["caller_registers_validation_attempt"] is not True:
        raise ValidationAttemptError("attempt_intent_must_be_literal_true")
    auth = value["authorizations"]
    if (value["authority"] != "validation_attempt_request_only"
            or not exact_keys(auth, _AUTHORIZATION_KEYS)
            or any(auth[key] is not False for key in _AUTHORIZATION_KEYS)):
        raise ValidationAttemptError("attempt_request_must_have_no_execution_authority")
    if not isinstance(value["attempt_key"], str) or not _ATTEMPT_KEY.fullmatch(value["attempt_key"]):
        raise ValidationAttemptError("attempt_key")
    if execution_store.bounded_validation_digest(value) is None or not is_sha256_id(value["lease_id"]):
        raise ValidationAttemptError("attempt_request_bounded_json_or_lease_id")
    return dict(value)


def _open_connection(store_dir, *, writable: bool) -> sqlite3.Connection:
    try:
        return execution_store.open_validation_store(store_dir, writable=writable, create=False)
    except (execution_store.ValidationExecutionStoreError, FileNotFoundError) as exc:
        raise ValidationAttemptError("validation_lease_store_unavailable") from exc


def _load_lease(conn, lease_id: str, store_dir) -> dict:
    try:
        return lease_store.load_validation_execution_lease_receipt(conn, lease_id, store_dir=store_dir)
    except lease_store.ValidationLeaseError as exc:
        raise ValidationAttemptError(str(exc)) from exc


def _initialize_table(conn) -> None:
    # Additive, versioned F135 table; F134's user_version and receipts are intact.
    conn.execute(f"""CREATE TABLE IF NOT EXISTS {TABLE_NAME} (
        attempt_id TEXT PRIMARY KEY NOT NULL,
        attempt_request_digest TEXT NOT NULL,
        attempt_key TEXT NOT NULL UNIQUE,
        lease_id TEXT NOT NULL UNIQUE REFERENCES validation_execution_leases(lease_id),
        authorization_binding_digest TEXT NOT NULL,
        authorization_assertion_digest TEXT NOT NULL,
        request_id TEXT NOT NULL, request_set_digest TEXT NOT NULL,
        scenario_id TEXT NOT NULL, validator_id TEXT NOT NULL,
        executor_id TEXT NOT NULL, operation_key TEXT NOT NULL,
        lease_acquired_at_epoch INTEGER NOT NULL,
        lease_expires_at_epoch INTEGER NOT NULL,
        registered_at_epoch INTEGER NOT NULL,
        receipt_json TEXT NOT NULL
    )""")
    execution_store.register_store_feature(conn, "attempt", 1, TABLE_NAME)


def _load_row(conn, lease_id: str):
    return execution_store.load_validation_feature_row(
        conn, table_name=TABLE_NAME, select_columns=(*_ROW_KEYS, "receipt_json"),
        key_column="lease_id", key_value=lease_id,
    )


def _verify_attempt(row, parent: Mapping[str, Any], store_dir) -> dict:
    try:
        receipt = json.loads(row["receipt_json"])
        if not exact_keys(receipt, _RECEIPT_KEYS):
            raise ValidationAttemptError("attempt_receipt_schema")
        body = {key: receipt[key] for key in _BODY_KEYS}
        if (execution_store.bounded_validation_digest(body) != receipt["attempt_id"]
                or not is_sha256_id(receipt["attempt_id"])
                or not verify_payload(body, receipt["provenance"], RECEIPT_ISSUER, store_dir=store_dir)):
            raise ValidationAttemptError("attempt_receipt_verification_failed")
        if any(type(row[k]) is not type(receipt[k]) or row[k] != receipt[k] for k in _ROW_KEYS):
            raise ValidationAttemptError("attempt_receipt_row_binding_mismatch")
        expected = {"schema_version": RECEIPT_SCHEMA_VERSION, "policy": POLICY_VERSION,
                    "attempt_state": "REGISTERED", "authority_class": "validation_attempt_registration",
                    "scope": "single_F134_lease_single_validation_attempt",
                    **{key: parent[key] for key in _BINDING_KEYS},
                    "lease_acquired_at_epoch": parent["acquired_at_epoch"],
                    "lease_expires_at_epoch": parent["expires_at_epoch"]}
        if any(type(receipt[k]) is not type(v) or receipt[k] != v for k, v in expected.items()):
            raise ValidationAttemptError("attempt_lease_binding_mismatch")
        registered = receipt["registered_at_epoch"]
        if type(registered) is not int or not parent["acquired_at_epoch"] <= registered < parent["expires_at_epoch"]:
            raise ValidationAttemptError("attempt_registration_time")
        req = _request(build_validation_attempt_request(parent, receipt["attempt_key"]))
        if receipt["attempt_request_digest"] != execution_store.bounded_validation_digest(req):
            raise ValidationAttemptError("attempt_request_digest_mismatch")
        return receipt
    except ValidationAttemptError:
        raise
    except (TypeError, ValueError, RecursionError, KeyError) as exc:
        raise ValidationAttemptError("attempt_receipt_corrupt") from exc


def _evaluate(conn, req: dict, store_dir) -> tuple[str, dict, dict]:
    parent = _load_lease(conn, req["lease_id"], store_dir)
    if any(type(req[k]) is not type(parent[k]) or req[k] != parent[k] for k in _BINDING_KEYS):
        raise ValidationAttemptError("attempt_request_lease_binding_mismatch")
    row = _load_row(conn, req["lease_id"])
    if row is not None:
        prior = _verify_attempt(row, parent, store_dir)
        if prior["attempt_request_digest"] != execution_store.bounded_validation_digest(req):
            raise ValidationAttemptError("lease_attempt_already_registered")
        return "recovered", parent, prior
    if execution_store.validation_table_exists(conn, TABLE_NAME) and conn.execute(
            f"SELECT 1 FROM {TABLE_NAME} WHERE attempt_key = ?", (req["attempt_key"],)).fetchone():
        raise ValidationAttemptError("attempt_key_conflict")
    if not parent["acquired_at_epoch"] <= int(time.time()) < parent["expires_at_epoch"]:
        raise ValidationAttemptError("lease_not_active_at_registration")
    return "eligible", parent, {}


def _result(status: str, req: Mapping[str, Any], receipt=None, failures=()) -> dict:
    registered, recovered = status == "registered", status == "recovered"
    stored = receipt or {}
    return {
        "schema_version": SCHEMA_VERSION, "policy": POLICY_VERSION,
        "decision": {
            "eligible": "VALIDATION_ATTEMPT_ELIGIBLE",
            "registered": "VALIDATION_ATTEMPT_REGISTERED",
            "recovered": "VALIDATION_ATTEMPT_RECOVERED_NO_NEW_AUTHORITY",
            "recovery_eligible": "VALIDATION_ATTEMPT_RECOVERY_ELIGIBLE",
        }.get(status, "VALIDATION_ATTEMPT_REJECTED"),
        "attempt_eligible": status == "eligible",
        "recovery_eligible": status == "recovery_eligible",
        "attempt_registered": registered,
        "idempotent_recovery": recovered,
        "attempt_exists": bool(stored),
        "attempt_id": stored.get("attempt_id", ""),
        "lease_id": stored.get("lease_id", req.get("lease_id", "")),
        "attempt_receipt": stored, "failed_conditions": list(failures),
        "dispatch_authorized": False, "dispatch_state_authority": False,
        "dispatch_state": "UNKNOWN_TO_F135", "runtime_executed": False,
        "evidence_returned": False, "truth_committed": False,
        "authority": {
            "durable_state_changed": registered, "attempt_registered_by_this_call": registered,
            "adapter_dispatch": False, "runtime_execution": False,
            "evidence_acceptance": False, "postcondition": False, "truth": False,
        },
        "effects": {"attempt_state_changed": registered, "adapter_dispatch_prepared": False,
                    "runtime_executed": False, "source_mutated": False, "truth_committed": False},
        "state_transition": {"from": "LEASED", "to": "ATTEMPT_REGISTERED" if registered else "UNCHANGED",
                             "durable": registered or recovered},
        "handoff": {"required_next_boundary": "VALIDATION_DISPATCH_INTENT",
                    "attempt_binding_present": bool(stored),
                    "dispatch_state_authority": False, "dispatch_state": "UNKNOWN_TO_F135",
                    "may_dispatch": False},
    }


def load_validation_attempt_receipt(connection: sqlite3.Connection, attempt_id: str, *, store_dir=None) -> dict:
    if not is_sha256_id(attempt_id):
        raise ValidationAttemptError("invalid_attempt_id")
    row = execution_store.load_validation_feature_row(
        connection, table_name=TABLE_NAME, select_columns=(*_ROW_KEYS, "receipt_json"),
        key_column="attempt_id", key_value=attempt_id,
    )
    if row is None:
        raise ValidationAttemptError("validation_attempt_not_found")
    parent = _load_lease(connection, row["lease_id"], store_dir)
    return _verify_attempt(row, parent, store_dir)


def evaluate_validation_attempt(request: Mapping[str, Any], *, store_dir=None) -> dict:
    """Read-only eligibility; exact durable recovery remains possible after expiry."""
    req = {}
    conn = None
    try:
        req = _request(request)
        conn = _open_connection(store_dir, writable=False)
        conn.execute("BEGIN")
        status, _, prior = _evaluate(conn, req, store_dir)
        return _result("recovery_eligible" if status == "recovered" else status, req, prior)
    except (ValidationAttemptError, sqlite3.Error, OSError, ValueError) as exc:
        return _result("rejected", req, failures=[str(exc)])
    finally:
        if conn is not None:
            conn.close()


def register_validation_attempt(request: Mapping[str, Any], *, store_dir=None,
                                _fail_before_commit: bool = False) -> dict:
    """Commit at most one attempt per exact lease; no host call or dispatch."""
    req = {}
    conn = None
    try:
        req = _request(request)
        conn = _open_connection(store_dir, writable=True)
        conn.execute("BEGIN IMMEDIATE")
        status, parent, prior = _evaluate(conn, req, store_dir)
        if status == "recovered":
            conn.execute("COMMIT")
            return _result(status, req, prior)
        _initialize_table(conn)
        registered = int(time.time())
        body = {
            "schema_version": RECEIPT_SCHEMA_VERSION, "policy": POLICY_VERSION,
            "attempt_state": "REGISTERED", "attempt_request_digest": execution_store.bounded_validation_digest(req),
            "attempt_key": req["attempt_key"],
            **{key: parent[key] for key in _BINDING_KEYS},
            "lease_acquired_at_epoch": parent["acquired_at_epoch"],
            "lease_expires_at_epoch": parent["expires_at_epoch"],
            "registered_at_epoch": registered,
            "authority_class": "validation_attempt_registration",
            "scope": "single_F134_lease_single_validation_attempt",
        }
        receipt = {**body, "attempt_id": execution_store.bounded_validation_digest(body),
                   "provenance": seal_payload(body, RECEIPT_ISSUER, store_dir=store_dir)}
        if not receipt["attempt_id"]:
            raise ValidationAttemptError("attempt_receipt_bounded_json")
        conn.execute(
            f"INSERT INTO {TABLE_NAME} ({_ROW_SELECT}) VALUES ({','.join('?' for _ in range(len(_ROW_KEYS) + 1))})",
            (*[receipt[key] for key in _ROW_KEYS], json.dumps(receipt, ensure_ascii=False, sort_keys=True)),
        )
        if _fail_before_commit:
            raise ValidationAttemptError("injected_precommit_failure")
        if not parent["acquired_at_epoch"] <= registered <= int(time.time()) < parent["expires_at_epoch"]:
            raise ValidationAttemptError("lease_expired_before_attempt_commit")
        conn.execute("COMMIT")
        return _result("registered", req, receipt)
    except (ValidationAttemptError, sqlite3.Error, OSError, ValueError) as exc:
        return _result("rejected", req, failures=[str(exc)])
    finally:
        if conn is not None:
            if conn.in_transaction:
                conn.rollback()
            conn.close()


def inspect_validation_attempt(lease_id: str, *, request_id: str | None = None,
                               executor_id: str | None = None, store_dir=None) -> dict:
    """Read a committed attempt and its exact parent in one SQLite snapshot."""
    conn = None
    try:
        if not is_sha256_id(lease_id):
            raise ValidationAttemptError("invalid_lease_id")
        conn = _open_connection(store_dir, writable=False)
        conn.execute("BEGIN")
        parent = _load_lease(conn, lease_id, store_dir)
        row = _load_row(conn, lease_id)
        if row is None:
            raise ValidationAttemptError("validation_attempt_not_found")
        receipt = _verify_attempt(row, parent, store_dir)
        if request_id is not None and receipt["request_id"] != request_id:
            raise ValidationAttemptError("request_binding_mismatch")
        if executor_id is not None and receipt["executor_id"] != executor_id:
            raise ValidationAttemptError("executor_binding_mismatch")
        return {
            "schema_version": RECEIPT_SCHEMA_VERSION, "attempt_found": True,
            "decision": "VALIDATION_ATTEMPT_REGISTERED",
            "lease_id": lease_id, "attempt_id": receipt["attempt_id"],
            "attempt_receipt": receipt,
            "lease_active": parent["acquired_at_epoch"] <= int(time.time()) < parent["expires_at_epoch"],
            "authority": "validation_attempt_inspection_only",
            "attempt_state": "REGISTERED",
            "attempt_registered_by_this_call": False, "dispatch_authorized": False,
            "dispatch_state_authority": False, "dispatch_state": "UNKNOWN_TO_F135",
            "next_boundary": "VALIDATION_DISPATCH_INTENT",
            "may_dispatch": False, "runtime_executed": False,
            "evidence_returned": False, "postcondition_proven": False, "truth_committed": False,
        }
    except (ValidationAttemptError, sqlite3.Error, OSError, ValueError) as exc:
        return {"attempt_found": False, "error": str(exc), "dispatch_authorized": False,
                "dispatch_state_authority": False, "dispatch_state": "UNKNOWN_TO_F135",
                "may_dispatch": False, "runtime_executed": False, "truth_committed": False}
    finally:
        if conn is not None:
            conn.close()


__all__ = [
    "SCHEMA_VERSION", "POLICY_VERSION", "RECEIPT_SCHEMA_VERSION", "RECEIPT_ISSUER",
    "TABLE_NAME", "ValidationAttemptError", "build_validation_attempt_request",
    "evaluate_validation_attempt", "register_validation_attempt", "inspect_validation_attempt",
    "load_validation_attempt_receipt",
]
