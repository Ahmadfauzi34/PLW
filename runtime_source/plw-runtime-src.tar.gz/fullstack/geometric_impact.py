"""Targeted geometric constraint evidence and topology impact projection.

F127 consumes already-normalized F125 UI reference state plus the same F124
Angular ownership and SharedGraph snapshots.  It evaluates explicit geometric
constraints and focused spatial relations, then projects proven UI ownership
back to bounded topology impact briefs.

This is a reference/query layer only.  It does not infer UI ownership, execute a
browser, mutate source, declare undeclared layout intent, or turn geometric
facts into behavioral/postcondition truth.
"""
from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

from codebase.topology_analyzers import query_impact

SCHEMA_VERSION = "geometric-impact-v1"
QUERY_SCHEMA_VERSION = "geometric-impact-query-v1"
MAX_QUERY_BYTES = 1_048_576
MAX_FOCUS_UI_IDS = 256
MAX_CONSTRAINTS = 4096
MAX_PAIR_RELATIONS = 10_000
MAX_TOPOLOGY_ITEMS = 64
_MAX_TEXT = 2048


class GeometricImpactError(ValueError):
    """Raised when an explicit F127 query violates the bounded contract."""


def _digest(value: Any) -> str:
    payload = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    digest = hashlib.sha256()
    digest.update(payload)
    return f"sha256:{digest.hexdigest()}"


def _text(value: Any, field: str, *, required: bool = False) -> Optional[str]:
    if value is None:
        if required:
            raise GeometricImpactError(f"{field} is required")
        return None
    if not isinstance(value, str):
        raise GeometricImpactError(f"{field} must be a string")
    value = value.strip()
    if required and not value:
        raise GeometricImpactError(f"{field} must be non-empty")
    if len(value) > _MAX_TEXT:
        raise GeometricImpactError(f"{field} exceeds {_MAX_TEXT} characters")
    return value or None


def _finite_nonnegative(value: Any, field: str, *, default: float = 0.0) -> float:
    if value is None:
        return default
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise GeometricImpactError(f"{field} must be a finite non-negative number")
    result = float(value)
    if not math.isfinite(result) or result < 0:
        raise GeometricImpactError(f"{field} must be a finite non-negative number")
    return result


def load_geometric_impact_query(path: str, *, max_bytes: int = MAX_QUERY_BYTES) -> Dict[str, Any]:
    target = Path(path)
    try:
        raw = target.read_bytes()
    except OSError as exc:
        raise GeometricImpactError(f"constraint query unavailable: {type(exc).__name__}") from exc
    if len(raw) > max_bytes:
        raise GeometricImpactError(f"constraint query exceeds {max_bytes} bytes")
    try:
        payload = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise GeometricImpactError(f"constraint query is not valid bounded UTF-8 JSON: {type(exc).__name__}") from exc
    if not isinstance(payload, dict):
        raise GeometricImpactError("constraint query root must be a JSON object")
    return payload


def _unique_texts(value: Any, field: str, *, limit: int) -> List[str]:
    if value is None:
        return []
    if isinstance(value, str):
        value = [value]
    if not isinstance(value, list):
        raise GeometricImpactError(f"{field} must be an array of strings")
    result: List[str] = []
    seen: set[str] = set()
    for index, item in enumerate(value):
        text = _text(item, f"{field}[{index}]", required=True)
        assert text is not None
        if text in seen:
            continue
        seen.add(text)
        result.append(text)
        if len(result) > limit:
            raise GeometricImpactError(f"{field} exceeds {limit} unique entries")
    return result


def normalize_geometric_impact_query(
    query: Optional[Mapping[str, Any]] = None,
    *,
    focus_ui_ids: Optional[Sequence[str]] = None,
    proximity_px: Optional[float] = None,
) -> Dict[str, Any]:
    """Normalize one explicit targeted geometry query.

    Query constraints are declarations by the caller, not inferred layout intent.
    Supported kinds are inside_viewport, inside_parent, no_overlap, and min_gap.
    """
    raw = dict(query or {})
    schema = raw.get("schema_version", QUERY_SCHEMA_VERSION)
    if schema != QUERY_SCHEMA_VERSION:
        raise GeometricImpactError(f"unsupported query schema_version: {schema}")
    supplied_focus = _unique_texts(raw.get("focus_ui_ids"), "focus_ui_ids", limit=MAX_FOCUS_UI_IDS)
    extra_focus = _unique_texts(list(focus_ui_ids or []), "focus_ui_ids", limit=MAX_FOCUS_UI_IDS)
    focus: List[str] = []
    for item in [*supplied_focus, *extra_focus]:
        if item not in focus:
            focus.append(item)
    if len(focus) > MAX_FOCUS_UI_IDS:
        raise GeometricImpactError(f"focus_ui_ids exceeds {MAX_FOCUS_UI_IDS} unique entries")

    raw_constraints = raw.get("constraints", [])
    if not isinstance(raw_constraints, list):
        raise GeometricImpactError("constraints must be an array")
    if len(raw_constraints) > MAX_CONSTRAINTS:
        raise GeometricImpactError(f"constraints exceeds {MAX_CONSTRAINTS}")
    constraints: List[Dict[str, Any]] = []
    seen_ids: set[str] = set()
    for index, item in enumerate(raw_constraints):
        field = f"constraints[{index}]"
        if not isinstance(item, dict):
            raise GeometricImpactError(f"{field} must be an object")
        kind = _text(item.get("kind"), f"{field}.kind", required=True)
        if kind not in {"inside_viewport", "inside_parent", "no_overlap", "min_gap"}:
            raise GeometricImpactError(f"{field}.kind is unsupported: {kind}")
        subject = _text(item.get("subject_ui_id"), f"{field}.subject_ui_id", required=True)
        other = _text(item.get("other_ui_id"), f"{field}.other_ui_id")
        if kind in {"no_overlap", "min_gap"} and not other:
            raise GeometricImpactError(f"{field}.other_ui_id is required for {kind}")
        if kind in {"inside_viewport", "inside_parent"} and other is not None:
            raise GeometricImpactError(f"{field}.other_ui_id is not valid for {kind}")
        minimum = _finite_nonnegative(item.get("min_px"), f"{field}.min_px") if kind == "min_gap" else None
        constraint_id = _text(item.get("constraint_id"), f"{field}.constraint_id")
        canonical = {
            "kind": kind,
            "subject_ui_id": subject,
            "other_ui_id": other,
            "min_px": minimum,
        }
        if constraint_id is None:
            constraint_id = _digest(canonical)
        if constraint_id in seen_ids:
            raise GeometricImpactError(f"duplicate constraint_id: {constraint_id}")
        seen_ids.add(constraint_id)
        constraints.append({"constraint_id": constraint_id, **canonical})

    proximity = _finite_nonnegative(
        proximity_px if proximity_px is not None else raw.get("proximity_px"),
        "proximity_px",
        default=0.0,
    )
    normalized = {
        "schema_version": QUERY_SCHEMA_VERSION,
        "focus_ui_ids": focus,
        "constraints": constraints,
        "proximity_px": proximity,
    }
    normalized["query_digest"] = _digest(normalized)
    return normalized


def _boxes(node: Mapping[str, Any]) -> Optional[Mapping[str, Any]]:
    geometry = node.get("geometry")
    if not isinstance(geometry, Mapping):
        return None
    box = geometry.get("bbox")
    return box if isinstance(box, Mapping) else None


def _rectangle_relation(subject: Mapping[str, Any], other: Mapping[str, Any]) -> Dict[str, Any]:
    a = _boxes(subject)
    b = _boxes(other)
    if a is None or b is None:
        return {"proof_class": "UNRESOLVED", "reason": "bbox_missing"}
    ax1, ay1 = float(a["x"]), float(a["y"])
    ax2, ay2 = ax1 + float(a["width"]), ay1 + float(a["height"])
    bx1, by1 = float(b["x"]), float(b["y"])
    bx2, by2 = bx1 + float(b["width"]), by1 + float(b["height"])
    overlap_w = max(0.0, min(ax2, bx2) - max(ax1, bx1))
    overlap_h = max(0.0, min(ay2, by2) - max(ay1, by1))
    overlap_area = overlap_w * overlap_h
    dx = max(bx1 - ax2, ax1 - bx2, 0.0)
    dy = max(by1 - ay2, ay1 - by2, 0.0)
    gap = math.hypot(dx, dy)
    a_area = max(0.0, float(a["width"]) * float(a["height"]))
    b_area = max(0.0, float(b["width"]) * float(b["height"]))
    return {
        "proof_class": "EXACT",
        "overlap": overlap_area > 0.0,
        "overlap_width": overlap_w,
        "overlap_height": overlap_h,
        "overlap_area": overlap_area,
        "subject_overlap_ratio": (overlap_area / a_area) if a_area > 0 else 0.0,
        "other_overlap_ratio": (overlap_area / b_area) if b_area > 0 else 0.0,
        "gap_x": dx,
        "gap_y": dy,
        "edge_gap_px": gap,
        "subject_contains_other": ax1 <= bx1 and ay1 <= by1 and ax2 >= bx2 and ay2 >= by2,
        "other_contains_subject": bx1 <= ax1 and by1 <= ay1 and bx2 >= ax2 and by2 >= ay2,
    }


def _viewport_evidence(node: Mapping[str, Any], viewport: Mapping[str, Any]) -> Dict[str, Any]:
    box = _boxes(node)
    if box is None:
        return {"proof_class": "UNRESOLVED", "reason": "bbox_missing"}
    x, y = float(box["x"]), float(box["y"])
    width, height = float(box["width"]), float(box["height"])
    right, bottom = x + width, y + height
    vw, vh = float(viewport["width"]), float(viewport["height"])
    return {
        "proof_class": "EXACT",
        "fully_inside": x >= 0.0 and y >= 0.0 and right <= vw and bottom <= vh,
        "intersects": not (right <= 0.0 or bottom <= 0.0 or x >= vw or y >= vh),
        "overflow": {
            "left": max(0.0, -x),
            "top": max(0.0, -y),
            "right": max(0.0, right - vw),
            "bottom": max(0.0, bottom - vh),
        },
    }


def _parent_evidence(node: Mapping[str, Any], nodes: Mapping[str, Mapping[str, Any]]) -> Dict[str, Any]:
    parent_id = node.get("parent_ui_id")
    if not isinstance(parent_id, str) or not parent_id:
        return {"proof_class": "UNRESOLVED", "reason": "parent_ui_id_missing", "parent_ui_id": parent_id}
    parent = nodes.get(parent_id)
    if parent is None:
        return {"proof_class": "UNRESOLVED", "reason": "parent_node_missing", "parent_ui_id": parent_id}
    relation = _rectangle_relation(node, parent)
    if relation.get("proof_class") != "EXACT":
        return {"proof_class": "UNRESOLVED", "reason": relation.get("reason"), "parent_ui_id": parent_id}
    return {
        "proof_class": "EXACT",
        "parent_ui_id": parent_id,
        "fully_inside": bool(relation.get("other_contains_subject")),
        "relation": relation,
    }



def _is_ancestor(ancestor_id: str, descendant_id: str, nodes: Mapping[str, Mapping[str, Any]]) -> bool:
    seen: set[str] = set()
    current = nodes.get(descendant_id)
    while isinstance(current, Mapping):
        parent_id = current.get("parent_ui_id")
        if not isinstance(parent_id, str) or not parent_id or parent_id in seen:
            return False
        if parent_id == ancestor_id:
            return True
        seen.add(parent_id)
        current = nodes.get(parent_id)
    return False

def _constraint_result(
    constraint: Mapping[str, Any],
    nodes: Mapping[str, Mapping[str, Any]],
    viewport: Mapping[str, Any],
) -> Dict[str, Any]:
    subject_id = str(constraint["subject_ui_id"])
    other_id = constraint.get("other_ui_id")
    subject = nodes.get(subject_id)
    base = {
        "constraint_id": constraint["constraint_id"],
        "kind": constraint["kind"],
        "subject_ui_id": subject_id,
        "other_ui_id": other_id,
        "declared_min_px": constraint.get("min_px"),
        "declared_by_query": True,
    }
    if subject is None:
        return {**base, "proof_class": "UNRESOLVED", "status": "UNRESOLVED", "reason": "subject_ui_id_not_found", "evidence": None}

    kind = constraint["kind"]
    if kind == "inside_viewport":
        evidence = _viewport_evidence(subject, viewport)
        if evidence.get("proof_class") != "EXACT":
            return {**base, "proof_class": "UNRESOLVED", "status": "UNRESOLVED", "reason": evidence.get("reason"), "evidence": evidence}
        satisfied = bool(evidence["fully_inside"])
    elif kind == "inside_parent":
        evidence = _parent_evidence(subject, nodes)
        if evidence.get("proof_class") != "EXACT":
            return {**base, "proof_class": "UNRESOLVED", "status": "UNRESOLVED", "reason": evidence.get("reason"), "evidence": evidence}
        satisfied = bool(evidence["fully_inside"])
    else:
        other = nodes.get(str(other_id)) if other_id is not None else None
        if other is None:
            return {**base, "proof_class": "UNRESOLVED", "status": "UNRESOLVED", "reason": "other_ui_id_not_found", "evidence": None}
        evidence = _rectangle_relation(subject, other)
        if evidence.get("proof_class") != "EXACT":
            return {**base, "proof_class": "UNRESOLVED", "status": "UNRESOLVED", "reason": evidence.get("reason"), "evidence": evidence}
        if kind == "no_overlap":
            satisfied = not bool(evidence["overlap"])
        else:
            satisfied = float(evidence["edge_gap_px"]) >= float(constraint.get("min_px") or 0.0)
    return {
        **base,
        "proof_class": "EXACT",
        "status": "SATISFIED" if satisfied else "VIOLATED",
        "reason": "declared_constraint_evaluated",
        "evidence": evidence,
    }


def _bounded(values: Iterable[str], limit: int = MAX_TOPOLOGY_ITEMS) -> Dict[str, Any]:
    ordered = sorted(set(str(item) for item in values))
    return {
        "items": ordered[:limit],
        "total_count": len(ordered),
        "omitted_count": max(0, len(ordered) - limit),
        "truncated": len(ordered) > limit,
    }


def _component_lookup(ownership: Mapping[str, Any]) -> Dict[str, Mapping[str, Any]]:
    result: Dict[str, Mapping[str, Any]] = {}
    for row in ownership.get("components", []):
        if isinstance(row, Mapping) and isinstance(row.get("component_id"), str):
            result[str(row["component_id"])] = row
    return result


def _resource_brief(component: Optional[Mapping[str, Any]]) -> Dict[str, Any]:
    if component is None:
        return {"template": None, "styles": []}
    template = component.get("template") if isinstance(component.get("template"), Mapping) else {}
    template_brief = {
        key: template.get(key)
        for key in ("kind", "resolved_path", "sha256", "proof_class", "content_proof_class")
        if template.get(key) is not None
    }
    styles: List[Dict[str, Any]] = []
    for style in component.get("styles", []):
        if not isinstance(style, Mapping):
            continue
        styles.append({
            key: style.get(key)
            for key in ("kind", "resolved_path", "sha256", "proof_class", "content_proof_class")
            if style.get(key) is not None
        })
    return {"template": template_brief or None, "styles": styles}


def _topology_projection(
    selected_ui_ids: Sequence[str],
    correspondence: Mapping[str, Any],
    ownership: Mapping[str, Any],
    shared_graph: Mapping[str, Any],
) -> Dict[str, Any]:
    mappings = {
        row.get("ui_id"): row
        for row in correspondence.get("mappings", [])
        if isinstance(row, Mapping) and isinstance(row.get("ui_id"), str)
    }
    components = _component_lookup(ownership)
    by_file: Dict[str, Dict[str, Any]] = {}
    unresolved: List[Dict[str, Any]] = []
    for ui_id in selected_ui_ids:
        mapping = mappings.get(ui_id)
        if mapping is None:
            unresolved.append({"ui_id": ui_id, "reason": "correspondence_missing"})
            continue
        proof_class = mapping.get("proof_class")
        component_file = mapping.get("component_file")
        component_id = mapping.get("component_id")
        if proof_class not in {"EXACT", "STRUCTURAL"} or not isinstance(component_file, str):
            unresolved.append({
                "ui_id": ui_id,
                "reason": mapping.get("reason") or "correspondence_unresolved",
                "correspondence_proof_class": proof_class,
            })
            continue
        bucket = by_file.setdefault(component_file, {
            "component_file": component_file,
            "component_ids": set(),
            "ui_ids": set(),
            "correspondence_proof_classes": set(),
        })
        bucket["ui_ids"].add(ui_id)
        if isinstance(component_id, str):
            bucket["component_ids"].add(component_id)
        bucket["correspondence_proof_classes"].add(str(proof_class))

    projections: List[Dict[str, Any]] = []
    for component_file in sorted(by_file):
        bucket = by_file[component_file]
        impact = query_impact(dict(shared_graph), component_file)
        component_ids = sorted(bucket["component_ids"])
        resources: List[Dict[str, Any]] = []
        for component_id in component_ids:
            resources.append({"component_id": component_id, **_resource_brief(components.get(component_id))})
        exists = impact.get("exists") is True
        projections.append({
            "component_file": component_file,
            "ui_ids": sorted(bucket["ui_ids"]),
            "component_ids": component_ids,
            "correspondence_proof_classes": sorted(bucket["correspondence_proof_classes"]),
            "projection_class": "STRUCTURAL" if exists else "UNRESOLVED",
            "projection_reason": "correspondence_to_shared_graph_target" if exists else impact.get("error"),
            "layout_resources": resources,
            "topology": {
                "target_resolution": impact.get("target_resolution"),
                "direct_upstream": _bounded(impact.get("direct_upstream", [])),
                "direct_downstream": _bounded(impact.get("direct_downstream", [])),
                "upstream": _bounded(impact.get("upstream", [])),
                "downstream": _bounded(impact.get("downstream", [])),
                "affected_entrypoints": _bounded(impact.get("affected_entrypoints", [])),
                "change_risk_level": impact.get("change_risk_level"),
                "change_risk_reasons": impact.get("change_risk_reasons", []),
            } if exists else None,
            "recover_full_topology_with": f"plw impact {component_file} <project-root> --json" if exists else None,
        })
    return {
        "projections": projections,
        "unresolved_ui_ids": unresolved,
        "projected_component_file_count": len(projections),
        "unresolved_ui_count": len(unresolved),
    }



def _runtime_capture_summary(runtime_capture: Optional[Mapping[str, Any]], geometry: Mapping[str, Any]) -> Dict[str, Any]:
    provided = isinstance(runtime_capture, Mapping)
    proof_class = runtime_capture.get("proof_class") if provided else None
    binding_digest = runtime_capture.get("capture_binding_digest") if provided else None
    checks = runtime_capture.get("checks") if provided and isinstance(runtime_capture.get("checks"), Mapping) else {}
    geometry_match = bool(provided and runtime_capture.get("geometry_snapshot_digest") == geometry.get("geometry_snapshot_digest"))
    scenario_match = bool(provided and runtime_capture.get("scenario_id") == geometry.get("scenario_id"))
    all_f126_checks = bool(checks) and all(value is True for value in checks.values())
    capture_authority = runtime_capture.get("authority") if provided and isinstance(runtime_capture.get("authority"), Mapping) else {}
    exact = bool(
        provided
        and runtime_capture.get("schema_version") == "runtime-geometry-capture-binding-v1"
        and proof_class == "EXACT"
        and capture_authority.get("adapter_observation_provenance_bound") is True
        and geometry_match
        and scenario_match
        and all_f126_checks
    )
    return {
        "provided": provided,
        "proof_class": proof_class,
        "capture_binding_digest": binding_digest,
        "geometry_snapshot_match": geometry_match,
        "scenario_match": scenario_match,
        "compatible_exact_binding": exact,
    }

def build_targeted_geometric_impact(
    ui_reference: Mapping[str, Any],
    angular_ownership: Mapping[str, Any],
    shared_graph: Mapping[str, Any],
    query: Optional[Mapping[str, Any]] = None,
    *,
    focus_ui_ids: Optional[Sequence[str]] = None,
    proximity_px: Optional[float] = None,
    runtime_capture: Optional[Mapping[str, Any]] = None,
) -> Dict[str, Any]:
    """Build targeted geometric evidence and recoverable topology projection."""
    geometry = ui_reference.get("geometry")
    correspondence = ui_reference.get("correspondence")
    if not isinstance(geometry, Mapping) or not isinstance(correspondence, Mapping):
        raise GeometricImpactError("ui_reference must contain F125 geometry and correspondence")
    normalized_query = normalize_geometric_impact_query(
        query,
        focus_ui_ids=focus_ui_ids,
        proximity_px=proximity_px,
    )
    node_list = [row for row in geometry.get("nodes", []) if isinstance(row, Mapping)]
    nodes = {str(row.get("ui_id")): row for row in node_list if isinstance(row.get("ui_id"), str)}
    viewport = geometry.get("scenario", {}).get("viewport") if isinstance(geometry.get("scenario"), Mapping) else None
    if not isinstance(viewport, Mapping):
        raise GeometricImpactError("ui_reference geometry scenario viewport is missing")

    requested_focus = list(normalized_query["focus_ui_ids"])
    missing_focus = sorted(ui_id for ui_id in requested_focus if ui_id not in nodes)
    focus = [ui_id for ui_id in requested_focus if ui_id in nodes]

    focus_facts: List[Dict[str, Any]] = []
    for ui_id in focus:
        node = nodes[ui_id]
        focus_facts.append({
            "ui_id": ui_id,
            "viewport": _viewport_evidence(node, viewport),
            "parent": _parent_evidence(node, nodes),
            "visible": node.get("geometry", {}).get("visible"),
            "z_index": node.get("geometry", {}).get("z_index"),
        })

    pair_relations: List[Dict[str, Any]] = []
    pair_candidates = pair_total = 0
    proximity = float(normalized_query["proximity_px"])
    seen_pairs: set[Tuple[str, str]] = set()
    for subject_id in focus:
        subject = nodes[subject_id]
        for other_id in sorted(nodes):
            if other_id == subject_id:
                continue
            key = tuple(sorted((subject_id, other_id)))
            if key in seen_pairs:
                continue
            seen_pairs.add(key)
            # Ancestor/descendant box overlap is normal containment evidence, not
            # a useful peer-overlap candidate. Explicit no_overlap/min_gap
            # constraints can still evaluate such a pair when the caller asks.
            if _is_ancestor(subject_id, other_id, nodes) or _is_ancestor(other_id, subject_id, nodes):
                continue
            pair_total += 1
            relation = _rectangle_relation(subject, nodes[other_id])
            if relation.get("proof_class") != "EXACT":
                continue
            if not relation.get("overlap") and float(relation.get("edge_gap_px", math.inf)) > proximity:
                continue
            pair_candidates += 1
            if len(pair_relations) >= MAX_PAIR_RELATIONS:
                continue
            pair_relations.append({
                "subject_ui_id": subject_id,
                "other_ui_id": other_id,
                "relation": relation,
            })

    constraint_results = [
        _constraint_result(constraint, nodes, viewport)
        for constraint in normalized_query["constraints"]
    ]
    violated = [row for row in constraint_results if row["status"] == "VIOLATED"]
    unresolved_constraints = [row for row in constraint_results if row["status"] == "UNRESOLVED"]

    selected: List[str] = []
    def select(ui_id: Any) -> None:
        if isinstance(ui_id, str) and ui_id in nodes and ui_id not in selected:
            selected.append(ui_id)
    for ui_id in focus:
        select(ui_id)
    for row in constraint_results:
        select(row.get("subject_ui_id"))
        select(row.get("other_ui_id"))
        evidence = row.get("evidence")
        if isinstance(evidence, Mapping):
            select(evidence.get("parent_ui_id"))
    for row in pair_relations:
        if row.get("relation", {}).get("overlap"):
            select(row.get("subject_ui_id"))
            select(row.get("other_ui_id"))

    projection = _topology_projection(selected, correspondence, angular_ownership, shared_graph)
    runtime_summary = _runtime_capture_summary(runtime_capture, geometry)
    result = {
        "schema_version": SCHEMA_VERSION,
        "scenario_id": geometry.get("scenario_id"),
        "geometry_snapshot_digest": geometry.get("geometry_snapshot_digest"),
        "reference_state_digest": ui_reference.get("reference_state_digest"),
        "runtime_capture": runtime_summary,
        "query": normalized_query,
        "selection": {
            "requested_focus_ui_ids": requested_focus,
            "resolved_focus_ui_ids": focus,
            "missing_focus_ui_ids": missing_focus,
            "selected_ui_ids": selected,
            "total_geometry_nodes": len(nodes),
            "omitted_geometry_nodes": max(0, len(nodes) - len(selected)),
            "omission_reason": "targeted focus/constraint projection; omission is not irrelevance",
            "recover": "add another --focus UI_ID or declare an explicit constraint; omit focus only if no pairwise scan is needed",
        },
        "geometric_evidence": {
            "focus_facts": focus_facts,
            "pair_relations": pair_relations,
            "pair_scan": {
                "pairs_examined": pair_total,
                "pairs_matching_overlap_or_proximity": pair_candidates,
                "relations_returned": len(pair_relations),
                "omitted_matching_relations": max(0, pair_candidates - len(pair_relations)),
                "proximity_px": proximity,
                "bounded_limit": MAX_PAIR_RELATIONS,
            },
            "constraints": constraint_results,
            "summary": {
                "constraint_count": len(constraint_results),
                "satisfied_count": sum(1 for row in constraint_results if row["status"] == "SATISFIED"),
                "violated_count": len(violated),
                "unresolved_count": len(unresolved_constraints),
                "overlap_relation_count": sum(1 for row in pair_relations if row.get("relation", {}).get("overlap")),
            },
        },
        "impact_projection": projection,
        "authority": {
            "geometric_fact_authority": "F125 normalized GeometrySnapshot",
            "constraint_intent_authority": "explicit F127 query only",
            "static_owner_authority": "F124 AngularOwnership",
            "topology_authority": "core.shared_graph",
            "runtime_capture_provenance_bound": runtime_summary["compatible_exact_binding"],
            "global_layout_correctness_proven": False,
            "behavior_proven": False,
            "postcondition_proven": False,
            "mutation_authority": False,
            "runtime_executed_by_query": False,
            "truth_committed": False,
        },
        "proof_boundary": {
            "overlap_fact_is_visual_bug": False,
            "constraint_violation_is_behavior_failure": False,
            "topology_projection_is_geometric_effect_proof": False,
            "omitted_surface_is_irrelevant": False,
            "structural_correspondence_is_runtime_instance_proof": False,
            "runtime_capture_exact_is_truthful_pixels": False,
        },
    }
    result["geometric_impact_digest"] = _digest({
        "scenario_id": result["scenario_id"],
        "geometry_snapshot_digest": result["geometry_snapshot_digest"],
        "reference_state_digest": result["reference_state_digest"],
        "runtime_capture": result["runtime_capture"],
        "query": normalized_query,
        "geometric_evidence": result["geometric_evidence"],
        "impact_projection": projection,
    })
    return result


__all__ = [
    "SCHEMA_VERSION",
    "QUERY_SCHEMA_VERSION",
    "MAX_QUERY_BYTES",
    "MAX_FOCUS_UI_IDS",
    "MAX_CONSTRAINTS",
    "MAX_PAIR_RELATIONS",
    "GeometricImpactError",
    "load_geometric_impact_query",
    "normalize_geometric_impact_query",
    "build_targeted_geometric_impact",
]
