"""Neutral durable coordination store for validation-execution checkpoints.

Owns SQLite location/opening and additive feature metadata only. Workflow
semantics stay in F134/F135/F136/F137 modules.
"""
from __future__ import annotations

import os
import sqlite3
from pathlib import Path
from typing import Any, Dict, Iterable

from core.capability_contracts import safe_canonical_digest
from core.context_accountability import DEFAULT_ACCOUNTABILITY_DIR

DATABASE_FILENAME = "validation_execution_leases.sqlite3"
BASE_SCHEMA_VERSION = 1
FEATURE_TABLE = "validation_execution_store_features"


class ValidationExecutionStoreError(ValueError):
    pass


def validation_store_path(store_dir: str | os.PathLike[str] | None) -> Path:
    base = Path(store_dir or os.environ.get("PLW_ACCOUNTABILITY_DIR") or DEFAULT_ACCOUNTABILITY_DIR)
    return base.expanduser().resolve() / DATABASE_FILENAME


def open_validation_store(store_dir, *, writable: bool, create: bool = False, allow_uninitialized: bool = False) -> sqlite3.Connection:
    path = validation_store_path(store_dir)
    if path.is_symlink():
        raise ValidationExecutionStoreError("validation execution database must not be a symbolic link")
    if create:
        path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        try:
            os.chmod(path.parent, 0o700)
        except OSError:
            pass
        conn = sqlite3.connect(str(path), timeout=5.0, isolation_level=None)
    else:
        if not path.is_file():
            raise FileNotFoundError("validation execution database is unavailable")
        mode = "rw" if writable else "ro"
        conn = sqlite3.connect(path.as_uri() + f"?mode={mode}", uri=True, timeout=5.0, isolation_level=None)
    conn.row_factory = sqlite3.Row
    try:
        conn.execute("PRAGMA busy_timeout=5000")
        conn.execute("PRAGMA foreign_keys=ON")
        if writable:
            conn.execute("PRAGMA synchronous=FULL")
        version = int(conn.execute("PRAGMA user_version").fetchone()[0])
        allowed = {BASE_SCHEMA_VERSION}
        if allow_uninitialized:
            allowed.add(0)
        if version not in allowed:
            raise ValidationExecutionStoreError("unsupported validation execution base schema")
        return conn
    except Exception:
        conn.close()
        raise


def bounded_validation_digest(value: Any, *, max_bytes: int = 65536) -> str | None:
    try:
        return safe_canonical_digest(value, max_bytes=max_bytes)
    except (TypeError, ValueError, RecursionError):
        return None


def validation_table_exists(connection: sqlite3.Connection, table_name: str) -> bool:
    return connection.execute(
        "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table_name,)
    ).fetchone() is not None


def load_validation_feature_row(connection: sqlite3.Connection, *, table_name: str, select_columns: Iterable[str], key_column: str, key_value: str):
    if not validation_table_exists(connection, table_name):
        return None
    cols = ", ".join(select_columns)
    return connection.execute(
        f"SELECT {cols} FROM {table_name} WHERE {key_column} = ?", (key_value,)
    ).fetchone()


def ensure_feature_registry(connection: sqlite3.Connection) -> None:
    connection.execute(f"""CREATE TABLE IF NOT EXISTS {FEATURE_TABLE} (
        feature TEXT PRIMARY KEY NOT NULL,
        version INTEGER NOT NULL,
        table_name TEXT NOT NULL UNIQUE
    )""")


def register_store_feature(connection: sqlite3.Connection, feature: str, version: int, table_name: str) -> None:
    if not feature or type(version) is not int or version < 1 or not table_name:
        raise ValidationExecutionStoreError("invalid validation store feature")
    ensure_feature_registry(connection)
    connection.execute(
        f"INSERT OR IGNORE INTO {FEATURE_TABLE} (feature, version, table_name) VALUES (?, ?, ?)",
        (feature, version, table_name),
    )
    row = connection.execute(
        f"SELECT feature, version, table_name FROM {FEATURE_TABLE} WHERE feature = ?", (feature,)
    ).fetchone()
    if row is None or row["version"] != version or row["table_name"] != table_name:
        raise ValidationExecutionStoreError("validation store feature registry drift")


def read_store_features(connection: sqlite3.Connection) -> Dict[str, dict]:
    if not validation_table_exists(connection, FEATURE_TABLE):
        return {}
    result: Dict[str, dict] = {}
    for row in connection.execute(
        f"SELECT feature, version, table_name FROM {FEATURE_TABLE} ORDER BY feature"
    ).fetchall():
        result[row["feature"]] = {"version": int(row["version"]), "table_name": str(row["table_name"])}
    return result


__all__ = [
    "DATABASE_FILENAME", "BASE_SCHEMA_VERSION", "FEATURE_TABLE",
    "ValidationExecutionStoreError", "validation_store_path", "open_validation_store",
    "bounded_validation_digest", "validation_table_exists", "load_validation_feature_row",
    "ensure_feature_registry", "register_store_feature", "read_store_features",
]
