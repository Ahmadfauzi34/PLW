"""F132 proof-obligation evidence request and validation execution handoff.

This module turns *semantically re-derived* F131 coverage gaps into bounded,
typed validator work requests.  A request is handoff metadata only: it selects
an exact F128 scenario, validator identity, executor identity, obligation set,
and expected F129 observation contract, but it grants no authorization, lease,
dispatch, runtime execution, postcondition, or truth authority.

The input coverage artifact is intentionally not accepted as authority.  F132
reprojects F129 + proof obligations internally through F131 every time.
"""
from __future__ import annotations

import re
from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple

from core.capability_contracts import is_sha256_id
from fullstack.proof_obligations import (
    ProofObligationError,
    normalize_proof_obligation_set,
    project_validation_proof_obligations,
    verify_validation_proof_coverage,
)
from fullstack.reference_digest import canonical_reference_digest
from fullstack.validation_evidence import (
    VALIDATION_OBSERVATION_KIND,
    VALIDATION_OBSERVATION_SCHEMA_VERSION,
    ValidationEvidenceError,
    verify_validation_evidence_binding,
)
from fullstack.validation_scenarios import (
    SCHEMA_VERSION as VALIDATION_PLAN_SCHEMA_VERSION,
    validation_plan_digest,
)

SCHEMA_VERSION = "validation-execution-request-set-v1"
REQUEST_SCHEMA_VERSION = "validation-execution-request-v1"
HANDOFF_SCHEMA_VERSION = "validation-execution-handoff-v1"
REQUEST_DIGEST_POLICY = "validation-execution-request-full-artifact-v1"
REQUEST_SET_DIGEST_POLICY = "validation-execution-request-set-full-artifact-v1"
MAX_EXECUTION_REQUESTS = 4096
MAX_TEXT = 2048
_TARGET_ID = re.compile(r"[A-Za-z0-9][A-Za-z0-9._:/-]{2,127}\Z")


class ValidationExecutionError(ValueError):
    """Raised when F132 request/handoff derivation violates its contract."""


def _target_id(value: Any, field: str) -> str:
    if not isinstance(value, str):
        raise ValidationExecutionError(f"{field} must be a string")
    result = value.strip()
    if len(result) > MAX_TEXT or _TARGET_ID.fullmatch(result) is None:
        raise ValidationExecutionError(f"{field} has invalid executor/validator identity syntax")
    return result


def _verify_plan(plan: Mapping[str, Any]) -> Tuple[str, Dict[str, Mapping[str, Any]]]:
    if not isinstance(plan, Mapping) or plan.get("schema_version") != VALIDATION_PLAN_SCHEMA_VERSION:
        raise ValidationExecutionError("validation plan must be an F128 validation-scenario-plan-v1 result")
    claimed = plan.get("validation_plan_digest")
    if not is_sha256_id(claimed):
        raise ValidationExecutionError("validation plan digest is missing or invalid")
    if validation_plan_digest(plan) != claimed:
        raise ValidationExecutionError("validation plan digest does not match plan contents")
    selected = plan.get("selected_scenarios")
    if not isinstance(selected, list):
        raise ValidationExecutionError("validation plan selected_scenarios must be an array")
    by_id: Dict[str, Mapping[str, Any]] = {}
    for index, row in enumerate(selected):
        if not isinstance(row, Mapping) or not is_sha256_id(row.get("scenario_id")):
            raise ValidationExecutionError(f"selected_scenarios[{index}] has invalid scenario_id")
        scenario_id = str(row["scenario_id"])
        if scenario_id in by_id:
            raise ValidationExecutionError(f"validation plan has duplicate selected scenario_id: {scenario_id}")
        if not isinstance(row.get("scenario"), Mapping):
            raise ValidationExecutionError(f"selected_scenarios[{index}].scenario must be an object")
        by_id[scenario_id] = row
    return str(claimed), by_id


def validation_execution_request_digest(request: Mapping[str, Any]) -> str:
    if not isinstance(request, Mapping):
        raise ValidationExecutionError("validation execution request must be an object")
    core = dict(request)
    core.pop("request_id", None)
    # handoff contains fields deterministically derived from request_id and the
    # already-bound executor/validator identities; exclude it to avoid a
    # circular digest dependency.
    core.pop("handoff", None)
    try:
        return canonical_reference_digest({
            "artifact_type": REQUEST_SCHEMA_VERSION,
            "digest_policy": REQUEST_DIGEST_POLICY,
            "artifact": core,
        })
    except (TypeError, ValueError) as exc:
        raise ValidationExecutionError("validation execution request is not canonical JSON") from exc


def validation_execution_request_set_digest(request_set: Mapping[str, Any]) -> str:
    if not isinstance(request_set, Mapping):
        raise ValidationExecutionError("validation execution request set must be an object")
    core = dict(request_set)
    core.pop("validation_execution_request_set_digest", None)
    try:
        return canonical_reference_digest({
            "artifact_type": SCHEMA_VERSION,
            "digest_policy": REQUEST_SET_DIGEST_POLICY,
            "artifact": core,
        })
    except (TypeError, ValueError) as exc:
        raise ValidationExecutionError("validation execution request set is not canonical JSON") from exc


def _unit_key(row: Mapping[str, Any]) -> Tuple[str, str, str]:
    scenario_id = str(row["scenario_id"])
    if row.get("witness_scope") == "SAME_OBSERVATION":
        return scenario_id, "GROUP", str(row.get("witness_group_id"))
    return scenario_id, "OBLIGATION", str(row["obligation_id"])


def _action_class(rows: Sequence[Mapping[str, Any]]) -> str:
    statuses = {str(row.get("coverage_status")) for row in rows}
    if "CONFLICTING" in statuses:
        return "ADJUDICATE_CONFLICT"
    if any(row.get("witness_scope") == "SAME_OBSERVATION" for row in rows):
        return "COLLECT_CORRELATED_OBSERVATION"
    return "COLLECT_EXACT_SCENARIO_OBSERVATION"


def _requested_surface(selected: Mapping[str, Any]) -> Dict[str, List[str]]:
    raw = selected.get("requested_validation")
    source = raw if isinstance(raw, Mapping) else {}
    return {
        "ui_ids_if_present": sorted({str(v) for v in source.get("ui_ids_if_present", []) if isinstance(v, str)}),
        "component_ids": sorted({str(v) for v in source.get("component_ids", []) if isinstance(v, str)}),
        "component_files": sorted({str(v) for v in source.get("component_files", []) if isinstance(v, str)}),
        "constraint_ids_if_applicable": sorted({
            str(v) for v in source.get("constraint_ids_if_applicable", []) if isinstance(v, str)
        }),
    }


def _build_request(
    rows: Sequence[Mapping[str, Any]],
    selected: Mapping[str, Any],
    *,
    validator_id: str,
    executor_id: str,
    validation_plan_digest_value: str,
    binding_digest: str,
    obligation_set_digest: str,
    coverage_digest: str,
) -> Dict[str, Any]:
    scenario_id = str(rows[0]["scenario_id"])
    obligation_rows = []
    observation_ids: set[str] = set()
    requested_check_ids: set[str] = set()
    requires_receipt = False
    requires_content_bound = False
    for row in rows:
        check_id = row.get("check_id")
        if isinstance(check_id, str):
            requested_check_ids.add(check_id)
        observation_ids.update(str(v) for v in row.get("observation_ids", []) if is_sha256_id(v))
        requirement = str(row["requirement"])
        requires_receipt = requires_receipt or requirement in {
            "F123_RECEIPT_VERIFIED", "F123_PROVENANCE_VERIFIED"
        }
        requires_content_bound = requires_content_bound or requirement == "F123_PROVENANCE_VERIFIED"
        obligation_rows.append({
            "obligation_id": row["obligation_id"],
            "requirement": requirement,
            "check_id": check_id,
            "current_status": row["coverage_status"],
            "individual_coverage_status": row.get("individual_coverage_status"),
            "witness_scope": row["witness_scope"],
            "witness_group_id": row.get("witness_group_id"),
            "reason": row["reason"],
        })
    obligation_rows.sort(key=lambda item: str(item["obligation_id"]))
    request: Dict[str, Any] = {
        "schema_version": REQUEST_SCHEMA_VERSION,
        "request_digest_policy": REQUEST_DIGEST_POLICY,
        "validation_plan_digest": validation_plan_digest_value,
        "validation_evidence_binding_digest": binding_digest,
        "proof_obligation_set_digest": obligation_set_digest,
        "proof_obligation_coverage_digest": coverage_digest,
        "scenario_id": scenario_id,
        "scenario": dict(selected["scenario"]),
        "validator_id": validator_id,
        "executor_id": executor_id,
        "action_class": _action_class(rows),
        "obligations": obligation_rows,
        "requested_validation": _requested_surface(selected),
        "requested_check_ids": sorted(requested_check_ids),
        "existing_observation_ids": sorted(observation_ids),
        "expected_result_contract": {
            "schema_version": VALIDATION_OBSERVATION_SCHEMA_VERSION,
            "observation_kind": VALIDATION_OBSERVATION_KIND,
            "scenario_id_must_equal_request": True,
            "validator_id_must_equal_request": True,
            "same_observation_group_must_return_one_correlated_observation": any(
                row.get("witness_scope") == "SAME_OBSERVATION" for row in rows
            ),
            "F123_receipt_required": requires_receipt,
            "F123_content_bound_provenance_required": requires_content_bound,
        },
        "execution_state": "REQUESTED",
        "authority": {
            "work_requested": True,
            "validator_selected": True,
            "executor_selected": True,
            "authorization_granted": False,
            "execution_lease_acquired": False,
            "adapter_dispatch_prepared": False,
            "runtime_dispatched": False,
            "validator_executed": False,
            "evidence_returned": False,
            "postcondition_proven": False,
            "truth_committed": False,
        },
    }
    request_id = validation_execution_request_digest(request)
    request["request_id"] = request_id
    request["handoff"] = {
        "schema_version": HANDOFF_SCHEMA_VERSION,
        "request_id": request_id,
        "executor_id": executor_id,
        "validator_id": validator_id,
        "operation_key": "validation:" + request_id.split(":", 1)[1][:48],
        "required_authority_chain": ["F116", "F117", "F118", "F119", "F121", "F122", "F123"],
        "authorization_binding_present": False,
        "lease_binding_present": False,
        "attempt_binding_present": False,
        "dispatch_binding_present": False,
        "may_dispatch": False,
        "recover": "bind this exact request_id through an authorized execution path before dispatch; return canonical F129 evidence afterward",
    }
    return request


def build_validation_execution_requests(
    plan: Mapping[str, Any],
    binding: Mapping[str, Any],
    obligation_set: Mapping[str, Any],
    *,
    validator_id: str,
    executor_id: str,
) -> Dict[str, Any]:
    """Re-derive F131 coverage and emit bounded F132 work requests.

    No supplied coverage artifact is consumed.  This function is pure/read-only.
    """
    validator = _target_id(validator_id, "validator_id")
    executor = _target_id(executor_id, "executor_id")
    plan_digest, selected_by_id = _verify_plan(plan)
    try:
        verify_validation_evidence_binding(binding)
    except ValidationEvidenceError as exc:
        raise ValidationExecutionError(f"F129 validation evidence binding rejected: {exc}") from exc
    if binding.get("validation_plan_digest") != plan_digest:
        raise ValidationExecutionError("F129 binding validation_plan_digest does not match F128 plan")
    try:
        normalized_obligations = normalize_proof_obligation_set(
            obligation_set, validation_plan_digest=plan_digest,
        )
        coverage = project_validation_proof_obligations(binding, obligation_set)
        verify_validation_proof_coverage(
            coverage, binding=binding, obligation_set=obligation_set,
        )
    except ProofObligationError as exc:
        raise ValidationExecutionError(f"F131 proof coverage rejected: {exc}") from exc

    unresolved = [
        row for row in coverage["obligation_results"]
        if row.get("coverage_status") != "COVERED"
    ]
    grouped: Dict[Tuple[str, str, str], List[Mapping[str, Any]]] = {}
    for row in unresolved:
        grouped.setdefault(_unit_key(row), []).append(row)
    if len(grouped) > MAX_EXECUTION_REQUESTS:
        raise ValidationExecutionError(
            f"execution requests exceeds {MAX_EXECUTION_REQUESTS}; narrow proof obligations"
        )

    requests: List[Dict[str, Any]] = []
    for key in sorted(grouped):
        rows = sorted(grouped[key], key=lambda item: str(item["obligation_id"]))
        scenario_id = str(rows[0]["scenario_id"])
        selected = selected_by_id.get(scenario_id)
        if selected is None:
            raise ValidationExecutionError(
                f"coverage references scenario not selected by F128 plan: {scenario_id}"
            )
        requests.append(_build_request(
            rows,
            selected,
            validator_id=validator,
            executor_id=executor,
            validation_plan_digest_value=plan_digest,
            binding_digest=str(binding["validation_evidence_binding_digest"]),
            obligation_set_digest=str(normalized_obligations["proof_obligation_set_digest"]),
            coverage_digest=str(coverage["proof_obligation_coverage_digest"]),
        ))

    result: Dict[str, Any] = {
        "schema_version": SCHEMA_VERSION,
        "request_set_digest_policy": REQUEST_SET_DIGEST_POLICY,
        "validation_plan_digest": plan_digest,
        "validation_evidence_binding_digest": binding["validation_evidence_binding_digest"],
        "proof_obligation_set_digest": normalized_obligations["proof_obligation_set_digest"],
        "proof_obligation_coverage_digest": coverage["proof_obligation_coverage_digest"],
        "validator_id": validator,
        "executor_id": executor,
        "execution_requests": requests,
        "summary": {
            "obligation_count": coverage["summary"]["obligation_count"],
            "covered_obligation_count": coverage["summary"]["covered_count"],
            "unresolved_obligation_count": len(unresolved),
            "execution_request_count": len(requests),
            "no_request_needed": len(requests) == 0,
        },
        "authority": {
            "F128_plan_identity_verified": True,
            "F129_binding_semantics_verified": True,
            "F131_coverage_rederived_internally": True,
            "supplied_coverage_artifact_trusted": False,
            "request_generation_is_authorization": False,
            "authorization_granted": False,
            "execution_lease_acquired": False,
            "adapter_dispatch_prepared": False,
            "runtime_dispatched": False,
            "validator_executed": False,
            "source_mutated": False,
            "postcondition_proven": False,
            "truth_committed": False,
        },
        "proof_boundary": {
            "request_is_authorization": False,
            "request_is_execution_lease": False,
            "request_is_adapter_dispatch": False,
            "request_is_validator_result": False,
            "returned_validator_PASS_is_postcondition_proof": False,
            "complete_future_coverage_is_truth": False,
            "executor_identity_is_permission": False,
        },
        "recovery": {
            "authorize": "bind the exact request_id through explicit execution authorization before dispatch",
            "dispatch": "bind authorization/lease/attempt/dispatch receipts to the exact request identity; never infer dispatch from this artifact",
            "return_evidence": "return bounded scenario-validation-evidence-bundle-v1 observations and re-run F129-F132",
            "no_requests": "all current obligations are covered; this still does not prove postcondition or truth",
        },
    }
    result["validation_execution_request_set_digest"] = validation_execution_request_set_digest(result)
    return result


def verify_validation_execution_requests(
    request_set: Mapping[str, Any],
    *,
    plan: Mapping[str, Any],
    binding: Mapping[str, Any],
    obligation_set: Mapping[str, Any],
    validator_id: str,
    executor_id: str,
) -> bool:
    """Semantically re-derive F132 requests and require exact request-set identity."""
    if not isinstance(request_set, Mapping) or request_set.get("schema_version") != SCHEMA_VERSION:
        raise ValidationExecutionError(f"request set must use {SCHEMA_VERSION}")
    if request_set.get("request_set_digest_policy") != REQUEST_SET_DIGEST_POLICY:
        raise ValidationExecutionError("request-set digest policy is missing or unsupported")
    claimed = request_set.get("validation_execution_request_set_digest")
    if not is_sha256_id(claimed):
        raise ValidationExecutionError("request-set digest is missing or invalid")
    if validation_execution_request_set_digest(request_set) != claimed:
        raise ValidationExecutionError("request-set digest does not match contents")
    expected = build_validation_execution_requests(
        plan,
        binding,
        obligation_set,
        validator_id=validator_id,
        executor_id=executor_id,
    )
    if expected["validation_execution_request_set_digest"] != claimed:
        raise ValidationExecutionError(
            "request set is checksum-valid but does not match semantic F132 derivation"
        )
    return True


__all__ = [
    "SCHEMA_VERSION",
    "REQUEST_SCHEMA_VERSION",
    "HANDOFF_SCHEMA_VERSION",
    "REQUEST_DIGEST_POLICY",
    "REQUEST_SET_DIGEST_POLICY",
    "MAX_EXECUTION_REQUESTS",
    "ValidationExecutionError",
    "validation_execution_request_digest",
    "validation_execution_request_set_digest",
    "build_validation_execution_requests",
    "verify_validation_execution_requests",
]
