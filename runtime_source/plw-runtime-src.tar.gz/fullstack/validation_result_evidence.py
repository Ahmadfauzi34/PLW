"""F138 validation-result evidence acceptance over resolved F137 runtime state.

F138 never runs a validator. It takes one exact F137 runtime observation plus the
raw canonical ``validation.result`` payload returned by the host and proves that
its digest, request/scenario/validator lineage, and evidence identifiers match the
durable execution chain. Only an F137 ``SUCCEEDED`` runtime terminal can become
accepted validation-result evidence; FAILED/INDETERMINATE runtime terminals stay
UNRESOLVED and are never reinterpreted as validator FAIL.
"""
from __future__ import annotations

import json
import sqlite3
import time
from collections.abc import Mapping, Sequence
from pathlib import Path
from typing import Any

from core.accountability_provenance import seal_payload, verify_payload
from core.capability_contracts import exact_keys, is_sha256_id
from fullstack import validation_dispatch as dispatch_store
from fullstack import validation_execution as execution_contract
from fullstack import validation_execution_store as execution_store
from fullstack import validation_runtime as runtime_store
from fullstack.validation_evidence import (
    VALIDATION_OBSERVATION_KIND,
    VALIDATION_OBSERVATION_SCHEMA_VERSION,
    ValidationEvidenceError,
    build_validation_observation_payload,
)

SCHEMA_VERSION = "validation-result-evidence-acceptance-v1"
POLICY_VERSION = "exact-f137-runtime-result-evidence-acceptance-v1"
RECEIPT_SCHEMA_VERSION = "validation-result-evidence-acceptance-receipt-v1"
RECEIPT_ISSUER = "plw.fullstack.validation-result-evidence-acceptance.v1"
TABLE_NAME = "validation_result_evidence_acceptance_v1"
MAX_RESULT_BYTES = 65_536
MAX_REQUEST_SET_BYTES = 1_048_576
VALIDATION_OUTCOMES = frozenset({"PASS", "FAIL", "INDETERMINATE"})

_ROW_KEYS = (
    "acceptance_id", "runtime_observation_id", "handoff_id", "dispatch_intent_id",
    "attempt_id", "lease_id", "request_id", "request_set_digest", "scenario_id",
    "validator_id", "executor_id", "operation_key", "runtime_terminal_status",
    "runtime_observation_digest", "validation_plan_digest", "validation_result_digest",
    "validation_outcome", "evidence_ids_digest", "accepted_at_epoch",
)
_BODY_KEYS = (frozenset(_ROW_KEYS) - {"acceptance_id"}) | {
    "schema_version", "policy", "acceptance_state", "evidence_ids",
    "authority_class", "scope",
}
_RECEIPT_KEYS = _BODY_KEYS | {"acceptance_id", "provenance"}
_REQUEST_SET_KEYS = frozenset({
    "schema_version", "request_set_digest_policy", "validation_plan_digest",
    "validation_evidence_binding_digest", "proof_obligation_set_digest",
    "proof_obligation_coverage_digest", "validator_id", "executor_id",
    "execution_requests", "summary", "authority", "proof_boundary", "recovery",
    "validation_execution_request_set_digest",
})
_RESULT_KEYS = frozenset({
    "schema_version", "validation_plan_digest", "scenario_id", "validator_id",
    "validator_run_ref", "outcome", "checks", "evidence_ids",
})


class ValidationResultEvidenceError(ValueError):
    """F138 structural, lineage, digest, or durable acceptance error."""


def _open(store_dir, *, writable: bool) -> sqlite3.Connection:
    try:
        return execution_store.open_validation_store(store_dir, writable=writable, create=False)
    except (execution_store.ValidationExecutionStoreError, FileNotFoundError) as exc:
        raise ValidationResultEvidenceError("validation_execution_store_unavailable") from exc


def load_validation_result_payload(path: str, *, max_bytes: int = MAX_RESULT_BYTES) -> dict:
    target = Path(path)
    try:
        raw = target.read_bytes()
    except OSError as exc:
        raise ValidationResultEvidenceError("validation_result_unavailable:" + type(exc).__name__) from exc
    if len(raw) > max_bytes:
        raise ValidationResultEvidenceError("validation_result_too_large")
    try:
        value = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValidationResultEvidenceError("validation_result_not_bounded_utf8_json") from exc
    if not isinstance(value, dict):
        raise ValidationResultEvidenceError("validation_result_root_must_be_object")
    return value


def load_validation_execution_request_set(path: str, *, max_bytes: int = MAX_REQUEST_SET_BYTES) -> dict:
    target = Path(path)
    try:
        raw = target.read_bytes()
    except OSError as exc:
        raise ValidationResultEvidenceError("validation_request_set_unavailable:" + type(exc).__name__) from exc
    if len(raw) > max_bytes:
        raise ValidationResultEvidenceError("validation_request_set_too_large")
    try:
        value = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValidationResultEvidenceError("validation_request_set_not_bounded_utf8_json") from exc
    if not isinstance(value, dict):
        raise ValidationResultEvidenceError("validation_request_set_root_must_be_object")
    return value


def _canonical_result(payload: Mapping[str, Any]) -> dict:
    if not exact_keys(payload, _RESULT_KEYS):
        raise ValidationResultEvidenceError("validation_result_exact_schema")
    if payload.get("schema_version") != VALIDATION_OBSERVATION_SCHEMA_VERSION:
        raise ValidationResultEvidenceError("validation_result_schema_version")
    plan_digest = payload.get("validation_plan_digest")
    if not is_sha256_id(plan_digest):
        raise ValidationResultEvidenceError("validation_result_plan_digest")
    raw_observation = {
        "scenario_id": payload.get("scenario_id"),
        "validator_id": payload.get("validator_id"),
        "validator_run_ref": payload.get("validator_run_ref"),
        "outcome": payload.get("outcome"),
        "checks": payload.get("checks"),
        "evidence_ids": payload.get("evidence_ids"),
    }
    try:
        normalized = build_validation_observation_payload(str(plan_digest), raw_observation)
    except ValidationEvidenceError as exc:
        raise ValidationResultEvidenceError("validation_result_contract:" + str(exc)) from exc
    if normalized != dict(payload):
        raise ValidationResultEvidenceError("validation_result_not_canonical")
    if normalized["outcome"] not in VALIDATION_OUTCOMES:
        raise ValidationResultEvidenceError("validation_result_outcome")
    return normalized


def _runtime_observation(connection: sqlite3.Connection, observation_id: str, store_dir) -> dict:
    try:
        return runtime_store.load_validation_runtime_observation_receipt(
            connection, observation_id, store_dir=store_dir,
        )
    except runtime_store.ValidationRuntimeError as exc:
        raise ValidationResultEvidenceError(str(exc)) from exc


def _dispatch_parent(connection: sqlite3.Connection, observation: Mapping[str, Any], store_dir) -> dict:
    try:
        return dispatch_store.load_validation_dispatch_intent_receipt(
            connection, str(observation["dispatch_intent_id"]), store_dir=store_dir,
        )
    except dispatch_store.ValidationDispatchError as exc:
        raise ValidationResultEvidenceError(str(exc)) from exc


def _verify_request_set(request_set: Mapping[str, Any], parent: Mapping[str, Any]) -> dict:
    if not exact_keys(request_set, _REQUEST_SET_KEYS):
        raise ValidationResultEvidenceError("validation_request_set_exact_schema")
    if request_set.get("schema_version") != execution_contract.SCHEMA_VERSION:
        raise ValidationResultEvidenceError("validation_request_set_schema_version")
    if request_set.get("request_set_digest_policy") != execution_contract.REQUEST_SET_DIGEST_POLICY:
        raise ValidationResultEvidenceError("validation_request_set_digest_policy")
    claimed = request_set.get("validation_execution_request_set_digest")
    if not is_sha256_id(claimed):
        raise ValidationResultEvidenceError("validation_request_set_digest")
    try:
        actual = execution_contract.validation_execution_request_set_digest(request_set)
    except execution_contract.ValidationExecutionError as exc:
        raise ValidationResultEvidenceError("validation_request_set_digest:" + str(exc)) from exc
    if actual != claimed or claimed != parent.get("request_set_digest"):
        raise ValidationResultEvidenceError("validation_request_set_lineage_mismatch")
    if request_set.get("validator_id") != parent.get("validator_id"):
        raise ValidationResultEvidenceError("validation_request_set_validator_mismatch")
    if request_set.get("executor_id") != parent.get("executor_id"):
        raise ValidationResultEvidenceError("validation_request_set_executor_mismatch")
    requests = request_set.get("execution_requests")
    if not isinstance(requests, list):
        raise ValidationResultEvidenceError("validation_execution_requests_array")
    matches = [row for row in requests if isinstance(row, Mapping) and row.get("request_id") == parent.get("request_id")]
    if len(matches) != 1:
        raise ValidationResultEvidenceError("validation_request_identity_not_unique")
    request = dict(matches[0])
    try:
        request_digest = execution_contract.validation_execution_request_digest(request)
    except execution_contract.ValidationExecutionError as exc:
        raise ValidationResultEvidenceError("validation_request_digest:" + str(exc)) from exc
    if request_digest != parent.get("request_id"):
        raise ValidationResultEvidenceError("validation_request_digest_mismatch")
    if request.get("scenario_id") != parent.get("scenario_id"):
        raise ValidationResultEvidenceError("validation_request_scenario_mismatch")
    if request.get("validator_id") != parent.get("validator_id"):
        raise ValidationResultEvidenceError("validation_request_validator_mismatch")
    if request.get("executor_id") != parent.get("executor_id"):
        raise ValidationResultEvidenceError("validation_request_executor_mismatch")
    handoff = request.get("handoff")
    if not isinstance(handoff, Mapping) or handoff.get("operation_key") != parent.get("operation_key"):
        raise ValidationResultEvidenceError("validation_request_operation_mismatch")
    if request.get("validation_plan_digest") != request_set.get("validation_plan_digest"):
        raise ValidationResultEvidenceError("validation_request_plan_digest_mismatch")
    expected = request.get("expected_result_contract")
    if not isinstance(expected, Mapping):
        raise ValidationResultEvidenceError("validation_expected_result_contract")
    if (
        expected.get("schema_version") != VALIDATION_OBSERVATION_SCHEMA_VERSION
        or expected.get("observation_kind") != VALIDATION_OBSERVATION_KIND
    ):
        raise ValidationResultEvidenceError("validation_expected_result_contract_mismatch")
    return request


def _evaluate(
    connection: sqlite3.Connection,
    runtime_observation_id: str,
    validation_result: Mapping[str, Any],
    request_set: Mapping[str, Any],
    store_dir,
) -> tuple[str, dict]:
    observation = _runtime_observation(connection, runtime_observation_id, store_dir)
    parent = _dispatch_parent(connection, observation, store_dir)
    payload = _canonical_result(validation_result)
    request = _verify_request_set(request_set, parent)

    lineage = {
        "observation": observation,
        "parent": parent,
        "payload": payload,
        "request": request,
    }
    if observation.get("reconciliation_state") != "RESOLVED" or not observation.get("terminal_status"):
        return "unresolved", {**lineage, "reason": "runtime_observation_not_terminal"}
    if observation.get("terminal_status") != "SUCCEEDED":
        return "unresolved", {**lineage, "reason": "runtime_terminal_not_succeeded"}
    if observation.get("observation_kind") != VALIDATION_OBSERVATION_KIND:
        raise ValidationResultEvidenceError("runtime_observation_kind_is_not_validation_result")

    result_digest = execution_store.bounded_validation_digest(payload, max_bytes=MAX_RESULT_BYTES)
    if result_digest is None:
        raise ValidationResultEvidenceError("validation_result_bounded_digest")
    if result_digest != observation.get("observation_digest"):
        raise ValidationResultEvidenceError("validation_result_runtime_digest_mismatch")
    if payload.get("validation_plan_digest") != request.get("validation_plan_digest"):
        raise ValidationResultEvidenceError("validation_result_plan_lineage_mismatch")
    if payload.get("scenario_id") != parent.get("scenario_id"):
        raise ValidationResultEvidenceError("validation_result_scenario_lineage_mismatch")
    if payload.get("validator_id") != parent.get("validator_id"):
        raise ValidationResultEvidenceError("validation_result_validator_lineage_mismatch")
    payload_evidence = payload.get("evidence_ids")
    if not isinstance(payload_evidence, Sequence) or isinstance(payload_evidence, (str, bytes)):
        raise ValidationResultEvidenceError("validation_result_evidence_ids")
    if sorted(set(payload_evidence)) != list(observation.get("evidence_ids", [])):
        raise ValidationResultEvidenceError("validation_result_evidence_ids_mismatch")
    return "eligible", {**lineage, "validation_result_digest": result_digest}


def _initialize(connection: sqlite3.Connection) -> None:
    connection.execute(f"""CREATE TABLE IF NOT EXISTS {TABLE_NAME} (
        acceptance_id TEXT PRIMARY KEY NOT NULL,
        runtime_observation_id TEXT NOT NULL UNIQUE,
        handoff_id TEXT NOT NULL,
        dispatch_intent_id TEXT NOT NULL,
        attempt_id TEXT NOT NULL,
        lease_id TEXT NOT NULL,
        request_id TEXT NOT NULL,
        request_set_digest TEXT NOT NULL,
        scenario_id TEXT NOT NULL,
        validator_id TEXT NOT NULL,
        executor_id TEXT NOT NULL,
        operation_key TEXT NOT NULL,
        runtime_terminal_status TEXT NOT NULL,
        runtime_observation_digest TEXT NOT NULL,
        validation_plan_digest TEXT NOT NULL,
        validation_result_digest TEXT NOT NULL,
        validation_outcome TEXT NOT NULL,
        evidence_ids_digest TEXT NOT NULL,
        accepted_at_epoch INTEGER NOT NULL,
        receipt_json TEXT NOT NULL,
        FOREIGN KEY(runtime_observation_id) REFERENCES {runtime_store.OBSERVATION_TABLE}(observation_id)
    )""")
    execution_store.register_store_feature(connection, "evidence_acceptance", 1, TABLE_NAME)


def _row(connection: sqlite3.Connection, runtime_observation_id: str):
    return execution_store.load_validation_feature_row(
        connection, table_name=TABLE_NAME, select_columns=(*_ROW_KEYS, "receipt_json"),
        key_column="runtime_observation_id", key_value=runtime_observation_id,
    )


def _verify_receipt(row, observation: Mapping[str, Any], parent: Mapping[str, Any], store_dir) -> dict:
    try:
        receipt = json.loads(row["receipt_json"])
        if not exact_keys(receipt, _RECEIPT_KEYS):
            raise ValidationResultEvidenceError("evidence_acceptance_receipt_schema")
        body = {key: receipt[key] for key in _BODY_KEYS}
        if (
            execution_store.bounded_validation_digest(body, max_bytes=MAX_RESULT_BYTES) != receipt["acceptance_id"]
            or not is_sha256_id(receipt["acceptance_id"])
            or not verify_payload(body, receipt["provenance"], RECEIPT_ISSUER, store_dir=store_dir)
        ):
            raise ValidationResultEvidenceError("evidence_acceptance_receipt_verification_failed")
        if any(type(row[key]) is not type(receipt[key]) or row[key] != receipt[key] for key in _ROW_KEYS):
            raise ValidationResultEvidenceError("evidence_acceptance_row_binding_mismatch")
        expected = {
            "schema_version": RECEIPT_SCHEMA_VERSION,
            "policy": POLICY_VERSION,
            "acceptance_state": "ACCEPTED",
            "runtime_observation_id": observation["observation_id"],
            "handoff_id": observation["handoff_id"],
            "dispatch_intent_id": observation["dispatch_intent_id"],
            "attempt_id": parent["attempt_id"],
            "lease_id": parent["lease_id"],
            "request_id": parent["request_id"],
            "request_set_digest": parent["request_set_digest"],
            "scenario_id": parent["scenario_id"],
            "validator_id": parent["validator_id"],
            "executor_id": parent["executor_id"],
            "operation_key": parent["operation_key"],
            "runtime_terminal_status": "SUCCEEDED",
            "runtime_observation_digest": observation["observation_digest"],
            "authority_class": "validation_result_evidence_acceptance",
            "scope": "single_F137_terminal_observation_single_exact_validation_result",
        }
        if any(type(receipt[key]) is not type(value) or receipt[key] != value for key, value in expected.items()):
            raise ValidationResultEvidenceError("evidence_acceptance_parent_binding_mismatch")
        if receipt["validation_outcome"] not in VALIDATION_OUTCOMES:
            raise ValidationResultEvidenceError("evidence_acceptance_outcome")
        if type(receipt["accepted_at_epoch"]) is not int or receipt["accepted_at_epoch"] < observation["observed_at_epoch"]:
            raise ValidationResultEvidenceError("evidence_acceptance_time")
        if execution_store.bounded_validation_digest(receipt["evidence_ids"]) != receipt["evidence_ids_digest"]:
            raise ValidationResultEvidenceError("evidence_acceptance_evidence_ids_digest")
        return receipt
    except ValidationResultEvidenceError:
        raise
    except (TypeError, ValueError, KeyError, RecursionError) as exc:
        raise ValidationResultEvidenceError("evidence_acceptance_receipt_corrupt") from exc


def _result(status: str, receipt=None, failures=(), reason: str = "") -> dict:
    stored = receipt or {}
    return {
        "schema_version": SCHEMA_VERSION,
        "decision": {
            "eligible": "VALIDATION_RESULT_EVIDENCE_ELIGIBLE",
            "accepted": "VALIDATION_RESULT_EVIDENCE_ACCEPTED",
            "recovered": "VALIDATION_RESULT_EVIDENCE_ACCEPTED_RECOVERED",
            "unresolved": "VALIDATION_RESULT_EVIDENCE_UNRESOLVED",
        }.get(status, "VALIDATION_RESULT_EVIDENCE_REJECTED"),
        "evidence_eligible": status == "eligible",
        "evidence_accepted": status in {"accepted", "recovered"},
        "acceptance_recorded_by_this_call": status == "accepted",
        "idempotent_recovery": status == "recovered",
        "acceptance_id": stored.get("acceptance_id", ""),
        "acceptance_receipt": stored,
        "validation_outcome": stored.get("validation_outcome", ""),
        "failed_conditions": list(failures),
        "unresolved_reason": reason if status == "unresolved" else "",
        "validator_executed_by_F138": False,
        "runtime_dispatched_by_F138": False,
        "postcondition_proven": False,
        "truth_committed": False,
        "authority": {
            "durable_state_changed": status == "accepted",
            "evidence_acceptance": status in {"accepted", "recovered"},
            "runtime_execution": False,
            "postcondition": False,
            "truth": False,
        },
        "proof_boundary": {
            "runtime_SUCCEEDED_is_validator_PASS": False,
            "validator_PASS_is_postcondition_proof": False,
            "validator_FAIL_is_runtime_failure": False,
            "accepted_evidence_is_truth": False,
        },
    }


def evaluate_validation_result_evidence(
    runtime_observation_id: str,
    validation_result: Mapping[str, Any],
    request_set: Mapping[str, Any],
    *,
    store_dir=None,
) -> dict:
    """Read-only F138 eligibility check; never creates the acceptance table."""
    connection = None
    try:
        if not is_sha256_id(runtime_observation_id):
            raise ValidationResultEvidenceError("invalid_runtime_observation_id")
        connection = _open(store_dir, writable=False)
        connection.execute("BEGIN")
        status, context = _evaluate(connection, runtime_observation_id, validation_result, request_set, store_dir)
        if status == "unresolved":
            return _result("unresolved", reason=str(context["reason"]))
        return _result("eligible")
    except (ValidationResultEvidenceError, sqlite3.Error, OSError, ValueError) as exc:
        return _result("rejected", failures=[str(exc)])
    finally:
        if connection is not None:
            connection.close()


def accept_validation_result_evidence(
    runtime_observation_id: str,
    validation_result: Mapping[str, Any],
    request_set: Mapping[str, Any],
    *,
    store_dir=None,
    _fail_before_commit: bool = False,
) -> dict:
    """Durably accept exactly one canonical validation result for one F137 terminal observation."""
    connection = None
    try:
        if not is_sha256_id(runtime_observation_id):
            raise ValidationResultEvidenceError("invalid_runtime_observation_id")
        connection = _open(store_dir, writable=True)
        connection.execute("BEGIN IMMEDIATE")
        status, context = _evaluate(connection, runtime_observation_id, validation_result, request_set, store_dir)
        if status == "unresolved":
            connection.execute("ROLLBACK")
            return _result("unresolved", reason=str(context["reason"]))
        observation = context["observation"]
        parent = context["parent"]
        payload = context["payload"]
        result_digest = context["validation_result_digest"]
        prior_row = _row(connection, runtime_observation_id)
        if prior_row is not None:
            prior = _verify_receipt(prior_row, observation, parent, store_dir)
            if prior["validation_result_digest"] != result_digest or prior["request_set_digest"] != parent["request_set_digest"]:
                raise ValidationResultEvidenceError("runtime_observation_evidence_already_accepted_with_different_content")
            connection.execute("COMMIT")
            return _result("recovered", prior)

        _initialize(connection)
        evidence_ids = list(payload["evidence_ids"])
        body = {
            "schema_version": RECEIPT_SCHEMA_VERSION,
            "policy": POLICY_VERSION,
            "acceptance_state": "ACCEPTED",
            "runtime_observation_id": observation["observation_id"],
            "handoff_id": observation["handoff_id"],
            "dispatch_intent_id": observation["dispatch_intent_id"],
            "attempt_id": parent["attempt_id"],
            "lease_id": parent["lease_id"],
            "request_id": parent["request_id"],
            "request_set_digest": parent["request_set_digest"],
            "scenario_id": parent["scenario_id"],
            "validator_id": parent["validator_id"],
            "executor_id": parent["executor_id"],
            "operation_key": parent["operation_key"],
            "runtime_terminal_status": observation["terminal_status"],
            "runtime_observation_digest": observation["observation_digest"],
            "validation_plan_digest": payload["validation_plan_digest"],
            "validation_result_digest": result_digest,
            "validation_outcome": payload["outcome"],
            "evidence_ids": evidence_ids,
            "evidence_ids_digest": execution_store.bounded_validation_digest(evidence_ids),
            "accepted_at_epoch": int(time.time()),
            "authority_class": "validation_result_evidence_acceptance",
            "scope": "single_F137_terminal_observation_single_exact_validation_result",
        }
        acceptance_id = execution_store.bounded_validation_digest(body, max_bytes=MAX_RESULT_BYTES)
        if acceptance_id is None or body["evidence_ids_digest"] is None:
            raise ValidationResultEvidenceError("evidence_acceptance_bounded_json")
        receipt = {
            **body,
            "acceptance_id": acceptance_id,
            "provenance": seal_payload(body, RECEIPT_ISSUER, store_dir=store_dir),
        }
        connection.execute(
            f"INSERT INTO {TABLE_NAME} ({', '.join((*_ROW_KEYS, 'receipt_json'))}) "
            f"VALUES ({','.join('?' for _ in range(len(_ROW_KEYS)+1))})",
            (*[receipt[key] for key in _ROW_KEYS], json.dumps(receipt, ensure_ascii=False, sort_keys=True)),
        )
        if _fail_before_commit:
            raise ValidationResultEvidenceError("injected_precommit_failure")
        connection.execute("COMMIT")
        return _result("accepted", receipt)
    except (ValidationResultEvidenceError, sqlite3.Error, OSError, ValueError) as exc:
        return _result("rejected", failures=[str(exc)])
    finally:
        if connection is not None:
            if connection.in_transaction:
                connection.rollback()
            connection.close()


def load_validation_result_evidence_acceptance_receipt(
    connection: sqlite3.Connection,
    acceptance_id: str,
    *,
    store_dir=None,
) -> dict:
    """Return one verified F138 acceptance for downstream F139 binding."""
    if not is_sha256_id(acceptance_id):
        raise ValidationResultEvidenceError("invalid_acceptance_id")
    row = execution_store.load_validation_feature_row(
        connection, table_name=TABLE_NAME, select_columns=(*_ROW_KEYS, "receipt_json"),
        key_column="acceptance_id", key_value=acceptance_id,
    )
    if row is None:
        raise ValidationResultEvidenceError("validation_result_evidence_acceptance_not_found")
    observation = _runtime_observation(connection, row["runtime_observation_id"], store_dir)
    parent = _dispatch_parent(connection, observation, store_dir)
    return _verify_receipt(row, observation, parent, store_dir)


def inspect_validation_result_evidence(runtime_observation_id: str, *, store_dir=None) -> dict:
    connection = None
    try:
        if not is_sha256_id(runtime_observation_id):
            raise ValidationResultEvidenceError("invalid_runtime_observation_id")
        connection = _open(store_dir, writable=False)
        connection.execute("BEGIN")
        observation = _runtime_observation(connection, runtime_observation_id, store_dir)
        parent = _dispatch_parent(connection, observation, store_dir)
        row = _row(connection, runtime_observation_id)
        if row is None:
            return {
                "acceptance_found": False,
                "decision": "VALIDATION_RESULT_EVIDENCE_NOT_ACCEPTED",
                "runtime_observation_id": runtime_observation_id,
                "runtime_terminal_status": observation.get("terminal_status", ""),
                "postcondition_proven": False,
                "truth_committed": False,
            }
        receipt = _verify_receipt(row, observation, parent, store_dir)
        return {
            "acceptance_found": True,
            "decision": "VALIDATION_RESULT_EVIDENCE_ACCEPTED",
            "acceptance_id": receipt["acceptance_id"],
            "acceptance_receipt": receipt,
            "validation_outcome": receipt["validation_outcome"],
            "postcondition_proven": False,
            "truth_committed": False,
            "next_boundary": "EXECUTION_BACKED_SCENARIO_EVIDENCE_BINDING",
        }
    except (ValidationResultEvidenceError, sqlite3.Error, OSError, ValueError) as exc:
        return {
            "acceptance_found": False,
            "error": str(exc),
            "postcondition_proven": False,
            "truth_committed": False,
        }
    finally:
        if connection is not None:
            connection.close()


__all__ = [
    "SCHEMA_VERSION", "POLICY_VERSION", "RECEIPT_SCHEMA_VERSION", "RECEIPT_ISSUER",
    "TABLE_NAME", "MAX_RESULT_BYTES", "ValidationResultEvidenceError",
    "load_validation_result_payload", "load_validation_execution_request_set",
    "evaluate_validation_result_evidence", "accept_validation_result_evidence",
    "inspect_validation_result_evidence", "load_validation_result_evidence_acceptance_receipt",
]
