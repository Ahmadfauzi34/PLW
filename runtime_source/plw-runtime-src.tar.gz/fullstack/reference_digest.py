"""Small neutral canonical digest primitive for cross-authority reference artifacts."""
from __future__ import annotations

import hashlib
import json
from typing import Any


def canonical_reference_digest(value: Any) -> str:
    raw = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    return "sha256:" + hashlib.sha256(raw).hexdigest()


__all__ = ["canonical_reference_digest"]
