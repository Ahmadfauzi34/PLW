"""F136 durable validation-dispatch intent bound to one exact F135 attempt.

Records local intent only. It never invokes a validator/runtime and never claims
that dispatch happened. Runtime dispatch truth belongs to a later boundary.
"""
from __future__ import annotations

import json
import re
import sqlite3
import time
from collections.abc import Mapping
from typing import Any

from core.accountability_provenance import seal_payload, verify_payload
from core.capability_contracts import exact_keys, is_sha256_id
from fullstack import validation_attempt as attempt_store
from fullstack import validation_execution_store as execution_store

SCHEMA_VERSION = "validation-dispatch-intent-request-v1"
POLICY_VERSION = "single-attempt-single-validation-dispatch-intent-v1"
RECEIPT_SCHEMA_VERSION = "validation-dispatch-intent-receipt-v1"
RECEIPT_ISSUER = "plw.fullstack.validation-dispatch-intent.v1"
TABLE_NAME = "validation_dispatch_intents_v1"
_DISPATCH_KEY = re.compile(r"[A-Za-z0-9][A-Za-z0-9._:-]{15,127}\Z")
_BINDING_KEYS = (
    "attempt_id", "lease_id", "authorization_binding_digest",
    "authorization_assertion_digest", "request_id", "request_set_digest",
    "scenario_id", "validator_id", "executor_id", "operation_key",
)
_AUTHORIZATION_KEYS = frozenset({
    "runtime_dispatch", "validator_execution", "evidence_acceptance", "postcondition", "truth",
})
_REQUEST_KEYS = frozenset(_BINDING_KEYS) | {
    "schema_version", "policy", "dispatch_key", "caller_prepares_validation_dispatch_intent",
    "authority", "authorizations",
}
_ROW_KEYS = (
    "dispatch_intent_id", "dispatch_request_digest", "dispatch_key", *_BINDING_KEYS,
    "attempt_registered_at_epoch", "prepared_at_epoch",
)
_BODY_KEYS = (frozenset(_ROW_KEYS) - {"dispatch_intent_id"}) | {
    "schema_version", "policy", "dispatch_intent_state", "authority_class", "scope",
}
_RECEIPT_KEYS = _BODY_KEYS | {"dispatch_intent_id", "provenance"}


class ValidationDispatchError(ValueError):
    pass


def build_validation_dispatch_request(attempt_receipt: Mapping[str, Any], dispatch_key: str) -> dict:
    source = attempt_receipt if isinstance(attempt_receipt, Mapping) else {}
    return {
        "schema_version": SCHEMA_VERSION,
        "policy": POLICY_VERSION,
        **{key: source.get(key, "") for key in _BINDING_KEYS},
        "dispatch_key": dispatch_key,
        "caller_prepares_validation_dispatch_intent": True,
        "authority": "validation_dispatch_intent_request_only",
        "authorizations": {key: False for key in sorted(_AUTHORIZATION_KEYS)},
    }


def _request(value: Any) -> dict:
    if not exact_keys(value, _REQUEST_KEYS):
        raise ValidationDispatchError("dispatch_request_exact_schema")
    if value["schema_version"] != SCHEMA_VERSION or value["policy"] != POLICY_VERSION:
        raise ValidationDispatchError("dispatch_request_version")
    if value["caller_prepares_validation_dispatch_intent"] is not True:
        raise ValidationDispatchError("dispatch_intent_must_be_literal_true")
    auth = value["authorizations"]
    if (
        value["authority"] != "validation_dispatch_intent_request_only"
        or not exact_keys(auth, _AUTHORIZATION_KEYS)
        or any(auth[key] is not False for key in _AUTHORIZATION_KEYS)
    ):
        raise ValidationDispatchError("dispatch_request_must_have_no_execution_authority")
    if not isinstance(value["dispatch_key"], str) or not _DISPATCH_KEY.fullmatch(value["dispatch_key"]):
        raise ValidationDispatchError("dispatch_key")
    if execution_store.bounded_validation_digest(value) is None or not is_sha256_id(value["attempt_id"]):
        raise ValidationDispatchError("dispatch_request_bounded_json_or_attempt_id")
    return dict(value)


def _open(store_dir, *, writable: bool) -> sqlite3.Connection:
    try:
        return execution_store.open_validation_store(store_dir, writable=writable, create=False)
    except (execution_store.ValidationExecutionStoreError, FileNotFoundError) as exc:
        raise ValidationDispatchError("validation_execution_store_unavailable") from exc


def _load_parent(conn, attempt_id: str, store_dir) -> dict:
    try:
        return attempt_store.load_validation_attempt_receipt(conn, attempt_id, store_dir=store_dir)
    except attempt_store.ValidationAttemptError as exc:
        raise ValidationDispatchError(str(exc)) from exc


def _initialize(conn) -> None:
    conn.execute(f"""CREATE TABLE IF NOT EXISTS {TABLE_NAME} (
        dispatch_intent_id TEXT PRIMARY KEY NOT NULL,
        dispatch_request_digest TEXT NOT NULL,
        dispatch_key TEXT NOT NULL UNIQUE,
        attempt_id TEXT NOT NULL UNIQUE REFERENCES {attempt_store.TABLE_NAME}(attempt_id),
        lease_id TEXT NOT NULL,
        authorization_binding_digest TEXT NOT NULL,
        authorization_assertion_digest TEXT NOT NULL,
        request_id TEXT NOT NULL,
        request_set_digest TEXT NOT NULL,
        scenario_id TEXT NOT NULL,
        validator_id TEXT NOT NULL,
        executor_id TEXT NOT NULL,
        operation_key TEXT NOT NULL,
        attempt_registered_at_epoch INTEGER NOT NULL,
        prepared_at_epoch INTEGER NOT NULL,
        receipt_json TEXT NOT NULL
    )""")
    execution_store.register_store_feature(conn, "dispatch_intent", 1, TABLE_NAME)


def _row(conn, attempt_id: str):
    return execution_store.load_validation_feature_row(
        conn, table_name=TABLE_NAME, select_columns=(*_ROW_KEYS, "receipt_json"),
        key_column="attempt_id", key_value=attempt_id,
    )


def _verify(row, parent: Mapping[str, Any], store_dir) -> dict:
    try:
        receipt = json.loads(row["receipt_json"])
        if not exact_keys(receipt, _RECEIPT_KEYS):
            raise ValidationDispatchError("dispatch_receipt_schema")
        body = {key: receipt[key] for key in _BODY_KEYS}
        if (
            execution_store.bounded_validation_digest(body) != receipt["dispatch_intent_id"]
            or not is_sha256_id(receipt["dispatch_intent_id"])
            or not verify_payload(body, receipt["provenance"], RECEIPT_ISSUER, store_dir=store_dir)
        ):
            raise ValidationDispatchError("dispatch_receipt_verification_failed")
        if any(type(row[k]) is not type(receipt[k]) or row[k] != receipt[k] for k in _ROW_KEYS):
            raise ValidationDispatchError("dispatch_receipt_row_binding_mismatch")
        expected = {
            "schema_version": RECEIPT_SCHEMA_VERSION,
            "policy": POLICY_VERSION,
            "dispatch_intent_state": "PREPARED",
            "authority_class": "validation_dispatch_intent",
            "scope": "single_F135_attempt_single_validation_dispatch_intent",
            **{key: parent[key] for key in _BINDING_KEYS},
            "attempt_registered_at_epoch": parent["registered_at_epoch"],
        }
        if any(type(receipt[k]) is not type(v) or receipt[k] != v for k, v in expected.items()):
            raise ValidationDispatchError("dispatch_attempt_binding_mismatch")
        if type(receipt["prepared_at_epoch"]) is not int or receipt["prepared_at_epoch"] < parent["registered_at_epoch"]:
            raise ValidationDispatchError("dispatch_prepare_time")
        req = _request(build_validation_dispatch_request(parent, receipt["dispatch_key"]))
        if receipt["dispatch_request_digest"] != execution_store.bounded_validation_digest(req):
            raise ValidationDispatchError("dispatch_request_digest_mismatch")
        return receipt
    except ValidationDispatchError:
        raise
    except (TypeError, ValueError, RecursionError, KeyError) as exc:
        raise ValidationDispatchError("dispatch_receipt_corrupt") from exc


def build_validation_dispatch_request_from_store(attempt_id: str, dispatch_key: str, *, store_dir=None) -> dict:
    conn = _open(store_dir, writable=False)
    try:
        conn.execute("BEGIN")
        parent = _load_parent(conn, attempt_id, store_dir)
        return build_validation_dispatch_request(parent, dispatch_key)
    finally:
        conn.close()


def _evaluate(conn, req: dict, store_dir) -> tuple[str, dict, dict]:
    parent = _load_parent(conn, req["attempt_id"], store_dir)
    if any(type(req[k]) is not type(parent[k]) or req[k] != parent[k] for k in _BINDING_KEYS):
        raise ValidationDispatchError("dispatch_request_attempt_binding_mismatch")
    prior_row = _row(conn, req["attempt_id"])
    if prior_row is not None:
        prior = _verify(prior_row, parent, store_dir)
        if prior["dispatch_request_digest"] != execution_store.bounded_validation_digest(req):
            raise ValidationDispatchError("attempt_dispatch_intent_already_prepared")
        return "recovered", parent, prior
    if execution_store.validation_table_exists(conn, TABLE_NAME):
        if conn.execute(f"SELECT 1 FROM {TABLE_NAME} WHERE dispatch_key=?", (req["dispatch_key"],)).fetchone():
            raise ValidationDispatchError("dispatch_key_conflict")
    return "eligible", parent, {}


def _result(status: str, req: Mapping[str, Any], receipt=None, failures=()) -> dict:
    prepared, recovered = status == "prepared", status == "recovered"
    stored = receipt or {}
    return {
        "schema_version": SCHEMA_VERSION,
        "policy": POLICY_VERSION,
        "decision": {
            "eligible": "VALIDATION_DISPATCH_INTENT_ELIGIBLE",
            "prepared": "VALIDATION_DISPATCH_INTENT_PREPARED",
            "recovered": "VALIDATION_DISPATCH_INTENT_RECOVERED_NO_NEW_AUTHORITY",
            "recovery_eligible": "VALIDATION_DISPATCH_INTENT_RECOVERY_ELIGIBLE",
        }.get(status, "VALIDATION_DISPATCH_INTENT_REJECTED"),
        "dispatch_intent_eligible": status == "eligible",
        "recovery_eligible": status == "recovery_eligible",
        "dispatch_intent_prepared": prepared,
        "idempotent_recovery": recovered,
        "dispatch_intent_exists": bool(stored),
        "dispatch_intent_id": stored.get("dispatch_intent_id", ""),
        "attempt_id": stored.get("attempt_id", req.get("attempt_id", "")),
        "lease_id": stored.get("lease_id", req.get("lease_id", "")),
        "dispatch_intent_receipt": stored,
        "failed_conditions": list(failures),
        "runtime_dispatch_authorized": False,
        "runtime_dispatch_state_authority": False,
        "runtime_dispatch_state": "UNKNOWN_TO_F136",
        "validator_executed": False,
        "evidence_returned": False,
        "postcondition_proven": False,
        "truth_committed": False,
        "authority": {
            "durable_state_changed": prepared,
            "dispatch_intent_prepared_by_this_call": prepared,
            "runtime_dispatch": False,
            "validator_execution": False,
            "evidence_acceptance": False,
            "postcondition": False,
            "truth": False,
        },
        "state_transition": {
            "from": "ATTEMPT_REGISTERED",
            "to": "DISPATCH_INTENT_PREPARED" if prepared else "UNCHANGED",
            "durable": prepared or recovered,
        },
        "handoff": {
            "required_next_boundary": "VALIDATION_RUNTIME_DISPATCH",
            "dispatch_intent_binding_present": bool(stored),
            "runtime_dispatch_state_authority": False,
            "runtime_dispatch_state": "UNKNOWN_TO_F136",
            "may_execute_runtime": False,
        },
    }


def evaluate_validation_dispatch_intent(request: Mapping[str, Any], *, store_dir=None) -> dict:
    req = {}
    conn = None
    try:
        req = _request(request)
        conn = _open(store_dir, writable=False)
        conn.execute("BEGIN")
        status, _, prior = _evaluate(conn, req, store_dir)
        return _result("recovery_eligible" if status == "recovered" else status, req, prior)
    except (ValidationDispatchError, sqlite3.Error, OSError, ValueError) as exc:
        return _result("rejected", req, failures=[str(exc)])
    finally:
        if conn is not None:
            conn.close()


def prepare_validation_dispatch_intent(request: Mapping[str, Any], *, store_dir=None, _fail_before_commit: bool = False) -> dict:
    req = {}
    conn = None
    try:
        req = _request(request)
        conn = _open(store_dir, writable=True)
        conn.execute("BEGIN IMMEDIATE")
        status, parent, prior = _evaluate(conn, req, store_dir)
        if status == "recovered":
            conn.execute("COMMIT")
            return _result(status, req, prior)
        _initialize(conn)
        parent = _load_parent(conn, req["attempt_id"], store_dir)
        now = int(time.time())
        body = {
            "schema_version": RECEIPT_SCHEMA_VERSION,
            "policy": POLICY_VERSION,
            "dispatch_intent_state": "PREPARED",
            "dispatch_request_digest": execution_store.bounded_validation_digest(req),
            "dispatch_key": req["dispatch_key"],
            **{key: parent[key] for key in _BINDING_KEYS},
            "attempt_registered_at_epoch": parent["registered_at_epoch"],
            "prepared_at_epoch": now,
            "authority_class": "validation_dispatch_intent",
            "scope": "single_F135_attempt_single_validation_dispatch_intent",
        }
        receipt = {**body, "dispatch_intent_id": execution_store.bounded_validation_digest(body),
                   "provenance": seal_payload(body, RECEIPT_ISSUER, store_dir=store_dir)}
        if not receipt["dispatch_intent_id"]:
            raise ValidationDispatchError("dispatch_receipt_bounded_json")
        conn.execute(
            f"INSERT INTO {TABLE_NAME} ({', '.join((*_ROW_KEYS, 'receipt_json'))}) VALUES ({','.join('?' for _ in range(len(_ROW_KEYS)+1))})",
            (*[receipt[k] for k in _ROW_KEYS], json.dumps(receipt, ensure_ascii=False, sort_keys=True)),
        )
        if _fail_before_commit:
            raise ValidationDispatchError("injected_precommit_failure")
        conn.execute("COMMIT")
        return _result("prepared", req, receipt)
    except (ValidationDispatchError, sqlite3.Error, OSError, ValueError) as exc:
        return _result("rejected", req, failures=[str(exc)])
    finally:
        if conn is not None:
            if conn.in_transaction:
                conn.rollback()
            conn.close()


def load_validation_dispatch_intent_receipt(connection: sqlite3.Connection, dispatch_intent_id: str, *, store_dir=None) -> dict:
    if not is_sha256_id(dispatch_intent_id):
        raise ValidationDispatchError("invalid_dispatch_intent_id")
    row = execution_store.load_validation_feature_row(
        connection, table_name=TABLE_NAME, select_columns=(*_ROW_KEYS, "receipt_json"),
        key_column="dispatch_intent_id", key_value=dispatch_intent_id,
    )
    if row is None:
        raise ValidationDispatchError("validation_dispatch_intent_not_found")
    parent = _load_parent(connection, row["attempt_id"], store_dir)
    return _verify(row, parent, store_dir)


def inspect_validation_dispatch_intent(attempt_id: str, *, request_id: str | None = None, executor_id: str | None = None, store_dir=None) -> dict:
    conn = None
    try:
        if not is_sha256_id(attempt_id):
            raise ValidationDispatchError("invalid_attempt_id")
        conn = _open(store_dir, writable=False)
        conn.execute("BEGIN")
        parent = _load_parent(conn, attempt_id, store_dir)
        row = _row(conn, attempt_id)
        if row is None:
            raise ValidationDispatchError("validation_dispatch_intent_not_found")
        receipt = _verify(row, parent, store_dir)
        if request_id is not None and receipt["request_id"] != request_id:
            raise ValidationDispatchError("request_binding_mismatch")
        if executor_id is not None and receipt["executor_id"] != executor_id:
            raise ValidationDispatchError("executor_binding_mismatch")
        return {
            "schema_version": RECEIPT_SCHEMA_VERSION,
            "dispatch_intent_found": True,
            "decision": "VALIDATION_DISPATCH_INTENT_PREPARED",
            "attempt_id": attempt_id,
            "dispatch_intent_id": receipt["dispatch_intent_id"],
            "dispatch_intent_receipt": receipt,
            "authority": "validation_dispatch_intent_inspection_only",
            "dispatch_intent_state": "PREPARED",
            "runtime_dispatch_authorized": False,
            "runtime_dispatch_state_authority": False,
            "runtime_dispatch_state": "UNKNOWN_TO_F136",
            "next_boundary": "VALIDATION_RUNTIME_DISPATCH",
            "may_execute_runtime": False,
            "validator_executed": False,
            "evidence_returned": False,
            "postcondition_proven": False,
            "truth_committed": False,
        }
    except (ValidationDispatchError, sqlite3.Error, OSError, ValueError) as exc:
        return {
            "dispatch_intent_found": False,
            "error": str(exc),
            "runtime_dispatch_authorized": False,
            "runtime_dispatch_state_authority": False,
            "runtime_dispatch_state": "UNKNOWN_TO_F136",
            "may_execute_runtime": False,
            "truth_committed": False,
        }
    finally:
        if conn is not None:
            conn.close()


__all__ = [
    "SCHEMA_VERSION", "POLICY_VERSION", "RECEIPT_SCHEMA_VERSION", "RECEIPT_ISSUER", "TABLE_NAME",
    "ValidationDispatchError", "build_validation_dispatch_request", "build_validation_dispatch_request_from_store",
    "evaluate_validation_dispatch_intent", "prepare_validation_dispatch_intent",
    "inspect_validation_dispatch_intent", "load_validation_dispatch_intent_receipt",
]
