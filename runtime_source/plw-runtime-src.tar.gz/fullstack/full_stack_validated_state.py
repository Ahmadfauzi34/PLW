"""F142 full-stack validated-state composition.

F142 composes already-distinct topology, geometry, correspondence, behavior,
and F141 postcondition authorities.  It verifies identity/digest compatibility
and emits one bounded composition state.  It does not merge graphs, vote on
evidence, execute runtime work, attest source mutation, promote stable state, or
commit truth.
"""
from __future__ import annotations

import json
from collections.abc import Mapping, Sequence
from pathlib import Path
from typing import Any, Dict, List, Optional

from core.capability_contracts import is_sha256_id
from core.shared_graph import build_shared_graph, graph_content_signature
from fullstack.reference_digest import canonical_reference_digest
from fullstack.execution_backed_evidence import (
    ExecutionBackedEvidenceError,
    verify_execution_backed_scenario_evidence,
)
from fullstack.postcondition_proof import (
    PostconditionProofError,
    verify_postcondition_proof_integrity,
)
from fullstack.geometric_impact import SCHEMA_VERSION as GEOMETRIC_IMPACT_SCHEMA_VERSION

SCHEMA_VERSION = "full-stack-validated-state-v1"
SPEC_SCHEMA_VERSION = "full-stack-validation-spec-v1"
DIGEST_POLICY = "f142-full-stack-composition-full-artifact-v1"
MAX_ARTIFACT_BYTES = 4 * 1024 * 1024
MAX_SCENARIOS = 1024
STATES = frozenset({"VALIDATED", "REJECTED", "UNRESOLVED", "CONFLICTING", "STALE"})
PROOF_RANK = {"UNRESOLVED": 0, "STRUCTURAL": 1, "EXACT": 2}


class FullStackValidatedStateError(ValueError):
    """Raised when an F142 authority artifact cannot be integrity-checked."""


def load_json_artifact(path: str, *, max_bytes: int = MAX_ARTIFACT_BYTES) -> Dict[str, Any]:
    target = Path(path)
    try:
        raw = target.read_bytes()
    except OSError as exc:
        raise FullStackValidatedStateError(f"artifact unavailable: {type(exc).__name__}") from exc
    if len(raw) > max_bytes:
        raise FullStackValidatedStateError(f"artifact exceeds {max_bytes} bytes")
    try:
        value = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise FullStackValidatedStateError(f"artifact is not bounded UTF-8 JSON: {type(exc).__name__}") from exc
    if not isinstance(value, dict):
        raise FullStackValidatedStateError("artifact root must be a JSON object")
    return value


def _text(value: Any, field: str, *, required: bool = False, max_len: int = 2048) -> Optional[str]:
    if value is None:
        if required:
            raise FullStackValidatedStateError(f"{field} is required")
        return None
    if not isinstance(value, str):
        raise FullStackValidatedStateError(f"{field} must be a string")
    value = value.strip()
    if required and not value:
        raise FullStackValidatedStateError(f"{field} must be non-empty")
    if len(value) > max_len:
        raise FullStackValidatedStateError(f"{field} exceeds {max_len} characters")
    return value or None


def _sha(value: Any, field: str) -> str:
    value = _text(value, field, required=True)
    assert value is not None
    if not is_sha256_id(value):
        raise FullStackValidatedStateError(f"{field} must be a sha256 id")
    return value


def normalize_full_stack_spec(payload: Mapping[str, Any]) -> Dict[str, Any]:
    if not isinstance(payload, Mapping):
        raise FullStackValidatedStateError("full-stack spec must be an object")
    allowed = {"schema_version", "change_identity_digest", "required_scenarios"}
    unknown = sorted(set(payload) - allowed)
    if unknown:
        raise FullStackValidatedStateError("full-stack spec contains unknown fields: " + ",".join(unknown))
    if payload.get("schema_version") != SPEC_SCHEMA_VERSION:
        raise FullStackValidatedStateError(f"full-stack spec must use {SPEC_SCHEMA_VERSION}")
    change_digest = _sha(payload.get("change_identity_digest"), "change_identity_digest")
    rows = payload.get("required_scenarios")
    if not isinstance(rows, list) or not rows:
        raise FullStackValidatedStateError("required_scenarios must be a non-empty array")
    if len(rows) > MAX_SCENARIOS:
        raise FullStackValidatedStateError(f"required_scenarios exceeds {MAX_SCENARIOS}")
    normalized: List[Dict[str, Any]] = []
    seen: set[str] = set()
    for index, row in enumerate(rows):
        field = f"required_scenarios[{index}]"
        if not isinstance(row, Mapping):
            raise FullStackValidatedStateError(f"{field} must be an object")
        allowed_row = {
            "scenario_id", "require_geometry", "required_geometry_constraint_ids",
            "require_correspondence", "minimum_correspondence_proof_class",
            "require_exact_runtime_capture",
        }
        unknown_row = sorted(set(row) - allowed_row)
        if unknown_row:
            raise FullStackValidatedStateError(f"{field} contains unknown fields: " + ",".join(unknown_row))
        sid = _sha(row.get("scenario_id"), f"{field}.scenario_id")
        if sid in seen:
            raise FullStackValidatedStateError(f"duplicate scenario_id: {sid}")
        seen.add(sid)
        require_geometry = row.get("require_geometry") is True
        require_correspondence = row.get("require_correspondence") is True
        require_exact_capture = row.get("require_exact_runtime_capture") is True
        if require_correspondence and not require_geometry:
            raise FullStackValidatedStateError(f"{field}: correspondence requires geometry")
        if require_exact_capture and not require_geometry:
            raise FullStackValidatedStateError(f"{field}: exact runtime capture requires geometry")
        raw_constraints = row.get("required_geometry_constraint_ids", [])
        if not isinstance(raw_constraints, list):
            raise FullStackValidatedStateError(f"{field}.required_geometry_constraint_ids must be an array")
        constraints: List[str] = []
        for cindex, value in enumerate(raw_constraints):
            text = _text(value, f"{field}.required_geometry_constraint_ids[{cindex}]", required=True, max_len=256)
            assert text is not None
            if text not in constraints:
                constraints.append(text)
        if constraints and not require_geometry:
            raise FullStackValidatedStateError(f"{field}: geometry constraints require geometry authority")
        proof_class = _text(
            row.get("minimum_correspondence_proof_class", "EXACT"),
            f"{field}.minimum_correspondence_proof_class", required=True, max_len=32,
        )
        assert proof_class is not None
        proof_class = proof_class.upper()
        if proof_class not in {"EXACT", "STRUCTURAL"}:
            raise FullStackValidatedStateError(f"{field}.minimum_correspondence_proof_class must be EXACT or STRUCTURAL")
        normalized.append({
            "scenario_id": sid,
            "require_geometry": require_geometry,
            "required_geometry_constraint_ids": sorted(constraints),
            "require_correspondence": require_correspondence,
            "minimum_correspondence_proof_class": proof_class,
            "require_exact_runtime_capture": require_exact_capture,
        })
    result = {
        "schema_version": SPEC_SCHEMA_VERSION,
        "change_identity_digest": change_digest,
        "required_scenarios": sorted(normalized, key=lambda row: row["scenario_id"]),
    }
    result["full_stack_spec_digest"] = canonical_reference_digest(result)
    return result


def _verify_ui_reference(value: Mapping[str, Any]) -> Dict[str, Any]:
    if not isinstance(value, Mapping) or value.get("schema_version") != "ui-reference-v1":
        raise FullStackValidatedStateError("UI reference must use ui-reference-v1")
    geometry = value.get("geometry")
    corr = value.get("correspondence")
    angular = value.get("angular_ownership")
    if not all(isinstance(v, Mapping) for v in (geometry, corr, angular)):
        raise FullStackValidatedStateError("UI reference geometry/correspondence/angular authority missing")
    scenario = geometry.get("scenario")
    if not isinstance(scenario, Mapping) or geometry.get("scenario_id") != canonical_reference_digest(scenario):
        raise FullStackValidatedStateError("geometry scenario_id does not match canonical scenario identity")
    expected_geometry = canonical_reference_digest({
        "scenario": scenario,
        "static_context": geometry.get("static_context"),
        "capture": geometry.get("capture"),
        "nodes": geometry.get("nodes"),
    })
    if geometry.get("geometry_snapshot_digest") != expected_geometry:
        raise FullStackValidatedStateError("geometry snapshot digest mismatch")
    if value.get("scenario_id") != geometry.get("scenario_id"):
        raise FullStackValidatedStateError("UI reference scenario identity mismatch")
    expected_corr = canonical_reference_digest({
        "scenario_id": corr.get("scenario_id"),
        "geometry_snapshot_digest": corr.get("geometry_snapshot_digest"),
        "angular_ownership_digest": corr.get("angular_ownership_digest"),
        "mappings": corr.get("mappings"),
    })
    if corr.get("correspondence_digest") != expected_corr:
        raise FullStackValidatedStateError("correspondence digest mismatch")
    if corr.get("scenario_id") != value.get("scenario_id") or corr.get("geometry_snapshot_digest") != geometry.get("geometry_snapshot_digest"):
        raise FullStackValidatedStateError("correspondence identity mismatch")
    if corr.get("angular_ownership_digest") != angular.get("ownership_digest"):
        raise FullStackValidatedStateError("correspondence ownership digest mismatch")
    expected_ref = canonical_reference_digest({
        "geometry_snapshot_digest": geometry.get("geometry_snapshot_digest"),
        "angular_ownership_digest": angular.get("ownership_digest"),
        "correspondence_digest": corr.get("correspondence_digest"),
    })
    if value.get("reference_state_digest") != expected_ref:
        raise FullStackValidatedStateError("UI reference digest mismatch")
    authority = value.get("authority")
    if not isinstance(authority, Mapping) or authority.get("truth_committed") is not False:
        raise FullStackValidatedStateError("UI reference authority widened")
    return dict(value)


def _verify_geometric_impact(value: Mapping[str, Any]) -> Dict[str, Any]:
    if not isinstance(value, Mapping) or value.get("schema_version") != GEOMETRIC_IMPACT_SCHEMA_VERSION:
        raise FullStackValidatedStateError(f"geometric impact must use {GEOMETRIC_IMPACT_SCHEMA_VERSION}")
    expected = canonical_reference_digest({
        "scenario_id": value.get("scenario_id"),
        "geometry_snapshot_digest": value.get("geometry_snapshot_digest"),
        "reference_state_digest": value.get("reference_state_digest"),
        "runtime_capture": value.get("runtime_capture"),
        "query": value.get("query"),
        "geometric_evidence": value.get("geometric_evidence"),
        "impact_projection": value.get("impact_projection"),
    })
    if value.get("geometric_impact_digest") != expected:
        raise FullStackValidatedStateError("geometric impact digest mismatch")
    authority = value.get("authority")
    if not isinstance(authority, Mapping) or authority.get("truth_committed") is not False:
        raise FullStackValidatedStateError("geometric impact authority widened")
    return dict(value)


def full_stack_validated_state_digest(result: Mapping[str, Any]) -> str:
    payload = {key: value for key, value in result.items() if key != "full_stack_validated_state_digest"}
    return canonical_reference_digest(payload)


def compose_full_stack_validated_state(
    scan_root: str,
    behavior_binding: Mapping[str, Any],
    postcondition_proof: Mapping[str, Any],
    spec_payload: Mapping[str, Any],
    *,
    current_revision: str,
    geometric_impacts: Sequence[Mapping[str, Any]] = (),
    ui_references: Sequence[Mapping[str, Any]] = (),
) -> Dict[str, Any]:
    """Compose separate authorities into one F142 state without merging them."""
    revision = _text(current_revision, "current_revision", required=True, max_len=256)
    assert revision is not None
    spec = normalize_full_stack_spec(spec_payload)
    try:
        behavior_rows = verify_execution_backed_scenario_evidence(behavior_binding)
        verify_postcondition_proof_integrity(postcondition_proof)
    except (ExecutionBackedEvidenceError, PostconditionProofError) as exc:
        raise FullStackValidatedStateError(f"verified input rejected: {exc}") from exc

    if postcondition_proof.get("execution_backed_evidence_binding_digest") != behavior_binding.get("execution_backed_evidence_binding_digest"):
        raise FullStackValidatedStateError("F141 proof is not bound to supplied F139 behavior artifact")
    if postcondition_proof.get("change_identity_digest") != spec["change_identity_digest"]:
        raise FullStackValidatedStateError("full-stack spec change_identity_digest mismatch")

    scenario_results = postcondition_proof.get("scenario_results")
    if not isinstance(scenario_results, list):
        raise FullStackValidatedStateError("F141 scenario_results missing")
    postcondition_scenarios = sorted(str(row.get("scenario_id")) for row in scenario_results if isinstance(row, Mapping))
    spec_scenarios = sorted(row["scenario_id"] for row in spec["required_scenarios"])
    if postcondition_scenarios != spec_scenarios:
        raise FullStackValidatedStateError("F142 scenario scope must exactly match F141 postcondition scenario scope")

    graph = build_shared_graph(scan_root)
    topology_signature = graph_content_signature(graph)
    topology_summary = graph.get("summary") if isinstance(graph.get("summary"), Mapping) else {}

    ui_by_sid: Dict[str, Dict[str, Any]] = {}
    for raw in ui_references:
        ref = _verify_ui_reference(raw)
        sid = str(ref.get("scenario_id"))
        if sid in ui_by_sid:
            raise FullStackValidatedStateError(f"duplicate UI reference scenario: {sid}")
        ui_by_sid[sid] = ref
    impact_by_sid: Dict[str, Dict[str, Any]] = {}
    for raw in geometric_impacts:
        impact = _verify_geometric_impact(raw)
        sid = str(impact.get("scenario_id"))
        if sid in impact_by_sid:
            raise FullStackValidatedStateError(f"duplicate geometric impact scenario: {sid}")
        impact_by_sid[sid] = impact

    stale: List[str] = []
    conflicts: List[str] = []
    rejected: List[str] = []
    unresolved: List[str] = []

    change = postcondition_proof.get("change_identity") if isinstance(postcondition_proof.get("change_identity"), Mapping) else {}
    candidate_revision = str(change.get("candidate_revision") or "")
    if revision != candidate_revision or postcondition_proof.get("current_revision") != revision:
        stale.append("current revision does not match F141 candidate/current revision")

    proof_state = str(postcondition_proof.get("proof_state") or "")
    if proof_state == "STALE":
        stale.append("F141 postcondition proof is stale")
    elif proof_state == "CONFLICTING":
        conflicts.append("F141 postcondition proof is conflicting")
    elif proof_state == "DISPROVEN":
        rejected.append("F141 postcondition proof is disproven")
    elif proof_state == "UNRESOLVED":
        unresolved.append("F141 postcondition proof is unresolved")
    elif proof_state != "PROVEN":
        unresolved.append("F141 postcondition proof is not in a composable state")

    scenario_states: List[Dict[str, Any]] = []
    for requirement in spec["required_scenarios"]:
        sid = requirement["scenario_id"]
        behavior = behavior_rows.get(sid)
        behavior_status = "OBSERVED" if isinstance(behavior, Mapping) and behavior.get("binding_status") == "OBSERVED" else "UNRESOLVED"
        if behavior_status != "OBSERVED":
            unresolved.append(f"behavior scenario {sid} is not execution-backed OBSERVED")
        observed_outcomes = list(behavior.get("validator_outcomes", [])) if isinstance(behavior, Mapping) else []

        geometry_status = "NOT_REQUIRED"
        correspondence_status = "NOT_REQUIRED"
        geometry_digest = None
        reference_digest = None
        correspondence_digest = None
        selected_ui_ids: List[str] = []

        if requirement["require_geometry"]:
            impact = impact_by_sid.get(sid)
            ref = ui_by_sid.get(sid)
            if impact is None or ref is None:
                geometry_status = "UNRESOLVED"
                unresolved.append(f"geometry authority missing for scenario {sid}")
            else:
                geometry = ref["geometry"]
                if geometry.get("scenario", {}).get("code_revision") != revision:
                    geometry_status = "STALE"
                    stale.append(f"geometry scenario {sid} targets a different code revision")
                elif impact.get("geometry_snapshot_digest") != geometry.get("geometry_snapshot_digest") or impact.get("reference_state_digest") != ref.get("reference_state_digest"):
                    geometry_status = "CONFLICTING"
                    conflicts.append(f"geometry/reference identity conflict for scenario {sid}")
                else:
                    evidence = impact.get("geometric_evidence") if isinstance(impact.get("geometric_evidence"), Mapping) else {}
                    constraints = evidence.get("constraints") if isinstance(evidence.get("constraints"), list) else []
                    by_constraint = {str(row.get("constraint_id")): row for row in constraints if isinstance(row, Mapping)}
                    required_constraints = requirement["required_geometry_constraint_ids"]
                    missing = [cid for cid in required_constraints if cid not in by_constraint]
                    violated = [cid for cid in required_constraints if by_constraint.get(cid, {}).get("status") == "VIOLATED"]
                    not_exact = [cid for cid in required_constraints if by_constraint.get(cid, {}).get("status") not in {"SATISFIED", "VIOLATED"}]
                    if missing:
                        geometry_status = "UNRESOLVED"
                        unresolved.append(f"geometry constraints missing for scenario {sid}: " + ",".join(missing))
                    elif violated:
                        geometry_status = "REJECTED"
                        rejected.append(f"geometry constraints violated for scenario {sid}: " + ",".join(violated))
                    elif not_exact:
                        geometry_status = "UNRESOLVED"
                        unresolved.append(f"geometry constraints unresolved for scenario {sid}: " + ",".join(not_exact))
                    elif requirement["require_exact_runtime_capture"] and impact.get("runtime_capture", {}).get("compatible_exact_binding") is not True:
                        geometry_status = "UNRESOLVED"
                        unresolved.append(f"geometry runtime capture is not EXACT for scenario {sid}")
                    elif not required_constraints:
                        geometry_status = "UNRESOLVED"
                        unresolved.append(f"geometry authority has no required constraints for scenario {sid}")
                    else:
                        geometry_status = "VALIDATED"
                geometry_digest = geometry.get("geometry_snapshot_digest")
                reference_digest = ref.get("reference_state_digest")
                selected_ui_ids = list((impact.get("selection") or {}).get("selected_ui_ids", [])) if isinstance(impact.get("selection"), Mapping) else []

                if requirement["require_correspondence"]:
                    angular = ref.get("angular_ownership") if isinstance(ref.get("angular_ownership"), Mapping) else {}
                    corr = ref.get("correspondence") if isinstance(ref.get("correspondence"), Mapping) else {}
                    correspondence_digest = corr.get("correspondence_digest")
                    if angular.get("graph_content_signature") != topology_signature:
                        correspondence_status = "STALE"
                        stale.append(f"correspondence topology binding is stale for scenario {sid}")
                    elif not selected_ui_ids:
                        correspondence_status = "UNRESOLVED"
                        unresolved.append(f"correspondence has no selected UI scope for scenario {sid}")
                    else:
                        mappings = {str(row.get("ui_id")): row for row in corr.get("mappings", []) if isinstance(row, Mapping)}
                        minimum = PROOF_RANK[requirement["minimum_correspondence_proof_class"]]
                        bad = []
                        for ui_id in selected_ui_ids:
                            row = mappings.get(ui_id)
                            proof_class = str(row.get("proof_class") if row else "UNRESOLVED")
                            if PROOF_RANK.get(proof_class, 0) < minimum:
                                bad.append(ui_id)
                        if bad:
                            correspondence_status = "UNRESOLVED"
                            unresolved.append(f"correspondence proof below policy for scenario {sid}: " + ",".join(sorted(bad)))
                        else:
                            correspondence_status = "VALIDATED"
        elif requirement["require_correspondence"]:
            raise FullStackValidatedStateError("normalized spec invariant violated: correspondence without geometry")

        scenario_states.append({
            "scenario_id": sid,
            "behavior": {"status": behavior_status, "validator_outcomes": observed_outcomes},
            "geometry": {"required": requirement["require_geometry"], "status": geometry_status, "geometry_snapshot_digest": geometry_digest},
            "correspondence": {
                "required": requirement["require_correspondence"],
                "status": correspondence_status,
                "minimum_proof_class": requirement["minimum_correspondence_proof_class"] if requirement["require_correspondence"] else None,
                "reference_state_digest": reference_digest,
                "correspondence_digest": correspondence_digest,
            },
        })

    if stale:
        state = "STALE"; reasons = sorted(set(stale))
    elif conflicts:
        state = "CONFLICTING"; reasons = sorted(set(conflicts))
    elif rejected:
        state = "REJECTED"; reasons = sorted(set(rejected))
    elif unresolved:
        state = "UNRESOLVED"; reasons = sorted(set(unresolved))
    else:
        state = "VALIDATED"; reasons = ["all required authorities are integrity-checked, compatible, fresh, and satisfied within the declared full-stack scope"]
    assert state in STATES

    result: Dict[str, Any] = {
        "schema_version": SCHEMA_VERSION,
        "digest_policy": DIGEST_POLICY,
        "composition_state": state,
        "current_revision": revision,
        "change_identity": dict(change),
        "change_identity_digest": postcondition_proof.get("change_identity_digest"),
        "full_stack_spec_digest": spec["full_stack_spec_digest"],
        "topology": {
            "graph_content_signature": topology_signature,
            "file_count": int(topology_summary.get("total_files", len(graph.get("vertices", []))) or 0),
            "edge_count": int(topology_summary.get("total_edges", len(graph.get("edges", []))) or 0),
            "status": "BOUND" if not stale else "STALE",
        },
        "behavior": {
            "execution_backed_evidence_binding_digest": behavior_binding.get("execution_backed_evidence_binding_digest"),
            "status": "VERIFIED",
            "double_counted_as_independent_vote": False,
        },
        "postcondition": {
            "postcondition_proof_digest": postcondition_proof.get("postcondition_proof_digest"),
            "proof_state": proof_state,
            "status": "VERIFIED",
            "behavior_lineage_dependency_preserved": True,
        },
        "scenario_states": scenario_states,
        "reasons": reasons,
        "authority": {
            "topology_authority": "core.shared_graph",
            "geometry_authority": "codebase.geometry_correspondence.GeometrySnapshot + F127 explicit constraints",
            "correspondence_authority": "codebase.geometry_correspondence.UIAngularCorrespondence",
            "behavior_authority": "F139 execution-backed scenario evidence",
            "postcondition_authority": "F141 postcondition proof",
            "authorities_merged": False,
            "graphs_merged": False,
            "evidence_voting_used": False,
            "source_mutation_attested": False,
            "stable_promoted": False,
            "truth_committed": False,
        },
        "proof_boundary": {
            "VALIDATED_is_truth_commit": False,
            "VALIDATED_is_stable_promotion": False,
            "VALIDATED_is_source_mutation_attestation": False,
            "behavior_and_postcondition_are_independent_votes": False,
            "topology_geometry_correspondence_behavior_postcondition_remain_separate_authorities": True,
        },
        "next_boundary": "OPTIONAL_PROMOTION_OR_TRUTH_COMMIT" if state == "VALIDATED" else "FULL_STACK_EVIDENCE_RECOVERY",
    }
    result["full_stack_validated_state_digest"] = full_stack_validated_state_digest(result)
    return result


def verify_full_stack_validated_state_integrity(result: Mapping[str, Any]) -> bool:
    if not isinstance(result, Mapping) or result.get("schema_version") != SCHEMA_VERSION:
        raise FullStackValidatedStateError(f"full-stack state must use {SCHEMA_VERSION}")
    if result.get("digest_policy") != DIGEST_POLICY:
        raise FullStackValidatedStateError("full-stack digest policy mismatch")
    claimed = result.get("full_stack_validated_state_digest")
    if not is_sha256_id(claimed) or full_stack_validated_state_digest(result) != claimed:
        raise FullStackValidatedStateError("full-stack state digest mismatch")
    if result.get("composition_state") not in STATES:
        raise FullStackValidatedStateError("unsupported full-stack composition state")
    authority = result.get("authority")
    if not isinstance(authority, Mapping):
        raise FullStackValidatedStateError("full-stack authority missing")
    if authority.get("authorities_merged") is not False or authority.get("graphs_merged") is not False:
        raise FullStackValidatedStateError("full-stack composition merged authority domains")
    if authority.get("truth_committed") is not False or authority.get("stable_promoted") is not False:
        raise FullStackValidatedStateError("full-stack composition widened authority")
    if authority.get("source_mutation_attested") is not False:
        raise FullStackValidatedStateError("full-stack composition falsely attests source mutation")
    return True


__all__ = [
    "SCHEMA_VERSION", "SPEC_SCHEMA_VERSION", "DIGEST_POLICY", "STATES",
    "FullStackValidatedStateError", "load_json_artifact", "normalize_full_stack_spec",
    "full_stack_validated_state_digest", "compose_full_stack_validated_state",
    "verify_full_stack_validated_state_integrity",
]
