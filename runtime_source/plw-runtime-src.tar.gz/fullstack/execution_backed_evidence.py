"""F139 execution-backed scenario evidence binding.

This read-only bridge consumes one verified F138 acceptance plus the exact raw
``validation.result`` payload and the exact F128 validation plan.  It binds the
accepted runtime result to the selected scenario set without executing a
validator, dispatching runtime, or claiming postcondition/truth authority.

F139 intentionally preserves F129 semantics (OBSERVED/MISSING and requested
check accounting) while using F138/F137 execution provenance instead of the
legacy F123 adapter-receipt provenance path.
"""
from __future__ import annotations

from collections.abc import Mapping
import json
from pathlib import Path
from typing import Any, Dict, List

from core.capability_contracts import is_sha256_id
from fullstack.reference_digest import canonical_reference_digest
from fullstack import validation_execution_store as execution_store
from fullstack import validation_result_evidence as accepted_result
from fullstack.validation_evidence import (
    VALIDATION_OBSERVATION_KIND,
    VALIDATION_OBSERVATION_SCHEMA_VERSION,
    ValidationEvidenceError,
    build_validation_observation_payload,
)
from fullstack.validation_scenarios import (
    SCHEMA_VERSION as VALIDATION_PLAN_SCHEMA_VERSION,
    validation_plan_digest,
)

SCHEMA_VERSION = "execution-backed-scenario-evidence-binding-v1"
BINDING_DIGEST_POLICY = "f139-execution-backed-scenario-evidence-full-artifact-v1"
PROVENANCE_CLASS = "F138_ACCEPTED_RUNTIME_RESULT"
MAX_RESULT_BYTES = accepted_result.MAX_RESULT_BYTES


class ExecutionBackedEvidenceError(ValueError):
    """Raised when F139 cannot establish exact F138→F128 evidence lineage."""


def _verify_plan(plan: Mapping[str, Any]) -> tuple[str, List[Mapping[str, Any]]]:
    if not isinstance(plan, Mapping) or plan.get("schema_version") != VALIDATION_PLAN_SCHEMA_VERSION:
        raise ExecutionBackedEvidenceError("validation_plan_schema")
    claimed = plan.get("validation_plan_digest")
    if not is_sha256_id(claimed):
        raise ExecutionBackedEvidenceError("validation_plan_digest")
    try:
        actual = validation_plan_digest(plan)
    except Exception as exc:  # validation_scenarios owns detailed schema validation
        raise ExecutionBackedEvidenceError("validation_plan_digest_recompute") from exc
    if actual != claimed:
        raise ExecutionBackedEvidenceError("validation_plan_digest_mismatch")
    selected = plan.get("selected_scenarios")
    if not isinstance(selected, list):
        raise ExecutionBackedEvidenceError("validation_plan_selected_scenarios")
    seen: set[str] = set()
    rows: List[Mapping[str, Any]] = []
    for index, row in enumerate(selected):
        if not isinstance(row, Mapping) or not is_sha256_id(row.get("scenario_id")):
            raise ExecutionBackedEvidenceError(f"selected_scenario_invalid:{index}")
        sid = str(row["scenario_id"])
        if sid in seen:
            raise ExecutionBackedEvidenceError("selected_scenario_duplicate")
        seen.add(sid)
        rows.append(row)
    return str(claimed), rows


def _canonical_result(result: Mapping[str, Any], plan_digest: str) -> Dict[str, Any]:
    if not isinstance(result, Mapping):
        raise ExecutionBackedEvidenceError("validation_result_root")
    try:
        canonical = build_validation_observation_payload(plan_digest, result)
    except ValidationEvidenceError as exc:
        raise ExecutionBackedEvidenceError("validation_result_contract:" + str(exc)) from exc
    if canonical != dict(result):
        raise ExecutionBackedEvidenceError("validation_result_not_canonical")
    if canonical.get("schema_version") != VALIDATION_OBSERVATION_SCHEMA_VERSION:
        raise ExecutionBackedEvidenceError("validation_result_schema")
    return canonical


def _acceptance_receipt(acceptance_id: str, *, store_dir=None) -> Dict[str, Any]:
    if not is_sha256_id(acceptance_id):
        raise ExecutionBackedEvidenceError("invalid_acceptance_id")
    try:
        with execution_store.open_validation_store(store_dir, writable=False, create=False) as connection:
            return accepted_result.load_validation_result_evidence_acceptance_receipt(
                connection, acceptance_id, store_dir=store_dir,
            )
    except (accepted_result.ValidationResultEvidenceError,
            execution_store.ValidationExecutionStoreError,
            FileNotFoundError) as exc:
        raise ExecutionBackedEvidenceError("acceptance_receipt_unavailable:" + str(exc)) from exc


def _requested_checks(selected_row: Mapping[str, Any]) -> List[str]:
    requested = selected_row.get("requested_validation")
    if not isinstance(requested, Mapping):
        return []
    values = requested.get("constraint_ids_if_applicable")
    if not isinstance(values, list):
        return []
    return sorted({str(value) for value in values if isinstance(value, str)})


def load_execution_backed_scenario_evidence(path: str, *, max_bytes: int = 1_048_576) -> Dict[str, Any]:
    """Load one bounded F139 execution-backed binding artifact from disk."""
    target = Path(path)
    try:
        raw = target.read_bytes()
    except OSError as exc:
        raise ExecutionBackedEvidenceError(f"execution-backed evidence unavailable: {type(exc).__name__}") from exc
    if len(raw) > max_bytes:
        raise ExecutionBackedEvidenceError(f"execution-backed evidence exceeds {max_bytes} bytes")
    try:
        payload = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ExecutionBackedEvidenceError(
            f"execution-backed evidence is not valid bounded UTF-8 JSON: {type(exc).__name__}"
        ) from exc
    if not isinstance(payload, dict):
        raise ExecutionBackedEvidenceError("execution-backed evidence root must be a JSON object")
    verify_execution_backed_scenario_evidence(payload)
    return payload


def execution_backed_evidence_binding_digest(binding: Mapping[str, Any]) -> str:
    payload = {key: value for key, value in binding.items() if key != "execution_backed_evidence_binding_digest"}
    return canonical_reference_digest(payload)


def bind_execution_backed_scenario_evidence(
    plan: Mapping[str, Any],
    validation_result: Mapping[str, Any],
    acceptance_id: str,
    *,
    store_dir=None,
) -> Dict[str, Any]:
    """Bind one F138-accepted validation result to exact F128 scenario identity."""
    plan_digest, selected = _verify_plan(plan)
    payload = _canonical_result(validation_result, plan_digest)
    receipt = _acceptance_receipt(acceptance_id, store_dir=store_dir)

    result_digest = execution_store.bounded_validation_digest(payload, max_bytes=MAX_RESULT_BYTES)
    if result_digest is None:
        raise ExecutionBackedEvidenceError("validation_result_bounded_digest")
    expected_pairs = {
        "validation_plan_digest": plan_digest,
        "validation_result_digest": result_digest,
        "scenario_id": payload["scenario_id"],
        "validator_id": payload["validator_id"],
        "validation_outcome": payload["outcome"],
    }
    for key, expected in expected_pairs.items():
        if receipt.get(key) != expected:
            raise ExecutionBackedEvidenceError(f"acceptance_{key}_mismatch")
    if list(receipt.get("evidence_ids", [])) != list(payload.get("evidence_ids", [])):
        raise ExecutionBackedEvidenceError("acceptance_evidence_ids_mismatch")
    if receipt.get("acceptance_state") != "ACCEPTED" or receipt.get("runtime_terminal_status") != "SUCCEEDED":
        raise ExecutionBackedEvidenceError("acceptance_not_runtime_succeeded")

    selected_by_id = {str(row["scenario_id"]): row for row in selected}
    scenario_id = str(payload["scenario_id"])
    if scenario_id not in selected_by_id:
        raise ExecutionBackedEvidenceError("accepted_result_scenario_not_selected_by_F128")

    provenance = {
        "class": PROVENANCE_CLASS,
        "acceptance_id": receipt["acceptance_id"],
        "runtime_observation_id": receipt["runtime_observation_id"],
        "handoff_id": receipt["handoff_id"],
        "request_id": receipt["request_id"],
        "request_set_digest": receipt["request_set_digest"],
        "validation_result_digest": receipt["validation_result_digest"],
        "receipt_verified": True,
        "content_bound": True,
        "execution_lineage_bound": True,
        "runtime_result_observed": True,
        "external_side_effect_truth": False,
    }
    observation_core = {
        "schema_version": VALIDATION_OBSERVATION_SCHEMA_VERSION,
        "observation_kind": VALIDATION_OBSERVATION_KIND,
        "scenario_id": payload["scenario_id"],
        "validator_id": payload["validator_id"],
        "validator_run_ref": payload.get("validator_run_ref"),
        "outcome": payload["outcome"],
        "checks": payload.get("checks", []),
        "evidence_ids": payload.get("evidence_ids", []),
        "provenance_v2": provenance,
    }
    observation = {
        "observation_id": canonical_reference_digest(observation_core),
        **observation_core,
    }

    bindings: List[Dict[str, Any]] = []
    for selected_row in selected:
        sid = str(selected_row["scenario_id"])
        requested_checks = _requested_checks(selected_row)
        rows = [observation] if sid == scenario_id else []
        observed_checks = sorted({
            str(check["check_id"])
            for item in rows
            for check in item.get("checks", [])
            if isinstance(check, Mapping) and isinstance(check.get("check_id"), str)
        })
        bindings.append({
            "scenario_id": sid,
            "scenario": selected_row.get("scenario"),
            "binding_status": "OBSERVED" if rows else "MISSING",
            "observation_count": len(rows),
            "validator_outcomes": [payload["outcome"]] if rows else [],
            "observation_ids": [observation["observation_id"]] if rows else [],
            "observations": rows,
            "requested_check_ids": requested_checks,
            "observed_check_ids": observed_checks,
            "missing_requested_check_ids": sorted(set(requested_checks) - set(observed_checks)),
            "unplanned_check_ids": sorted(set(observed_checks) - set(requested_checks)),
            "missing_evidence_is_failure": False,
            "validator_outcome_is_postcondition_proof": False,
        })

    result: Dict[str, Any] = {
        "schema_version": SCHEMA_VERSION,
        "binding_digest_policy": BINDING_DIGEST_POLICY,
        "validation_plan_digest": plan_digest,
        "F138_acceptance_id": receipt["acceptance_id"],
        "runtime_observation_id": receipt["runtime_observation_id"],
        "validation_result_digest": receipt["validation_result_digest"],
        "scenario_bindings": bindings,
        "summary": {
            "selected_scenario_count": len(bindings),
            "observed_scenario_count": 1,
            "missing_scenario_count": max(0, len(bindings) - 1),
            "execution_backed_observation_count": 1,
            "F138_content_bound_observation_count": 1,
        },
        "authority": {
            "F128_plan_identity_verified": True,
            "F138_acceptance_receipt_verified": True,
            "F138_result_content_bound": True,
            "F137_runtime_result_observed": True,
            "validator_executed_by_F139": False,
            "runtime_dispatched_by_F139": False,
            "proof_obligation_coverage": False,
            "postcondition_proven": False,
            "truth_committed": False,
        },
        "proof_boundary": {
            "runtime_SUCCEEDED_is_validator_PASS": False,
            "accepted_evidence_is_proof_obligation_coverage": False,
            "validator_PASS_is_postcondition_proof": False,
            "validator_FAIL_is_runtime_failure": False,
            "execution_backed_evidence_is_truth": False,
            "missing_scenario_is_validation_failure": False,
        },
        "next_boundary": "PROOF_OBLIGATION_RE_DERIVATION",
    }
    result["execution_backed_evidence_binding_digest"] = execution_backed_evidence_binding_digest(result)
    return result


def verify_execution_backed_scenario_evidence(binding: Mapping[str, Any]) -> Dict[str, Mapping[str, Any]]:
    """Verify F139 artifact structure and digest without re-opening runtime state."""
    if not isinstance(binding, Mapping) or binding.get("schema_version") != SCHEMA_VERSION:
        raise ExecutionBackedEvidenceError("execution_backed_binding_schema")
    if binding.get("binding_digest_policy") != BINDING_DIGEST_POLICY:
        raise ExecutionBackedEvidenceError("execution_backed_binding_policy")
    claimed = binding.get("execution_backed_evidence_binding_digest")
    if not is_sha256_id(claimed) or execution_backed_evidence_binding_digest(binding) != claimed:
        raise ExecutionBackedEvidenceError("execution_backed_binding_digest_mismatch")
    for key in ("validation_plan_digest", "F138_acceptance_id", "runtime_observation_id", "validation_result_digest"):
        if not is_sha256_id(binding.get(key)):
            raise ExecutionBackedEvidenceError(f"execution_backed_binding_{key}")
    rows = binding.get("scenario_bindings")
    if not isinstance(rows, list):
        raise ExecutionBackedEvidenceError("execution_backed_binding_rows")
    by_id: Dict[str, Mapping[str, Any]] = {}
    observation_count = 0
    for index, row in enumerate(rows):
        if not isinstance(row, Mapping) or not is_sha256_id(row.get("scenario_id")):
            raise ExecutionBackedEvidenceError(f"execution_backed_row_invalid:{index}")
        sid = str(row["scenario_id"])
        if sid in by_id:
            raise ExecutionBackedEvidenceError("execution_backed_duplicate_scenario")
        observations = row.get("observations")
        if not isinstance(observations, list):
            raise ExecutionBackedEvidenceError("execution_backed_observations_array")
        expected_status = "OBSERVED" if observations else "MISSING"
        if row.get("binding_status") != expected_status or row.get("observation_count") != len(observations):
            raise ExecutionBackedEvidenceError("execution_backed_row_derived_state")
        for observation in observations:
            if not isinstance(observation, Mapping) or observation.get("scenario_id") != sid:
                raise ExecutionBackedEvidenceError("execution_backed_observation_scenario")
            provenance = observation.get("provenance_v2")
            if not isinstance(provenance, Mapping) or provenance.get("class") != PROVENANCE_CLASS:
                raise ExecutionBackedEvidenceError("execution_backed_provenance_class")
            if not all(provenance.get(flag) is True for flag in (
                "receipt_verified", "content_bound", "execution_lineage_bound", "runtime_result_observed"
            )):
                raise ExecutionBackedEvidenceError("execution_backed_provenance_incomplete")
            if provenance.get("external_side_effect_truth") is not False:
                raise ExecutionBackedEvidenceError("execution_backed_provenance_widened")
            core = {key: value for key, value in observation.items() if key != "observation_id"}
            if canonical_reference_digest(core) != observation.get("observation_id"):
                raise ExecutionBackedEvidenceError("execution_backed_observation_digest")
            observation_count += 1
        by_id[sid] = row
    if observation_count != 1:
        raise ExecutionBackedEvidenceError("execution_backed_binding_requires_one_accepted_observation")
    authority = binding.get("authority")
    if not isinstance(authority, Mapping) or authority.get("postcondition_proven") is not False or authority.get("truth_committed") is not False:
        raise ExecutionBackedEvidenceError("execution_backed_authority_widened")
    return by_id


__all__ = [
    "SCHEMA_VERSION", "BINDING_DIGEST_POLICY", "PROVENANCE_CLASS",
    "ExecutionBackedEvidenceError", "load_execution_backed_scenario_evidence",
    "execution_backed_evidence_binding_digest", "bind_execution_backed_scenario_evidence",
    "verify_execution_backed_scenario_evidence",
]
