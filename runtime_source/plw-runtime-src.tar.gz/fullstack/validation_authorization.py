"""F133 principal-bound authorization binding for one exact F132 request.

F133 intentionally stops before leases, attempts, adapter dispatch, validator
execution, returned evidence, postconditions, or truth.  A host may issue the
signed assertion only after its own approval ceremony.  The binding function
then semantically re-derives F132 and proves that the short-lived grant names
that exact request identity, validator, executor, scenario, and operation key.

This is an authorization *binding* checkpoint, not an execution path.  F121+
lease/attempt/adapter consumption is deliberately deferred to a later contract.
"""
from __future__ import annotations

import secrets
import time
from typing import Any, Dict, Mapping, Optional

from core.accountability_provenance import seal_payload, verify_payload
from core.capability_contracts import bounded_text, exact_keys, is_sha256_id, safe_canonical_digest
from fullstack.validation_execution import (
    REQUEST_SCHEMA_VERSION,
    ValidationExecutionError,
    verify_validation_execution_requests,
)

SCHEMA_VERSION = "validation-request-authorization-binding-v1"
ASSERTION_SCHEMA_VERSION = "validation-request-authority-assertion-v1"
POLICY_VERSION = "principal-bound-exact-validation-request-grant-v1"
BINDING_DIGEST_POLICY = "validation-request-authorization-binding-full-artifact-v1"
AUTHORITY_CLASS = "validation_request_execution"
VALIDATION_AUTHORITY_ISSUER = "plw.authority.validation-request-grant.v1"
MAX_TTL_SECONDS = 900
_CLOCK_SKEW_SECONDS = 5

_ASSERTION_KEYS = frozenset({
    "schema_version", "policy", "authority_class", "scope", "grant",
    "principal_id", "request_id", "request_set_digest", "scenario_id",
    "validator_id", "executor_id", "operation_key", "issued_at_epoch",
    "expires_at_epoch", "nonce", "provenance",
})


class ValidationAuthorizationError(ValueError):
    """Raised when an F133 authorization binding fails closed."""


def _select_request(request_set: Mapping[str, Any], request_id: str) -> Dict[str, Any]:
    if not is_sha256_id(request_id):
        raise ValidationAuthorizationError("request_id must be a sha256 identity")
    rows = request_set.get("execution_requests")
    if not isinstance(rows, list):
        raise ValidationAuthorizationError("F132 request set execution_requests must be an array")
    matches = [row for row in rows if isinstance(row, Mapping) and row.get("request_id") == request_id]
    if len(matches) != 1:
        raise ValidationAuthorizationError("request_id must identify exactly one F132 execution request")
    row = dict(matches[0])
    if row.get("schema_version") != REQUEST_SCHEMA_VERSION:
        raise ValidationAuthorizationError("selected request is not an F132 validation execution request")
    handoff = row.get("handoff") if isinstance(row.get("handoff"), Mapping) else {}
    if handoff.get("request_id") != request_id or handoff.get("may_dispatch") is not False:
        raise ValidationAuthorizationError("F132 request handoff contract is malformed")
    return row


def _semantic_request(
    request_set: Mapping[str, Any],
    request_id: str,
    *,
    plan: Mapping[str, Any],
    binding: Mapping[str, Any],
    obligation_set: Mapping[str, Any],
    validator_id: str,
    executor_id: str,
) -> Dict[str, Any]:
    try:
        verify_validation_execution_requests(
            request_set,
            plan=plan,
            binding=binding,
            obligation_set=obligation_set,
            validator_id=validator_id,
            executor_id=executor_id,
        )
    except ValidationExecutionError as exc:
        raise ValidationAuthorizationError(f"F132 request set rejected: {exc}") from exc
    row = _select_request(request_set, request_id)
    if row.get("validator_id") != validator_id or row.get("executor_id") != executor_id:
        raise ValidationAuthorizationError("validator/executor identity does not match selected F132 request")
    return row


def validation_authorization_binding_digest(artifact: Mapping[str, Any]) -> str:
    core = dict(artifact)
    core.pop("validation_authorization_binding_digest", None)
    digest = safe_canonical_digest({
        "artifact_type": SCHEMA_VERSION,
        "digest_policy": BINDING_DIGEST_POLICY,
        "artifact": core,
    }, max_bytes=262144)
    if digest is None:
        raise ValidationAuthorizationError("authorization binding is not bounded canonical JSON")
    return digest


def issue_validation_request_authorization_assertion(
    request_set: Mapping[str, Any],
    request_id: str,
    principal_id: str,
    *,
    plan: Mapping[str, Any],
    binding: Mapping[str, Any],
    obligation_set: Mapping[str, Any],
    validator_id: str,
    executor_id: str,
    store_dir: str | None = None,
    ttl_seconds: int = 300,
    now_epoch: int | None = None,
    nonce: str | None = None,
) -> Dict[str, Any]:
    """Issue one signed grant after an external principal has approved F132 work."""
    request = _semantic_request(
        request_set, request_id,
        plan=plan, binding=binding, obligation_set=obligation_set,
        validator_id=validator_id, executor_id=executor_id,
    )
    if not bounded_text(principal_id, maximum=128):
        raise ValidationAuthorizationError("principal_id is invalid")
    if type(ttl_seconds) is not int or not (1 <= ttl_seconds <= MAX_TTL_SECONDS):
        raise ValidationAuthorizationError("authorization TTL is outside the allowed bound")
    issued = int(time.time()) if now_epoch is None else now_epoch
    if type(issued) is not int or issued < 0:
        raise ValidationAuthorizationError("authorization issuance time is invalid")
    assertion_nonce = secrets.token_hex(16) if nonce is None else nonce
    if (
        not isinstance(assertion_nonce, str)
        or not (32 <= len(assertion_nonce) <= 64)
        or any(ch not in "0123456789abcdef" for ch in assertion_nonce)
    ):
        raise ValidationAuthorizationError("authorization nonce is invalid")
    handoff = request.get("handoff") if isinstance(request.get("handoff"), Mapping) else {}
    body = {
        "schema_version": ASSERTION_SCHEMA_VERSION,
        "policy": POLICY_VERSION,
        "authority_class": AUTHORITY_CLASS,
        "scope": "single_validation_request",
        "grant": True,
        "principal_id": principal_id,
        "request_id": request_id,
        "request_set_digest": request_set.get("validation_execution_request_set_digest"),
        "scenario_id": request.get("scenario_id"),
        "validator_id": validator_id,
        "executor_id": executor_id,
        "operation_key": handoff.get("operation_key"),
        "issued_at_epoch": issued,
        "expires_at_epoch": issued + ttl_seconds,
        "nonce": assertion_nonce,
    }
    return {
        **body,
        "provenance": seal_payload(body, VALIDATION_AUTHORITY_ISSUER, store_dir=store_dir),
    }


def verify_validation_request_authorization_assertion(
    assertion: Any,
    request_set: Mapping[str, Any],
    request_id: str,
    *,
    plan: Mapping[str, Any],
    binding: Mapping[str, Any],
    obligation_set: Mapping[str, Any],
    validator_id: str,
    executor_id: str,
    store_dir: str | None = None,
    now_epoch: int | None = None,
) -> tuple[bool, list[str]]:
    failures: list[str] = []
    if not exact_keys(assertion, _ASSERTION_KEYS):
        return False, ["validation_authority_assertion_exact_schema"]
    assert isinstance(assertion, dict)
    try:
        request = _semantic_request(
            request_set, request_id,
            plan=plan, binding=binding, obligation_set=obligation_set,
            validator_id=validator_id, executor_id=executor_id,
        )
    except ValidationAuthorizationError as exc:
        return False, ["F132_request_semantics:" + str(exc)]
    handoff = request.get("handoff") if isinstance(request.get("handoff"), Mapping) else {}
    expected = {
        "schema_version": ASSERTION_SCHEMA_VERSION,
        "policy": POLICY_VERSION,
        "authority_class": AUTHORITY_CLASS,
        "scope": "single_validation_request",
        "grant": True,
        "request_id": request_id,
        "request_set_digest": request_set.get("validation_execution_request_set_digest"),
        "scenario_id": request.get("scenario_id"),
        "validator_id": validator_id,
        "executor_id": executor_id,
        "operation_key": handoff.get("operation_key"),
    }
    for key, value in expected.items():
        if assertion.get(key) != value:
            failures.append("validation_authority_assertion_" + key)
    if not bounded_text(assertion.get("principal_id"), maximum=128):
        failures.append("validation_authority_assertion_principal")
    nonce = assertion.get("nonce")
    if (
        not isinstance(nonce, str)
        or not (32 <= len(nonce) <= 64)
        or any(ch not in "0123456789abcdef" for ch in nonce)
    ):
        failures.append("validation_authority_assertion_nonce")
    issued, expires = assertion.get("issued_at_epoch"), assertion.get("expires_at_epoch")
    current = int(time.time()) if now_epoch is None else now_epoch
    if type(issued) is not int or type(expires) is not int or type(current) is not int:
        failures.append("validation_authority_assertion_time_type")
    elif (
        issued < 0
        or expires <= issued
        or expires - issued > MAX_TTL_SECONDS
        or issued > current + _CLOCK_SKEW_SECONDS
        or expires <= current
    ):
        failures.append("validation_authority_assertion_freshness")
    body = {key: assertion[key] for key in _ASSERTION_KEYS if key != "provenance"}
    if not verify_payload(body, assertion.get("provenance"), VALIDATION_AUTHORITY_ISSUER, store_dir=store_dir):
        failures.append("validation_authority_assertion_provenance")
    return not failures, failures


def build_validation_authorization_binding(
    request_set: Mapping[str, Any],
    request_id: str,
    assertion: Mapping[str, Any],
    *,
    plan: Mapping[str, Any],
    binding: Mapping[str, Any],
    obligation_set: Mapping[str, Any],
    validator_id: str,
    executor_id: str,
    store_dir: str | None = None,
    now_epoch: int | None = None,
) -> Dict[str, Any]:
    """Bind a valid short-lived principal grant to one exact F132 request."""
    request = _semantic_request(
        request_set, request_id,
        plan=plan, binding=binding, obligation_set=obligation_set,
        validator_id=validator_id, executor_id=executor_id,
    )
    valid, failures = verify_validation_request_authorization_assertion(
        assertion, request_set, request_id,
        plan=plan, binding=binding, obligation_set=obligation_set,
        validator_id=validator_id, executor_id=executor_id,
        store_dir=store_dir, now_epoch=now_epoch,
    )
    if not valid:
        raise ValidationAuthorizationError("validation authority assertion rejected: " + ",".join(failures))
    assertion_digest = safe_canonical_digest(assertion, max_bytes=262144)
    if assertion_digest is None:
        raise ValidationAuthorizationError("validation authority assertion is not bounded canonical JSON")
    handoff = request.get("handoff") if isinstance(request.get("handoff"), Mapping) else {}
    result: Dict[str, Any] = {
        "schema_version": SCHEMA_VERSION,
        "policy": POLICY_VERSION,
        "binding_digest_policy": BINDING_DIGEST_POLICY,
        "request_id": request_id,
        "request_set_digest": request_set.get("validation_execution_request_set_digest"),
        "scenario_id": request.get("scenario_id"),
        "validator_id": validator_id,
        "executor_id": executor_id,
        "operation_key": handoff.get("operation_key"),
        "authorization_state": "AUTHORIZED_BOUND",
        "authorization_principal": assertion.get("principal_id"),
        "authorization_assertion_digest": assertion_digest,
        "authorization_expires_at_epoch": assertion.get("expires_at_epoch"),
        "authority": {
            "F132_request_semantics_verified": True,
            "principal_grant_signature_verified": True,
            "principal_grant_fresh": True,
            "exact_request_identity_bound": True,
            "authorization_bound": True,
            "execution_lease_acquired": False,
            "attempt_registered": False,
            "adapter_dispatch_prepared": False,
            "runtime_dispatched": False,
            "validator_executed": False,
            "evidence_returned": False,
            "postcondition_proven": False,
            "truth_committed": False,
        },
        "handoff": {
            "request_id": request_id,
            "operation_key": handoff.get("operation_key"),
            "required_next_boundary": "LEASE_BINDING",
            "authorization_binding_present": True,
            "lease_binding_present": False,
            "attempt_binding_present": False,
            "dispatch_binding_present": False,
            "may_dispatch": False,
            "recover": "acquire a future lease that is semantically bound to this authorization binding and exact F132 request; do not dispatch from F133 alone",
        },
        "proof_boundary": {
            "authorization_binding_is_execution_lease": False,
            "authorization_binding_is_attempt": False,
            "authorization_binding_is_dispatch": False,
            "authorization_binding_is_validator_result": False,
            "authorization_binding_is_postcondition_proof": False,
            "authorization_binding_is_truth": False,
        },
    }
    result["validation_authorization_binding_digest"] = validation_authorization_binding_digest(result)
    return result


def verify_validation_authorization_binding(
    artifact: Mapping[str, Any],
    request_set: Mapping[str, Any],
    request_id: str,
    assertion: Mapping[str, Any],
    *,
    plan: Mapping[str, Any],
    binding: Mapping[str, Any],
    obligation_set: Mapping[str, Any],
    validator_id: str,
    executor_id: str,
    store_dir: str | None = None,
    now_epoch: int | None = None,
) -> bool:
    if not isinstance(artifact, Mapping) or artifact.get("schema_version") != SCHEMA_VERSION:
        raise ValidationAuthorizationError(f"authorization binding must use {SCHEMA_VERSION}")
    if artifact.get("binding_digest_policy") != BINDING_DIGEST_POLICY:
        raise ValidationAuthorizationError("authorization binding digest policy is missing or unsupported")
    claimed = artifact.get("validation_authorization_binding_digest")
    if not is_sha256_id(claimed) or validation_authorization_binding_digest(artifact) != claimed:
        raise ValidationAuthorizationError("authorization binding digest does not match contents")
    expected = build_validation_authorization_binding(
        request_set, request_id, assertion,
        plan=plan, binding=binding, obligation_set=obligation_set,
        validator_id=validator_id, executor_id=executor_id,
        store_dir=store_dir, now_epoch=now_epoch,
    )
    if expected["validation_authorization_binding_digest"] != claimed:
        raise ValidationAuthorizationError(
            "authorization binding is checksum-valid but does not match semantic F133 derivation"
        )
    return True


__all__ = [
    "SCHEMA_VERSION", "ASSERTION_SCHEMA_VERSION", "POLICY_VERSION",
    "BINDING_DIGEST_POLICY", "AUTHORITY_CLASS", "VALIDATION_AUTHORITY_ISSUER",
    "MAX_TTL_SECONDS", "ValidationAuthorizationError",
    "validation_authorization_binding_digest",
    "issue_validation_request_authorization_assertion",
    "verify_validation_request_authorization_assertion",
    "build_validation_authorization_binding",
    "verify_validation_authorization_binding",
]
