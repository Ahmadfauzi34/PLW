"""Validation-evidence coverage and proof-obligation projection.

F130/F131 consume a verified F129 scenario-bound evidence binding plus an
explicit caller-declared obligation set. Coverage v2 can require several
obligations to share one observation witness. Nothing in this read-only layer
promotes validator output into postcondition, behavioral, pixel, or truth
claims.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional

from core.capability_contracts import is_sha256_id
from fullstack.reference_digest import canonical_reference_digest
from fullstack.validation_evidence import (
    ValidationEvidenceError,
    verify_validation_evidence_binding,
)

SCHEMA_VERSION = "validation-proof-obligation-coverage-v2"
LEGACY_SCHEMA_VERSION = "validation-proof-obligation-coverage-v1"
OBLIGATION_SCHEMA_VERSION = "validation-proof-obligation-set-v2"
LEGACY_OBLIGATION_SCHEMA_VERSION = "validation-proof-obligation-set-v1"
EXECUTION_OBLIGATION_SCHEMA_VERSION = "validation-proof-obligation-set-v3"
COVERAGE_DIGEST_POLICY = "validation-proof-obligation-coverage-full-artifact-v2"
EXECUTION_COVERAGE_SCHEMA_VERSION = "execution-backed-proof-obligation-coverage-v1"
EXECUTION_COVERAGE_DIGEST_POLICY = "execution-backed-proof-obligation-coverage-full-artifact-v1"
MAX_OBLIGATION_BYTES = 1_048_576
MAX_OBLIGATIONS = 4096
MAX_TEXT = 2048
LEGACY_REQUIREMENTS = frozenset({
    "SCENARIO_OBSERVED",
    "CHECK_OBSERVED",
    "F123_RECEIPT_VERIFIED",
    "F123_PROVENANCE_VERIFIED",
    "CONSISTENT_SCENARIO_OUTCOME",
})
EXECUTION_REQUIREMENTS = frozenset({
    "EXECUTION_RECEIPT_VERIFIED",
    "EXECUTION_PROVENANCE_VERIFIED",
})
REQUIREMENTS = LEGACY_REQUIREMENTS | EXECUTION_REQUIREMENTS
WITNESS_SCOPES = frozenset({"SCENARIO_ANY", "SAME_OBSERVATION"})
COVERAGE_STATUSES = frozenset({"COVERED", "PARTIAL", "MISSING", "CONFLICTING"})


class ProofObligationError(ValueError):
    """Raised when a proof-obligation artifact violates its contract."""


def _text(value: Any, field: str, *, required: bool = False) -> Optional[str]:
    if value is None:
        if required:
            raise ProofObligationError(f"{field} is required")
        return None
    if not isinstance(value, str):
        raise ProofObligationError(f"{field} must be a string")
    value = value.strip()
    if required and not value:
        raise ProofObligationError(f"{field} must be non-empty")
    if len(value) > MAX_TEXT:
        raise ProofObligationError(f"{field} exceeds {MAX_TEXT} characters")
    return value or None


def _sha(value: Any, field: str, *, required: bool = False) -> Optional[str]:
    text = _text(value, field, required=required)
    if text is None:
        return None
    if not is_sha256_id(text):
        raise ProofObligationError(f"{field} must be a sha256 id")
    return text


def load_proof_obligation_set(path: str, *, max_bytes: int = MAX_OBLIGATION_BYTES) -> Dict[str, Any]:
    target = Path(path)
    try:
        raw = target.read_bytes()
    except OSError as exc:
        raise ProofObligationError(f"proof obligation set unavailable: {type(exc).__name__}") from exc
    if len(raw) > max_bytes:
        raise ProofObligationError(f"proof obligation set exceeds {max_bytes} bytes")
    try:
        payload = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ProofObligationError(
            f"proof obligation set is not valid bounded UTF-8 JSON: {type(exc).__name__}"
        ) from exc
    if not isinstance(payload, dict):
        raise ProofObligationError("proof obligation set root must be a JSON object")
    return payload


def normalize_proof_obligation_set(
    payload: Mapping[str, Any],
    *,
    validation_plan_digest: Optional[str] = None,
) -> Dict[str, Any]:
    if not isinstance(payload, Mapping):
        raise ProofObligationError("proof obligation set must be an object")
    allowed = {"schema_version", "validation_plan_digest", "obligations"}
    unknown = sorted(set(payload) - allowed)
    if unknown:
        raise ProofObligationError("proof obligation set contains unknown fields: " + ",".join(unknown))
    input_schema = payload.get("schema_version")
    if input_schema not in {
        OBLIGATION_SCHEMA_VERSION, LEGACY_OBLIGATION_SCHEMA_VERSION, EXECUTION_OBLIGATION_SCHEMA_VERSION,
    }:
        raise ProofObligationError(f"unsupported obligation schema_version: {input_schema}")
    plan_digest = _sha(payload.get("validation_plan_digest"), "validation_plan_digest", required=True)
    assert plan_digest is not None
    if validation_plan_digest is not None and plan_digest != validation_plan_digest:
        raise ProofObligationError("proof obligation set validation_plan_digest does not match F129 binding")

    obligations = payload.get("obligations")
    if not isinstance(obligations, list):
        raise ProofObligationError("obligations must be an array")
    if len(obligations) > MAX_OBLIGATIONS:
        raise ProofObligationError(f"obligations exceeds {MAX_OBLIGATIONS}")

    normalized: List[Dict[str, Any]] = []
    seen_ids: set[str] = set()
    for index, item in enumerate(obligations):
        field = f"obligations[{index}]"
        if not isinstance(item, Mapping):
            raise ProofObligationError(f"{field} must be an object")
        allowed_item = {
            "obligation_id", "scenario_id", "requirement", "check_id",
            "witness_scope", "witness_group_id",
        }
        unknown_item = sorted(set(item) - allowed_item)
        if unknown_item:
            raise ProofObligationError(f"{field} contains unknown fields: {','.join(unknown_item)}")
        if input_schema == LEGACY_OBLIGATION_SCHEMA_VERSION and (
            "witness_scope" in item or "witness_group_id" in item
        ):
            raise ProofObligationError(f"{field} uses v2 witness fields with the legacy schema")
        obligation_id = _text(item.get("obligation_id"), f"{field}.obligation_id", required=True)
        scenario_id = _sha(item.get("scenario_id"), f"{field}.scenario_id", required=True)
        requirement = _text(item.get("requirement"), f"{field}.requirement", required=True)
        check_id = _text(item.get("check_id"), f"{field}.check_id")
        witness_scope = _text(item.get("witness_scope"), f"{field}.witness_scope") or "SCENARIO_ANY"
        witness_group_id = _text(item.get("witness_group_id"), f"{field}.witness_group_id")
        assert obligation_id is not None and scenario_id is not None and requirement is not None
        requirement = requirement.upper()
        witness_scope = witness_scope.upper()
        allowed_requirements = (
            REQUIREMENTS if input_schema == EXECUTION_OBLIGATION_SCHEMA_VERSION else LEGACY_REQUIREMENTS
        )
        if requirement not in allowed_requirements:
            raise ProofObligationError(
                f"{field}.requirement must be one of: {','.join(sorted(allowed_requirements))}"
            )
        if witness_scope not in WITNESS_SCOPES:
            raise ProofObligationError(
                f"{field}.witness_scope must be one of: {','.join(sorted(WITNESS_SCOPES))}"
            )
        if requirement == "CHECK_OBSERVED" and check_id is None:
            raise ProofObligationError(f"{field}.check_id is required for CHECK_OBSERVED")
        if requirement != "CHECK_OBSERVED" and check_id is not None:
            raise ProofObligationError(f"{field}.check_id is only valid for CHECK_OBSERVED")
        if witness_scope == "SAME_OBSERVATION" and witness_group_id is None:
            raise ProofObligationError(f"{field}.witness_group_id is required for SAME_OBSERVATION")
        if witness_scope != "SAME_OBSERVATION" and witness_group_id is not None:
            raise ProofObligationError(f"{field}.witness_group_id is only valid for SAME_OBSERVATION")
        if obligation_id in seen_ids:
            raise ProofObligationError(f"duplicate obligation_id: {obligation_id}")
        seen_ids.add(obligation_id)
        normalized.append({
            "obligation_id": obligation_id,
            "scenario_id": scenario_id,
            "requirement": requirement,
            "check_id": check_id,
            "witness_scope": witness_scope,
            "witness_group_id": witness_group_id,
        })

    result = {
        "schema_version": (
            EXECUTION_OBLIGATION_SCHEMA_VERSION
            if input_schema == EXECUTION_OBLIGATION_SCHEMA_VERSION
            else OBLIGATION_SCHEMA_VERSION
        ),
        "validation_plan_digest": plan_digest,
        "obligations": normalized,
    }
    result["proof_obligation_set_digest"] = canonical_reference_digest({
        "artifact_type": result["schema_version"],
        "artifact": result,
    })
    return result


def _verify_binding(binding: Mapping[str, Any]) -> Dict[str, Mapping[str, Any]]:
    try:
        return verify_validation_evidence_binding(binding)
    except ValidationEvidenceError as exc:
        raise ProofObligationError(f"F129 validation evidence binding rejected: {exc}") from exc


def _observation_ids(observations: Any) -> List[str]:
    if not isinstance(observations, list):
        return []
    return [
        str(item["observation_id"])
        for item in observations
        if isinstance(item, Mapping) and is_sha256_id(item.get("observation_id"))
    ]


def _scenario_observed(row: Mapping[str, Any]) -> Dict[str, Any]:
    observations = row.get("observations") if isinstance(row.get("observations"), list) else []
    status = "COVERED" if observations else "MISSING"
    return {
        "coverage_status": status,
        "reason": "one_or_more_scenario_observations_present" if observations else "no_observation_for_selected_scenario",
        "observation_ids": _observation_ids(observations),
        "binding_status": row.get("binding_status"),
    }


def _check_observed(row: Mapping[str, Any], check_id: str) -> Dict[str, Any]:
    observations = row.get("observations") if isinstance(row.get("observations"), list) else []
    matched_ids: List[str] = []
    outcomes: set[str] = set()
    for observation in observations:
        if not isinstance(observation, Mapping):
            continue
        found = False
        for check in observation.get("checks", []):
            if not isinstance(check, Mapping) or check.get("check_id") != check_id:
                continue
            found = True
            outcome = check.get("outcome")
            if isinstance(outcome, str):
                outcomes.add(outcome)
        if found and is_sha256_id(observation.get("observation_id")):
            matched_ids.append(str(observation["observation_id"]))
    if not matched_ids:
        status = "MISSING"
        reason = "requested_check_not_observed"
    elif len(outcomes) > 1:
        status = "CONFLICTING"
        reason = "requested_check_has_conflicting_validator_outcomes"
    else:
        status = "COVERED"
        reason = "requested_check_observed"
    requested = row.get("requested_check_ids") if isinstance(row.get("requested_check_ids"), list) else []
    return {
        "coverage_status": status,
        "reason": reason,
        "observation_ids": matched_ids,
        "check_outcomes": sorted(outcomes),
        "check_planning_status": "PLANNED" if check_id in requested else "UNPLANNED",
        "binding_status": row.get("binding_status"),
    }


def _verified_provenance(row: Mapping[str, Any], *, receipt_only: bool) -> Dict[str, Any]:
    observations = row.get("observations") if isinstance(row.get("observations"), list) else []
    verified_ids: List[str] = []
    status_key = "receipt_verified" if receipt_only else "content_bound"
    for observation in observations:
        if not isinstance(observation, Mapping):
            continue
        provenance = observation.get("provenance_status")
        if (
            isinstance(provenance, Mapping)
            and provenance.get(status_key) is True
            and is_sha256_id(observation.get("observation_id"))
        ):
            verified_ids.append(str(observation["observation_id"]))
    if verified_ids:
        status = "COVERED"
        reason = (
            "one_or_more_F123_observation_receipts_verified"
            if receipt_only
            else "one_or_more_F123_receipts_content_bound_to_exact_validation_observation"
        )
    elif observations:
        status = "PARTIAL"
        reason = (
            "scenario_evidence_present_but_F123_receipt_not_verified"
            if receipt_only
            else "scenario_evidence_present_but_F123_provenance_not_content_bound"
        )
    else:
        status = "MISSING"
        reason = "no_scenario_evidence_available_for_provenance_verification"
    return {
        "coverage_status": status,
        "reason": reason,
        "observation_ids": verified_ids,
        "binding_status": row.get("binding_status"),
    }


def _execution_verified_provenance(row: Mapping[str, Any], *, receipt_only: bool) -> Dict[str, Any]:
    """Evaluate verified F139/F138 execution provenance without pretending it is F123."""
    observations = row.get("observations") if isinstance(row.get("observations"), list) else []
    verified_ids: List[str] = []
    for observation in observations:
        if not isinstance(observation, Mapping):
            continue
        provenance = observation.get("provenance_v2")
        if not isinstance(provenance, Mapping):
            continue
        receipt_ok = provenance.get("receipt_verified") is True
        lineage_ok = all(provenance.get(flag) is True for flag in (
            "receipt_verified", "content_bound", "execution_lineage_bound", "runtime_result_observed",
        ))
        satisfied = receipt_ok if receipt_only else lineage_ok
        if satisfied and is_sha256_id(observation.get("observation_id")):
            verified_ids.append(str(observation["observation_id"]))
    if verified_ids:
        status = "COVERED"
        reason = (
            "one_or_more_F138_acceptance_receipts_verified"
            if receipt_only
            else "one_or_more_F138_results_content_and_execution_lineage_verified"
        )
    elif observations:
        status = "PARTIAL"
        reason = (
            "scenario_evidence_present_but_F138_acceptance_receipt_not_verified"
            if receipt_only
            else "scenario_evidence_present_but_execution_provenance_not_fully_bound"
        )
    else:
        status = "MISSING"
        reason = "no_execution_backed_scenario_evidence_available"
    return {
        "coverage_status": status,
        "reason": reason,
        "observation_ids": verified_ids,
        "binding_status": row.get("binding_status"),
    }


def _consistent_outcome(row: Mapping[str, Any]) -> Dict[str, Any]:
    observations = row.get("observations") if isinstance(row.get("observations"), list) else []
    outcomes = sorted({
        str(item.get("outcome"))
        for item in observations
        if isinstance(item, Mapping) and isinstance(item.get("outcome"), str)
    })
    if not observations:
        status = "MISSING"
        reason = "no_validator_outcome_observed"
    elif len(outcomes) > 1 or row.get("binding_status") == "CONFLICTING":
        status = "CONFLICTING"
        reason = "validator_outcomes_conflict"
    else:
        status = "COVERED"
        reason = "observed_validator_outcomes_are_consistent"
    return {
        "coverage_status": status,
        "reason": reason,
        "observation_ids": _observation_ids(observations),
        "validator_outcomes": outcomes,
        "binding_status": row.get("binding_status"),
    }


def _apply_same_observation_witnesses(results: List[Dict[str, Any]]) -> None:
    groups: Dict[tuple[str, str], List[Dict[str, Any]]] = {}
    for row in results:
        row["individual_coverage_status"] = row.get("coverage_status")
        if row.get("witness_scope") != "SAME_OBSERVATION":
            row["correlated_witness_observation_ids"] = list(row.get("observation_ids", []))
            row["witness_group_status"] = "NOT_APPLICABLE"
            continue
        key = (str(row["scenario_id"]), str(row["witness_group_id"]))
        groups.setdefault(key, []).append(row)

    for members in groups.values():
        candidate_sets = [set(row.get("observation_ids", [])) for row in members]
        common = sorted(set.intersection(*candidate_sets)) if candidate_sets else []
        all_individually_covered = all(
            row.get("individual_coverage_status") == "COVERED" for row in members
        )
        group_complete = bool(common) and all_individually_covered
        group_status = "COVERED" if group_complete else "PARTIAL"
        for row in members:
            row["correlated_witness_observation_ids"] = common
            row["witness_group_member_count"] = len(members)
            row["witness_group_status"] = group_status
            # A SAME_OBSERVATION member cannot remain globally COVERED when the
            # correlated group itself is incomplete. Preserve stronger
            # individual failures (MISSING/CONFLICTING/PARTIAL) as-is.
            if not group_complete and row.get("coverage_status") == "COVERED":
                row["coverage_status"] = "PARTIAL"
                row["reason"] = (
                    "same_observation_witness_not_found"
                    if not common
                    else "same_observation_group_member_incomplete"
                )


def _recovery(requirement: str, status: str) -> str:
    matrix = {
        ("CHECK_OBSERVED", "MISSING"): "return exact selected-scenario evidence containing the requested check_id",
        ("CHECK_OBSERVED", "PARTIAL"): "return one exact observation satisfying the requested check and every same-observation witness-group obligation",
        ("CHECK_OBSERVED", "CONFLICTING"): "preserve all conflicting check results and obtain independent or adjudicating evidence for the same exact check_id",
        ("SCENARIO_OBSERVED", "MISSING"): "return one or more observations for the exact selected scenario",
        ("SCENARIO_OBSERVED", "PARTIAL"): "return one exact observation satisfying every same-observation witness-group obligation",
        ("SCENARIO_OBSERVED", "CONFLICTING"): "preserve conflicting scenario evidence and obtain an independent or adjudicating exact-scenario observation",
        ("F123_RECEIPT_VERIFIED", "MISSING"): "return exact selected-scenario evidence carrying an F123 receipt and provide its trust store",
        ("F123_RECEIPT_VERIFIED", "PARTIAL"): "provide a readable trust store containing the claimed exact F123 receipt",
        ("F123_RECEIPT_VERIFIED", "CONFLICTING"): "preserve receipt evidence and investigate the conflicting receipt claims",
        ("F123_PROVENANCE_VERIFIED", "MISSING"): "record and return the canonical validation.result payload through F123 for the exact selected scenario",
        ("F123_PROVENANCE_VERIFIED", "PARTIAL"): "return one F123 receipt whose validation.result digest matches the exact evidence observation and any same-observation witness group",
        ("F123_PROVENANCE_VERIFIED", "CONFLICTING"): "preserve all provenance claims and obtain a content-bound F123 receipt for an adjudicating observation",
        ("CONSISTENT_SCENARIO_OUTCOME", "MISSING"): "return the first validator observation for the exact selected scenario",
        ("CONSISTENT_SCENARIO_OUTCOME", "PARTIAL"): "return one exact observation satisfying every same-observation witness-group obligation",
        ("CONSISTENT_SCENARIO_OUTCOME", "CONFLICTING"): "preserve all conflicting outcomes and obtain independent or adjudicating validator evidence; no winner is chosen here",
        ("EXECUTION_RECEIPT_VERIFIED", "MISSING"): "return F139 execution-backed evidence carrying one verified F138 acceptance receipt for the exact selected scenario",
        ("EXECUTION_RECEIPT_VERIFIED", "PARTIAL"): "re-establish the exact F138 acceptance receipt for the observed F139 scenario evidence",
        ("EXECUTION_RECEIPT_VERIFIED", "CONFLICTING"): "preserve conflicting execution receipts and obtain one exact adjudicating F138 acceptance lineage",
        ("EXECUTION_PROVENANCE_VERIFIED", "MISSING"): "return F139 evidence with F138 content binding and F137/F138 execution lineage for the exact selected scenario",
        ("EXECUTION_PROVENANCE_VERIFIED", "PARTIAL"): "re-establish content-bound F138 acceptance plus execution-lineage binding for the observed scenario",
        ("EXECUTION_PROVENANCE_VERIFIED", "CONFLICTING"): "preserve conflicting provenance and obtain one adjudicating content-bound execution lineage",
    }
    return matrix[(requirement, status)]


def proof_obligation_coverage_digest(coverage: Mapping[str, Any]) -> str:
    """Digest every semantic field, including recovery requests and boundaries."""
    if not isinstance(coverage, Mapping):
        raise ProofObligationError("proof obligation coverage must be an object")
    core = dict(coverage)
    core.pop("proof_obligation_coverage_digest", None)
    try:
        return canonical_reference_digest({
            "artifact_type": SCHEMA_VERSION,
            "digest_policy": COVERAGE_DIGEST_POLICY,
            "artifact": core,
        })
    except (TypeError, ValueError) as exc:
        raise ProofObligationError("proof obligation coverage is not canonical JSON") from exc


def verify_validation_proof_coverage_integrity(coverage: Mapping[str, Any]) -> bool:
    """Verify only the self-contained F131 coverage checksum envelope.

    This is deliberately *not* semantic authority: an untrusted caller can
    construct a different artifact and recompute this unkeyed digest. Use
    ``verify_validation_proof_coverage`` when coverage must be trusted as the
    exact derivation of an F129 binding plus obligation set.
    """
    if not isinstance(coverage, Mapping) or coverage.get("schema_version") != SCHEMA_VERSION:
        raise ProofObligationError(f"coverage must use {SCHEMA_VERSION}")
    if coverage.get("coverage_digest_policy") != COVERAGE_DIGEST_POLICY:
        raise ProofObligationError("coverage digest policy is missing or unsupported")
    claimed = _sha(
        coverage.get("proof_obligation_coverage_digest"),
        "proof_obligation_coverage_digest",
        required=True,
    )
    assert claimed is not None
    if proof_obligation_coverage_digest(coverage) != claimed:
        raise ProofObligationError("proof obligation coverage digest does not match coverage contents")
    return True


def _prepare_obligation_projection(
    plan_digest: str,
    obligation_set: Mapping[str, Any],
) -> tuple[Dict[str, Any], List[Dict[str, Any]]]:
    """Shared F129/F139 setup so both authority paths use one obligation normalizer."""
    obligations = normalize_proof_obligation_set(
        obligation_set,
        validation_plan_digest=plan_digest,
    )
    return obligations, []


def _finalize_coverage_results(
    results: List[Dict[str, Any]],
) -> tuple[List[Dict[str, Any]], Dict[str, Any]]:
    """Apply shared witness semantics, recovery requests, and coverage summary."""
    _apply_same_observation_witnesses(results)
    next_evidence_requests: List[Dict[str, Any]] = []
    emitted_groups: set[tuple[str, str]] = set()
    for row in results:
        status = str(row["coverage_status"])
        if status == "COVERED":
            continue
        group_key: Optional[tuple[str, str]] = None
        if row.get("witness_scope") == "SAME_OBSERVATION" and status == "PARTIAL":
            group_key = (str(row["scenario_id"]), str(row["witness_group_id"]))
            if group_key in emitted_groups:
                continue
            emitted_groups.add(group_key)
        request = {
            "obligation_id": row["obligation_id"],
            "scenario_id": row["scenario_id"],
            "requirement": row["requirement"],
            "check_id": row.get("check_id"),
            "current_status": status,
            "reason": row["reason"],
            "witness_scope": row["witness_scope"],
            "witness_group_id": row.get("witness_group_id"),
            "recover": _recovery(str(row["requirement"]), status),
        }
        if group_key is not None:
            request["group_obligation_ids"] = [
                candidate["obligation_id"]
                for candidate in results
                if (candidate.get("scenario_id"), candidate.get("witness_group_id")) == group_key
            ]
        next_evidence_requests.append(request)

    counts = {
        status: sum(1 for row in results if row["coverage_status"] == status)
        for status in sorted(COVERAGE_STATUSES)
    }
    summary = {
        "obligation_count": len(results),
        "covered_count": counts["COVERED"],
        "partial_count": counts["PARTIAL"],
        "missing_count": counts["MISSING"],
        "conflicting_count": counts["CONFLICTING"],
        "coverage_complete": bool(results) and counts["COVERED"] == len(results),
        "coverage_complete_is_postcondition_proof": False,
    }
    return next_evidence_requests, summary


def verify_validation_proof_coverage(
    coverage: Mapping[str, Any],
    *,
    binding: Mapping[str, Any],
    obligation_set: Mapping[str, Any],
) -> bool:
    """Re-derive coverage from F129 + obligations and require exact semantics.

    The coverage digest is an integrity checksum, not issuer authentication.
    Semantic verification therefore recomputes the authoritative projection
    from the verified F129 binding and caller-declared obligations, then
    requires the supplied artifact digest to equal that fresh derivation.
    """
    verify_validation_proof_coverage_integrity(coverage)
    expected = project_validation_proof_obligations(binding, obligation_set)
    claimed = str(coverage["proof_obligation_coverage_digest"])
    expected_digest = str(expected["proof_obligation_coverage_digest"])
    if claimed != expected_digest:
        raise ProofObligationError(
            "proof obligation coverage is checksum-valid but does not match semantic derivation"
        )
    return True


def project_validation_proof_obligations(
    binding: Mapping[str, Any],
    obligation_set: Mapping[str, Any],
) -> Dict[str, Any]:
    """Project verified F129 evidence onto exact caller-declared obligations."""
    by_scenario = _verify_binding(binding)
    plan_digest = str(binding["validation_plan_digest"])
    obligations, results = _prepare_obligation_projection(plan_digest, obligation_set)
    if any(row.get("requirement") in EXECUTION_REQUIREMENTS for row in obligations["obligations"]):
        raise ProofObligationError(
            "execution provenance obligations require F139 execution-backed coverage mode"
        )
    for obligation in obligations["obligations"]:
        scenario_id = obligation["scenario_id"]
        row = by_scenario.get(scenario_id)
        if row is None:
            raise ProofObligationError(
                f"obligation {obligation['obligation_id']} targets scenario_id not selected by F128 plan"
            )
        requirement = obligation["requirement"]
        if requirement == "SCENARIO_OBSERVED":
            coverage = _scenario_observed(row)
        elif requirement == "CHECK_OBSERVED":
            coverage = _check_observed(row, str(obligation["check_id"]))
        elif requirement == "F123_RECEIPT_VERIFIED":
            coverage = _verified_provenance(row, receipt_only=True)
        elif requirement == "F123_PROVENANCE_VERIFIED":
            coverage = _verified_provenance(row, receipt_only=False)
        else:
            coverage = _consistent_outcome(row)
        results.append({
            **obligation,
            **coverage,
            "claim_truth_proven": False,
            "postcondition_proven": False,
        })

    next_evidence_requests, summary = _finalize_coverage_results(results)
    result: Dict[str, Any] = {
        "schema_version": SCHEMA_VERSION,
        "coverage_digest_policy": COVERAGE_DIGEST_POLICY,
        "validation_plan_digest": plan_digest,
        "validation_evidence_binding_digest": binding["validation_evidence_binding_digest"],
        "proof_obligation_set_digest": obligations["proof_obligation_set_digest"],
        "obligation_results": results,
        "next_evidence_requests": next_evidence_requests,
        "summary": summary,
        "authority": {
            "F129_binding_digest_verified": True,
            "F129_binding_structure_validated": True,
            "F129_binding_origin_authenticated": False,
            "proof_obligations_caller_declared": True,
            "validator_executed_by_projector": False,
            "runtime_dispatched_by_projector": False,
            "source_mutated": False,
            "postcondition_proven": False,
            "truth_committed": False,
        },
        "proof_boundary": {
            "covered_obligation_is_claim_truth": False,
            "complete_coverage_is_postcondition_proof": False,
            "validator_PASS_is_claim_truth": False,
            "missing_obligation_is_validation_failure": False,
            "conflicting_obligation_is_auto_resolved": False,
            "verified_F123_receipt_is_content_provenance": False,
            "content_bound_F123_provenance_is_pixel_or_behavior_truth": False,
            "binding_digest_authenticates_issuer": False,
        },
        "recovery": {
            "missing_or_partial": "follow next_evidence_requests using the exact F128 scenario identity and witness scope",
            "conflicting": "preserve all validator/run evidence and investigate; no winner is chosen here",
            "expand_obligations": "supply a new explicit obligation set bound to the same validation_plan_digest",
        },
    }
    result["proof_obligation_coverage_digest"] = proof_obligation_coverage_digest(result)
    return result




def execution_proof_obligation_coverage_digest(coverage: Mapping[str, Any]) -> str:
    """Digest an F140 execution-backed coverage artifact."""
    if not isinstance(coverage, Mapping):
        raise ProofObligationError("execution-backed proof coverage must be an object")
    core = dict(coverage)
    core.pop("proof_obligation_coverage_digest", None)
    try:
        return canonical_reference_digest({
            "artifact_type": EXECUTION_COVERAGE_SCHEMA_VERSION,
            "digest_policy": EXECUTION_COVERAGE_DIGEST_POLICY,
            "artifact": core,
        })
    except (TypeError, ValueError) as exc:
        raise ProofObligationError("execution-backed proof coverage is not canonical JSON") from exc


def project_execution_backed_proof_obligations(
    binding: Mapping[str, Any],
    obligation_set: Mapping[str, Any],
) -> Dict[str, Any]:
    """F140: re-derive obligations from verified F139 execution-backed evidence.

    This reuses the F130/F131 obligation evaluators and witness-group semantics,
    but provenance requirements are explicitly F137/F138 execution provenance,
    never silently relabeled as F123 provenance.
    """
    # Lazy import avoids a module cycle through validation_execution -> proof_obligations.
    from fullstack.execution_backed_evidence import (
        ExecutionBackedEvidenceError, verify_execution_backed_scenario_evidence,
    )
    try:
        by_scenario = verify_execution_backed_scenario_evidence(binding)
    except ExecutionBackedEvidenceError as exc:
        raise ProofObligationError(f"F139 execution-backed evidence rejected: {exc}") from exc
    plan_digest = str(binding["validation_plan_digest"])
    obligations, results = _prepare_obligation_projection(plan_digest, obligation_set)
    for obligation in obligations["obligations"]:
        scenario_id = obligation["scenario_id"]
        row = by_scenario.get(scenario_id)
        if row is None:
            raise ProofObligationError(
                f"obligation {obligation['obligation_id']} targets scenario_id not selected by F128/F139 binding"
            )
        requirement = obligation["requirement"]
        if requirement == "SCENARIO_OBSERVED":
            coverage = _scenario_observed(row)
        elif requirement == "CHECK_OBSERVED":
            coverage = _check_observed(row, str(obligation["check_id"]))
        elif requirement == "F123_RECEIPT_VERIFIED":
            coverage = _verified_provenance(row, receipt_only=True)
        elif requirement == "F123_PROVENANCE_VERIFIED":
            coverage = _verified_provenance(row, receipt_only=False)
        elif requirement == "EXECUTION_RECEIPT_VERIFIED":
            coverage = _execution_verified_provenance(row, receipt_only=True)
        elif requirement == "EXECUTION_PROVENANCE_VERIFIED":
            coverage = _execution_verified_provenance(row, receipt_only=False)
        else:
            coverage = _consistent_outcome(row)
        results.append({
            **obligation,
            **coverage,
            "evidence_authority": "F139_EXECUTION_BACKED_SCENARIO_EVIDENCE",
            "claim_truth_proven": False,
            "postcondition_proven": False,
        })

    next_evidence_requests, summary = _finalize_coverage_results(results)
    result: Dict[str, Any] = {
        "schema_version": EXECUTION_COVERAGE_SCHEMA_VERSION,
        "coverage_digest_policy": EXECUTION_COVERAGE_DIGEST_POLICY,
        "validation_plan_digest": plan_digest,
        "execution_backed_evidence_binding_digest": binding["execution_backed_evidence_binding_digest"],
        "F138_acceptance_id": binding["F138_acceptance_id"],
        "runtime_observation_id": binding["runtime_observation_id"],
        "proof_obligation_set_digest": obligations["proof_obligation_set_digest"],
        "obligation_results": results,
        "next_evidence_requests": next_evidence_requests,
        "summary": summary,
        "authority": {
            "F139_binding_digest_verified": True,
            "F138_acceptance_receipt_verified_by_F139": True,
            "execution_lineage_bound_by_F139": True,
            "proof_obligations_caller_declared": True,
            "validator_executed_by_projector": False,
            "runtime_dispatched_by_projector": False,
            "source_mutated": False,
            "postcondition_proven": False,
            "truth_committed": False,
        },
        "proof_boundary": {
            "coverage_is_fresh_re_derivation": True,
            "F139_execution_backed_evidence_is_postcondition_proof": False,
            "covered_obligation_is_claim_truth": False,
            "complete_coverage_is_postcondition_proof": False,
            "validator_PASS_is_claim_truth": False,
            "validator_FAIL_is_runtime_failure": False,
            "legacy_F123_requirement_is_satisfied_by_F139_provenance": False,
            "execution_provenance_is_external_side_effect_truth": False,
        },
        "recovery": {
            "missing_or_partial": "follow next_evidence_requests using the exact F128/F139 scenario identity and witness scope",
            "conflicting": "preserve all execution-backed evidence and obtain independent/adjudicating evidence; no winner is chosen here",
            "legacy_F123_requirement": "do not silently reinterpret an F123-specific obligation as F137/F138 execution provenance; declare an execution provenance obligation explicitly when intended",
        },
        "next_boundary": "POSTCONDITION_PROOF_ASSEMBLY",
    }
    result["proof_obligation_coverage_digest"] = execution_proof_obligation_coverage_digest(result)
    return result


def verify_execution_backed_proof_coverage_integrity(coverage: Mapping[str, Any]) -> bool:
    if not isinstance(coverage, Mapping) or coverage.get("schema_version") != EXECUTION_COVERAGE_SCHEMA_VERSION:
        raise ProofObligationError(f"coverage must use {EXECUTION_COVERAGE_SCHEMA_VERSION}")
    if coverage.get("coverage_digest_policy") != EXECUTION_COVERAGE_DIGEST_POLICY:
        raise ProofObligationError("execution-backed coverage digest policy is missing or unsupported")
    claimed = _sha(coverage.get("proof_obligation_coverage_digest"), "proof_obligation_coverage_digest", required=True)
    assert claimed is not None
    if execution_proof_obligation_coverage_digest(coverage) != claimed:
        raise ProofObligationError("execution-backed proof coverage digest does not match coverage contents")
    return True


def verify_execution_backed_proof_coverage(
    coverage: Mapping[str, Any],
    *,
    binding: Mapping[str, Any],
    obligation_set: Mapping[str, Any],
) -> bool:
    """Freshly re-derive F140 semantics; checksum alone is never authority."""
    verify_execution_backed_proof_coverage_integrity(coverage)
    expected = project_execution_backed_proof_obligations(binding, obligation_set)
    if coverage["proof_obligation_coverage_digest"] != expected["proof_obligation_coverage_digest"]:
        raise ProofObligationError(
            "execution-backed coverage is checksum-valid but does not match fresh semantic derivation"
        )
    return True


__all__ = [
    "SCHEMA_VERSION",
    "LEGACY_SCHEMA_VERSION",
    "OBLIGATION_SCHEMA_VERSION",
    "LEGACY_OBLIGATION_SCHEMA_VERSION",
    "EXECUTION_OBLIGATION_SCHEMA_VERSION",
    "EXECUTION_COVERAGE_SCHEMA_VERSION",
    "EXECUTION_COVERAGE_DIGEST_POLICY",
    "COVERAGE_DIGEST_POLICY",
    "MAX_OBLIGATION_BYTES",
    "MAX_OBLIGATIONS",
    "REQUIREMENTS",
    "WITNESS_SCOPES",
    "COVERAGE_STATUSES",
    "ProofObligationError",
    "load_proof_obligation_set",
    "normalize_proof_obligation_set",
    "proof_obligation_coverage_digest",
    "verify_validation_proof_coverage_integrity",
    "verify_validation_proof_coverage",
    "project_validation_proof_obligations",
    "execution_proof_obligation_coverage_digest",
    "project_execution_backed_proof_obligations",
    "verify_execution_backed_proof_coverage_integrity",
    "verify_execution_backed_proof_coverage",
]
