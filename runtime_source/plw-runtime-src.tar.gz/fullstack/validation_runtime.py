"""F137 validation runtime-dispatch handoff and reconciliation.

F136 owns durable local dispatch intent. F137 may claim one runtime handoff and,
when an explicit host adapter is supplied by the embedding application, invoke
it exactly once from the reference machine's perspective. A recovered handoff
is never blindly dispatched again; it requires adapter reconciliation.

Runtime observations are append-only, content-addressed evidence records. A
terminal runtime report is still not evidence acceptance, postcondition proof,
or truth.
"""
from __future__ import annotations

import json
import re
import sqlite3
import time
from collections.abc import Mapping, Sequence
from typing import Any, Protocol, runtime_checkable

from core.accountability_provenance import seal_payload, verify_payload
from core.capability_contracts import exact_keys, is_sha256_id
from fullstack import validation_dispatch as dispatch_store
from fullstack import validation_execution_store as execution_store

SCHEMA_VERSION = "validation-runtime-handoff-v1"
POLICY_VERSION = "single-dispatch-intent-single-runtime-handoff-v1"
HANDOFF_RECEIPT_SCHEMA = "validation-runtime-handoff-receipt-v1"
OBSERVATION_RECEIPT_SCHEMA = "validation-runtime-observation-receipt-v1"
HANDOFF_ISSUER = "plw.fullstack.validation-runtime-handoff.v1"
OBSERVATION_ISSUER = "plw.fullstack.validation-runtime-observation.v1"
TABLE_NAME = "validation_runtime_dispatches_v1"
OBSERVATION_TABLE = "validation_runtime_observations_v1"
_RUNTIME_KEY = re.compile(r"[A-Za-z0-9][A-Za-z0-9._:-]{15,127}\Z")
TERMINAL_STATUSES = frozenset({"SUCCEEDED", "FAILED", "INDETERMINATE"})
NONTERMINAL_RECONCILIATION_STATES = frozenset({"PENDING", "NOT_FOUND", "UNKNOWN"})
TERMINAL_RECONCILIATION_STATES = frozenset({"RESOLVED"})
DISPATCH_STATES = frozenset({"ACKNOWLEDGED", "REJECTED", "UNKNOWN"})

_HANDOFF_ROW_KEYS = (
    "handoff_id", "dispatch_intent_id", "attempt_id", "lease_id", "runtime_key",
    "validator_id", "executor_id", "operation_key", "claimed_at_epoch",
)
_HANDOFF_BODY_KEYS = (frozenset(_HANDOFF_ROW_KEYS) - {"handoff_id"}) | {
    "schema_version", "policy", "handoff_state", "authority_class", "scope",
}
_HANDOFF_RECEIPT_KEYS = _HANDOFF_BODY_KEYS | {"handoff_id", "provenance"}
_OBSERVATION_ROW_KEYS = (
    "observation_id", "handoff_id", "dispatch_intent_id", "ordinal",
    "observation_key_digest", "observation_digest", "dispatch_state",
    "reconciliation_state", "terminal_status", "observed_at_epoch",
)
_OBSERVATION_BODY_KEYS = (frozenset(_OBSERVATION_ROW_KEYS) - {"observation_id"}) | {
    "schema_version", "policy", "observation_kind", "evidence_ids",
    "authority_class", "scope",
}
_OBSERVATION_RECEIPT_KEYS = _OBSERVATION_BODY_KEYS | {"observation_id", "provenance"}


class ValidationRuntimeError(ValueError):
    pass


@runtime_checkable
class ValidationRuntimeAdapter(Protocol):
    validator_id: str
    executor_id: str

    def dispatch(self, context: Mapping[str, Any]) -> Mapping[str, Any]: ...
    def reconcile(self, context: Mapping[str, Any]) -> Mapping[str, Any]: ...


def _open(store_dir, *, writable: bool) -> sqlite3.Connection:
    try:
        return execution_store.open_validation_store(store_dir, writable=writable, create=False)
    except (execution_store.ValidationExecutionStoreError, FileNotFoundError) as exc:
        raise ValidationRuntimeError("validation_execution_store_unavailable") from exc


def _parent(conn, dispatch_intent_id: str, store_dir) -> dict:
    try:
        return dispatch_store.load_validation_dispatch_intent_receipt(
            conn, dispatch_intent_id, store_dir=store_dir
        )
    except dispatch_store.ValidationDispatchError as exc:
        raise ValidationRuntimeError(str(exc)) from exc


def _initialize(conn) -> None:
    conn.execute(f"""CREATE TABLE IF NOT EXISTS {TABLE_NAME} (
        handoff_id TEXT PRIMARY KEY NOT NULL,
        dispatch_intent_id TEXT NOT NULL UNIQUE REFERENCES {dispatch_store.TABLE_NAME}(dispatch_intent_id),
        attempt_id TEXT NOT NULL,
        lease_id TEXT NOT NULL,
        runtime_key TEXT NOT NULL UNIQUE,
        validator_id TEXT NOT NULL,
        executor_id TEXT NOT NULL,
        operation_key TEXT NOT NULL,
        claimed_at_epoch INTEGER NOT NULL,
        receipt_json TEXT NOT NULL
    )""")
    conn.execute(f"""CREATE TABLE IF NOT EXISTS {OBSERVATION_TABLE} (
        observation_id TEXT PRIMARY KEY NOT NULL,
        handoff_id TEXT NOT NULL REFERENCES {TABLE_NAME}(handoff_id),
        dispatch_intent_id TEXT NOT NULL,
        ordinal INTEGER NOT NULL,
        observation_key_digest TEXT NOT NULL,
        observation_digest TEXT NOT NULL,
        dispatch_state TEXT NOT NULL,
        reconciliation_state TEXT NOT NULL,
        terminal_status TEXT NOT NULL,
        observed_at_epoch INTEGER NOT NULL,
        receipt_json TEXT NOT NULL,
        UNIQUE(handoff_id, ordinal),
        UNIQUE(handoff_id, observation_key_digest)
    )""")
    conn.execute(
        f"CREATE UNIQUE INDEX IF NOT EXISTS one_terminal_validation_runtime_observation "
        f"ON {OBSERVATION_TABLE}(handoff_id) WHERE terminal_status <> ''"
    )
    execution_store.register_store_feature(conn, "runtime_dispatch", 1, TABLE_NAME)


def _handoff_row(conn, dispatch_intent_id: str):
    return execution_store.load_validation_feature_row(
        conn, table_name=TABLE_NAME, select_columns=(*_HANDOFF_ROW_KEYS, "receipt_json"),
        key_column="dispatch_intent_id", key_value=dispatch_intent_id,
    )


def _verify_handoff(row, parent: Mapping[str, Any], store_dir) -> dict:
    try:
        receipt = json.loads(row["receipt_json"])
        if not exact_keys(receipt, _HANDOFF_RECEIPT_KEYS):
            raise ValidationRuntimeError("runtime_handoff_receipt_schema")
        body = {key: receipt[key] for key in _HANDOFF_BODY_KEYS}
        if (
            execution_store.bounded_validation_digest(body) != receipt["handoff_id"]
            or not is_sha256_id(receipt["handoff_id"])
            or not verify_payload(body, receipt["provenance"], HANDOFF_ISSUER, store_dir=store_dir)
        ):
            raise ValidationRuntimeError("runtime_handoff_receipt_verification_failed")
        if any(type(row[k]) is not type(receipt[k]) or row[k] != receipt[k] for k in _HANDOFF_ROW_KEYS):
            raise ValidationRuntimeError("runtime_handoff_row_binding_mismatch")
        expected = {
            "schema_version": HANDOFF_RECEIPT_SCHEMA,
            "policy": POLICY_VERSION,
            "handoff_state": "CLAIMED",
            "authority_class": "validation_runtime_handoff",
            "scope": "single_F136_intent_single_runtime_handoff",
            "dispatch_intent_id": parent["dispatch_intent_id"],
            "attempt_id": parent["attempt_id"],
            "lease_id": parent["lease_id"],
            "validator_id": parent["validator_id"],
            "executor_id": parent["executor_id"],
            "operation_key": parent["operation_key"],
        }
        if any(type(receipt[k]) is not type(v) or receipt[k] != v for k, v in expected.items()):
            raise ValidationRuntimeError("runtime_handoff_parent_binding_mismatch")
        if type(receipt["claimed_at_epoch"]) is not int or receipt["claimed_at_epoch"] < parent["prepared_at_epoch"]:
            raise ValidationRuntimeError("runtime_handoff_time")
        return receipt
    except ValidationRuntimeError:
        raise
    except (TypeError, ValueError, KeyError, RecursionError) as exc:
        raise ValidationRuntimeError("runtime_handoff_receipt_corrupt") from exc


def claim_validation_runtime_handoff(
    dispatch_intent_id: str, runtime_key: str, *, store_dir=None, _fail_before_commit: bool = False
) -> dict:
    """Atomically claim one pre-host handoff; no adapter call occurs here."""
    conn = None
    try:
        if not is_sha256_id(dispatch_intent_id):
            raise ValidationRuntimeError("invalid_dispatch_intent_id")
        if not isinstance(runtime_key, str) or not _RUNTIME_KEY.fullmatch(runtime_key):
            raise ValidationRuntimeError("runtime_key")
        conn = _open(store_dir, writable=True)
        conn.execute("BEGIN IMMEDIATE")
        parent = _parent(conn, dispatch_intent_id, store_dir)
        prior_row = _handoff_row(conn, dispatch_intent_id)
        if prior_row is not None:
            prior = _verify_handoff(prior_row, parent, store_dir)
            if prior["runtime_key"] != runtime_key:
                raise ValidationRuntimeError("dispatch_intent_runtime_handoff_already_claimed")
            conn.execute("COMMIT")
            return _handoff_result("recovered", prior)
        if execution_store.validation_table_exists(conn, TABLE_NAME):
            if conn.execute(f"SELECT 1 FROM {TABLE_NAME} WHERE runtime_key=?", (runtime_key,)).fetchone():
                raise ValidationRuntimeError("runtime_key_conflict")
        _initialize(conn)
        body = {
            "schema_version": HANDOFF_RECEIPT_SCHEMA,
            "policy": POLICY_VERSION,
            "handoff_state": "CLAIMED",
            "dispatch_intent_id": parent["dispatch_intent_id"],
            "attempt_id": parent["attempt_id"],
            "lease_id": parent["lease_id"],
            "runtime_key": runtime_key,
            "validator_id": parent["validator_id"],
            "executor_id": parent["executor_id"],
            "operation_key": parent["operation_key"],
            "claimed_at_epoch": int(time.time()),
            "authority_class": "validation_runtime_handoff",
            "scope": "single_F136_intent_single_runtime_handoff",
        }
        receipt = {
            **body,
            "handoff_id": execution_store.bounded_validation_digest(body),
            "provenance": seal_payload(body, HANDOFF_ISSUER, store_dir=store_dir),
        }
        if not receipt["handoff_id"]:
            raise ValidationRuntimeError("runtime_handoff_bounded_json")
        conn.execute(
            f"INSERT INTO {TABLE_NAME} ({', '.join((*_HANDOFF_ROW_KEYS, 'receipt_json'))}) "
            f"VALUES ({','.join('?' for _ in range(len(_HANDOFF_ROW_KEYS)+1))})",
            (*[receipt[k] for k in _HANDOFF_ROW_KEYS], json.dumps(receipt, ensure_ascii=False, sort_keys=True)),
        )
        if _fail_before_commit:
            raise ValidationRuntimeError("injected_precommit_failure")
        conn.execute("COMMIT")
        return _handoff_result("claimed", receipt)
    except (ValidationRuntimeError, sqlite3.Error, OSError, ValueError) as exc:
        return _handoff_result("rejected", failures=[str(exc)])
    finally:
        if conn is not None:
            if conn.in_transaction:
                conn.rollback()
            conn.close()


def _handoff_result(status: str, receipt=None, failures=()) -> dict:
    stored = receipt or {}
    claimed = status == "claimed"
    recovered = status == "recovered"
    return {
        "schema_version": SCHEMA_VERSION,
        "policy": POLICY_VERSION,
        "decision": {
            "claimed": "VALIDATION_RUNTIME_HANDOFF_CLAIMED",
            "recovered": "VALIDATION_RUNTIME_HANDOFF_RECOVERED_RECONCILIATION_REQUIRED",
        }.get(status, "VALIDATION_RUNTIME_HANDOFF_REJECTED"),
        "handoff_claimed": claimed,
        "idempotent_recovery": recovered,
        "reconciliation_required": recovered,
        "handoff_id": stored.get("handoff_id", ""),
        "dispatch_intent_id": stored.get("dispatch_intent_id", ""),
        "handoff_receipt": stored,
        "failed_conditions": list(failures),
        "runtime_dispatch_observed": False,
        "runtime_dispatch_state_authority": False,
        "runtime_dispatch_state": "UNKNOWN_TO_F137",
        "validator_executed": False,
        "evidence_accepted": False,
        "postcondition_proven": False,
        "truth_committed": False,
        "authority": {
            "durable_state_changed": claimed,
            "external_execution_allowed_by_this_result": False,
            "evidence_acceptance": False,
            "postcondition": False,
            "truth": False,
        },
    }


def _normalize_observation(raw: Mapping[str, Any]) -> dict:
    if not isinstance(raw, Mapping):
        raise ValidationRuntimeError("runtime_observation_mapping")
    reconciliation_state = str(raw.get("reconciliation_state") or "UNKNOWN")
    if reconciliation_state not in NONTERMINAL_RECONCILIATION_STATES | TERMINAL_RECONCILIATION_STATES:
        raise ValidationRuntimeError("reconciliation_state")
    dispatch_state = str(raw.get("dispatch_state") or "UNKNOWN")
    if dispatch_state not in DISPATCH_STATES:
        raise ValidationRuntimeError("dispatch_state")
    terminal_status = str(raw.get("terminal_status") or "")
    if reconciliation_state in NONTERMINAL_RECONCILIATION_STATES and terminal_status:
        raise ValidationRuntimeError("nonterminal_reconciliation_cannot_claim_terminal")
    if reconciliation_state in TERMINAL_RECONCILIATION_STATES and terminal_status not in TERMINAL_STATUSES:
        raise ValidationRuntimeError("terminal_reconciliation_status_required")
    kind = str(raw.get("observation_kind") or "runtime_status")
    observation = raw.get("observation")
    digest = execution_store.bounded_validation_digest(observation)
    if digest is None:
        raise ValidationRuntimeError("runtime_observation_bounded_json")
    evidence_ids = raw.get("evidence_ids") or []
    if not isinstance(evidence_ids, Sequence) or isinstance(evidence_ids, (str, bytes)):
        raise ValidationRuntimeError("evidence_ids")
    clean_ids = []
    for item in evidence_ids:
        if not is_sha256_id(item):
            raise ValidationRuntimeError("evidence_id")
        clean_ids.append(str(item))
    return {
        "dispatch_state": dispatch_state,
        "reconciliation_state": reconciliation_state,
        "terminal_status": terminal_status,
        "observation_kind": kind,
        "observation_digest": digest,
        "evidence_ids": sorted(set(clean_ids)),
    }


def _observation_key(normalized: Mapping[str, Any]) -> str:
    return execution_store.bounded_validation_digest({
        "dispatch_state": normalized["dispatch_state"],
        "reconciliation_state": normalized["reconciliation_state"],
        "terminal_status": normalized["terminal_status"],
        "observation_kind": normalized["observation_kind"],
        "observation_digest": normalized["observation_digest"],
        "evidence_ids": normalized["evidence_ids"],
    }) or ""


def record_validation_runtime_observation(
    dispatch_intent_id: str, observation: Mapping[str, Any], *, store_dir=None, _fail_before_commit: bool = False
) -> dict:
    """Append one digest-only host observation and preserve unresolved states."""
    conn = None
    try:
        normalized = _normalize_observation(observation)
        key = _observation_key(normalized)
        conn = _open(store_dir, writable=True)
        conn.execute("BEGIN IMMEDIATE")
        parent = _parent(conn, dispatch_intent_id, store_dir)
        row = _handoff_row(conn, dispatch_intent_id)
        if row is None:
            raise ValidationRuntimeError("runtime_handoff_not_claimed")
        handoff = _verify_handoff(row, parent, store_dir)
        _initialize(conn)
        prior = conn.execute(
            f"SELECT {', '.join((*_OBSERVATION_ROW_KEYS, 'receipt_json'))} FROM {OBSERVATION_TABLE} "
            "WHERE handoff_id=? AND observation_key_digest=?",
            (handoff["handoff_id"], key),
        ).fetchone()
        if prior is not None:
            receipt = _verify_observation(prior, handoff, store_dir)
            conn.execute("COMMIT")
            return _observation_result("recovered", receipt)
        if normalized["terminal_status"]:
            terminal = conn.execute(
                f"SELECT 1 FROM {OBSERVATION_TABLE} WHERE handoff_id=? AND terminal_status<>''",
                (handoff["handoff_id"],),
            ).fetchone()
            if terminal:
                raise ValidationRuntimeError("runtime_terminal_already_recorded")
        ordinal = int(conn.execute(
            f"SELECT count(*) FROM {OBSERVATION_TABLE} WHERE handoff_id=?", (handoff["handoff_id"],)
        ).fetchone()[0]) + 1
        now = int(time.time())
        body = {
            "schema_version": OBSERVATION_RECEIPT_SCHEMA,
            "policy": POLICY_VERSION,
            "handoff_id": handoff["handoff_id"],
            "dispatch_intent_id": handoff["dispatch_intent_id"],
            "ordinal": ordinal,
            "observation_key_digest": key,
            "observation_digest": normalized["observation_digest"],
            "dispatch_state": normalized["dispatch_state"],
            "reconciliation_state": normalized["reconciliation_state"],
            "terminal_status": normalized["terminal_status"],
            "observed_at_epoch": now,
            "observation_kind": normalized["observation_kind"],
            "evidence_ids": normalized["evidence_ids"],
            "authority_class": "validation_runtime_observation",
            "scope": "runtime_status_observation_only",
        }
        receipt = {**body, "observation_id": execution_store.bounded_validation_digest(body),
                   "provenance": seal_payload(body, OBSERVATION_ISSUER, store_dir=store_dir)}
        if not receipt["observation_id"]:
            raise ValidationRuntimeError("runtime_observation_receipt_bounded_json")
        conn.execute(
            f"INSERT INTO {OBSERVATION_TABLE} ({', '.join((*_OBSERVATION_ROW_KEYS, 'receipt_json'))}) "
            f"VALUES ({','.join('?' for _ in range(len(_OBSERVATION_ROW_KEYS)+1))})",
            (*[receipt[k] for k in _OBSERVATION_ROW_KEYS], json.dumps(receipt, ensure_ascii=False, sort_keys=True)),
        )
        if _fail_before_commit:
            raise ValidationRuntimeError("injected_precommit_failure")
        conn.execute("COMMIT")
        return _observation_result("recorded", receipt)
    except (ValidationRuntimeError, sqlite3.Error, OSError, ValueError) as exc:
        return _observation_result("rejected", failures=[str(exc)])
    finally:
        if conn is not None:
            if conn.in_transaction:
                conn.rollback()
            conn.close()


def _verify_observation(row, handoff: Mapping[str, Any], store_dir) -> dict:
    try:
        receipt = json.loads(row["receipt_json"])
        if not exact_keys(receipt, _OBSERVATION_RECEIPT_KEYS):
            raise ValidationRuntimeError("runtime_observation_receipt_schema")
        body = {k: receipt[k] for k in _OBSERVATION_BODY_KEYS}
        if (
            execution_store.bounded_validation_digest(body) != receipt["observation_id"]
            or not verify_payload(body, receipt["provenance"], OBSERVATION_ISSUER, store_dir=store_dir)
        ):
            raise ValidationRuntimeError("runtime_observation_receipt_verification_failed")
        if any(type(row[k]) is not type(receipt[k]) or row[k] != receipt[k] for k in _OBSERVATION_ROW_KEYS):
            raise ValidationRuntimeError("runtime_observation_row_binding_mismatch")
        if receipt["handoff_id"] != handoff["handoff_id"] or receipt["dispatch_intent_id"] != handoff["dispatch_intent_id"]:
            raise ValidationRuntimeError("runtime_observation_parent_binding_mismatch")
        _normalize_observation({
            "dispatch_state": receipt["dispatch_state"],
            "reconciliation_state": receipt["reconciliation_state"],
            "terminal_status": receipt["terminal_status"],
            "observation_kind": receipt["observation_kind"],
            "observation": {"digest_witness": receipt["observation_digest"]},
            "evidence_ids": receipt["evidence_ids"],
        })
        return receipt
    except ValidationRuntimeError:
        raise
    except (TypeError, ValueError, KeyError, RecursionError) as exc:
        raise ValidationRuntimeError("runtime_observation_receipt_corrupt") from exc


def _observation_result(status: str, receipt=None, failures=()) -> dict:
    stored = receipt or {}
    terminal = stored.get("terminal_status", "")
    reconciliation = stored.get("reconciliation_state", "")
    return {
        "schema_version": SCHEMA_VERSION,
        "decision": {
            "recorded": "VALIDATION_RUNTIME_OBSERVATION_RECORDED",
            "recovered": "VALIDATION_RUNTIME_OBSERVATION_RECOVERED",
        }.get(status, "VALIDATION_RUNTIME_OBSERVATION_REJECTED"),
        "observation_recorded": status == "recorded",
        "idempotent_recovery": status == "recovered",
        "observation_receipt": stored,
        "failed_conditions": list(failures),
        "runtime_terminal": terminal in TERMINAL_STATUSES,
        "runtime_terminal_status": terminal,
        "reconciliation_state": reconciliation,
        "evidence_accepted": False,
        "postcondition_proven": False,
        "truth_committed": False,
        "proof_boundary": {
            "runtime_terminal_is_evidence_acceptance": False,
            "runtime_terminal_is_postcondition_proof": False,
            "runtime_terminal_is_truth": False,
        },
    }


def load_validation_runtime_observation_receipt(
    connection: sqlite3.Connection,
    observation_id: str,
    *,
    store_dir=None,
) -> dict:
    """Return one verified F137 observation inside the caller's SQLite snapshot."""
    if not is_sha256_id(observation_id):
        raise ValidationRuntimeError("invalid_runtime_observation_id")
    row = execution_store.load_validation_feature_row(
        connection, table_name=OBSERVATION_TABLE,
        select_columns=(*_OBSERVATION_ROW_KEYS, "receipt_json"),
        key_column="observation_id", key_value=observation_id,
    )
    if row is None:
        raise ValidationRuntimeError("runtime_observation_not_found")
    parent = _parent(connection, row["dispatch_intent_id"], store_dir)
    handoff_row = _handoff_row(connection, row["dispatch_intent_id"])
    if handoff_row is None:
        raise ValidationRuntimeError("runtime_handoff_not_claimed")
    handoff = _verify_handoff(handoff_row, parent, store_dir)
    if handoff["handoff_id"] != row["handoff_id"]:
        raise ValidationRuntimeError("runtime_observation_handoff_binding_mismatch")
    return _verify_observation(row, handoff, store_dir)


def inspect_validation_runtime(dispatch_intent_id: str, *, store_dir=None) -> dict:
    conn = None
    try:
        if not is_sha256_id(dispatch_intent_id):
            raise ValidationRuntimeError("invalid_dispatch_intent_id")
        conn = _open(store_dir, writable=False)
        conn.execute("BEGIN")
        parent = _parent(conn, dispatch_intent_id, store_dir)
        row = _handoff_row(conn, dispatch_intent_id)
        if row is None:
            raise ValidationRuntimeError("runtime_handoff_not_claimed")
        handoff = _verify_handoff(row, parent, store_dir)
        observations = []
        if execution_store.validation_table_exists(conn, OBSERVATION_TABLE):
            rows = conn.execute(
                f"SELECT {', '.join((*_OBSERVATION_ROW_KEYS, 'receipt_json'))} FROM {OBSERVATION_TABLE} "
                "WHERE handoff_id=? ORDER BY ordinal", (handoff["handoff_id"],)
            ).fetchall()
            observations = [_verify_observation(item, handoff, store_dir) for item in rows]
        terminal = next((r for r in observations if r["terminal_status"] in TERMINAL_STATUSES), None)
        return {
            "runtime_state_found": True,
            "decision": "VALIDATION_RUNTIME_RESOLVED" if terminal else "VALIDATION_RUNTIME_UNRESOLVED",
            "handoff_receipt": handoff,
            "observation_count": len(observations),
            "observation_ids": [r["observation_id"] for r in observations],
            "runtime_terminal": terminal is not None,
            "runtime_terminal_status": terminal["terminal_status"] if terminal else "",
            "reconciliation_required": terminal is None,
            "runtime_dispatch_state_authority": True,
            "runtime_dispatch_state": "RESOLVED" if terminal else "UNRESOLVED",
            "evidence_accepted": False,
            "postcondition_proven": False,
            "truth_committed": False,
            "next_boundary": "VALIDATION_RESULT_EVIDENCE_ACCEPTANCE" if terminal else "VALIDATION_RUNTIME_RECONCILIATION",
        }
    except (ValidationRuntimeError, sqlite3.Error, OSError, ValueError) as exc:
        return {
            "runtime_state_found": False,
            "error": str(exc),
            "runtime_dispatch_state_authority": False,
            "runtime_dispatch_state": "UNKNOWN_TO_F137",
            "truth_committed": False,
        }
    finally:
        if conn is not None:
            conn.close()


def _adapter_identity(adapter: ValidationRuntimeAdapter, parent: Mapping[str, Any]) -> None:
    if not isinstance(adapter, ValidationRuntimeAdapter):
        raise ValidationRuntimeError("runtime_adapter_protocol")
    if adapter.validator_id != parent["validator_id"] or adapter.executor_id != parent["executor_id"]:
        raise ValidationRuntimeError("runtime_adapter_identity_mismatch")


def _context(parent: Mapping[str, Any], handoff: Mapping[str, Any]) -> dict:
    return {
        "dispatch_intent_id": parent["dispatch_intent_id"],
        "handoff_id": handoff["handoff_id"],
        "attempt_id": parent["attempt_id"],
        "lease_id": parent["lease_id"],
        "request_id": parent["request_id"],
        "scenario_id": parent["scenario_id"],
        "validator_id": parent["validator_id"],
        "executor_id": parent["executor_id"],
        "operation_key": parent["operation_key"],
    }


def invoke_validation_runtime_adapter(
    dispatch_intent_id: str, runtime_key: str, adapter: ValidationRuntimeAdapter,
    *, allow_external_execution: bool = False, store_dir=None,
) -> dict:
    """Claim then invoke host dispatch only on first handoff; recovered handoff reconciles."""
    if allow_external_execution is not True:
        return {"adapter_invoked": False, "error": "explicit_external_execution_acknowledgement_required"}
    claim = claim_validation_runtime_handoff(dispatch_intent_id, runtime_key, store_dir=store_dir)
    if not claim.get("handoff_claimed"):
        if claim.get("idempotent_recovery"):
            return {
                "adapter_invoked": False,
                "reconciliation_required": True,
                "decision": "VALIDATION_RUNTIME_RECOVERED_HANDOFF_REQUIRES_RECONCILIATION",
                "handoff_receipt": claim.get("handoff_receipt", {}),
            }
        return {"adapter_invoked": False, "failed_conditions": claim.get("failed_conditions", [])}
    conn = None
    try:
        conn = _open(store_dir, writable=False)
        conn.execute("BEGIN")
        parent = _parent(conn, dispatch_intent_id, store_dir)
        _adapter_identity(adapter, parent)
        context = _context(parent, claim["handoff_receipt"])
    except ValidationRuntimeError as exc:
        return {"adapter_invoked": False, "error": str(exc), "reconciliation_required": True}
    finally:
        if conn is not None:
            conn.close()
    try:
        raw = adapter.dispatch(context)
    except Exception as exc:
        return {
            "adapter_invoked": True,
            "adapter_error": type(exc).__name__,
            "reconciliation_required": True,
            "decision": "VALIDATION_RUNTIME_DISPATCH_EXCEPTION_AMBIGUOUS",
        }
    recorded = record_validation_runtime_observation(dispatch_intent_id, raw, store_dir=store_dir)
    return {"adapter_invoked": True, "reconciliation_required": not recorded.get("runtime_terminal", False), "observation": recorded}


def reconcile_validation_runtime_adapter(
    dispatch_intent_id: str, adapter: ValidationRuntimeAdapter, *, store_dir=None
) -> dict:
    state = inspect_validation_runtime(dispatch_intent_id, store_dir=store_dir)
    if not state.get("runtime_state_found"):
        return {"adapter_queried": False, "error": state.get("error", "runtime_state_missing")}
    if state.get("runtime_terminal"):
        return {"adapter_queried": False, "already_terminal": True, "state": state}
    handoff = state["handoff_receipt"]
    conn = _open(store_dir, writable=False)
    try:
        conn.execute("BEGIN")
        parent = _parent(conn, dispatch_intent_id, store_dir)
        _adapter_identity(adapter, parent)
        context = _context(parent, handoff)
    except ValidationRuntimeError as exc:
        return {"adapter_queried": False, "error": str(exc)}
    finally:
        conn.close()
    try:
        raw = adapter.reconcile(context)
    except Exception as exc:
        return {"adapter_queried": True, "error": type(exc).__name__, "reconciliation_required": True}
    recorded = record_validation_runtime_observation(dispatch_intent_id, raw, store_dir=store_dir)
    return {
        "adapter_queried": True,
        "observation": recorded,
        "reconciliation_required": not recorded.get("runtime_terminal", False),
        "runtime_terminal_status": recorded.get("runtime_terminal_status", ""),
    }


__all__ = [
    "SCHEMA_VERSION", "POLICY_VERSION", "HANDOFF_RECEIPT_SCHEMA", "OBSERVATION_RECEIPT_SCHEMA",
    "TABLE_NAME", "OBSERVATION_TABLE", "TERMINAL_STATUSES", "ValidationRuntimeError",
    "ValidationRuntimeAdapter", "claim_validation_runtime_handoff", "record_validation_runtime_observation",
    "load_validation_runtime_observation_receipt", "inspect_validation_runtime",
    "invoke_validation_runtime_adapter", "reconcile_validation_runtime_adapter",
]
