"""F134 single-use lease for one exact F133 validation authorization binding.

F134 is the first state-changing boundary in the validation-execution branch.
It semantically re-verifies F132 + F133, then atomically consumes one exact
F133 authorization binding into a short-lived lease.  The lease is durable
coordination metadata only: it does not register an attempt, prepare an adapter
dispatch, execute a validator/runtime, return evidence, prove a postcondition,
or commit truth.

Exact replay of the same idempotency key recovers the existing receipt but does
not grant a second downstream-start authorization.  A different idempotency key
cannot consume the same F133 authorization binding twice.
"""
from __future__ import annotations

import json
import os
import re
import sqlite3
import time
from collections.abc import Mapping
from pathlib import Path
from typing import Any, Dict

from core.accountability_provenance import seal_payload, verify_payload
from core.capability_contracts import exact_keys, is_sha256_id, safe_canonical_digest
from fullstack import validation_execution_store as execution_store
from fullstack.validation_authorization import (
    SCHEMA_VERSION as AUTHORIZATION_BINDING_SCHEMA_VERSION,
    ValidationAuthorizationError,
    verify_validation_authorization_binding,
)

SCHEMA_VERSION = "validation-execution-lease-request-v1"
POLICY_VERSION = "single-use-validation-execution-lease-v1"
DECISION_TYPE = "validation_execution_lease"
LEASE_RECEIPT_SCHEMA = "validation-execution-lease-receipt-v1"
LEASE_RECEIPT_ISSUER = "plw.fullstack.validation-execution-lease.v1"
LEASE_DATABASE_SCHEMA_VERSION = execution_store.BASE_SCHEMA_VERSION
MAX_LEASE_TTL_SECONDS = 30

_IDEMPOTENCY_KEY = re.compile(r"[A-Za-z0-9][A-Za-z0-9._:-]{15,127}\Z")
_REQUEST_KEYS = frozenset({
    "schema_version", "policy", "authorization_binding_digest", "request_id",
    "request_set_digest", "scenario_id", "validator_id", "executor_id",
    "operation_key", "idempotency_key", "lease_ttl_seconds",
    "caller_requests_validation_execution_lease", "authority", "authorizations",
})
_AUTHORIZATION_KEYS = frozenset({
    "attempt_registration", "adapter_dispatch", "runtime_execution",
    "evidence_acceptance", "postcondition", "truth",
})
_RECEIPT_BODY_KEYS = frozenset({
    "schema_version", "decision_type", "policy", "lease_state",
    "lease_request_digest", "authorization_binding_digest",
    "authorization_assertion_digest", "request_id", "request_set_digest",
    "scenario_id", "validator_id", "executor_id", "operation_key",
    "authorization_principal", "idempotency_key", "acquired_at_epoch",
    "expires_at_epoch", "authority_class", "scope",
})
_RECEIPT_KEYS = _RECEIPT_BODY_KEYS | {"lease_id", "provenance"}
_ROW_BINDING_KEYS = (
    "lease_id", "lease_request_digest", "authorization_binding_digest",
    "authorization_assertion_digest", "request_id", "executor_id",
    "idempotency_key", "acquired_at_epoch", "expires_at_epoch",
)
_ROW_SELECT = ", ".join((*_ROW_BINDING_KEYS, "receipt_json"))


class ValidationLeaseError(ValueError):
    """Raised for malformed F134 request or semantic binding failures."""


def _lease_database_path(store_dir: str | os.PathLike[str] | None) -> Path:
    return execution_store.validation_store_path(store_dir)


def _initialize_database(path: Path) -> sqlite3.Connection:
    if path.is_symlink():
        raise ValidationLeaseError("validation lease database must not be a symbolic link")
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    try:
        os.chmod(path.parent, 0o700)
    except OSError:
        pass
    connection = sqlite3.connect(str(path), timeout=5.0, isolation_level=None)
    connection.row_factory = sqlite3.Row
    try:
        connection.execute("PRAGMA busy_timeout=5000")
        connection.execute("PRAGMA foreign_keys=ON")
        connection.execute("PRAGMA synchronous=FULL")
        connection.execute("PRAGMA journal_mode=DELETE")
        connection.execute("BEGIN IMMEDIATE")
        version = int(connection.execute("PRAGMA user_version").fetchone()[0])
        if version not in (0, LEASE_DATABASE_SCHEMA_VERSION):
            raise ValidationLeaseError("unsupported validation lease database schema")
        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS validation_execution_leases (
                lease_id TEXT PRIMARY KEY,
                lease_request_digest TEXT NOT NULL,
                authorization_binding_digest TEXT NOT NULL UNIQUE,
                authorization_assertion_digest TEXT NOT NULL UNIQUE,
                request_id TEXT NOT NULL,
                executor_id TEXT NOT NULL,
                idempotency_key TEXT NOT NULL UNIQUE,
                acquired_at_epoch INTEGER NOT NULL,
                expires_at_epoch INTEGER NOT NULL,
                receipt_json TEXT NOT NULL
            )
            """
        )
        execution_store.register_store_feature(connection, "lease", 1, "validation_execution_leases")
        if version == 0:
            connection.execute(f"PRAGMA user_version={LEASE_DATABASE_SCHEMA_VERSION}")
        connection.execute("COMMIT")
        try:
            os.chmod(path, 0o600)
        except OSError:
            pass
        return connection
    except Exception:
        try:
            connection.execute("ROLLBACK")
        except sqlite3.Error:
            pass
        connection.close()
        raise


def _read_connection(path: Path) -> sqlite3.Connection:
    if not path.is_file() or path.is_symlink():
        raise FileNotFoundError("validation lease database is unavailable")
    connection = sqlite3.connect(path.as_uri() + "?mode=ro", uri=True, timeout=5.0)
    connection.row_factory = sqlite3.Row
    try:
        connection.execute("PRAGMA busy_timeout=5000")
        version = int(connection.execute("PRAGMA user_version").fetchone()[0])
        if version != LEASE_DATABASE_SCHEMA_VERSION:
            raise ValidationLeaseError("unsupported validation lease database schema")
        return connection
    except Exception:
        connection.close()
        raise


def _no_authorizations(value: Any) -> bool:
    return (
        isinstance(value, Mapping)
        and set(value) == _AUTHORIZATION_KEYS
        and all(value.get(key) is False for key in _AUTHORIZATION_KEYS)
    )


def build_validation_execution_lease_request(
    authorization_binding: Mapping[str, Any],
    idempotency_key: str,
    *,
    lease_ttl_seconds: int = 15,
) -> Dict[str, Any]:
    """Build a no-effect request from one F133 authorization binding."""
    source = authorization_binding if isinstance(authorization_binding, Mapping) else {}
    return {
        "schema_version": SCHEMA_VERSION,
        "policy": POLICY_VERSION,
        "authorization_binding_digest": str(source.get("validation_authorization_binding_digest") or ""),
        "request_id": str(source.get("request_id") or ""),
        "request_set_digest": str(source.get("request_set_digest") or ""),
        "scenario_id": str(source.get("scenario_id") or ""),
        "validator_id": str(source.get("validator_id") or ""),
        "executor_id": str(source.get("executor_id") or ""),
        "operation_key": str(source.get("operation_key") or ""),
        "idempotency_key": str(idempotency_key or ""),
        "lease_ttl_seconds": lease_ttl_seconds,
        "caller_requests_validation_execution_lease": True,
        "authority": "validation_execution_lease_request_only",
        "authorizations": {key: False for key in sorted(_AUTHORIZATION_KEYS)},
    }


def evaluate_validation_execution_lease(
    request: Mapping[str, Any],
    authorization_binding: Mapping[str, Any],
    request_set: Mapping[str, Any],
    request_id: str,
    assertion: Mapping[str, Any],
    *,
    plan: Mapping[str, Any],
    binding: Mapping[str, Any],
    obligation_set: Mapping[str, Any],
    validator_id: str,
    executor_id: str,
    store_dir: str | os.PathLike[str] | None = None,
    now_epoch: int | None = None,
) -> Dict[str, Any]:
    """Revalidate F133 and lease eligibility without changing durable state."""
    failures: list[str] = []
    req = dict(request) if isinstance(request, Mapping) else {}
    auth = dict(authorization_binding) if isinstance(authorization_binding, Mapping) else {}
    if not exact_keys(req, _REQUEST_KEYS):
        failures.append("request_exact_schema")
    if req.get("schema_version") != SCHEMA_VERSION:
        failures.append("schema_version")
    if req.get("policy") != POLICY_VERSION:
        failures.append("policy")
    if req.get("caller_requests_validation_execution_lease") is not True:
        failures.append("caller_requests_validation_execution_lease_is_true")
    if req.get("authority") != "validation_execution_lease_request_only" or not _no_authorizations(req.get("authorizations")):
        failures.append("request_must_have_no_execution_authority")

    try:
        verify_validation_authorization_binding(
            auth, request_set, request_id, assertion,
            plan=plan, binding=binding, obligation_set=obligation_set,
            validator_id=validator_id, executor_id=executor_id,
            store_dir=str(store_dir) if store_dir is not None else None,
            now_epoch=now_epoch,
        )
    except ValidationAuthorizationError as exc:
        failures.append("F133_authorization_binding:" + str(exc))

    binding_digest = auth.get("validation_authorization_binding_digest")
    if auth.get("schema_version") != AUTHORIZATION_BINDING_SCHEMA_VERSION or not is_sha256_id(binding_digest):
        failures.append("authorization_binding_identity")

    expected_fields = {
        "authorization_binding_digest": binding_digest,
        "request_id": auth.get("request_id"),
        "request_set_digest": auth.get("request_set_digest"),
        "scenario_id": auth.get("scenario_id"),
        "validator_id": validator_id,
        "executor_id": executor_id,
        "operation_key": auth.get("operation_key"),
    }
    for key, expected in expected_fields.items():
        if req.get(key) != expected:
            failures.append("request_binding_" + key)

    idempotency_key = req.get("idempotency_key")
    if not isinstance(idempotency_key, str) or _IDEMPOTENCY_KEY.fullmatch(idempotency_key) is None:
        failures.append("idempotency_key")
    ttl = req.get("lease_ttl_seconds")
    if type(ttl) is not int or not (1 <= ttl <= MAX_LEASE_TTL_SECONDS):
        failures.append("lease_ttl_seconds")

    current = int(time.time()) if now_epoch is None else now_epoch
    if type(current) is not int or current < 0:
        failures.append("evaluation_time")
        current = 0
    auth_expiry = auth.get("authorization_expires_at_epoch")
    if type(auth_expiry) is not int or auth_expiry <= current:
        failures.append("authorization_binding_expired")
        proposed_expiry = current
    else:
        proposed_expiry = min(current + ttl, auth_expiry) if type(ttl) is int else current
        if proposed_expiry <= current:
            failures.append("effective_lease_expiry")

    request_digest = safe_canonical_digest(req, max_bytes=65536)
    if request_digest is None:
        failures.append("lease_request_bounded_canonical_json")

    eligible = not failures
    return {
        "schema_version": SCHEMA_VERSION,
        "decision_type": DECISION_TYPE,
        "policy": POLICY_VERSION,
        "lease_eligible": eligible,
        "decision": "VALIDATION_EXECUTION_LEASE_ELIGIBLE" if eligible else "VALIDATION_EXECUTION_LEASE_REJECTED",
        "failed_conditions": failures,
        "lease_request_digest": request_digest or "",
        "authorization_binding_digest": str(binding_digest or ""),
        "authorization_assertion_digest": str(auth.get("authorization_assertion_digest") or ""),
        "request_id": str(auth.get("request_id") or ""),
        "request_set_digest": str(auth.get("request_set_digest") or ""),
        "scenario_id": str(auth.get("scenario_id") or ""),
        "validator_id": str(validator_id or ""),
        "executor_id": str(executor_id or ""),
        "operation_key": str(auth.get("operation_key") or ""),
        "authorization_principal": str(auth.get("authorization_principal") or ""),
        "idempotency_key": str(idempotency_key or ""),
        "evaluated_at_epoch": current,
        "proposed_expires_at_epoch": proposed_expiry,
        "authority": {
            "F133_authorization_semantics_reverified": not any(item.startswith("F133_authorization_binding:") for item in failures),
            "lease_eligibility_only": True,
            "durable_state_changed": False,
            "attempt_registered": False,
            "adapter_dispatch_prepared": False,
            "runtime_dispatched": False,
            "validator_executed": False,
            "evidence_returned": False,
            "postcondition_proven": False,
            "truth_committed": False,
        },
        "proof_boundary": {
            "eligibility_is_lease_acquisition": False,
            "eligibility_is_attempt_registration": False,
            "eligibility_is_dispatch": False,
            "eligibility_is_validator_execution": False,
        },
    }


def _verify_lease_receipt(receipt: Any, *, store_dir: str | os.PathLike[str] | None) -> bool:
    if not exact_keys(receipt, _RECEIPT_KEYS):
        return False
    assert isinstance(receipt, dict)
    body = {key: receipt[key] for key in _RECEIPT_BODY_KEYS}
    lease_id = safe_canonical_digest(body, max_bytes=65536)
    return (
        lease_id is not None
        and receipt.get("lease_id") == lease_id
        and verify_payload(body, receipt.get("provenance"), LEASE_RECEIPT_ISSUER, store_dir=store_dir)
    )


def _verified_row_receipt(
    row: sqlite3.Row, *, store_dir: str | os.PathLike[str] | None,
) -> Dict[str, Any]:
    """A signed receipt authenticates only its own exact durable row.

    Checking the MAC alone permits substitution of another valid receipt from
    the same store. Bind every indexed value, including the lookup identity and
    both timestamps, before inspection or idempotent recovery can trust it.
    """
    try:
        receipt = json.loads(row["receipt_json"])
    except (TypeError, ValueError, RecursionError) as exc:
        raise ValidationLeaseError("lease_receipt_corrupt") from exc
    try:
        verified = _verify_lease_receipt(receipt, store_dir=store_dir)
    except (TypeError, ValueError, RecursionError):
        verified = False
    if not verified:
        raise ValidationLeaseError("lease_receipt_verification_failed")
    if any(
        type(row[key]) is not type(receipt[key]) or row[key] != receipt[key]
        for key in _ROW_BINDING_KEYS
    ):
        raise ValidationLeaseError("lease_receipt_row_binding_mismatch")
    return receipt


def load_validation_execution_lease_receipt(
    connection: sqlite3.Connection, lease_id: str, *, store_dir=None
) -> Dict[str, Any]:
    if not is_sha256_id(lease_id):
        raise ValidationLeaseError("invalid_lease_id")
    row = connection.execute(
        f"SELECT {_ROW_SELECT} FROM validation_execution_leases WHERE lease_id = ?", (lease_id,)
    ).fetchone()
    if row is None:
        raise ValidationLeaseError("validation_lease_not_found")
    receipt = _verified_row_receipt(row, store_dir=store_dir)
    if (receipt.get("schema_version") != LEASE_RECEIPT_SCHEMA
            or receipt.get("policy") != POLICY_VERSION
            or receipt.get("lease_state") != "ACTIVE"
            or receipt.get("authority_class") != "validation_request_execution"
            or receipt.get("scope") != "single_F133_binding_single_validation_lease"):
        raise ValidationLeaseError("validation_lease_scope")
    acquired, expires = receipt.get("acquired_at_epoch"), receipt.get("expires_at_epoch")
    if (type(acquired) is not int or type(expires) is not int
            or acquired < 0 or not (1 <= expires - acquired <= MAX_LEASE_TTL_SECONDS)):
        raise ValidationLeaseError("validation_lease_time_contract")
    return receipt


def _claim_authorization_binding(
    eligibility: Mapping[str, Any],
    *,
    store_dir: str | os.PathLike[str] | None,
    fail_before_commit: bool = False,
) -> Dict[str, Any]:
    acquired_at = int(eligibility.get("evaluated_at_epoch") or int(time.time()))
    body = {
        "schema_version": LEASE_RECEIPT_SCHEMA,
        "decision_type": DECISION_TYPE,
        "policy": POLICY_VERSION,
        "lease_state": "ACTIVE",
        "lease_request_digest": str(eligibility.get("lease_request_digest") or ""),
        "authorization_binding_digest": str(eligibility.get("authorization_binding_digest") or ""),
        "authorization_assertion_digest": str(eligibility.get("authorization_assertion_digest") or ""),
        "request_id": str(eligibility.get("request_id") or ""),
        "request_set_digest": str(eligibility.get("request_set_digest") or ""),
        "scenario_id": str(eligibility.get("scenario_id") or ""),
        "validator_id": str(eligibility.get("validator_id") or ""),
        "executor_id": str(eligibility.get("executor_id") or ""),
        "operation_key": str(eligibility.get("operation_key") or ""),
        "authorization_principal": str(eligibility.get("authorization_principal") or ""),
        "idempotency_key": str(eligibility.get("idempotency_key") or ""),
        "acquired_at_epoch": acquired_at,
        "expires_at_epoch": int(eligibility.get("proposed_expires_at_epoch") or acquired_at),
        "authority_class": "validation_request_execution",
        "scope": "single_F133_binding_single_validation_lease",
    }
    lease_id = safe_canonical_digest(body, max_bytes=65536)
    if lease_id is None:
        return {"status": "store_error", "failed_conditions": ["lease_receipt_bounded_json"]}
    try:
        receipt = {
            "lease_id": lease_id,
            **body,
            "provenance": seal_payload(body, LEASE_RECEIPT_ISSUER, store_dir=store_dir),
        }
        connection = _initialize_database(_lease_database_path(store_dir))
    except Exception as exc:
        return {"status": "store_error", "failed_conditions": ["lease_store_open:" + type(exc).__name__]}

    try:
        connection.execute("BEGIN IMMEDIATE")
        existing = connection.execute(
            f"SELECT {_ROW_SELECT} FROM validation_execution_leases WHERE idempotency_key = ?",
            (body["idempotency_key"],),
        ).fetchone()
        if existing is not None:
            connection.execute("COMMIT")
            try:
                prior = _verified_row_receipt(existing, store_dir=store_dir)
            except ValidationLeaseError as exc:
                return {"status": "store_error", "failed_conditions": [str(exc)]}
            # A replay reuses the original times; all other signed fields must
            # describe this exact request and semantically reverified grant.
            replay_keys = _RECEIPT_BODY_KEYS - {"acquired_at_epoch", "expires_at_epoch"}
            if all(prior[key] == body[key] for key in replay_keys):
                return {"status": "recovered", "receipt": prior, "failed_conditions": []}
            return {"status": "conflict", "failed_conditions": ["idempotency_key_conflict"]}

        # Re-check real clock at the durable boundary; an F133 grant cannot be
        # extended by a stale eligibility object.
        if body["expires_at_epoch"] <= int(time.time()):
            connection.execute("ROLLBACK")
            return {"status": "conflict", "failed_conditions": ["effective_lease_expired_before_commit"]}
        try:
            connection.execute(
                """
                INSERT INTO validation_execution_leases (
                    lease_id, lease_request_digest, authorization_binding_digest,
                    authorization_assertion_digest, request_id, executor_id,
                    idempotency_key, acquired_at_epoch, expires_at_epoch, receipt_json
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    lease_id, body["lease_request_digest"], body["authorization_binding_digest"],
                    body["authorization_assertion_digest"], body["request_id"], body["executor_id"],
                    body["idempotency_key"], body["acquired_at_epoch"], body["expires_at_epoch"],
                    json.dumps(receipt, ensure_ascii=False, sort_keys=True, separators=(",", ":")),
                ),
            )
        except sqlite3.IntegrityError:
            failures: list[str] = []
            if connection.execute(
                "SELECT 1 FROM validation_execution_leases WHERE authorization_binding_digest = ?",
                (body["authorization_binding_digest"],),
            ).fetchone():
                failures.append("authorization_binding_already_consumed")
            if connection.execute(
                "SELECT 1 FROM validation_execution_leases WHERE authorization_assertion_digest = ?",
                (body["authorization_assertion_digest"],),
            ).fetchone():
                failures.append("authorization_assertion_already_consumed")
            connection.execute("ROLLBACK")
            return {"status": "conflict", "failed_conditions": failures or ["lease_unique_constraint"]}
        if fail_before_commit:
            raise RuntimeError("injected_precommit_failure")
        connection.execute("COMMIT")
        return {"status": "acquired", "receipt": receipt, "failed_conditions": []}
    except Exception as exc:
        try:
            connection.execute("ROLLBACK")
        except sqlite3.Error:
            pass
        return {"status": "store_error", "failed_conditions": ["lease_transaction:" + type(exc).__name__]}
    finally:
        connection.close()


def acquire_validation_execution_lease(
    request: Mapping[str, Any],
    authorization_binding: Mapping[str, Any],
    request_set: Mapping[str, Any],
    request_id: str,
    assertion: Mapping[str, Any],
    *,
    plan: Mapping[str, Any],
    binding: Mapping[str, Any],
    obligation_set: Mapping[str, Any],
    validator_id: str,
    executor_id: str,
    store_dir: str | os.PathLike[str] | None = None,
    _fail_before_commit: bool = False,
) -> Dict[str, Any]:
    """Atomically consume one exact F133 binding into one short-lived lease."""
    eligibility = evaluate_validation_execution_lease(
        request, authorization_binding, request_set, request_id, assertion,
        plan=plan, binding=binding, obligation_set=obligation_set,
        validator_id=validator_id, executor_id=executor_id, store_dir=store_dir,
    )
    if eligibility.get("lease_eligible") is not True:
        return {
            **eligibility,
            "lease_acquired": False,
            "idempotent_recovery": False,
            "attempt_registration_authorized": False,
            "durable_authorization_binding_consumed": False,
        }
    result = _claim_authorization_binding(
        eligibility, store_dir=store_dir, fail_before_commit=_fail_before_commit,
    )
    status = result.get("status")
    acquired = status == "acquired"
    recovered = status == "recovered"
    receipt = result.get("receipt") if isinstance(result.get("receipt"), dict) else {}
    return {
        **eligibility,
        "lease_eligible": True,
        "lease_acquired": acquired,
        "idempotent_recovery": recovered,
        "attempt_registration_authorized": acquired,
        "durable_authorization_binding_consumed": acquired or recovered,
        "decision": (
            "VALIDATION_EXECUTION_LEASE_ACQUIRED" if acquired
            else "VALIDATION_EXECUTION_LEASE_RECOVERED_NO_SECOND_ATTEMPT" if recovered
            else "VALIDATION_EXECUTION_LEASE_REJECTED"
        ),
        "failed_conditions": list(result.get("failed_conditions") or []),
        "lease_id": str(receipt.get("lease_id") or ""),
        "lease_receipt": receipt,
        "compare_and_swap": {
            "expected_authorization_binding_state": "UNCONSUMED",
            "observed_transition": "UNCONSUMED_TO_LEASED" if acquired else "UNCHANGED",
            "atomic": status in {"acquired", "recovered", "conflict"},
            "durable": status in {"acquired", "recovered"},
        },
        "authority": {
            **eligibility.get("authority", {}),
            "lease_eligibility_only": False,
            "durable_state_changed": acquired,
            "lease_acquired": acquired or recovered,
            "attempt_registration_authorized_by_this_call": acquired,
            "adapter_dispatch_prepared": False,
            "runtime_dispatched": False,
            "validator_executed": False,
            "evidence_returned": False,
            "postcondition_proven": False,
            "truth_committed": False,
        },
        "effects": {
            "lease_state_changed": acquired,
            "authorization_binding_consumed": acquired,
            "attempt_registered": False,
            "adapter_dispatch_prepared": False,
            "runtime_executed": False,
            "source_mutated": False,
            "truth_committed": False,
        },
        "handoff": {
            "request_id": str(receipt.get("request_id") or eligibility.get("request_id") or ""),
            "lease_id": str(receipt.get("lease_id") or ""),
            "operation_key": str(receipt.get("operation_key") or eligibility.get("operation_key") or ""),
            "required_next_boundary": "VALIDATION_ATTEMPT_REGISTRATION",
            "lease_binding_present": bool(receipt),
            "attempt_binding_present": False,
            "dispatch_binding_present": False,
            "may_dispatch": False,
            "recover": "register a durable validation attempt against this exact lease before any adapter/runtime dispatch; exact lease replay does not authorize a second attempt",
        },
        "proof_boundary": {
            "lease_acquisition_is_attempt_registration": False,
            "lease_acquisition_is_adapter_dispatch": False,
            "lease_acquisition_is_validator_execution": False,
            "lease_acquisition_is_evidence_return": False,
            "lease_acquisition_is_postcondition_proof": False,
            "lease_acquisition_is_truth": False,
        },
    }


def inspect_validation_execution_lease(
    lease_id: str,
    *,
    request_id: str | None = None,
    executor_id: str | None = None,
    store_dir: str | os.PathLike[str] | None = None,
) -> Dict[str, Any]:
    """Read one durable F134 lease without regranting attempt authority."""
    if not is_sha256_id(lease_id):
        return {"lease_found": False, "error": "invalid_lease_id"}
    try:
        connection = _read_connection(_lease_database_path(store_dir))
        try:
            receipt = load_validation_execution_lease_receipt(connection, lease_id, store_dir=store_dir)
        finally:
            connection.close()
    except (FileNotFoundError, ValidationLeaseError, sqlite3.Error, OSError) as exc:
        return {"lease_found": False, "error": str(exc)}
    if request_id is not None and receipt.get("request_id") != request_id:
        return {"lease_found": False, "error": "request_binding_mismatch"}
    if executor_id is not None and receipt.get("executor_id") != executor_id:
        return {"lease_found": False, "error": "executor_binding_mismatch"}
    active = type(receipt.get("expires_at_epoch")) is int and receipt["expires_at_epoch"] > int(time.time())
    return {
        "lease_found": True,
        "lease_active": active,
        "decision": "VALIDATION_EXECUTION_LEASE_ACTIVE" if active else "VALIDATION_EXECUTION_LEASE_EXPIRED",
        "lease_id": lease_id,
        "lease_receipt": receipt,
        "attempt_registration_authorized": False,
        "may_dispatch": False,
        "authority": "validation_execution_lease_inspection_only",
        "invariants": {
            "inspection_is_read_only": True,
            "inspection_cannot_regrant_attempt_registration": True,
            "consumed_authorization_binding_remains_consumed_after_expiry": True,
        },
    }


__all__ = [
    "SCHEMA_VERSION", "POLICY_VERSION", "DECISION_TYPE", "LEASE_RECEIPT_SCHEMA",
    "LEASE_RECEIPT_ISSUER", "LEASE_DATABASE_SCHEMA_VERSION", "MAX_LEASE_TTL_SECONDS",
    "ValidationLeaseError", "load_validation_execution_lease_receipt",
    "build_validation_execution_lease_request",
    "evaluate_validation_execution_lease", "acquire_validation_execution_lease",
    "inspect_validation_execution_lease",
]
