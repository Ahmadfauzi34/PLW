"""F141 postcondition proof assembly.

This read-only layer freshly verifies an F139 execution-backed scenario binding
and its F140 proof-obligation coverage, then evaluates an explicit caller-
declared postcondition specification against observed scenario/check outcomes.

PROVEN is scoped to the declared change identity, revision assertion, scenarios,
checks, obligation set, and verified evidence lineage.  It is not source-mutation
attestation, stable promotion, external side-effect truth, or truth commit.
"""
from __future__ import annotations

import json
from collections.abc import Mapping
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from core.capability_contracts import is_sha256_id
from fullstack.reference_digest import canonical_reference_digest
from fullstack.execution_backed_evidence import (
    ExecutionBackedEvidenceError,
    verify_execution_backed_scenario_evidence,
)
from fullstack.proof_obligations import (
    ProofObligationError,
    normalize_proof_obligation_set,
    verify_execution_backed_proof_coverage,
)

SCHEMA_VERSION = "postcondition-proof-assembly-v1"
SPEC_SCHEMA_VERSION = "postcondition-proof-spec-v1"
DIGEST_POLICY = "f141-postcondition-proof-full-artifact-v1"
MAX_SPEC_BYTES = 1_048_576
MAX_TEXT = 2048
OUTCOMES = frozenset({"PASS", "FAIL"})
PROOF_STATES = frozenset({"PROVEN", "DISPROVEN", "UNRESOLVED", "CONFLICTING", "STALE"})


class PostconditionProofError(ValueError):
    """Raised when F141 input identity/integrity cannot be established."""


def _text(value: Any, field: str, *, required: bool = False, max_len: int = MAX_TEXT) -> Optional[str]:
    if value is None:
        if required:
            raise PostconditionProofError(f"{field} is required")
        return None
    if not isinstance(value, str):
        raise PostconditionProofError(f"{field} must be a string")
    value = value.strip()
    if required and not value:
        raise PostconditionProofError(f"{field} must be non-empty")
    if len(value) > max_len:
        raise PostconditionProofError(f"{field} exceeds {max_len} characters")
    return value or None


def _sha(value: Any, field: str) -> str:
    text = _text(value, field, required=True)
    assert text is not None
    if not is_sha256_id(text):
        raise PostconditionProofError(f"{field} must be a sha256 id")
    return text


def _outcome(value: Any, field: str) -> str:
    text = _text(value, field, required=True)
    assert text is not None
    text = text.upper()
    if text not in OUTCOMES:
        raise PostconditionProofError(f"{field} must be PASS or FAIL")
    return text


def load_postcondition_spec(path: str, *, max_bytes: int = MAX_SPEC_BYTES) -> Dict[str, Any]:
    target = Path(path)
    try:
        raw = target.read_bytes()
    except OSError as exc:
        raise PostconditionProofError(f"postcondition spec unavailable: {type(exc).__name__}") from exc
    if len(raw) > max_bytes:
        raise PostconditionProofError(f"postcondition spec exceeds {max_bytes} bytes")
    try:
        payload = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise PostconditionProofError(
            f"postcondition spec is not valid bounded UTF-8 JSON: {type(exc).__name__}"
        ) from exc
    if not isinstance(payload, dict):
        raise PostconditionProofError("postcondition spec root must be a JSON object")
    return payload


def load_postcondition_coverage(path: str, *, max_bytes: int = MAX_SPEC_BYTES) -> Dict[str, Any]:
    target = Path(path)
    try:
        raw = target.read_bytes()
    except OSError as exc:
        raise PostconditionProofError(f"F140 coverage unavailable: {type(exc).__name__}") from exc
    if len(raw) > max_bytes:
        raise PostconditionProofError(f"F140 coverage exceeds {max_bytes} bytes")
    try:
        payload = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise PostconditionProofError(
            f"F140 coverage is not valid bounded UTF-8 JSON: {type(exc).__name__}"
        ) from exc
    if not isinstance(payload, dict):
        raise PostconditionProofError("F140 coverage root must be a JSON object")
    return payload


def normalize_postcondition_spec(payload: Mapping[str, Any]) -> Dict[str, Any]:
    if not isinstance(payload, Mapping):
        raise PostconditionProofError("postcondition spec must be an object")
    allowed = {
        "schema_version", "validation_plan_digest", "change_identity",
        "required_obligation_ids", "scenario_expectations", "check_expectations",
    }
    unknown = sorted(set(payload) - allowed)
    if unknown:
        raise PostconditionProofError("postcondition spec contains unknown fields: " + ",".join(unknown))
    if payload.get("schema_version") != SPEC_SCHEMA_VERSION:
        raise PostconditionProofError(f"postcondition spec must use {SPEC_SCHEMA_VERSION}")
    plan_digest = _sha(payload.get("validation_plan_digest"), "validation_plan_digest")

    change = payload.get("change_identity")
    if not isinstance(change, Mapping):
        raise PostconditionProofError("change_identity must be an object")
    unknown_change = sorted(set(change) - {"change_id", "base_revision", "candidate_revision"})
    if unknown_change:
        raise PostconditionProofError("change_identity contains unknown fields: " + ",".join(unknown_change))
    change_id = _sha(change.get("change_id"), "change_identity.change_id")
    base_revision = _text(change.get("base_revision"), "change_identity.base_revision", max_len=256)
    candidate_revision = _text(
        change.get("candidate_revision"), "change_identity.candidate_revision", required=True, max_len=256,
    )
    assert candidate_revision is not None

    required = payload.get("required_obligation_ids")
    if not isinstance(required, list) or not required:
        raise PostconditionProofError("required_obligation_ids must be a non-empty array")
    required_ids: List[str] = []
    seen_required: set[str] = set()
    for index, value in enumerate(required):
        item = _text(value, f"required_obligation_ids[{index}]", required=True)
        assert item is not None
        if item in seen_required:
            raise PostconditionProofError(f"duplicate required_obligation_id: {item}")
        seen_required.add(item)
        required_ids.append(item)

    scenarios_raw = payload.get("scenario_expectations")
    if not isinstance(scenarios_raw, list) or not scenarios_raw:
        raise PostconditionProofError("scenario_expectations must be a non-empty array")
    scenarios: List[Dict[str, str]] = []
    seen_scenarios: set[str] = set()
    for index, item in enumerate(scenarios_raw):
        field = f"scenario_expectations[{index}]"
        if not isinstance(item, Mapping) or set(item) != {"scenario_id", "expected_outcome"}:
            raise PostconditionProofError(f"{field} must contain only scenario_id and expected_outcome")
        sid = _sha(item.get("scenario_id"), f"{field}.scenario_id")
        if sid in seen_scenarios:
            raise PostconditionProofError(f"duplicate scenario expectation: {sid}")
        seen_scenarios.add(sid)
        scenarios.append({"scenario_id": sid, "expected_outcome": _outcome(item.get("expected_outcome"), f"{field}.expected_outcome")})

    checks_raw = payload.get("check_expectations", [])
    if not isinstance(checks_raw, list):
        raise PostconditionProofError("check_expectations must be an array")
    checks: List[Dict[str, str]] = []
    seen_checks: set[Tuple[str, str]] = set()
    for index, item in enumerate(checks_raw):
        field = f"check_expectations[{index}]"
        if not isinstance(item, Mapping) or set(item) != {"scenario_id", "check_id", "expected_outcome"}:
            raise PostconditionProofError(
                f"{field} must contain only scenario_id, check_id, and expected_outcome"
            )
        sid = _sha(item.get("scenario_id"), f"{field}.scenario_id")
        check_id = _text(item.get("check_id"), f"{field}.check_id", required=True)
        assert check_id is not None
        key = (sid, check_id)
        if key in seen_checks:
            raise PostconditionProofError(f"duplicate check expectation: {sid}:{check_id}")
        seen_checks.add(key)
        checks.append({
            "scenario_id": sid,
            "check_id": check_id,
            "expected_outcome": _outcome(item.get("expected_outcome"), f"{field}.expected_outcome"),
        })

    normalized: Dict[str, Any] = {
        "schema_version": SPEC_SCHEMA_VERSION,
        "validation_plan_digest": plan_digest,
        "change_identity": {
            "change_id": change_id,
            "base_revision": base_revision,
            "candidate_revision": candidate_revision,
        },
        "required_obligation_ids": sorted(required_ids),
        "scenario_expectations": sorted(scenarios, key=lambda row: row["scenario_id"]),
        "check_expectations": sorted(checks, key=lambda row: (row["scenario_id"], row["check_id"])),
    }
    normalized["change_identity_digest"] = canonical_reference_digest(normalized["change_identity"])
    normalized["postcondition_spec_digest"] = canonical_reference_digest({
        "artifact_type": SPEC_SCHEMA_VERSION,
        "artifact": {key: value for key, value in normalized.items() if key != "postcondition_spec_digest"},
    })
    return normalized


def postcondition_proof_digest(result: Mapping[str, Any]) -> str:
    core = {key: value for key, value in result.items() if key != "postcondition_proof_digest"}
    try:
        return canonical_reference_digest({
            "artifact_type": SCHEMA_VERSION,
            "digest_policy": DIGEST_POLICY,
            "artifact": core,
        })
    except (TypeError, ValueError) as exc:
        raise PostconditionProofError("postcondition proof is not canonical JSON") from exc


def _outcome_sets(binding_rows: Mapping[str, Mapping[str, Any]]) -> tuple[Dict[str, List[str]], Dict[Tuple[str, str], List[str]]]:
    scenario_outcomes: Dict[str, List[str]] = {}
    check_outcomes: Dict[Tuple[str, str], List[str]] = {}
    for sid, row in binding_rows.items():
        observed = sorted({str(value).upper() for value in row.get("validator_outcomes", []) if str(value).upper() in OUTCOMES})
        scenario_outcomes[sid] = observed
        for observation in row.get("observations", []):
            if not isinstance(observation, Mapping):
                continue
            for check in observation.get("checks", []):
                if not isinstance(check, Mapping) or not isinstance(check.get("check_id"), str):
                    continue
                outcome = str(check.get("outcome", "")).upper()
                if outcome not in OUTCOMES:
                    continue
                check_outcomes.setdefault((sid, str(check["check_id"])), []).append(outcome)
    for key, values in list(check_outcomes.items()):
        check_outcomes[key] = sorted(set(values))
    return scenario_outcomes, check_outcomes


def assemble_postcondition_proof(
    binding: Mapping[str, Any],
    coverage: Mapping[str, Any],
    obligation_set: Mapping[str, Any],
    spec_payload: Mapping[str, Any],
    *,
    current_revision: str,
) -> Dict[str, Any]:
    """Freshly verify F139+F140 and assemble one explicit F141 proof state."""
    try:
        binding_rows = verify_execution_backed_scenario_evidence(binding)
        verify_execution_backed_proof_coverage(
            coverage, binding=binding, obligation_set=obligation_set,
        )
        obligations = normalize_proof_obligation_set(
            obligation_set, validation_plan_digest=str(binding["validation_plan_digest"]),
        )
    except (ExecutionBackedEvidenceError, ProofObligationError) as exc:
        raise PostconditionProofError(f"verified input rejected: {exc}") from exc

    spec = normalize_postcondition_spec(spec_payload)
    revision = _text(current_revision, "current_revision", required=True, max_len=256)
    assert revision is not None
    plan_digest = str(binding["validation_plan_digest"])
    if spec["validation_plan_digest"] != plan_digest:
        raise PostconditionProofError("postcondition spec validation_plan_digest mismatch")
    if coverage.get("validation_plan_digest") != plan_digest:
        raise PostconditionProofError("F140 coverage validation_plan_digest mismatch")

    obligation_rows = obligations["obligations"]
    obligation_ids = sorted(str(row["obligation_id"]) for row in obligation_rows)
    coverage_rows = coverage.get("obligation_results")
    if not isinstance(coverage_rows, list):
        raise PostconditionProofError("F140 coverage obligation_results missing")
    coverage_by_id = {str(row.get("obligation_id")): row for row in coverage_rows if isinstance(row, Mapping)}
    if sorted(coverage_by_id) != obligation_ids:
        raise PostconditionProofError("F140 coverage obligation identity set mismatch")

    unresolved: List[str] = []
    conflicts: List[str] = []
    disproven: List[str] = []

    if spec["required_obligation_ids"] != obligation_ids:
        unresolved.append("postcondition spec required_obligation_ids do not exactly match the verified obligation set")

    coverage_statuses = {str(row.get("coverage_status")) for row in coverage_rows if isinstance(row, Mapping)}
    if "CONFLICTING" in coverage_statuses:
        conflicts.append("F140 coverage contains conflicting obligations")
    if any(status in {"MISSING", "PARTIAL"} for status in coverage_statuses):
        unresolved.append("F140 coverage is incomplete")
    if coverage.get("summary", {}).get("coverage_complete") is not True:
        unresolved.append("F140 summary does not establish complete obligation coverage")

    expected_scenarios = {row["scenario_id"]: row["expected_outcome"] for row in spec["scenario_expectations"]}
    expected_checks = {
        (row["scenario_id"], row["check_id"]): row["expected_outcome"]
        for row in spec["check_expectations"]
    }
    required_scenarios = sorted({str(row["scenario_id"]) for row in obligation_rows})
    missing_scenario_specs = sorted(set(required_scenarios) - set(expected_scenarios))
    extra_scenario_specs = sorted(set(expected_scenarios) - set(required_scenarios))
    if missing_scenario_specs:
        unresolved.append("missing expected scenario outcomes for: " + ",".join(missing_scenario_specs))
    if extra_scenario_specs:
        unresolved.append("postcondition spec includes scenarios outside the obligation set: " + ",".join(extra_scenario_specs))

    required_checks = sorted({
        (str(row["scenario_id"]), str(row["check_id"]))
        for row in obligation_rows if row.get("requirement") == "CHECK_OBSERVED"
    })
    missing_check_specs = sorted(set(required_checks) - set(expected_checks))
    extra_check_specs = sorted(set(expected_checks) - set(required_checks))
    if missing_check_specs:
        unresolved.append(
            "CHECK_OBSERVED obligations require explicit expected check outcomes for: "
            + ",".join(f"{sid}:{cid}" for sid, cid in missing_check_specs)
        )
    if extra_check_specs:
        unresolved.append(
            "postcondition spec includes check expectations outside CHECK_OBSERVED obligations: "
            + ",".join(f"{sid}:{cid}" for sid, cid in extra_check_specs)
        )

    scenario_outcomes, check_outcomes = _outcome_sets(binding_rows)
    scenario_results: List[Dict[str, Any]] = []
    for sid in required_scenarios:
        expected = expected_scenarios.get(sid)
        actual = scenario_outcomes.get(sid, [])
        if expected is None:
            status = "UNRESOLVED"
        elif not actual:
            unresolved.append(f"scenario {sid} has no observed validator outcome")
            status = "UNRESOLVED"
        elif len(actual) > 1:
            conflicts.append(f"scenario {sid} has conflicting validator outcomes")
            status = "CONFLICTING"
        elif actual[0] != expected:
            disproven.append(f"scenario {sid} expected {expected} but observed {actual[0]}")
            status = "MISMATCH"
        else:
            status = "MATCH"
        scenario_results.append({
            "scenario_id": sid, "expected_outcome": expected,
            "observed_outcomes": actual, "comparison_status": status,
        })

    check_results: List[Dict[str, Any]] = []
    for sid, check_id in required_checks:
        expected = expected_checks.get((sid, check_id))
        actual = check_outcomes.get((sid, check_id), [])
        if expected is None:
            status = "UNRESOLVED"
        elif not actual:
            unresolved.append(f"check {sid}:{check_id} has no observed outcome")
            status = "UNRESOLVED"
        elif len(actual) > 1:
            conflicts.append(f"check {sid}:{check_id} has conflicting outcomes")
            status = "CONFLICTING"
        elif actual[0] != expected:
            disproven.append(f"check {sid}:{check_id} expected {expected} but observed {actual[0]}")
            status = "MISMATCH"
        else:
            status = "MATCH"
        check_results.append({
            "scenario_id": sid, "check_id": check_id, "expected_outcome": expected,
            "observed_outcomes": actual, "comparison_status": status,
        })

    candidate_revision = str(spec["change_identity"]["candidate_revision"])
    stale = revision != candidate_revision
    if stale:
        state = "STALE"
        reasons = [f"current revision {revision!r} does not match candidate revision {candidate_revision!r}"]
    elif conflicts:
        state = "CONFLICTING"
        reasons = sorted(set(conflicts))
    elif unresolved:
        state = "UNRESOLVED"
        reasons = sorted(set(unresolved))
    elif disproven:
        state = "DISPROVEN"
        reasons = sorted(set(disproven))
    else:
        state = "PROVEN"
        reasons = ["all declared obligations are covered and all explicit scenario/check expectations match"]
    assert state in PROOF_STATES

    result: Dict[str, Any] = {
        "schema_version": SCHEMA_VERSION,
        "proof_digest_policy": DIGEST_POLICY,
        "proof_state": state,
        "validation_plan_digest": plan_digest,
        "change_identity": spec["change_identity"],
        "change_identity_digest": spec["change_identity_digest"],
        "postcondition_spec_digest": spec["postcondition_spec_digest"],
        "current_revision": revision,
        "candidate_revision_matches_current_assertion": not stale,
        "execution_backed_evidence_binding_digest": binding["execution_backed_evidence_binding_digest"],
        "proof_obligation_coverage_digest": coverage["proof_obligation_coverage_digest"],
        "proof_obligation_set_digest": coverage["proof_obligation_set_digest"],
        "required_obligation_ids": spec["required_obligation_ids"],
        "scenario_results": scenario_results,
        "check_results": check_results,
        "reasons": reasons,
        "summary": {
            "required_obligation_count": len(obligation_ids),
            "coverage_complete": coverage.get("summary", {}).get("coverage_complete") is True,
            "scenario_expectation_count": len(spec["scenario_expectations"]),
            "check_expectation_count": len(spec["check_expectations"]),
            "mismatch_count": len(disproven),
            "unresolved_count": len(unresolved),
            "conflict_count": len(conflicts),
            "stale": stale,
        },
        "authority": {
            "F139_binding_verified": True,
            "F140_coverage_freshly_verified": True,
            "caller_declared_change_identity": True,
            "current_revision_caller_asserted": True,
            "source_revision_attested": False,
            "change_applied_to_source_verified": False,
            "postcondition_proven": state == "PROVEN",
            "postcondition_disproven": state == "DISPROVEN",
            "stable_promoted": False,
            "truth_committed": False,
        },
        "proof_boundary": {
            "PROVEN_is_scoped_to_declared_change_revision_scenarios_checks_and_obligations": True,
            "PROVEN_is_source_mutation_attestation": False,
            "PROVEN_is_stable_promotion": False,
            "PROVEN_is_truth_commit": False,
            "overall_validator_PASS_without_expected_check_match_is_sufficient": False,
            "caller_asserted_current_revision_is_source_attestation": False,
        },
        "next_boundary": "FULL_STACK_VALIDATED_STATE" if state in {"PROVEN", "DISPROVEN"} else "POSTCONDITION_EVIDENCE_RECOVERY",
    }
    result["postcondition_proof_digest"] = postcondition_proof_digest(result)
    return result


def verify_postcondition_proof_integrity(result: Mapping[str, Any]) -> bool:
    if not isinstance(result, Mapping) or result.get("schema_version") != SCHEMA_VERSION:
        raise PostconditionProofError(f"postcondition proof must use {SCHEMA_VERSION}")
    if result.get("proof_digest_policy") != DIGEST_POLICY:
        raise PostconditionProofError("postcondition proof digest policy mismatch")
    claimed = result.get("postcondition_proof_digest")
    if not is_sha256_id(claimed) or postcondition_proof_digest(result) != claimed:
        raise PostconditionProofError("postcondition proof digest mismatch")
    if result.get("proof_state") not in PROOF_STATES:
        raise PostconditionProofError("unsupported postcondition proof state")
    authority = result.get("authority")
    if not isinstance(authority, Mapping):
        raise PostconditionProofError("postcondition proof authority missing")
    if authority.get("truth_committed") is not False or authority.get("stable_promoted") is not False:
        raise PostconditionProofError("postcondition proof authority widened")
    if authority.get("change_applied_to_source_verified") is not False:
        raise PostconditionProofError("postcondition proof falsely attests source mutation")
    return True


__all__ = [
    "SCHEMA_VERSION", "SPEC_SCHEMA_VERSION", "DIGEST_POLICY", "MAX_SPEC_BYTES",
    "OUTCOMES", "PROOF_STATES", "PostconditionProofError",
    "load_postcondition_spec", "load_postcondition_coverage", "normalize_postcondition_spec",
    "postcondition_proof_digest", "assemble_postcondition_proof", "verify_postcondition_proof_integrity",
]
