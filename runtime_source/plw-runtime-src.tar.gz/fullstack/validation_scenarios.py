"""Recoverable targeted validation scenario planning over F127 impact evidence.

F128 does not execute renders/tests and does not invent missing scenarios.  It
selects a bounded validation set only from the current F125 scenario plus a
caller-supplied catalog, preserving omitted candidates and recovery metadata.
"""
from __future__ import annotations

import json
import math
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional, Sequence

from codebase.geometry_correspondence import GeometrySnapshotError, normalize_geometry_snapshot
from fullstack.reference_digest import canonical_reference_digest

SCHEMA_VERSION = "validation-scenario-plan-v1"
CATALOG_SCHEMA_VERSION = "validation-scenario-catalog-v1"
MAX_CATALOG_BYTES = 1_048_576
MAX_CATALOG_SCENARIOS = 2048
MAX_SCENARIOS = 64
MAX_COVERAGE_ITEMS = 4096
_MAX_TEXT = 2048


class ValidationScenarioError(ValueError):
    """Raised when F128 planning input violates its bounded contract."""


def _text(value: Any, field: str, *, required: bool = False) -> Optional[str]:
    if value is None:
        if required:
            raise ValidationScenarioError(f"{field} is required")
        return None
    if not isinstance(value, str):
        raise ValidationScenarioError(f"{field} must be a string")
    value = value.strip()
    if required and not value:
        raise ValidationScenarioError(f"{field} must be non-empty")
    if len(value) > _MAX_TEXT:
        raise ValidationScenarioError(f"{field} exceeds {_MAX_TEXT} characters")
    return value or None


def _bounded_strings(value: Any, field: str) -> List[str]:
    if value is None:
        return []
    if not isinstance(value, list):
        raise ValidationScenarioError(f"{field} must be an array of strings")
    result: List[str] = []
    seen: set[str] = set()
    for index, item in enumerate(value):
        text = _text(item, f"{field}[{index}]", required=True)
        assert text is not None
        if text in seen:
            continue
        seen.add(text)
        result.append(text)
        if len(result) > MAX_COVERAGE_ITEMS:
            raise ValidationScenarioError(f"{field} exceeds {MAX_COVERAGE_ITEMS} unique entries")
    return result


def _normalize_max_scenarios(value: Any) -> int:
    if isinstance(value, bool):
        raise ValidationScenarioError("max_scenarios must be an integer")
    try:
        result = int(value)
    except (TypeError, ValueError) as exc:
        raise ValidationScenarioError("max_scenarios must be an integer") from exc
    if result < 1 or result > MAX_SCENARIOS:
        raise ValidationScenarioError(f"max_scenarios must be between 1 and {MAX_SCENARIOS}")
    return result


def _scenario_from_identity(value: Any, field: str) -> Dict[str, Any]:
    if not isinstance(value, Mapping):
        raise ValidationScenarioError(f"{field} must be an object")
    try:
        normalized = normalize_geometry_snapshot({
            "schema_version": "geometry-snapshot-v1",
            "scenario": dict(value),
            "static_context": {},
            "capture": {},
            "nodes": [],
        })
    except GeometrySnapshotError as exc:
        raise ValidationScenarioError(f"{field} is invalid: {exc}") from exc
    return {
        "scenario": normalized["scenario"],
        "scenario_id": normalized["scenario_id"],
    }


def load_validation_scenario_catalog(path: str, *, max_bytes: int = MAX_CATALOG_BYTES) -> Dict[str, Any]:
    target = Path(path)
    try:
        raw = target.read_bytes()
    except OSError as exc:
        raise ValidationScenarioError(f"scenario catalog unavailable: {type(exc).__name__}") from exc
    if len(raw) > max_bytes:
        raise ValidationScenarioError(f"scenario catalog exceeds {max_bytes} bytes")
    try:
        payload = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValidationScenarioError(f"scenario catalog is not valid bounded UTF-8 JSON: {type(exc).__name__}") from exc
    if not isinstance(payload, dict):
        raise ValidationScenarioError("scenario catalog root must be a JSON object")
    return payload


def normalize_validation_scenario_catalog(catalog: Optional[Mapping[str, Any]]) -> Dict[str, Any]:
    raw = dict(catalog or {"schema_version": CATALOG_SCHEMA_VERSION, "scenarios": []})
    if raw.get("schema_version", CATALOG_SCHEMA_VERSION) != CATALOG_SCHEMA_VERSION:
        raise ValidationScenarioError(f"unsupported catalog schema_version: {raw.get('schema_version')}")
    scenarios = raw.get("scenarios", [])
    if not isinstance(scenarios, list):
        raise ValidationScenarioError("scenarios must be an array")
    if len(scenarios) > MAX_CATALOG_SCENARIOS:
        raise ValidationScenarioError(f"scenarios exceeds {MAX_CATALOG_SCENARIOS}")
    result: List[Dict[str, Any]] = []
    seen: set[str] = set()
    for index, item in enumerate(scenarios):
        field = f"scenarios[{index}]"
        if not isinstance(item, Mapping):
            raise ValidationScenarioError(f"{field} must be an object")
        identity = _scenario_from_identity(item.get("scenario"), f"{field}.scenario")
        claimed = _text(item.get("scenario_id"), f"{field}.scenario_id")
        if claimed is not None and claimed != identity["scenario_id"]:
            raise ValidationScenarioError(f"{field}.scenario_id does not match scenario identity")
        scenario_id = identity["scenario_id"]
        if scenario_id in seen:
            raise ValidationScenarioError(f"duplicate scenario_id: {scenario_id}")
        seen.add(scenario_id)
        coverage_raw = item.get("coverage") or {}
        if not isinstance(coverage_raw, Mapping):
            raise ValidationScenarioError(f"{field}.coverage must be an object")
        coverage = {
            "ui_ids": _bounded_strings(coverage_raw.get("ui_ids"), f"{field}.coverage.ui_ids"),
            "component_ids": _bounded_strings(coverage_raw.get("component_ids"), f"{field}.coverage.component_ids"),
            "component_files": _bounded_strings(coverage_raw.get("component_files"), f"{field}.coverage.component_files"),
        }
        result.append({
            **identity,
            "coverage": coverage,
            "source": _text(item.get("source"), f"{field}.source") or "caller_catalog",
        })
    normalized = {"schema_version": CATALOG_SCHEMA_VERSION, "scenarios": result}
    normalized["catalog_digest"] = canonical_reference_digest(normalized)
    return normalized


def _projected_targets(geometric_impact: Mapping[str, Any]) -> Dict[str, List[str]]:
    selection = geometric_impact.get("selection") if isinstance(geometric_impact.get("selection"), Mapping) else {}
    projection = geometric_impact.get("impact_projection") if isinstance(geometric_impact.get("impact_projection"), Mapping) else {}
    ui_ids = sorted({str(v) for v in selection.get("selected_ui_ids", []) if isinstance(v, str)})
    component_files: set[str] = set()
    component_ids: set[str] = set()
    for row in projection.get("projections", []):
        if not isinstance(row, Mapping) or row.get("projection_class") != "STRUCTURAL":
            continue
        if isinstance(row.get("component_file"), str):
            component_files.add(str(row["component_file"]))
        component_ids.update(str(v) for v in row.get("component_ids", []) if isinstance(v, str))
    return {
        "ui_ids": ui_ids,
        "component_ids": sorted(component_ids),
        "component_files": sorted(component_files),
    }


def _variation(current: Mapping[str, Any], candidate: Mapping[str, Any]) -> Dict[str, bool]:
    return {
        "route": candidate.get("route") != current.get("route"),
        "viewport": candidate.get("viewport") != current.get("viewport"),
        "ui_state": candidate.get("ui_state") != current.get("ui_state"),
        "data_fixture": candidate.get("data_fixture") != current.get("data_fixture"),
    }


def _candidate(
    entry: Mapping[str, Any],
    current: Mapping[str, Any],
    current_id: str,
    targets: Mapping[str, Sequence[str]],
) -> Dict[str, Any]:
    scenario = entry["scenario"]
    coverage = entry.get("coverage") if isinstance(entry.get("coverage"), Mapping) else {}
    ui_overlap = sorted(set(targets["ui_ids"]) & set(coverage.get("ui_ids", [])))
    component_id_overlap = sorted(set(targets["component_ids"]) & set(coverage.get("component_ids", [])))
    file_overlap = sorted(set(targets["component_files"]) & set(coverage.get("component_files", [])))
    same_revision = scenario.get("code_revision") == current.get("code_revision")
    same_route = scenario.get("route") == current.get("route")
    is_current = entry["scenario_id"] == current_id
    variation = _variation(current, scenario)
    reasons: List[str] = []
    if is_current:
        reasons.append("CURRENT_SCENARIO")
    if ui_overlap:
        reasons.append("DECLARED_UI_COVERAGE_INTERSECTION")
    if component_id_overlap:
        reasons.append("DECLARED_COMPONENT_ID_COVERAGE_INTERSECTION")
    if file_overlap:
        reasons.append("DECLARED_COMPONENT_FILE_COVERAGE_INTERSECTION")
    if same_route and not is_current:
        reasons.append("SAME_ROUTE_VARIATION")
    if same_route and variation["viewport"]:
        reasons.append("VIEWPORT_VARIATION")
    if same_route and variation["ui_state"]:
        reasons.append("UI_STATE_VARIATION")
    if same_route and variation["data_fixture"]:
        reasons.append("DATA_FIXTURE_VARIATION")
    coverage_match = bool(ui_overlap or component_id_overlap or file_overlap)
    eligible = bool(same_revision and (is_current or coverage_match or same_route))
    if not same_revision:
        omission_reason = "code_revision_mismatch"
    elif not eligible:
        omission_reason = "no_current_coverage_or_same_route_relation"
    else:
        omission_reason = None
    # Deterministic priority is routing policy, not a correctness/effect score.
    priority = (
        (1000 if is_current else 0)
        + 400 * len(ui_overlap)
        + 300 * len(component_id_overlap)
        + 250 * len(file_overlap)
        + (100 if same_route else 0)
        + (30 if same_route and variation["viewport"] else 0)
        + (20 if same_route and variation["ui_state"] else 0)
        + (10 if same_route and variation["data_fixture"] else 0)
    )
    return {
        "scenario_id": entry["scenario_id"],
        "scenario": scenario,
        "source": entry.get("source"),
        "eligible": eligible,
        "priority": priority,
        "selection_reasons": reasons,
        "omission_reason": omission_reason,
        "variation_from_current": variation,
        "coverage_intersection": {
            "ui_ids": ui_overlap,
            "component_ids": component_id_overlap,
            "component_files": file_overlap,
        },
        "coverage_authority": "caller_declared_catalog_metadata",
        "coverage_proves_rendered_surface": False,
    }


def build_targeted_validation_plan(
    ui_reference: Mapping[str, Any],
    geometric_impact: Mapping[str, Any],
    catalog: Optional[Mapping[str, Any]] = None,
    *,
    max_scenarios: int = 8,
) -> Dict[str, Any]:
    """Build a bounded, recoverable plan without executing any validation."""
    limit = _normalize_max_scenarios(max_scenarios)
    geometry = ui_reference.get("geometry") if isinstance(ui_reference.get("geometry"), Mapping) else None
    if geometry is None or not isinstance(geometry.get("scenario"), Mapping):
        raise ValidationScenarioError("ui_reference must contain F125 geometry scenario identity")
    if geometric_impact.get("schema_version") != "geometric-impact-v1":
        raise ValidationScenarioError("geometric_impact must be an F127 geometric-impact-v1 result")
    if geometric_impact.get("scenario_id") != geometry.get("scenario_id"):
        raise ValidationScenarioError("geometric_impact scenario does not match ui_reference")
    if geometric_impact.get("geometry_snapshot_digest") != geometry.get("geometry_snapshot_digest"):
        raise ValidationScenarioError("geometric_impact geometry digest does not match ui_reference")

    normalized_catalog = normalize_validation_scenario_catalog(catalog)
    current = dict(geometry["scenario"])
    current_id = str(geometry["scenario_id"])
    targets = _projected_targets(geometric_impact)
    current_entry = {"scenario_id": current_id, "scenario": current, "coverage": targets, "source": "F125_current_scenario"}
    entries = [current_entry, *normalized_catalog["scenarios"]]
    dedup: Dict[str, Mapping[str, Any]] = {}
    for entry in entries:
        scenario_id = str(entry["scenario_id"])
        # Current F125 identity overrides catalog metadata for its exact identity.
        if scenario_id not in dedup or entry.get("source") == "F125_current_scenario":
            dedup[scenario_id] = entry
    candidates = [_candidate(entry, current, current_id, targets) for entry in dedup.values()]
    eligible = sorted(
        (row for row in candidates if row["eligible"]),
        key=lambda row: (-int(row["priority"]), str(row["scenario_id"])),
    )
    selected = eligible[:limit]
    selected_ids = {row["scenario_id"] for row in selected}
    omitted = []
    for row in sorted(candidates, key=lambda item: str(item["scenario_id"])):
        if row["scenario_id"] in selected_ids:
            continue
        reason = row["omission_reason"] or "bounded_max_scenarios"
        omitted.append({
            "scenario_id": row["scenario_id"],
            "scenario": row["scenario"],
            "reason": reason,
            "selection_reasons": row["selection_reasons"],
            "priority": row["priority"],
            "recover": "increase --max-scenarios or provide explicit catalog coverage; omission is not irrelevance",
        })

    constraints = geometric_impact.get("geometric_evidence", {}).get("constraints", [])
    constraint_ids = [
        str(row.get("constraint_id"))
        for row in constraints
        if isinstance(row, Mapping) and isinstance(row.get("constraint_id"), str)
    ]
    planned: List[Dict[str, Any]] = []
    for row in selected:
        planned.append({
            **row,
            "requested_validation": {
                "ui_ids_if_present": list(targets["ui_ids"]),
                "component_ids": list(targets["component_ids"]),
                "component_files": list(targets["component_files"]),
                "constraint_ids_if_applicable": constraint_ids,
            },
            "execution_status": "NOT_EXECUTED",
        })

    selected_scenarios = [row["scenario"] for row in selected]
    variation_coverage = {
        axis: any(item.get(axis) != current.get(axis) for item in selected_scenarios)
        for axis in ("viewport", "ui_state", "data_fixture")
    }
    available_same_route = [
        row for row in candidates
        if row["scenario"].get("route") == current.get("route") and row["scenario_id"] != current_id
    ]
    gaps = [
        axis for axis, covered in variation_coverage.items()
        if not covered
    ]
    result: Dict[str, Any] = {
        "schema_version": SCHEMA_VERSION,
        "scenario_id": current_id,
        "geometry_snapshot_digest": geometry.get("geometry_snapshot_digest"),
        "geometric_impact_digest": geometric_impact.get("geometric_impact_digest"),
        "catalog_digest": normalized_catalog["catalog_digest"],
        "targets": targets,
        "planning": {
            "max_scenarios": limit,
            "candidate_count": len(candidates),
            "eligible_count": len(eligible),
            "selected_count": len(selected),
            "omitted_count": len(omitted),
            "current_scenario_included": current_id in selected_ids,
            "same_route_alternative_count": len(available_same_route),
            "variation_coverage": variation_coverage,
            "uncovered_variation_axes": gaps,
            "variation_gap_reason": "catalog_has_no_selected_witness_for_axis; planner does not invent scenarios",
        },
        "selected_scenarios": planned,
        "omitted_scenarios": omitted,
        "authority": {
            "current_scenario_authority": "F125 normalized GeometrySnapshot",
            "impact_target_authority": "F127 targeted projection",
            "catalog_authority": "caller_declared_candidate metadata",
            "scenario_generated_by_planner": False,
            "validation_executed": False,
            "runtime_dispatched": False,
            "mutation_authority": False,
            "postcondition_proven": False,
            "truth_committed": False,
        },
        "proof_boundary": {
            "selected_scenario_is_rendered_surface_proof": False,
            "catalog_coverage_is_runtime_presence_proof": False,
            "omitted_scenario_is_irrelevant": False,
            "same_route_variant_is_impacted_proof": False,
            "validation_plan_is_validation_result": False,
        },
        "recovery": {
            "expand_bounded_set": "increase --max-scenarios up to 64",
            "add_known_scenarios": "supply --scenario-catalog with observed/declared scenario identities",
            "prove_runtime_after_planning": "execute through an external authorized adapter and return evidence through the existing F121-F123 authority chain",
        },
    }
    result["validation_plan_digest"] = validation_plan_digest(result)
    return result


def validation_plan_digest(plan: Mapping[str, Any]) -> str:
    """Return the canonical F128 plan identity used by downstream binders."""
    return canonical_reference_digest({
        "scenario_id": plan.get("scenario_id"),
        "geometry_snapshot_digest": plan.get("geometry_snapshot_digest"),
        "geometric_impact_digest": plan.get("geometric_impact_digest"),
        "catalog_digest": plan.get("catalog_digest"),
        "targets": plan.get("targets"),
        "planning": plan.get("planning"),
        "selected_scenarios": plan.get("selected_scenarios"),
        "omitted_scenarios": plan.get("omitted_scenarios"),
    })


__all__ = [
    "SCHEMA_VERSION",
    "CATALOG_SCHEMA_VERSION",
    "MAX_CATALOG_BYTES",
    "MAX_CATALOG_SCENARIOS",
    "MAX_SCENARIOS",
    "ValidationScenarioError",
    "load_validation_scenario_catalog",
    "normalize_validation_scenario_catalog",
    "build_targeted_validation_plan",
    "validation_plan_digest",
]
