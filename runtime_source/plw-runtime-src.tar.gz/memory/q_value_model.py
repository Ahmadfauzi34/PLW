"""Proof-constrained empirical Q/value model for PLW policy learning.

The model is procedural policy memory only. It estimates strategy value from
validated transition outcomes and state-conditioned observations, while the
LTS/proof system remains authoritative for legality, evidence admission, and
proof-state commit.

Reward is intentionally proof-first: token/context savings are only a bounded
secondary adjustment and can never turn a validation-rejected transition into
positive reward. Q-values are strategy estimates, never truth confidence.
"""
from __future__ import annotations

import copy
from typing import Any, Dict, List, Optional, Sequence, Tuple

from memory.state_transition_model import load_state_transition_observations
from memory.transition_outcomes import load_transition_outcomes
from memory.delayed_costs import delayed_cost_for_outcome

SCHEMA_VERSION = "proof-q-value-v1"
POLICY_VERSION = "proof_constrained_empirical_q_value_v1"
REWARD_POLICY = "proof_first_bounded_efficiency_reward_v3_causal_lineage_cost"
RESPONSIBLE_ROLE = "proof_policy_value_custodian"
GAMMA = 0.80


def _clamp(value: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, float(value)))


def _ordinal(value: Any) -> float:
    try:
        return _clamp(float(value or 0) / 3.0)
    except (TypeError, ValueError):
        return 0.0


def reward_for_outcome(outcome: Dict[str, Any]) -> Dict[str, Any]:
    """Compute a bounded proof-first immediate policy reward.

    The reward cannot assert claim truth. Validation rejection has a hard
    negative ceiling: no token saving or low compute cost can compensate for
    rejected evidence.
    """
    settlement = str(outcome.get("settlement") or "claim_still_blocked")
    proof_progress = _clamp(float(outcome.get("proof_progress", 0.0) or 0.0))
    if settlement == "claim_satisfied":
        evidence_gain = 1.0
        epistemic_base = 0.75 * proof_progress + 0.25 * evidence_gain
    elif settlement == "claim_still_blocked":
        evidence_gain = 0.25
        epistemic_base = 0.25 * evidence_gain
    else:  # validation_rejected
        evidence_gain = 0.0
        epistemic_base = -1.0

    cost = outcome.get("cost", {}) or {}
    observed = outcome.get("policy_cost_observation", {}) or {}
    raw_tokens = observed.get("raw_tokens")
    compacted_tokens = observed.get("compacted_tokens")
    tokens_saved = observed.get("tokens_saved")

    if observed.get("available") and compacted_tokens is not None:
        compacted = max(0.0, float(compacted_tokens or 0))
        context_cost = compacted / (compacted + 512.0) if compacted else 0.0
    else:
        context_cost = _ordinal(cost.get("context"))

    if observed.get("available") and raw_tokens is not None and float(raw_tokens or 0) > 0:
        savings_rate = _clamp(float(tokens_saved or 0) / max(1.0, float(raw_tokens or 0)))
    else:
        savings_rate = 0.0

    rerun_cost = _clamp(float(observed.get("repeat_observations", 0) or 0) / 3.0)
    recovery_cost = _clamp(float(observed.get("output_recoveries", 0) or 0) / 2.0)
    delayed = outcome.get("delayed_policy_cost_observation", {}) or {}
    delayed_rerun_cost = _clamp(float(delayed.get("repeat_observations", 0) or 0) / 3.0)
    delayed_recovery_cost = _clamp(float(delayed.get("output_recoveries", 0) or 0) / 2.0)
    delayed_compacted = max(0.0, float(delayed.get("compacted_tokens_observed", 0) or 0))
    delayed_reexpansion = max(0.0, float(delayed.get("context_reexpansion_tokens", 0) or 0))
    delayed_context_tokens = delayed_compacted + delayed_reexpansion
    delayed_context_cost = delayed_context_tokens / (delayed_context_tokens + 512.0) if delayed_context_tokens else 0.0
    compute_cost = _ordinal(cost.get("compute"))
    mutation_risk = _ordinal(cost.get("mutation_risk"))

    # Efficiency is deliberately secondary. Maximum positive token-savings
    # credit is +0.04; all costs together can subtract at most 0.28.
    penalty = (
        0.08 * context_cost
        + 0.04 * compute_cost
        + 0.04 * rerun_cost
        + 0.04 * recovery_cost
        + 0.08 * mutation_risk
    )
    savings_credit = 0.04 * savings_rate if settlement != "validation_rejected" else 0.0
    efficiency_adjustment = max(-0.28, min(0.04, savings_credit - penalty))
    # Costs observed *after* settlement are reconciled separately so an output
    # that looked cheap initially cannot hide downstream recovery/rerun work.
    delayed_penalty = min(
        0.24,
        0.08 * delayed_context_cost
        + 0.08 * delayed_rerun_cost
        + 0.08 * delayed_recovery_cost,
    )
    reward = epistemic_base + efficiency_adjustment - delayed_penalty
    if settlement == "validation_rejected":
        reward = min(reward, -0.75)

    return {
        "reward": round(float(reward), 6),
        "reward_policy": REWARD_POLICY,
        "settlement": settlement,
        "components": {
            "proof_progress": round(proof_progress, 6),
            "evidence_gain": round(evidence_gain, 6),
            "epistemic_base": round(epistemic_base, 6),
            "context_cost": round(context_cost, 6),
            "compute_cost": round(compute_cost, 6),
            "rerun_cost": round(rerun_cost, 6),
            "recovery_cost": round(recovery_cost, 6),
            "delayed_context_cost": round(delayed_context_cost, 6),
            "delayed_context_reexpansion_tokens": int(delayed_reexpansion),
            "delayed_rerun_cost": round(delayed_rerun_cost, 6),
            "delayed_recovery_cost": round(delayed_recovery_cost, 6),
            "delayed_penalty": round(delayed_penalty, 6),
            "mutation_risk": round(mutation_risk, 6),
            "token_savings_rate": round(savings_rate, 6),
            "efficiency_adjustment": round(efficiency_adjustment, 6),
        },
        "invariants": {
            "reward_is_not_truth_confidence": True,
            "validation_rejection_cannot_be_offset_by_token_savings": True,
            "proof_progress_dominates_efficiency": True,
            "token_savings_credit_is_bounded": True,
            "post_settlement_cost_is_reconciled": True,
            "explicit_lineage_context_cost_is_reconciled": True,
            "semantic_similarity_is_not_causal_cost": True,
            "delayed_cost_cannot_change_claim_truth": True,
        },
    }


def _joined_samples() -> List[Dict[str, Any]]:
    outcomes = {str(item.get("outcome_id") or ""): item for item in load_transition_outcomes()}
    samples: List[Dict[str, Any]] = []
    for obs in load_state_transition_observations():
        outcome = outcomes.get(str(obs.get("outcome_id") or ""))
        if not outcome:
            continue
        reconciliation = delayed_cost_for_outcome(str(outcome.get("outcome_id") or ""))
        effective_outcome = copy.deepcopy(outcome)
        effective_outcome["delayed_policy_cost_observation"] = reconciliation.get("delayed_cost", {})
        reward = reward_for_outcome(effective_outcome)
        samples.append({
            "source_state_class_id": str(obs.get("source_state_class_id") or ""),
            "destination_state_class_id": str(obs.get("destination_state_class_id") or ""),
            "destination_phase": str(obs.get("destination_phase") or "unknown"),
            "claim_type": str(obs.get("claim_type") or ""),
            "transition_type": str(obs.get("transition_type") or ""),
            "settlement": str(obs.get("settlement") or ""),
            "reward": float(reward["reward"]),
            "reward_components": reward["components"],
            "outcome_id": str(obs.get("outcome_id") or ""),
            "reconciliation_id": reconciliation.get("reconciliation_id"),
            "has_delayed_cost": bool((reconciliation.get("delayed_cost", {}) or {}).get("has_delayed_cost")),
        })
    return samples


def _group(samples: Sequence[Dict[str, Any]]) -> Dict[Tuple[str, str, str], List[Dict[str, Any]]]:
    grouped: Dict[Tuple[str, str, str], List[Dict[str, Any]]] = {}
    for item in samples:
        key = (
            str(item.get("source_state_class_id") or ""),
            str(item.get("claim_type") or ""),
            str(item.get("transition_type") or ""),
        )
        grouped.setdefault(key, []).append(item)
    return grouped


def summarize_q_value_model(*, source_state_class_id: Optional[str] = None) -> Dict[str, Any]:
    """Return empirical immediate reward and one-step bootstrapped Q estimates."""
    samples = _joined_samples()
    grouped = _group(samples)

    # V0 is an empirical one-step strategy baseline. It is not a truth value.
    immediate_by_state: Dict[str, List[float]] = {}
    immediate_rows: Dict[Tuple[str, str, str], float] = {}
    for key, rows in grouped.items():
        mean_reward = sum(float(r["reward"]) for r in rows) / max(1, len(rows))
        immediate_rows[key] = mean_reward
        immediate_by_state.setdefault(key[0], []).append(mean_reward)
    v0 = {state: max(values) for state, values in immediate_by_state.items() if values}

    rows_out: List[Dict[str, Any]] = []
    for key, rows in grouped.items():
        state, claim, transition = key
        if source_state_class_id and state != source_state_class_id:
            continue
        immediate = immediate_rows[key]
        returns: List[float] = []
        for sample in rows:
            dest = str(sample.get("destination_state_class_id") or "")
            terminal = str(sample.get("destination_phase") or "") == "satisfied"
            bootstrap = 0.0 if terminal else float(v0.get(dest, 0.0))
            returns.append(float(sample["reward"]) + GAMMA * bootstrap)
        q_value = sum(returns) / max(1, len(returns))
        rewards = [float(r["reward"]) for r in rows]
        rows_out.append({
            "source_state_class_id": state,
            "claim_type": claim,
            "transition_type": transition,
            "visits": len(rows),
            "immediate_reward_mean": round(immediate, 6),
            "reward_min": round(min(rewards), 6),
            "reward_max": round(max(rewards), 6),
            "q_value": round(q_value, 6),
            "gamma": GAMMA,
            "estimate_semantics": "empirical_strategy_value_not_truth_confidence",
            "authority": "strategy_experience_only",
        })
    rows_out.sort(key=lambda x: (x["source_state_class_id"], x["claim_type"], -float(x["q_value"]), x["transition_type"]))

    state_values: Dict[str, Dict[str, Any]] = {}
    for row in rows_out:
        state = str(row["source_state_class_id"])
        current = state_values.get(state)
        if current is None or float(row["q_value"]) > float(current["value"]):
            state_values[state] = {
                "state_class_id": state,
                "value": float(row["q_value"]),
                "best_observed_transition_type": row["transition_type"],
                "semantics": "best_observed_strategy_value_not_truth_value",
            }

    return {
        "schema_version": SCHEMA_VERSION,
        "policy": POLICY_VERSION,
        "reward_policy": REWARD_POLICY,
        "authority": "strategy_experience_only",
        "model_family": "proof_constrained_empirical_one_step_q_value",
        "mdp_status": "q_value_over_empirical_state_model_markov_sufficiency_not_proven",
        "gamma": GAMMA,
        "sample_count": len(samples),
        "delayed_cost_sample_count": sum(1 for item in samples if item.get("has_delayed_cost")),
        "state_action_values": rows_out,
        "state_values": sorted(state_values.values(), key=lambda x: x["state_class_id"]),
        "invariants": {
            "q_value_is_not_truth_confidence": True,
            "value_is_not_proof_status": True,
            "cannot_change_transition_validity": True,
            "cannot_satisfy_claim_obligations": True,
            "cannot_commit_proof_state": True,
            "reward_is_proof_first": True,
            "token_savings_cannot_reward_validation_rejection": True,
            "post_settlement_recovery_rerun_cost_reconciled": True,
            "reconciliation_does_not_change_truth_or_settlement": True,
            "markov_sufficiency_proven": False,
            "bellman_optimality_proven": False,
        },
    }


def q_value_prior(*, source_state_class_id: str, claim_type: str, transition_type: str) -> Dict[str, Any]:
    summary = summarize_q_value_model(source_state_class_id=source_state_class_id)
    row = next((
        item for item in summary.get("state_action_values", [])
        if item.get("claim_type") == claim_type and item.get("transition_type") == transition_type
    ), None)
    return {
        "available": bool(row),
        "source_state_class_id": source_state_class_id,
        "visits": int((row or {}).get("visits", 0)),
        "q_value": (row or {}).get("q_value"),
        "immediate_reward_mean": (row or {}).get("immediate_reward_mean"),
        "authority": "strategy_experience_only",
        "semantics": "empirical_strategy_value_not_truth_confidence",
        "affects_transition_validity": False,
        "affects_claim_settlement": False,
        "can_commit_proof_state": False,
        "markov_sufficiency_proven": False,
        "bellman_optimality_proven": False,
    }


def annotate_candidates_with_q_values(
    candidates: Sequence[Dict[str, Any]], *, source_state_class_id: str
) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    for candidate in candidates or []:
        item = copy.deepcopy(candidate)
        item["q_value_prior"] = q_value_prior(
            source_state_class_id=source_state_class_id,
            claim_type=str(item.get("claim_type") or ""),
            transition_type=str(item.get("transition_type") or ""),
        )
        out.append(item)
    return out


__all__ = [
    "SCHEMA_VERSION",
    "POLICY_VERSION",
    "REWARD_POLICY",
    "RESPONSIBLE_ROLE",
    "GAMMA",
    "reward_for_outcome",
    "summarize_q_value_model",
    "q_value_prior",
    "annotate_candidates_with_q_values",
]
