"""State-conditioned procedural transition model for PLW.

This is policy memory, not truth memory.  It estimates empirical observed
frequencies P_hat(S'|S,A) over *abstract proof-state classes*.  The abstraction
is intentionally lossy, therefore the Markov property is NOT asserted.  The
model cannot admit an action, validate evidence, settle a claim, or commit a
proof state.
"""
from __future__ import annotations

import copy
import datetime
import hashlib
import json
import os
from typing import Any, Dict, List, Optional, Sequence, Tuple

from memory.runtime import (
    get_memory_runtime_paths,
    memory_runtime_lock,
    read_json_unlocked,
    write_json_unlocked,
)

SCHEMA_VERSION = "state-transition-model-v1"
POLICY_VERSION = "empirical_state_conditioned_transition_model_v1"
RESPONSIBLE_ROLE = "state_transition_model_custodian"
MAX_INTENTS = 256
MAX_OBSERVATIONS = 512


def _now_iso() -> str:
    return datetime.datetime.now(datetime.timezone.utc).isoformat().replace("+00:00", "Z")


def _sha(value: str) -> str:
    return "sha256:" + hashlib.sha256(str(value or "").encode("utf-8")).hexdigest()


def _id(payload: Dict[str, Any]) -> str:
    raw = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return "sha256:" + hashlib.sha256(raw).hexdigest()


def _store_path(paths: Dict[str, Any]) -> str:
    return str(paths.get("state_transition_model_path") or os.path.join(str(paths["scope_dir"]), "state_transition_model.json"))


def _default_store() -> Dict[str, Any]:
    paths = get_memory_runtime_paths(create=True)
    return {
        "schema_version": SCHEMA_VERSION,
        "policy": POLICY_VERSION,
        "scope": {
            "scope_id": paths["scope_id"],
            "scope_kind": paths["scope_kind"],
            "scope_name": paths["scope_name"],
        },
        "intents": [],
        "observations": [],
        "updated_at": _now_iso(),
        "invariants": _invariants(),
    }


def _validate_store(store: Any) -> None:
    if not isinstance(store, dict) or store.get("schema_version") != SCHEMA_VERSION:
        raise ValueError("state transition model schema mismatch")
    if not isinstance(store.get("intents"), list) or not isinstance(store.get("observations"), list):
        raise ValueError("state transition model lists are invalid")


def _invariants() -> Dict[str, Any]:
    return {
        "procedural_policy_memory_only": True,
        "not_canonical_truth_memory": True,
        "cannot_change_transition_validity": True,
        "cannot_satisfy_claim_obligations": True,
        "cannot_commit_proof_state": True,
        "empirical_probability_is_not_truth_confidence": True,
        "markov_sufficiency_proven": False,
        "state_aliasing_risk_explicit": True,
        "raw_query_not_stored": True,
        "raw_target_path_not_stored": True,
        "raw_truth_scope_not_stored": True,
        "raw_command_not_stored": True,
        "raw_output_not_stored": True,
    }


def register_transition_intents(
    *,
    proof_state: Dict[str, Any],
    candidates: Sequence[Dict[str, Any]],
    truth_scope: str,
) -> Dict[str, Any]:
    """Bind already-valid candidate IDs to the current abstract source state."""
    class_id = str(proof_state.get("state_class_id") or "")
    instance_id = str(proof_state.get("state_instance_id") or "")
    if not class_id or not instance_id:
        return {"stored_count": 0, "reused_count": 0, "intent_ids": [], "available": False}
    scope_fp = _sha(str(truth_scope or "unscoped"))
    rows: List[Dict[str, Any]] = []
    for candidate in candidates or []:
        transition_id = str(candidate.get("transition_id") or "")
        transition_type = str(candidate.get("transition_type") or "")
        claim_type = str(candidate.get("claim_type") or "")
        if not transition_id or not transition_type or not claim_type:
            continue
        stable = {
            "transition_id": transition_id,
            "transition_type": transition_type,
            "claim_type": claim_type,
            "source_state_class_id": class_id,
            "source_state_instance_id": instance_id,
            "truth_scope_fingerprint": scope_fp,
            "transition_lineage_id": ((candidate.get("lineage") or {}).get("id")),
            "authority": "strategy_state_binding_only",
        }
        rows.append({**stable, "intent_id": _id(stable), "recorded_at": _now_iso()})

    stored = reused = 0
    ids: List[str] = []
    with memory_runtime_lock() as paths:
        path = _store_path(paths)
        store = read_json_unlocked(path, _default_store, _validate_store)
        existing = {str(item.get("intent_id")): item for item in store.get("intents", [])}
        for row in rows:
            iid = str(row["intent_id"])
            ids.append(iid)
            if iid in existing:
                reused += 1
                continue
            store["intents"].append(row)
            existing[iid] = row
            stored += 1
        store["intents"] = store["intents"][-MAX_INTENTS:]
        store["updated_at"] = _now_iso()
        write_json_unlocked(path, store)
    return {"stored_count": stored, "reused_count": reused, "intent_ids": ids, "available": True}


def find_transition_intent(*, transition_id: str, truth_scope: str) -> Optional[Dict[str, Any]]:
    scope_fp = _sha(str(truth_scope or "unscoped"))
    with memory_runtime_lock() as paths:
        store = read_json_unlocked(_store_path(paths), _default_store, _validate_store)
        matches = [
            item for item in store.get("intents", [])
            if str(item.get("transition_id")) == str(transition_id)
            and str(item.get("truth_scope_fingerprint")) == scope_fp
        ]
    if not matches:
        return None
    item = matches[-1]
    return {
        "intent_id": item.get("intent_id"),
        "transition_id": item.get("transition_id"),
        "transition_type": item.get("transition_type"),
        "claim_type": item.get("claim_type"),
        "source_state_class_id": item.get("source_state_class_id"),
        "source_state_instance_id": item.get("source_state_instance_id"),
        "transition_lineage_id": item.get("transition_lineage_id"),
        "authority": "strategy_state_binding_only",
    }


def record_state_transition_observation(
    *,
    source_state_class_id: str,
    source_state_instance_id: str,
    destination_proof_state: Dict[str, Any],
    transition_id: str,
    transition_type: str,
    claim_type: str,
    settlement: str,
    outcome_id: Optional[str] = None,
) -> Dict[str, Any]:
    dest_class = str(destination_proof_state.get("state_class_id") or "")
    dest_instance = str(destination_proof_state.get("state_instance_id") or "")
    if not source_state_class_id or not source_state_instance_id or not dest_class or not dest_instance:
        return {"stored": False, "reused": False, "available": False, "reason": "state_binding_incomplete"}
    stable = {
        "source_state_class_id": str(source_state_class_id),
        "source_state_instance_id": str(source_state_instance_id),
        "transition_id": str(transition_id),
        "transition_type": str(transition_type),
        "claim_type": str(claim_type),
        "destination_state_class_id": dest_class,
        "destination_state_instance_id": dest_instance,
        "destination_phase": str(destination_proof_state.get("phase") or "unknown"),
        "settlement": str(settlement),
        "outcome_id": str(outcome_id or "") or None,
        "authority": "strategy_experience_only",
    }
    observation_id = _id(stable)
    record = {**stable, "observation_id": observation_id, "recorded_at": _now_iso()}
    with memory_runtime_lock() as paths:
        path = _store_path(paths)
        store = read_json_unlocked(path, _default_store, _validate_store)
        for existing in store.get("observations", []):
            if existing.get("observation_id") == observation_id:
                return {"stored": False, "reused": True, "available": True, "observation": copy.deepcopy(existing)}
        store["observations"].append(record)
        store["observations"] = store["observations"][-MAX_OBSERVATIONS:]
        store["updated_at"] = _now_iso()
        write_json_unlocked(path, store)
    return {"stored": True, "reused": False, "available": True, "observation": copy.deepcopy(record)}


def load_state_transition_observations(*, limit: int = MAX_OBSERVATIONS) -> List[Dict[str, Any]]:
    with memory_runtime_lock() as paths:
        store = read_json_unlocked(_store_path(paths), _default_store, _validate_store)
        values = list(store.get("observations", []))
    return copy.deepcopy(values[-max(0, int(limit)):])


def _aggregate(observations: Sequence[Dict[str, Any]]) -> List[Dict[str, Any]]:
    buckets: Dict[Tuple[str, str, str], Dict[str, Any]] = {}
    for item in observations:
        key = (
            str(item.get("source_state_class_id") or ""),
            str(item.get("claim_type") or ""),
            str(item.get("transition_type") or ""),
        )
        bucket = buckets.setdefault(key, {
            "source_state_class_id": key[0],
            "claim_type": key[1],
            "transition_type": key[2],
            "attempts": 0,
            "settled": 0,
            "settlements": {"claim_satisfied": 0, "claim_still_blocked": 0, "validation_rejected": 0},
            "destinations": {},
        })
        bucket["attempts"] += 1
        settlement = str(item.get("settlement") or "")
        if settlement == "claim_satisfied":
            bucket["settled"] += 1
        if settlement in bucket["settlements"]:
            bucket["settlements"][settlement] += 1
        dest = str(item.get("destination_state_class_id") or "")
        if dest:
            entry = bucket["destinations"].setdefault(dest, {
                "state_class_id": dest,
                "count": 0,
                "phase": str(item.get("destination_phase") or "unknown"),
            })
            entry["count"] += 1
    out: List[Dict[str, Any]] = []
    for bucket in buckets.values():
        attempts = max(1, int(bucket["attempts"]))
        destinations = []
        for entry in bucket["destinations"].values():
            destinations.append({
                **entry,
                "empirical_probability": round(int(entry["count"]) / attempts, 6),
                "probability_semantics": "observed_state_transition_frequency_not_truth_confidence",
            })
        destinations.sort(key=lambda x: (-int(x["count"]), str(x["state_class_id"])))
        settlement_distribution = [
            {
                "settlement": key,
                "count": int(count),
                "empirical_probability": round(int(count) / attempts, 6),
                "probability_semantics": "observed_validation_outcome_frequency_not_truth_confidence",
            }
            for key, count in sorted(bucket["settlements"].items()) if int(count) > 0
        ]
        out.append({
            "source_state_class_id": bucket["source_state_class_id"],
            "claim_type": bucket["claim_type"],
            "transition_type": bucket["transition_type"],
            "attempts": int(bucket["attempts"]),
            "settled": int(bucket["settled"]),
            "settlement_rate": round(int(bucket["settled"]) / attempts, 6),
            "settlement_distribution": settlement_distribution,
            "destination_distribution": destinations,
            "markov_sufficiency_proven": False,
            "authority": "strategy_experience_only",
        })
    return sorted(out, key=lambda x: (x["source_state_class_id"], x["claim_type"], x["transition_type"]))


def summarize_state_transition_model(*, source_state_class_id: Optional[str] = None) -> Dict[str, Any]:
    observations = load_state_transition_observations()
    rows = _aggregate(observations)
    if source_state_class_id:
        rows = [item for item in rows if item.get("source_state_class_id") == source_state_class_id]
    paths = get_memory_runtime_paths(create=True)
    return {
        "schema_version": SCHEMA_VERSION,
        "policy": POLICY_VERSION,
        "authority": "strategy_experience_only",
        "scope_id": paths["scope_id"],
        "observation_count": len(observations),
        "state_action_models": rows,
        "probability_semantics": "empirical_observed_transition_frequency_not_truth_confidence",
        "mdp_status": "state_conditioned_empirical_model_markov_sufficiency_not_proven",
        "invariants": _invariants(),
    }


def state_conditioned_prior(*, source_state_class_id: str, claim_type: str, transition_type: str) -> Dict[str, Any]:
    summary = summarize_state_transition_model(source_state_class_id=source_state_class_id)
    row = next((
        item for item in summary.get("state_action_models", [])
        if item.get("claim_type") == claim_type and item.get("transition_type") == transition_type
    ), None)
    return {
        "available": bool(row),
        "source_state_class_id": source_state_class_id,
        "attempts": int((row or {}).get("attempts", 0)),
        "settlement_rate": (row or {}).get("settlement_rate"),
        "settlement_distribution": copy.deepcopy((row or {}).get("settlement_distribution", [])),
        "destination_distribution": copy.deepcopy((row or {}).get("destination_distribution", [])),
        "authority": "strategy_experience_only",
        "probability_semantics": "empirical_observed_transition_frequency_not_truth_confidence",
        "affects_transition_validity": False,
        "affects_claim_settlement": False,
        "markov_sufficiency_proven": False,
    }


def annotate_candidates_with_state_model(
    candidates: Sequence[Dict[str, Any]], *, source_state_class_id: str
) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    for candidate in candidates or []:
        item = copy.deepcopy(candidate)
        item["state_conditioned_prior"] = state_conditioned_prior(
            source_state_class_id=source_state_class_id,
            claim_type=str(item.get("claim_type") or ""),
            transition_type=str(item.get("transition_type") or ""),
        )
        out.append(item)
    return out


__all__ = [
    "SCHEMA_VERSION",
    "POLICY_VERSION",
    "RESPONSIBLE_ROLE",
    "register_transition_intents",
    "find_transition_intent",
    "record_state_transition_observation",
    "load_state_transition_observations",
    "summarize_state_transition_model",
    "state_conditioned_prior",
    "annotate_candidates_with_state_model",
]
