"""Transition Outcome Memory — procedural policy-memory subdomain.

Captures experience about proof transitions, never truth about the codebase.
It is physically separate from canonical domain-memory recall so strategy
history cannot be retrieved as a source/history witness for a claim.
"""
from __future__ import annotations
import copy, datetime, hashlib, json, os
from typing import Any, Dict, List, Optional, Sequence
from memory.runtime import get_memory_runtime_paths, memory_runtime_lock, read_json_unlocked, write_json_unlocked
from memory.state_transition_model import record_state_transition_observation

SCHEMA_VERSION = "transition-outcome-memory-v1"
POLICY_VERSION = "procedural_transition_outcome_memory_v1"
RESPONSIBLE_ROLE = "transition_outcome_memory_custodian"
MAX_OUTCOMES = 256


def _now_iso() -> str:
    return datetime.datetime.now(datetime.timezone.utc).isoformat().replace("+00:00", "Z")

def _store_path(paths: Dict[str, Any]) -> str:
    return str(paths.get("transition_outcomes_path") or os.path.join(paths["scope_dir"], "transition_outcomes.json"))

def _default_store() -> Dict[str, Any]:
    paths = get_memory_runtime_paths(create=True)
    return {
        "schema_version": SCHEMA_VERSION, "policy": POLICY_VERSION,
        "scope": {"scope_id": paths["scope_id"], "scope_kind": paths["scope_kind"], "scope_name": paths["scope_name"]},
        "outcomes": [], "updated_at": _now_iso(),
        "invariants": {
            "procedural_policy_memory_only": True, "not_canonical_truth_memory": True,
            "cannot_satisfy_claim_obligations": True, "cannot_change_transition_validity": True,
            "raw_query_not_stored": True, "raw_command_not_stored": True,
            "raw_output_not_stored": True, "raw_target_path_not_stored": True,
        },
    }

def _validate_store(store: Any) -> None:
    if not isinstance(store, dict) or store.get("schema_version") != SCHEMA_VERSION:
        raise ValueError("transition outcome memory schema mismatch")
    outcomes = store.get("outcomes")
    if not isinstance(outcomes, list): raise ValueError("transition outcome memory outcomes must be a list")
    ids=[]
    for item in outcomes:
        if not isinstance(item, dict) or not item.get("outcome_id"): raise ValueError("transition outcome entry must have an outcome_id")
        ids.append(str(item["outcome_id"]))
    if len(ids) != len(set(ids)): raise ValueError("transition outcome ids must be unique")

def _fingerprint(value: str) -> str:
    return "sha256:" + hashlib.sha256(str(value or "").encode("utf-8")).hexdigest()

def _normalize_sha(value: Any) -> Optional[str]:
    text=str(value or "").strip().lower()
    return text if text.startswith("sha256:") and len(text)==71 else None

def _target_features(target_paths: Optional[Sequence[str]]) -> Dict[str, Any]:
    normalized=[os.path.normpath(str(v)).replace("\\","/") for v in (target_paths or []) if v]
    return {
        "target_count": len(normalized),
        "target_extensions": sorted({os.path.splitext(v)[1].lower() or "<none>" for v in normalized}),
        "target_set_fingerprint": _fingerprint("\n".join(sorted(normalized))) if normalized else None,
    }

def _outcome_id(payload: Dict[str, Any]) -> str:
    raw=json.dumps(payload,ensure_ascii=False,sort_keys=True,separators=(",",":")).encode("utf-8")
    return "sha256:"+hashlib.sha256(raw).hexdigest()

def record_transition_outcome(*, transition_id: str, transition_type: str, claim_type: str,
    authority_domain: str, settlement: str, graph_content_signature: str, truth_scope: str,
    target_paths: Optional[Sequence[str]]=None, attestation_id: Optional[str]=None,
    evidence_id: Optional[str]=None, exit_code: Optional[int]=None, command_head: Optional[str]=None,
    command_fingerprint_value: Optional[str]=None,
    cost: Optional[Dict[str, Any]]=None, policy_cost_observation: Optional[Dict[str, Any]]=None) -> Dict[str, Any]:
    if settlement not in {"claim_satisfied","claim_still_blocked","validation_rejected"}:
        raise ValueError("unsupported transition outcome settlement")
    stable={
        "transition_id": str(transition_id or ""), "transition_type": str(transition_type or ""),
        "claim_type": str(claim_type or ""), "authority_domain": str(authority_domain or ""),
        "settlement": settlement, "graph_content_signature": _normalize_sha(graph_content_signature),
        "truth_scope_fingerprint": _fingerprint(truth_scope), **_target_features(target_paths),
        "attestation_id": _normalize_sha(attestation_id), "evidence_id": _normalize_sha(evidence_id),
        "exit_code": int(exit_code) if exit_code is not None else None,
        "command_head": os.path.basename(str(command_head or "")).lower() or None,
        "command_fingerprint": _normalize_sha(command_fingerprint_value),
        "cost": {"context": int((cost or {}).get("context",0)), "compute": int((cost or {}).get("compute",0)), "mutation_risk": int((cost or {}).get("mutation_risk",0))},
        "policy_cost_observation": {
            "available": bool((policy_cost_observation or {}).get("available")),
            "raw_tokens": (policy_cost_observation or {}).get("raw_tokens"),
            "compacted_tokens": (policy_cost_observation or {}).get("compacted_tokens"),
            "tokens_saved": (policy_cost_observation or {}).get("tokens_saved"),
            "within_budget": (policy_cost_observation or {}).get("within_budget"),
            "repeat_observations": int((policy_cost_observation or {}).get("repeat_observations", 0) or 0),
            "same_command_observations": int((policy_cost_observation or {}).get("same_command_observations", 0) or 0),
            "same_command_raw_tokens_total": int((policy_cost_observation or {}).get("same_command_raw_tokens_total", 0) or 0),
            "same_command_compacted_tokens_total": int((policy_cost_observation or {}).get("same_command_compacted_tokens_total", 0) or 0),
            "same_command_tokens_saved_total": int((policy_cost_observation or {}).get("same_command_tokens_saved_total", 0) or 0),
            "output_recoveries": int((policy_cost_observation or {}).get("output_recoveries", 0) or 0),
            "kind": (policy_cost_observation or {}).get("kind"),
            "authority": "behavioral_policy_cost_observation_only",
        },
        "authority": "strategy_experience_only",
    }
    outcome_id=_outcome_id(stable)
    record={**stable,"outcome_id":outcome_id,"recorded_at":_now_iso(),
        "proof_progress":1.0 if settlement=="claim_satisfied" else 0.0,
        "invariants":{"does_not_assert_claim_truth":True,"does_not_satisfy_claim_obligation":True,
            "does_not_change_transition_validity":True,"raw_query_not_stored":True,"raw_command_not_stored":True,
            "raw_output_not_stored":True,"raw_target_path_not_stored":True}}
    with memory_runtime_lock() as paths:
        path=_store_path(paths); store=read_json_unlocked(path,_default_store,_validate_store)
        for existing in store.get("outcomes",[]):
            if existing.get("outcome_id")==outcome_id:
                return {"stored":False,"reused":True,"outcome":copy.deepcopy(existing)}
        store["outcomes"].append(record); store["outcomes"]=store["outcomes"][-MAX_OUTCOMES:]; store["updated_at"]=_now_iso()
        write_json_unlocked(path,store)
    return {"stored":True,"reused":False,"outcome":copy.deepcopy(record)}

def load_transition_outcomes(*, limit:int=256)->List[Dict[str,Any]]:
    with memory_runtime_lock() as paths:
        store=read_json_unlocked(_store_path(paths),_default_store,_validate_store); values=list(store.get("outcomes",[]))
    return copy.deepcopy(values[-max(0,int(limit)):])

def summarize_transition_outcomes(*, limit:int=256)->Dict[str,Any]:
    outcomes=load_transition_outcomes(limit=limit); buckets: Dict[str,Dict[str,Any]]={}
    for item in outcomes:
        key=f"{item.get('claim_type')}::{item.get('transition_type')}"
        b=buckets.setdefault(key,{"claim_type":item.get("claim_type"),"transition_type":item.get("transition_type"),"attempts":0,"settled":0,"still_blocked":0,"rejected":0,"progress":0.0})
        b["attempts"]+=1; b["progress"]+=float(item.get("proof_progress",0.0))
        if item.get("settlement")=="claim_satisfied": b["settled"]+=1
        elif item.get("settlement")=="claim_still_blocked": b["still_blocked"]+=1
        elif item.get("settlement")=="validation_rejected": b["rejected"]+=1
    for b in buckets.values():
        n=max(1,int(b["attempts"])); b["settlement_rate"]=round(b["settled"]/n,6); b["mean_proof_progress"]=round(b["progress"]/n,6); b.pop("progress",None)
    paths=get_memory_runtime_paths(create=True)
    return {"schema_version":SCHEMA_VERSION,"policy":POLICY_VERSION,"authority":"strategy_experience_only","scope_id":paths["scope_id"],
        "outcome_count":len(outcomes),"by_transition":sorted(buckets.values(),key=lambda x:(str(x["claim_type"]),str(x["transition_type"]))),
        "invariants":_default_store()["invariants"]}

def annotate_transition_candidates(candidates: Sequence[Dict[str,Any]])->List[Dict[str,Any]]:
    summary=summarize_transition_outcomes(); idx={(str(v.get("claim_type")),str(v.get("transition_type"))):v for v in summary.get("by_transition",[])}; out=[]
    for candidate in candidates:
        item=copy.deepcopy(candidate); prior=idx.get((str(item.get("claim_type")),str(item.get("transition_type"))))
        item["outcome_memory_prior"]={"available":bool(prior),"attempts":int((prior or {}).get("attempts",0)),
            "settlement_rate":(prior or {}).get("settlement_rate"),"mean_proof_progress":(prior or {}).get("mean_proof_progress"),
            "authority":"strategy_experience_only","affects_transition_validity":False,"affects_claim_settlement":False,"changes_ranking_in_v1":False}
        out.append(item)
    return out

def record_settled_runtime_outcomes(*, runtime_attestations: Sequence[Dict[str,Any]], claim_obligations: Dict[str,Any],
    destination_proof_state: Optional[Dict[str,Any]]=None, runtime_attempts: Optional[Sequence[Dict[str,Any]]]=None,
    current_graph_content_signature: Optional[str]=None)->Dict[str,Any]:
    """Record explicit transition attempts after validation, including rejection.

    Absence of an attempt is never counted as failure. An attestation is settled
    once: later graph drift does not retroactively turn a previously validated
    success into a failure.
    """
    satisfied={str(i.get("claim_type")) for i in (claim_obligations.get("proof_obligations",[]) or []) if i.get("satisfied") is True and i.get("claim_type") in {"runtime_test_result","runtime_behavior"}}
    admissible_ids={str(i.get("attestation_id") or "") for i in (runtime_attestations or []) if i.get("attestation_id")}
    attempts=list(runtime_attempts if runtime_attempts is not None else runtime_attestations or [])
    existing_attestations={str(i.get("attestation_id")) for i in load_transition_outcomes() if i.get("attestation_id")}
    stored=reused=0; ids=[]; state_stored=state_reused=0; state_ids=[]; rejected=still_blocked=0
    for item in attempts:
        claim=str(item.get("claim_type") or "")
        if claim not in {"runtime_test_result","runtime_behavior"}: continue
        attestation_id=str(item.get("attestation_id") or "")
        if attestation_id and attestation_id in existing_attestations:
            reused += 1
            continue
        tid=str(item.get("transition_id") or ""); tt=str(item.get("transition_type") or "")
        if not tid or not tt: continue
        if attestation_id in admissible_ids and claim in satisfied:
            settlement="claim_satisfied"
        elif current_graph_content_signature and str(item.get("graph_content_signature") or "") != str(current_graph_content_signature):
            settlement="validation_rejected"; rejected+=1
        elif item.get("raw_output_recoverable") is not True:
            settlement="validation_rejected"; rejected+=1
        elif attestation_id not in admissible_ids:
            settlement="validation_rejected"; rejected+=1
        else:
            settlement="claim_still_blocked"; still_blocked+=1
        r=record_transition_outcome(transition_id=tid,transition_type=tt,claim_type=claim,authority_domain=str(item.get("authority_domain") or "current_runtime_observation"),
            settlement=settlement,graph_content_signature=str(item.get("graph_content_signature") or ""),truth_scope=str(item.get("truth_scope") or ""),
            target_paths=item.get("target_paths",[]) or [],attestation_id=item.get("attestation_id"),evidence_id=item.get("output_id"),exit_code=item.get("exit_code"),command_head=item.get("command_head"),command_fingerprint_value=item.get("command_fingerprint"),cost=item.get("transition_cost",{}) or {},policy_cost_observation=item.get("policy_cost_observation",{}) or {})
        stored+=int(bool(r.get("stored"))); reused+=int(bool(r.get("reused"))); oid=(r.get("outcome",{}) or {}).get("outcome_id")
        if oid: ids.append(str(oid))
        binding=item.get("source_proof_state",{}) or {}
        if destination_proof_state and binding.get("source_state_class_id") and binding.get("source_state_instance_id"):
            sm=record_state_transition_observation(
                source_state_class_id=str(binding.get("source_state_class_id")),
                source_state_instance_id=str(binding.get("source_state_instance_id")),
                destination_proof_state=destination_proof_state,
                transition_id=tid, transition_type=tt, claim_type=claim,
                settlement=settlement, outcome_id=str(oid or "") or None,
            )
            state_stored+=int(bool(sm.get("stored"))); state_reused+=int(bool(sm.get("reused")))
            sid=(sm.get("observation",{}) or {}).get("observation_id")
            if sid: state_ids.append(str(sid))
    return {"stored_count":stored,"reused_count":reused,"outcome_ids":ids,
        "state_model_stored_count":state_stored,"state_model_reused_count":state_reused,
        "state_transition_observation_ids":state_ids,"validation_rejected_count":rejected,
        "claim_still_blocked_count":still_blocked,"authority":"strategy_experience_only"}

__all__=["SCHEMA_VERSION","POLICY_VERSION","RESPONSIBLE_ROLE","record_transition_outcome","load_transition_outcomes","summarize_transition_outcomes","annotate_transition_candidates","record_settled_runtime_outcomes"]
