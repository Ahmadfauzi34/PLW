"""Project-scoped procedural memory for reconciled post-settlement costs.

This store contains only sanitized strategy-cost deltas produced by the core
reconciliation layer.  It has no access to raw command/output stores and is not
canonical/domain truth memory.
"""
from __future__ import annotations

import copy
import datetime
import os
from typing import Any, Dict, List, Optional, Sequence

from memory.runtime import get_memory_runtime_paths, memory_runtime_lock, read_json_unlocked, write_json_unlocked

SCHEMA_VERSION = "delayed-cost-memory-v1"
POLICY_VERSION = "procedural_delayed_cost_memory_v1"
RESPONSIBLE_ROLE = "delayed_cost_memory_custodian"
MAX_RECORDS = 256


def _now_iso() -> str:
    return datetime.datetime.now(datetime.timezone.utc).isoformat().replace("+00:00", "Z")


def _store_path(paths: Dict[str, Any]) -> str:
    return str(paths.get("delayed_costs_path") or os.path.join(str(paths["scope_dir"]), "delayed_costs.json"))


def _default_store() -> Dict[str, Any]:
    paths = get_memory_runtime_paths(create=True)
    return {
        "schema_version": SCHEMA_VERSION,
        "policy": POLICY_VERSION,
        "scope": {"scope_id": paths["scope_id"], "scope_kind": paths["scope_kind"], "scope_name": paths["scope_name"]},
        "records": [],
        "updated_at": _now_iso(),
        "invariants": {
            "procedural_policy_memory_only": True,
            "not_canonical_truth_memory": True,
            "cannot_change_claim_settlement": True,
            "cannot_change_transition_validity": True,
            "cannot_commit_proof_state": True,
            "raw_command_not_stored": True,
            "raw_output_not_stored": True,
            "raw_query_not_stored": True,
            "raw_target_path_not_stored": True,
            "raw_truth_scope_not_stored": True,
        },
    }


def _validate_store(store: Any) -> None:
    if not isinstance(store, dict) or store.get("schema_version") != SCHEMA_VERSION:
        raise ValueError("delayed cost memory schema mismatch")
    if not isinstance(store.get("records"), list):
        raise ValueError("delayed cost memory records must be a list")


def record_delayed_cost_reconciliations(rows: Sequence[Dict[str, Any]]) -> Dict[str, Any]:
    """Upsert the latest content-addressed reconciliation for each outcome."""
    sanitized: List[Dict[str, Any]] = []
    for row in rows or []:
        outcome_id = str(row.get("outcome_id") or "")
        reconciliation_id = str(row.get("reconciliation_id") or "")
        if not outcome_id or not reconciliation_id:
            continue
        sanitized.append({
            "outcome_id": outcome_id,
            "reconciliation_id": reconciliation_id,
            "transition_id": row.get("transition_id"),
            "transition_type": row.get("transition_type"),
            "claim_type": row.get("claim_type"),
            "evidence_id": row.get("evidence_id"),
            "delayed_cost": copy.deepcopy(row.get("delayed_cost", {}) or {}),
            "representation_accountability": copy.deepcopy(row.get("representation_accountability", {}) or {}),
            "authority": "strategy_cost_reconciliation_only",
            "recorded_at": _now_iso(),
        })

    stored = reused = 0
    with memory_runtime_lock() as paths:
        path = _store_path(paths)
        store = read_json_unlocked(path, _default_store, _validate_store)
        existing = {str(item.get("outcome_id") or ""): item for item in store.get("records", [])}
        for row in sanitized:
            old = existing.get(row["outcome_id"])
            if old and str(old.get("reconciliation_id")) == str(row.get("reconciliation_id")):
                reused += 1
                continue
            existing[row["outcome_id"]] = row
            stored += 1
        records = list(existing.values())
        records.sort(key=lambda x: str(x.get("recorded_at") or ""))
        store["records"] = records[-MAX_RECORDS:]
        store["updated_at"] = _now_iso()
        write_json_unlocked(path, store)
    return {"stored_count": stored, "reused_count": reused, "record_count": len(sanitized), "authority": "strategy_cost_reconciliation_only"}


def load_delayed_cost_reconciliations(*, limit: int = MAX_RECORDS) -> List[Dict[str, Any]]:
    with memory_runtime_lock() as paths:
        store = read_json_unlocked(_store_path(paths), _default_store, _validate_store)
        values = list(store.get("records", []))
    return copy.deepcopy(values[-max(0, int(limit)):])


def delayed_cost_for_outcome(outcome_id: str) -> Dict[str, Any]:
    wanted = str(outcome_id or "")
    for item in reversed(load_delayed_cost_reconciliations()):
        if str(item.get("outcome_id") or "") == wanted:
            return copy.deepcopy(item)
    return {"available": False, "outcome_id": wanted, "delayed_cost": {}, "authority": "strategy_cost_reconciliation_only"}


def summarize_delayed_cost_memory() -> Dict[str, Any]:
    rows = load_delayed_cost_reconciliations()
    return {
        "schema_version": SCHEMA_VERSION,
        "policy": POLICY_VERSION,
        "authority": "strategy_cost_reconciliation_only",
        "record_count": len(rows),
        "with_delayed_cost": sum(1 for row in rows if (row.get("delayed_cost", {}) or {}).get("has_delayed_cost")),
        "records": rows,
        "invariants": _default_store()["invariants"],
    }


__all__ = [
    "SCHEMA_VERSION", "POLICY_VERSION", "RESPONSIBLE_ROLE",
    "record_delayed_cost_reconciliations", "load_delayed_cost_reconciliations",
    "delayed_cost_for_outcome", "summarize_delayed_cost_memory",
]
