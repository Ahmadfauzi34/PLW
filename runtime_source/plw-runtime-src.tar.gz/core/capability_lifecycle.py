"""Fail-closed lifecycle gate for experimental PLW capabilities.

Generalizes the proven F103-F105 sequence without granting source truth,
execution, external mutation, or stable promotion authority.
"""
from __future__ import annotations

import hashlib
import json
from typing import Any, Dict, Mapping, Sequence, Tuple

SCHEMA_VERSION = "capability-lifecycle-v1"
POLICY_VERSION = "proof_driven_capability_lifecycle_v1"

FROZEN = "FROZEN"
DOSSIER_QUALIFIED = "DOSSIER_QUALIFIED"
SHADOW_PROTOTYPE = "SHADOW_PROTOTYPE"
ECONOMICS_REVIEW = "ECONOMICS_REVIEW"
ACCEPTED = "ACCEPTED"
RETIRED = "RETIRED"

LEGAL_TRANSITIONS: Dict[str, Tuple[str, ...]] = {
    FROZEN: (DOSSIER_QUALIFIED,),
    DOSSIER_QUALIFIED: (SHADOW_PROTOTYPE,),
    SHADOW_PROTOTYPE: (ECONOMICS_REVIEW,),
    ECONOMICS_REVIEW: (ACCEPTED, RETIRED),
    ACCEPTED: (),
    RETIRED: (),
}

_DOSSIER_TRUE = (
    "proposal_dossier_exists",
    "observed_before_implementation",
    "selection_rule_fixed_before_count",
    "uses_existing_frontend_primitives",
    "no_new_lexer_or_scanner",
    "single_mask_per_source_file",
)
_PROTOTYPE_TRUE = (
    "prototype_implemented",
    "all_dossier_occurrences_rediscovered",
    "old_rule_projection_preserved",
    "candidate_identity_preserved",
    "single_mask_per_source_file",
    "no_new_lexer_or_scanner",
    "positive_negative_fixtures_pass",
    "self_host_frontier_not_reopened",
)
_ACCEPT_TRUE = (
    "economics_measured",
    "all_dossier_occurrences_rediscovered",
    "old_rule_projection_preserved",
    "candidate_identity_preserved",
    "single_mask_per_source_file",
    "no_new_lexer_or_scanner",
    "positive_negative_fixtures_pass",
    "known_false_positive_count_is_zero",
    "self_host_frontier_not_reopened",
)


def _identity(capability_id: str, state: str, evidence: Mapping[str, Any]) -> str:
    payload = json.dumps(
        {"capability_id": capability_id, "state": state, "evidence": dict(evidence), "policy": POLICY_VERSION},
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    )
    return "sha256:" + hashlib.sha256(payload.encode()).hexdigest()


def _num(evidence: Mapping[str, Any], key: str) -> float | None:
    value = evidence.get(key)
    return float(value) if isinstance(value, (int, float)) and not isinstance(value, bool) else None


def _missing_true(evidence: Mapping[str, Any], keys: Sequence[str]) -> list[str]:
    return [key for key in keys if evidence.get(key) is not True]


def _gate(source: str, target: str, evidence: Mapping[str, Any]) -> list[str]:
    failures: list[str] = []
    if (source, target) == (FROZEN, DOSSIER_QUALIFIED):
        failures += _missing_true(evidence, _DOSSIER_TRUE)
        repos = _num(evidence, "independent_repository_count")
        total = _num(evidence, "verified_occurrence_count")
        per_repo = _num(evidence, "minimum_occurrences_per_repository")
        budget = _num(evidence, "prototype_budget_loc")
        estimate = _num(evidence, "estimated_marginal_cost_loc")
        if repos is None or repos < 2: failures.append("independent_repository_count>=2")
        if total is None or total < 4: failures.append("verified_occurrence_count>=4")
        if per_repo is None or per_repo < 2: failures.append("minimum_occurrences_per_repository>=2")
        if budget is None or estimate is None or estimate > budget:
            failures.append("estimated_marginal_cost_within_prototype_budget")
    elif (source, target) == (DOSSIER_QUALIFIED, SHADOW_PROTOTYPE):
        failures += _missing_true(evidence, _PROTOTYPE_TRUE)
        budget = _num(evidence, "prototype_budget_loc")
        actual = _num(evidence, "actual_marginal_cost_loc")
        if budget is None or actual is None or actual > budget:
            failures.append("actual_marginal_cost_within_prototype_budget")
    elif (source, target) == (SHADOW_PROTOTYPE, ECONOMICS_REVIEW):
        failures += _missing_true(evidence, ("economics_measured",))
        if _num(evidence, "proven_target_gain_loc") is None or _num(evidence, "effective_machine_cost_loc") is None:
            failures.append("gain_and_cost_available")
    elif (source, target) == (ECONOMICS_REVIEW, ACCEPTED):
        failures += _missing_true(evidence, _ACCEPT_TRUE)
        gain, cost = _num(evidence, "proven_target_gain_loc"), _num(evidence, "effective_machine_cost_loc")
        if gain is None or cost is None or gain < cost:
            failures.append("proven_target_gain_loc>=effective_machine_cost_loc")
    elif (source, target) == (ECONOMICS_REVIEW, RETIRED):
        failures += _missing_true(evidence, ("economics_measured", "retirement_preserves_historical_evidence"))
        gain, cost = _num(evidence, "proven_target_gain_loc"), _num(evidence, "effective_machine_cost_loc")
        if gain is None or cost is None:
            failures.append("gain_and_cost_available")
        elif gain >= cost:
            failures.append("economics_must_fail_for_retirement")
    return failures


def evaluate_transition(
    capability_id: str,
    current_state: str,
    target_state: str,
    evidence: Mapping[str, Any] | None = None,
) -> Dict[str, Any]:
    """Evaluate one lifecycle transition without mutating external state."""
    evidence = dict(evidence or {})
    source, target = str(current_state or ""), str(target_state or "")
    legal = target in LEGAL_TRANSITIONS.get(source, ())
    failures = _gate(source, target, evidence) if legal else ["illegal_transition"]
    allowed = legal and not failures
    return {
        "schema_version": SCHEMA_VERSION,
        "policy": POLICY_VERSION,
        "capability_id": str(capability_id or ""),
        "current_state": source,
        "target_state": target,
        "transition_legal": legal,
        "gate_passes": not failures,
        "transition_allowed": allowed,
        "failed_conditions": failures,
        "next_state": target if allowed else source,
        "lifecycle_identity": _identity(str(capability_id or ""), source, evidence),
        "authority": "experimental_capability_lifecycle_only",
        "authorizations": {"external_patch": False, "stable_promotion": False, "truth_commit": False, "runtime_execution": False},
        "invariants": lifecycle_invariants(),
    }


def lifecycle_invariants() -> Dict[str, bool]:
    return {
        "fail_closed_on_missing_evidence": True,
        "cannot_skip_lifecycle_states": True,
        "dossier_must_precede_prototype": True,
        "prototype_does_not_equal_acceptance": True,
        "economics_review_required_before_accept_or_retire": True,
        "acceptance_does_not_authorize_external_patch": True,
        "acceptance_does_not_authorize_stable_promotion": True,
        "retirement_must_preserve_historical_evidence": True,
        "lifecycle_evidence_is_not_current_source_truth": True,
        "lifecycle_policy_cannot_commit_proof_state": True,
    }


__all__ = [
    "SCHEMA_VERSION", "POLICY_VERSION", "FROZEN", "DOSSIER_QUALIFIED", "SHADOW_PROTOTYPE",
    "ECONOMICS_REVIEW", "ACCEPTED", "RETIRED", "LEGAL_TRANSITIONS", "evaluate_transition",
    "lifecycle_invariants",
]
