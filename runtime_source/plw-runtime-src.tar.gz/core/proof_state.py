"""Proof-state abstraction for policy learning under deterministic proof boundaries.

The abstraction deliberately separates an exact *state instance* from a reusable
*state class*:
- instance identity is snapshot/scope/target-set bound for provenance;
- class identity contains only proof-relevant, privacy-bounded features so policy
  experience can generalize across tasks/snapshots.

This module does not assert truth, choose actions, or validate transitions.  It is
an observation/reference layer for the proof-constrained decision process.
"""
from __future__ import annotations

import hashlib
import json
import os
from typing import Any, Dict, Iterable, List, Optional, Sequence

SCHEMA_VERSION = "proof-state-v1"
POLICY_VERSION = "proof_state_abstraction_v1"
RESPONSIBLE_COMPONENT = "core.proof_state.abstract_proof_state"
RESPONSIBLE_ROLE = "proof_state_abstraction_custodian"


def _sha(value: str) -> str:
    return "sha256:" + hashlib.sha256(str(value or "").encode("utf-8")).hexdigest()


def _hash_payload(value: Dict[str, Any]) -> str:
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return "sha256:" + hashlib.sha256(raw).hexdigest()


def _count_bucket(value: Any) -> str:
    try:
        n = max(0, int(value or 0))
    except (TypeError, ValueError):
        n = 0
    if n == 0:
        return "0"
    if n == 1:
        return "1"
    if n <= 4:
        return "2-4"
    if n <= 9:
        return "5-9"
    return "10+"


def _target_shape(paths: Optional[Sequence[str]]) -> Dict[str, Any]:
    normalized = [os.path.normpath(str(v)).replace("\\", "/") for v in (paths or []) if v]
    return {
        "count_bucket": _count_bucket(len(normalized)),
        "extensions": sorted({os.path.splitext(v)[1].lower() or "<none>" for v in normalized}),
    }


def _target_set_fingerprint(paths: Optional[Sequence[str]]) -> Optional[str]:
    normalized = sorted(os.path.normpath(str(v)).replace("\\", "/") for v in (paths or []) if v)
    return _sha("\n".join(normalized)) if normalized else None


def _claim_features(claim_obligations: Dict[str, Any]) -> Dict[str, Any]:
    obligations = list(claim_obligations.get("proof_obligations", []) or [])
    missing: List[str] = []
    witness_types: List[str] = []
    for item in obligations:
        missing.extend(str(v) for v in (item.get("missing", []) or []) if v)
        for witness in item.get("witnesses", []) or []:
            if isinstance(witness, dict) and witness.get("type"):
                witness_types.append(str(witness.get("type")))
    return {
        "status": str(claim_obligations.get("status") or "unavailable"),
        "requested": sorted(str(v) for v in (claim_obligations.get("requested_claims", []) or []) if v),
        "blocked": sorted(str(v) for v in (claim_obligations.get("blocked_claims", []) or []) if v),
        "allowed": sorted(str(v) for v in (claim_obligations.get("allowed_claims", []) or []) if v),
        "missing_evidence": sorted(set(missing)),
        "witness_types": sorted(set(witness_types)),
    }


def _truth_features(truth_floor: Dict[str, Any]) -> Dict[str, Any]:
    gate = truth_floor.get("claim_gate", {}) or {}
    source_floor = truth_floor.get("source_floor", {}) or {}
    memory_floor = truth_floor.get("memory_floor", {}) or {}
    return {
        "status": str(truth_floor.get("status") or "unavailable"),
        "current_source_claims_allowed": bool(gate.get("current_source_claims_allowed", True)),
        "historical_claims_allowed": bool(gate.get("historical_or_rationale_claims_allowed", True)),
        "context_complete_allowed": bool(gate.get("context_may_be_presented_as_complete", True)),
        "source_floor_status": str(source_floor.get("status") or "unavailable"),
        "memory_floor_status": str(memory_floor.get("status") or "unavailable"),
        "history_intent": bool(memory_floor.get("history_intent", False)),
        "unresolved_source_bucket": _count_bucket(len(source_floor.get("unresolved", []) or source_floor.get("unresolved_targets", []) or [])),
        "unresolved_memory_bucket": _count_bucket(len(memory_floor.get("unresolved", []) or memory_floor.get("unresolved_memories", []) or [])),
    }


def _projection_features(pack: Dict[str, Any]) -> Dict[str, Any]:
    budget = pack.get("budget", {}) or {}
    accountability = pack.get("accountability", {}) or {}
    debt = accountability.get("evidence_debt", {}) or {}
    delivery = pack.get("truth_delivery", {}) or {}
    return {
        "within_budget": bool(budget.get("within_budget", True)),
        "source_grounding_satisfied": bool(budget.get("source_grounding_satisfied", True)),
        "omitted_file_bucket": _count_bucket(debt.get("project_files_omitted", debt.get("candidate_files_omitted", 0))),
        "omitted_source_line_bucket": _count_bucket(debt.get("source_excerpt_lines_omitted", 0)),
        "omitted_memory_bucket": _count_bucket(debt.get("memory_records_omitted", 0)),
        "truth_delivery_status": str(delivery.get("delivery_status") or "unavailable"),
        "due_target_bucket": _count_bucket(len(delivery.get("due_targets", []) or [])),
        "unresolved_due_target_bucket": _count_bucket(len(delivery.get("unresolved_due_targets", []) or [])),
    }


def abstract_proof_state(
    *,
    claim_obligations: Dict[str, Any],
    truth_floor: Dict[str, Any],
    pack: Dict[str, Any],
    graph_content_signature: Optional[str],
    truth_scope: Optional[str],
    target_paths: Optional[Sequence[str]] = None,
) -> Dict[str, Any]:
    """Return a privacy-bounded proof-state class plus exact instance identity."""
    targets = list(target_paths or [])
    features = {
        "claims": _claim_features(claim_obligations),
        "truth": _truth_features(truth_floor),
        "projection": _projection_features(pack),
        "target_shape": _target_shape(targets),
    }
    class_payload = {
        "policy": POLICY_VERSION,
        "features": features,
    }
    class_id = _hash_payload(class_payload)
    scope_fp = _sha(str(truth_scope or "unscoped"))
    target_fp = _target_set_fingerprint(targets)
    instance_payload = {
        "policy": POLICY_VERSION,
        "state_class_id": class_id,
        "graph_content_signature": str(graph_content_signature or ""),
        "truth_scope_fingerprint": scope_fp,
        "target_set_fingerprint": target_fp,
    }
    instance_id = _hash_payload(instance_payload)
    phase = "blocked" if features["claims"]["blocked"] else (
        "satisfied" if features["claims"]["requested"] else "observational"
    )
    return {
        "schema_version": SCHEMA_VERSION,
        "policy": POLICY_VERSION,
        "responsible_component": RESPONSIBLE_COMPONENT,
        "responsible_role": RESPONSIBLE_ROLE,
        "authority": "state_abstraction_only",
        "phase": phase,
        "state_class_id": class_id,
        "state_instance_id": instance_id,
        "features": features,
        "instance_binding": {
            "graph_content_signature": str(graph_content_signature or "") or None,
            "truth_scope_fingerprint": scope_fp,
            "target_set_fingerprint": target_fp,
        },
        "invariants": {
            "state_class_excludes_raw_query": True,
            "state_class_excludes_raw_target_paths": True,
            "state_class_excludes_truth_scope_identity": True,
            "state_instance_is_snapshot_and_scope_bound": True,
            "state_class_is_for_policy_generalization_only": True,
            "does_not_assert_truth": True,
            "does_not_validate_transitions": True,
            "markov_sufficiency_proven": False,
            "state_aliasing_risk_explicit": True,
        },
    }


__all__ = [
    "SCHEMA_VERSION",
    "POLICY_VERSION",
    "RESPONSIBLE_COMPONENT",
    "RESPONSIBLE_ROLE",
    "abstract_proof_state",
]
