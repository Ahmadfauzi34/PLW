"""Typed, fail-closed relevance request for advisory capability workflow context.

This module decides only whether an already-built advisory workflow envelope should be
*requested* for context. It does not execute lifecycle transitions, mutate source,
promote stable state, commit truth, or bypass the F108 context budget/source floor.
"""
from __future__ import annotations

from typing import Any, Dict, Mapping

from core.accountability_provenance import RELEVANCE_ISSUER, record_provenanced
from core.capability_contracts import (
    bounded_text,
    no_effect_authorizations,
    normalize_mapping,
    safe_canonical_digest,
)
from core.capability_workflow import ADAPTER_POLICY, SCHEMA_VERSION as WORKFLOW_SCHEMA

SCHEMA_VERSION = "capability-workflow-relevance-v1"
POLICY_VERSION = "explicit_typed_workflow_relevance_v1"

ALLOWED_REASONS = {
    "LIFECYCLE_STATUS",
    "TRANSITION_READINESS",
    "BLOCKED_EVIDENCE",
    "RETIREMENT_REVIEW",
}
ALLOWED_FIELDS = {"state", "next_action", "allowed_targets", "blocked_targets", "evidence_digest"}
_REQUIRED_AUTH = {
    "transition_execution",
    "runtime_execution",
    "external_patch",
    "stable_promotion",
    "truth_commit",
}
_ALLOWED_REQUEST_KEYS = {
    "schema_version",
    "policy",
    "capability_id",
    "caller_declared_relevant",
    "reason_kind",
    "requested_fields",
    "evidence_refs",
    "envelope_evidence_digest",
    "expected_state",
    "authority",
    "authorizations",
}


def _safe_workflow_envelope(envelope: Any) -> bool:
    return (
        isinstance(envelope, dict)
        and envelope.get("schema_version") == WORKFLOW_SCHEMA
        and envelope.get("policy") == ADAPTER_POLICY
        and envelope.get("authority") == "advisory_workflow_only"
        and no_effect_authorizations(envelope.get("authorizations"))
    )


def build_relevance_request(
    capability_id: str,
    reason_kind: str,
    requested_fields: list[str],
    evidence_refs: list[str],
    envelope_evidence_digest: str,
    expected_state: str,
) -> Dict[str, Any]:
    """Build an explicit request; construction itself does not make it relevant."""
    return {
        "schema_version": SCHEMA_VERSION,
        "policy": POLICY_VERSION,
        "capability_id": str(capability_id or ""),
        "caller_declared_relevant": True,
        "reason_kind": str(reason_kind or ""),
        "requested_fields": list(requested_fields or []),
        "evidence_refs": list(evidence_refs or []),
        "envelope_evidence_digest": str(envelope_evidence_digest or ""),
        "expected_state": str(expected_state or ""),
        "authority": "relevance_request_only",
        "authorizations": {key: False for key in sorted(_REQUIRED_AUTH)},
    }


def evaluate_relevance_request(request: Mapping[str, Any] | None, envelope: Mapping[str, Any] | None) -> Dict[str, Any]:
    """Evaluate a structured request without query/keyword/embedding heuristics."""
    req, request_mapping_valid = normalize_mapping(request)
    env, envelope_mapping_valid = normalize_mapping(envelope)
    failures: list[str] = []

    if not request_mapping_valid:
        failures.append("request_mapping")
    if not envelope_mapping_valid:
        failures.append("workflow_envelope_mapping")
    unknown = sorted(set(req) - _ALLOWED_REQUEST_KEYS)
    if unknown:
        failures.append("unknown_request_fields:" + ",".join(unknown))
    if req.get("schema_version") != SCHEMA_VERSION:
        failures.append("schema_version")
    if req.get("policy") != POLICY_VERSION:
        failures.append("policy")
    if req.get("caller_declared_relevant") is not True:
        failures.append("caller_declared_relevant_is_true")
    if not bounded_text(req.get("capability_id"), maximum=128):
        failures.append("capability_id")
    if req.get("reason_kind") not in ALLOWED_REASONS:
        failures.append("allowed_reason_kind")

    fields = req.get("requested_fields")
    if not isinstance(fields, list) or not fields or len(fields) > len(ALLOWED_FIELDS):
        failures.append("bounded_requested_fields")
    elif any(not isinstance(field, str) or field not in ALLOWED_FIELDS for field in fields):
        failures.append("requested_fields_allowlist")

    refs = req.get("evidence_refs")
    if not isinstance(refs, list) or not (1 <= len(refs) <= 8):
        failures.append("bounded_evidence_refs")
    elif any(not isinstance(ref, str) or not ref.strip() or len(ref) > 128 for ref in refs):
        failures.append("valid_evidence_refs")

    if req.get("authority") != "relevance_request_only" or not no_effect_authorizations(req.get("authorizations")):
        failures.append("request_authority_advisory_only")
    request_digest = safe_canonical_digest(req)
    if request_digest is None:
        failures.append("request_bounded_canonical_json")
    if not _safe_workflow_envelope(env):
        failures.append("workflow_envelope_advisory_only")
    else:
        if req.get("capability_id") != env.get("capability_id"):
            failures.append("capability_binding")
        if req.get("expected_state") != env.get("state"):
            failures.append("state_binding")
        if req.get("envelope_evidence_digest") != env.get("evidence_digest"):
            failures.append("evidence_digest_binding")

    relevant = not failures
    return {
        "schema_version": SCHEMA_VERSION,
        "policy": POLICY_VERSION,
        "relevant": relevant,
        "decision": "REQUEST_WORKFLOW_CONTEXT" if relevant else "DO_NOT_REQUEST_WORKFLOW_CONTEXT",
        "failed_conditions": failures,
        "request_digest": request_digest or "",
        "reason_kind": req.get("reason_kind"),
        "capability_id": str(req.get("capability_id") or ""),
        "authority": "relevance_decision_only",
        "authorizations": {key: False for key in sorted(_REQUIRED_AUTH)},
        "invariants": {
            "query_text_is_not_a_trigger": True,
            "keyword_or_embedding_score_is_not_a_trigger": True,
            "explicit_structured_request_required": True,
            "evidence_digest_binding_required": True,
            "decision_does_not_execute_transition": True,
            "decision_does_not_guarantee_context_inclusion": True,
        },
    }



ACCOUNTABILITY_DECISION_TYPE = "capability_workflow_relevance"
ACCOUNTABILITY_POLICY = "capability_workflow_relevance_accountability_v1"
ACCOUNTABILITY_SCHEMA = "capability-workflow-relevance-accountability-v1"
ACCOUNTABILITY_RECORD_KEYS = frozenset({
    "schema_version", "decision_type", "policy", "capability_id", "reason_kind",
    "relevance_decision", "relevant", "failed_conditions", "request_digest",
    "workflow_state", "workflow_evidence_digest", "requested_fields",
    "evidence_ref_count", "evidence_refs_digest", "authority", "authorizations",
    "invariants", "provenance", "decision_id", "recorded_at",
})


def _digest_list(values: list[str]) -> str:
    return safe_canonical_digest(list(values or [])) or ""


def build_relevance_accountability(
    request: Mapping[str, Any] | None,
    envelope: Mapping[str, Any] | None,
    decision: Mapping[str, Any] | None = None,
) -> Dict[str, Any]:
    """Build a compact audit record bound to the exact relevance decision.

    The record stores no raw query text and no raw evidence payload. Evidence refs are
    represented only by a bounded count + digest. Building the record has no prompt,
    lifecycle, execution, patch, promotion, or truth authority.
    """
    req, _ = normalize_mapping(request)
    env, _ = normalize_mapping(envelope)
    expected = evaluate_relevance_request(req, env)
    supplied = dict(decision or expected)
    stable_keys = (
        "schema_version", "policy", "relevant", "decision", "failed_conditions",
        "request_digest", "reason_kind", "capability_id", "authority", "authorizations",
    )
    if any(supplied.get(key) != expected.get(key) for key in stable_keys):
        raise ValueError("relevance decision does not match request/envelope")

    refs = req.get("evidence_refs") if isinstance(req.get("evidence_refs"), list) else []
    fields = req.get("requested_fields") if isinstance(req.get("requested_fields"), list) else []
    return {
        "schema_version": ACCOUNTABILITY_SCHEMA,
        "decision_type": ACCOUNTABILITY_DECISION_TYPE,
        "policy": ACCOUNTABILITY_POLICY,
        "capability_id": expected.get("capability_id"),
        "reason_kind": expected.get("reason_kind"),
        "relevance_decision": expected.get("decision"),
        "relevant": expected.get("relevant") is True,
        "failed_conditions": list(expected.get("failed_conditions") or []),
        "request_digest": expected.get("request_digest"),
        "workflow_state": str(env.get("state") or ""),
        "workflow_evidence_digest": str(env.get("evidence_digest") or ""),
        "requested_fields": list(fields),
        "evidence_ref_count": len(refs),
        "evidence_refs_digest": _digest_list([str(ref) for ref in refs]),
        "authority": "workflow_relevance_accountability_only",
        "authorizations": {key: False for key in sorted(_REQUIRED_AUTH)},
        "invariants": {
            "audit_record_does_not_change_relevance": True,
            "audit_record_does_not_change_prompt": True,
            "raw_query_not_stored": True,
            "raw_evidence_not_stored": True,
            "evidence_refs_not_stored_raw": True,
            "transition_execution": False,
            "runtime_execution": False,
            "external_patch": False,
            "stable_promotion": False,
            "truth_commit": False,
        },
    }


def record_relevance_accountability(
    request: Mapping[str, Any] | None,
    envelope: Mapping[str, Any] | None,
    decision: Mapping[str, Any] | None = None,
    *,
    store_dir: str | None = None,
) -> Dict[str, Any]:
    """Persist a relevance audit artifact through the existing accountability ledger."""
    payload = build_relevance_accountability(request, envelope, decision)
    receipt = record_provenanced(payload, RELEVANCE_ISSUER, store_dir=store_dir)
    return {
        **receipt,
        "decision_type": ACCOUNTABILITY_DECISION_TYPE,
        "relevance_decision": payload["relevance_decision"],
        "relevant": payload["relevant"],
        "authority": "workflow_relevance_accountability_reference_only",
    }

def build_workflow_context(request: Mapping[str, Any] | None, envelope: Mapping[str, Any] | None) -> Dict[str, Any]:
    """Adapt a relevance decision to the unchanged F108 context-pack input contract."""
    decision = evaluate_relevance_request(request, envelope)
    return {
        "relevant": decision["relevant"],
        "envelope": dict(envelope or {}),
        "relevance_decision": decision,
    }


__all__ = [
    "SCHEMA_VERSION",
    "POLICY_VERSION",
    "ALLOWED_REASONS",
    "ALLOWED_FIELDS",
    "ACCOUNTABILITY_SCHEMA",
    "ACCOUNTABILITY_RECORD_KEYS",
    "build_relevance_request",
    "evaluate_relevance_request",
    "build_workflow_context",
    "ACCOUNTABILITY_DECISION_TYPE",
    "ACCOUNTABILITY_POLICY",
    "build_relevance_accountability",
    "record_relevance_accountability",
]
