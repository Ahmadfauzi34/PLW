"""F122 lease-bound executor attempt and terminal outcome reference machine.

F121 proves that one fresh, issuer-sealed plan was leased to one exact executor.
F122 adds a durable handoff ledger around that lease without pretending that a
ledger transition is the external action itself:

    LEASED -> ATTEMPT_REGISTERED -> SUCCEEDED | FAILED | INDETERMINATE

ATTEMPT_REGISTERED is a pre-execution durable barrier.  It proves only that the
bound executor claimed the one lease handoff.  A missing terminal receipt is
therefore unresolved evidence, not success or failure.  Terminal receipts are
executor observations bound to the exact lease/plan/attempt and likewise do not
prove postconditions, promote stable state, or commit truth by themselves.
"""
from __future__ import annotations

import json
import os
import re
import sqlite3
import time
from collections.abc import Mapping, Sequence
from pathlib import Path
from typing import Any, Dict

from core.accountability_provenance import seal_payload, verify_payload
from core.capability_action_lease import inspect_action_lease
from core.capability_contracts import (
    AUTHORIZATION_KEYS,
    exact_keys,
    is_sha256_id,
    no_effect_authorizations,
    normalize_mapping,
    safe_canonical_digest,
)
from core.context_accountability import DEFAULT_ACCOUNTABILITY_DIR


SCHEMA_VERSION = "capability-workflow-executor-outcome-v1"
POLICY_VERSION = "lease-bound-executor-outcome-v1"
ATTEMPT_DECISION_TYPE = "capability_workflow_executor_attempt"
OUTCOME_DECISION_TYPE = "capability_workflow_executor_outcome"
ATTEMPT_RECEIPT_SCHEMA = "capability-workflow-executor-attempt-receipt-v1"
OUTCOME_RECEIPT_SCHEMA = "capability-workflow-executor-outcome-receipt-v1"
ATTEMPT_RECEIPT_ISSUER = "plw.workflow.lease-bound-executor-attempt.v1"
OUTCOME_RECEIPT_ISSUER = "plw.workflow.lease-bound-executor-outcome.v1"
OUTCOME_DATABASE_SCHEMA_VERSION = 1
TERMINAL_STATUSES = frozenset({"SUCCEEDED", "FAILED", "INDETERMINATE"})

_EXECUTOR_ID = re.compile(r"[A-Za-z0-9][A-Za-z0-9._:/-]{2,127}\Z")
_ATTEMPT_KEY = re.compile(r"[A-Za-z0-9][A-Za-z0-9._:-]{15,127}\Z")
_OBSERVATION_KIND = re.compile(r"[a-z][a-z0-9._:-]{2,63}\Z")

_ATTEMPT_REQUEST_KEYS = frozenset({
    "schema_version", "policy", "lease_id", "executor_id", "attempt_key",
    "caller_registers_executor_attempt", "authority", "authorizations",
})
_ATTEMPT_BODY_KEYS = frozenset({
    "schema_version", "decision_type", "policy", "attempt_state",
    "request_digest", "lease_id", "executor_id", "attempt_key",
    "plan_digest", "capability_id", "workflow_state", "workflow_evidence_digest",
    "lease_acquired_at_epoch", "lease_expires_at_epoch", "registered_at_epoch",
    "authority_class", "scope",
})
_ATTEMPT_RECEIPT_KEYS = _ATTEMPT_BODY_KEYS | {"attempt_id", "provenance"}

_OUTCOME_REQUEST_KEYS = frozenset({
    "schema_version", "policy", "lease_id", "executor_id", "attempt_id",
    "terminal_status", "observation_kind", "observation_digest", "evidence_ids",
    "caller_reports_terminal_outcome", "authority", "authorizations",
})
_OUTCOME_BODY_KEYS = frozenset({
    "schema_version", "decision_type", "policy", "outcome_state",
    "request_digest", "lease_id", "attempt_id", "executor_id", "plan_digest",
    "capability_id", "workflow_state", "workflow_evidence_digest",
    "terminal_status", "observation_kind", "observation_digest", "evidence_ids",
    "registered_at_epoch", "recorded_at_epoch", "authority_class", "scope",
})
_OUTCOME_RECEIPT_KEYS = _OUTCOME_BODY_KEYS | {"outcome_id", "provenance"}


def _database_path(store_dir: str | os.PathLike[str] | None) -> Path:
    base = Path(
        store_dir
        or os.environ.get("PLW_ACCOUNTABILITY_DIR")
        or DEFAULT_ACCOUNTABILITY_DIR
    )
    return (base / "executor_outcomes.sqlite3").expanduser().resolve()


def _initialize_database(path: Path) -> sqlite3.Connection:
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    try:
        os.chmod(path.parent, 0o700)
    except OSError:
        pass
    if path.is_symlink():
        raise ValueError("Executor outcome database must not be a symbolic link")

    connection = sqlite3.connect(str(path), timeout=5.0, isolation_level=None)
    try:
        connection.execute("PRAGMA busy_timeout=5000")
        connection.execute("PRAGMA foreign_keys=ON")
        connection.execute("PRAGMA synchronous=FULL")
        connection.execute("PRAGMA journal_mode=DELETE")
        connection.execute("BEGIN IMMEDIATE")
        version = int(connection.execute("PRAGMA user_version").fetchone()[0])
        if version not in (0, OUTCOME_DATABASE_SCHEMA_VERSION):
            raise ValueError("Unsupported executor outcome database schema")
        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS executor_attempts (
                lease_id TEXT PRIMARY KEY,
                attempt_id TEXT NOT NULL UNIQUE,
                attempt_key TEXT NOT NULL UNIQUE,
                executor_id TEXT NOT NULL,
                plan_digest TEXT NOT NULL,
                registered_at_epoch INTEGER NOT NULL,
                attempt_request_digest TEXT NOT NULL,
                attempt_receipt_json TEXT NOT NULL,
                outcome_request_digest TEXT,
                terminal_status TEXT,
                recorded_at_epoch INTEGER,
                outcome_receipt_json TEXT
            )
            """
        )
        if version == 0:
            connection.execute(f"PRAGMA user_version={OUTCOME_DATABASE_SCHEMA_VERSION}")
        connection.execute("COMMIT")
        try:
            os.chmod(path, 0o600)
        except OSError:
            pass
        return connection
    except Exception:
        try:
            connection.execute("ROLLBACK")
        except sqlite3.Error:
            pass
        connection.close()
        raise


def _read_connection(path: Path) -> sqlite3.Connection:
    if not path.is_file() or path.is_symlink():
        raise FileNotFoundError("Executor outcome database is unavailable")
    connection = sqlite3.connect(path.as_uri() + "?mode=ro", uri=True, timeout=5.0)
    connection.execute("PRAGMA busy_timeout=5000")
    version = int(connection.execute("PRAGMA user_version").fetchone()[0])
    if version != OUTCOME_DATABASE_SCHEMA_VERSION:
        connection.close()
        raise ValueError("Unsupported executor outcome database schema")
    return connection


def _normalize_evidence_ids(value: Any) -> tuple[list[str], bool]:
    if value is None:
        return [], True
    if isinstance(value, (str, bytes)) or not isinstance(value, Sequence):
        return [], False
    if len(value) > 16:
        return [], False
    result: list[str] = []
    for item in value:
        if not is_sha256_id(item):
            return [], False
        assert isinstance(item, str)
        if item in result:
            return [], False
        result.append(item)
    return result, True


def _request_contract_failures(
    request: Mapping[str, Any],
    mapping_valid: bool,
    required_keys: frozenset[str],
) -> list[str]:
    """Return the shared exact-envelope failures for one F122 request."""
    failures: list[str] = []
    if not mapping_valid:
        failures.append("request_mapping")
    if not exact_keys(request, required_keys):
        failures.append("request_exact_schema")
    unknown = sorted(set(request) - required_keys)
    if unknown:
        failures.append("unknown_request_fields:" + ",".join(unknown))
    if request.get("schema_version") != SCHEMA_VERSION:
        failures.append("schema_version")
    if request.get("policy") != POLICY_VERSION:
        failures.append("policy")
    return failures


def _verify_attempt_receipt(
    receipt: Any,
    *,
    store_dir: str | os.PathLike[str] | None,
) -> bool:
    if not exact_keys(receipt, _ATTEMPT_RECEIPT_KEYS):
        return False
    assert isinstance(receipt, dict)
    body = {key: receipt[key] for key in _ATTEMPT_BODY_KEYS}
    attempt_id = safe_canonical_digest(body, max_bytes=32768)
    return (
        attempt_id is not None
        and receipt.get("attempt_id") == attempt_id
        and verify_payload(
            body, receipt.get("provenance"), ATTEMPT_RECEIPT_ISSUER,
            store_dir=store_dir,
        )
    )


def _verify_outcome_receipt(
    receipt: Any,
    *,
    store_dir: str | os.PathLike[str] | None,
) -> bool:
    if not exact_keys(receipt, _OUTCOME_RECEIPT_KEYS):
        return False
    assert isinstance(receipt, dict)
    body = {key: receipt[key] for key in _OUTCOME_BODY_KEYS}
    outcome_id = safe_canonical_digest(body, max_bytes=32768)
    return (
        outcome_id is not None
        and receipt.get("outcome_id") == outcome_id
        and verify_payload(
            body, receipt.get("provenance"), OUTCOME_RECEIPT_ISSUER,
            store_dir=store_dir,
        )
    )


def build_executor_attempt_request(
    lease_id: str,
    executor_id: str,
    attempt_key: str,
) -> Dict[str, Any]:
    """Build a no-effect F122 attempt-registration request."""
    return {
        "schema_version": SCHEMA_VERSION,
        "policy": POLICY_VERSION,
        "lease_id": str(lease_id or ""),
        "executor_id": str(executor_id or ""),
        "attempt_key": str(attempt_key or ""),
        "caller_registers_executor_attempt": True,
        "authority": "lease_bound_executor_attempt_request_only",
        "authorizations": {key: False for key in sorted(AUTHORIZATION_KEYS)},
    }


def evaluate_executor_attempt(
    request: Mapping[str, Any] | None,
    *,
    store_dir: str | os.PathLike[str] | None = None,
) -> Dict[str, Any]:
    """Evaluate one F121 -> F122 handoff without changing F122 durable state."""
    req, mapping_valid = normalize_mapping(request)
    failures = _request_contract_failures(req, mapping_valid, _ATTEMPT_REQUEST_KEYS)
    if req.get("caller_registers_executor_attempt") is not True:
        failures.append("caller_registers_executor_attempt_is_true")
    if (
        req.get("authority") != "lease_bound_executor_attempt_request_only"
        or not no_effect_authorizations(req.get("authorizations"))
    ):
        failures.append("request_has_no_execution_effect")

    request_digest = safe_canonical_digest(req)
    if request_digest is None:
        failures.append("request_bounded_canonical_json")
    lease_id = req.get("lease_id")
    executor_id = req.get("executor_id")
    attempt_key = req.get("attempt_key")
    if not is_sha256_id(lease_id):
        failures.append("lease_id")
    if not isinstance(executor_id, str) or _EXECUTOR_ID.fullmatch(executor_id) is None:
        failures.append("executor_id")
    if not isinstance(attempt_key, str) or _ATTEMPT_KEY.fullmatch(attempt_key) is None:
        failures.append("attempt_key")

    lease = inspect_action_lease(
        str(lease_id or ""),
        executor_id=str(executor_id) if isinstance(executor_id, str) else None,
        store_dir=store_dir,
    )
    if lease.get("lease_found") is not True:
        failures.append("lease_verification:" + str(lease.get("error") or "not_found"))
    elif lease.get("lease_active") is not True:
        failures.append("lease_not_active")
    receipt = lease.get("lease_receipt") if isinstance(lease.get("lease_receipt"), dict) else {}
    if receipt.get("scope") != "single_plan_single_executor_start":
        failures.append("lease_scope_binding")
    if receipt.get("executor_id") != executor_id:
        failures.append("executor_binding")
    if not is_sha256_id(receipt.get("plan_digest")):
        failures.append("plan_digest_binding")

    eligible = not failures
    return {
        "schema_version": SCHEMA_VERSION,
        "decision_type": ATTEMPT_DECISION_TYPE,
        "policy": POLICY_VERSION,
        "attempt_eligible": eligible,
        "decision": "EXECUTOR_ATTEMPT_ELIGIBLE" if eligible else "EXECUTOR_ATTEMPT_REJECTED",
        "failed_conditions": failures,
        "request_digest": request_digest or "",
        "lease_id": str(lease_id or ""),
        "executor_id": str(executor_id or ""),
        "attempt_key": str(attempt_key or ""),
        "plan_digest": str(receipt.get("plan_digest") or ""),
        "capability_id": str(receipt.get("capability_id") or ""),
        "workflow_state": str(receipt.get("workflow_state") or ""),
        "workflow_evidence_digest": str(receipt.get("workflow_evidence_digest") or ""),
        "lease_acquired_at_epoch": receipt.get("acquired_at_epoch"),
        "lease_expires_at_epoch": receipt.get("expires_at_epoch"),
        "evaluated_at_epoch": int(time.time()),
        "authority": "lease_bound_executor_attempt_eligibility_only",
        "authorizations": {key: False for key in sorted(AUTHORIZATION_KEYS)},
        "invariants": {
            "exact_f121_lease_revalidated": lease.get("lease_found") is True,
            "lease_must_be_active_at_registration": True,
            "attempt_evaluation_is_read_only": True,
            "attempt_eligibility_is_not_external_execution": True,
        },
    }


def register_executor_attempt(
    request: Mapping[str, Any] | None,
    *,
    store_dir: str | os.PathLike[str] | None = None,
    _fail_before_commit: bool = False,
) -> Dict[str, Any]:
    """Atomically register one executor attempt for one exact active F121 lease."""
    eligibility = evaluate_executor_attempt(request, store_dir=store_dir)
    if eligibility.get("attempt_eligible") is not True:
        return {
            **eligibility,
            "attempt_registered": False,
            "idempotent_recovery": False,
            "executor_handoff_claimed": False,
        }

    path = _database_path(store_dir)
    registered_at = int(time.time())
    body = {
        "schema_version": ATTEMPT_RECEIPT_SCHEMA,
        "decision_type": ATTEMPT_DECISION_TYPE,
        "policy": POLICY_VERSION,
        "attempt_state": "REGISTERED",
        "request_digest": str(eligibility.get("request_digest") or ""),
        "lease_id": str(eligibility.get("lease_id") or ""),
        "executor_id": str(eligibility.get("executor_id") or ""),
        "attempt_key": str(eligibility.get("attempt_key") or ""),
        "plan_digest": str(eligibility.get("plan_digest") or ""),
        "capability_id": str(eligibility.get("capability_id") or ""),
        "workflow_state": str(eligibility.get("workflow_state") or ""),
        "workflow_evidence_digest": str(eligibility.get("workflow_evidence_digest") or ""),
        "lease_acquired_at_epoch": int(eligibility.get("lease_acquired_at_epoch") or 0),
        "lease_expires_at_epoch": int(eligibility.get("lease_expires_at_epoch") or 0),
        "registered_at_epoch": registered_at,
        "authority_class": "lease_bound_executor_attempt",
        "scope": "single_lease_single_executor_attempt",
    }
    attempt_id = safe_canonical_digest(body, max_bytes=32768)
    if attempt_id is None:
        return {
            **eligibility,
            "attempt_registered": False,
            "idempotent_recovery": False,
            "executor_handoff_claimed": False,
            "failed_conditions": ["attempt_receipt_bounded_json"],
        }
    try:
        receipt = {
            "attempt_id": attempt_id,
            **body,
            "provenance": seal_payload(
                body, ATTEMPT_RECEIPT_ISSUER, store_dir=store_dir,
            ),
        }
        connection = _initialize_database(path)
    except Exception as exc:
        return {
            **eligibility,
            "attempt_registered": False,
            "idempotent_recovery": False,
            "executor_handoff_claimed": False,
            "failed_conditions": ["executor_outcome_store_open:" + type(exc).__name__],
        }

    status = "store_error"
    stored_receipt: Dict[str, Any] = {}
    failures: list[str] = []
    try:
        connection.execute("BEGIN IMMEDIATE")
        existing_key = connection.execute(
            "SELECT lease_id, executor_id, attempt_receipt_json FROM executor_attempts WHERE attempt_key = ?",
            (body["attempt_key"],),
        ).fetchone()
        if existing_key is not None:
            connection.execute("COMMIT")
            try:
                prior = json.loads(existing_key[2])
            except (TypeError, json.JSONDecodeError):
                status = "store_error"
                failures = ["attempt_receipt_corrupt"]
            else:
                if (
                    existing_key[0] == body["lease_id"]
                    and existing_key[1] == body["executor_id"]
                    and prior.get("request_digest") == body["request_digest"]
                    and _verify_attempt_receipt(prior, store_dir=store_dir)
                ):
                    status = "recovered"
                    stored_receipt = prior
                else:
                    status = "conflict"
                    failures = ["attempt_key_conflict"]
        else:
            # Expiry is checked again after acquiring the write lock.  The lease
            # only controls whether an attempt may start; a terminal receipt may
            # be recorded later even if the lease subsequently expires.
            if body["lease_expires_at_epoch"] <= int(time.time()):
                connection.execute("ROLLBACK")
                status = "conflict"
                failures = ["lease_expired_before_attempt_commit"]
            else:
                try:
                    connection.execute(
                        """
                        INSERT INTO executor_attempts (
                            lease_id, attempt_id, attempt_key, executor_id, plan_digest,
                            registered_at_epoch, attempt_request_digest,
                            attempt_receipt_json
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                        """,
                        (
                            body["lease_id"], attempt_id, body["attempt_key"],
                            body["executor_id"], body["plan_digest"], registered_at,
                            body["request_digest"],
                            json.dumps(receipt, ensure_ascii=False, sort_keys=True, separators=(",", ":")),
                        ),
                    )
                except sqlite3.IntegrityError:
                    connection.execute("ROLLBACK")
                    status = "conflict"
                    failures = ["lease_attempt_already_registered"]
                else:
                    if _fail_before_commit:
                        raise RuntimeError("injected_precommit_failure")
                    connection.execute("COMMIT")
                    status = "registered"
                    stored_receipt = receipt
    except Exception as exc:
        try:
            connection.execute("ROLLBACK")
        except sqlite3.Error:
            pass
        status = "store_error"
        failures = ["executor_attempt_transaction:" + type(exc).__name__]
    finally:
        connection.close()

    registered = status == "registered"
    recovered = status == "recovered"
    return {
        **eligibility,
        "attempt_registered": registered,
        "idempotent_recovery": recovered,
        "executor_handoff_claimed": registered,
        "decision": (
            "EXECUTOR_ATTEMPT_REGISTERED" if registered
            else "EXECUTOR_ATTEMPT_RECOVERED_NO_SECOND_HANDOFF" if recovered
            else "EXECUTOR_ATTEMPT_REJECTED"
        ),
        "failed_conditions": failures,
        "attempt_id": str(stored_receipt.get("attempt_id") or ""),
        "attempt_receipt": stored_receipt,
        "state_transition": {
            "from": "LEASED",
            "to": "ATTEMPT_REGISTERED" if registered else "UNCHANGED",
            "durable": registered or recovered,
            "atomic": status in {"registered", "recovered", "conflict"},
        },
        "authority": "workflow_lease_bound_executor_attempt_only",
        "authorizations": {key: False for key in sorted(AUTHORIZATION_KEYS)},
        "effects": {
            "attempt_state_changed": registered,
            "external_execution_observed": False,
            "postcondition_proven": False,
            "truth_committed": False,
        },
        "invariants": {
            **eligibility.get("invariants", {}),
            "one_registered_attempt_per_lease": True,
            "recovery_never_claims_second_handoff": True,
            "registration_is_not_proof_external_execution_started": True,
            "missing_terminal_outcome_remains_unresolved": True,
        },
    }


def build_executor_outcome_request(
    lease_id: str,
    executor_id: str,
    attempt_id: str,
    terminal_status: str,
    observation_kind: str,
    observation: Mapping[str, Any] | None,
    *,
    evidence_ids: Sequence[str] | None = None,
) -> Dict[str, Any]:
    """Build an F122 terminal report while keeping raw observation out of the receipt."""
    observed, valid = normalize_mapping(observation)
    normalized_evidence, evidence_valid = _normalize_evidence_ids(evidence_ids)
    return {
        "schema_version": SCHEMA_VERSION,
        "policy": POLICY_VERSION,
        "lease_id": str(lease_id or ""),
        "executor_id": str(executor_id or ""),
        "attempt_id": str(attempt_id or ""),
        "terminal_status": str(terminal_status or "").upper(),
        "observation_kind": str(observation_kind or ""),
        "observation_digest": safe_canonical_digest(observed, max_bytes=32768) if valid else "",
        "evidence_ids": normalized_evidence if evidence_valid else [],
        "caller_reports_terminal_outcome": valid and evidence_valid,
        "authority": "lease_bound_executor_terminal_report_only",
        "authorizations": {key: False for key in sorted(AUTHORIZATION_KEYS)},
    }


def _load_attempt_row(
    connection: sqlite3.Connection,
    lease_id: str,
) -> tuple[Any, ...] | None:
    return connection.execute(
        """
        SELECT attempt_id, executor_id, plan_digest, registered_at_epoch,
               attempt_receipt_json, outcome_request_digest, terminal_status,
               recorded_at_epoch, outcome_receipt_json
        FROM executor_attempts WHERE lease_id = ?
        """,
        (lease_id,),
    ).fetchone()


def record_executor_outcome(
    request: Mapping[str, Any] | None,
    observation: Mapping[str, Any] | None,
    *,
    store_dir: str | os.PathLike[str] | None = None,
    _fail_before_commit: bool = False,
) -> Dict[str, Any]:
    """Record exactly one terminal executor observation for one registered attempt."""
    req, req_valid = normalize_mapping(request)
    observed, observation_valid = normalize_mapping(observation)
    failures = _request_contract_failures(req, req_valid, _OUTCOME_REQUEST_KEYS)
    if not observation_valid:
        failures.append("observation_mapping")
    if req.get("caller_reports_terminal_outcome") is not True:
        failures.append("caller_reports_terminal_outcome_is_true")
    if (
        req.get("authority") != "lease_bound_executor_terminal_report_only"
        or not no_effect_authorizations(req.get("authorizations"))
    ):
        failures.append("request_has_no_new_execution_authority")
    if not is_sha256_id(req.get("lease_id")):
        failures.append("lease_id")
    if not is_sha256_id(req.get("attempt_id")):
        failures.append("attempt_id")
    executor_id = req.get("executor_id")
    if not isinstance(executor_id, str) or _EXECUTOR_ID.fullmatch(executor_id) is None:
        failures.append("executor_id")
    terminal_status = req.get("terminal_status")
    if terminal_status not in TERMINAL_STATUSES:
        failures.append("terminal_status")
    observation_kind = req.get("observation_kind")
    if not isinstance(observation_kind, str) or _OBSERVATION_KIND.fullmatch(observation_kind) is None:
        failures.append("observation_kind")
    observation_digest = safe_canonical_digest(observed, max_bytes=32768)
    if observation_digest is None or req.get("observation_digest") != observation_digest:
        failures.append("observation_digest")
    evidence_ids, evidence_valid = _normalize_evidence_ids(req.get("evidence_ids"))
    if not evidence_valid or evidence_ids != req.get("evidence_ids"):
        failures.append("evidence_ids")
    request_digest = safe_canonical_digest(req)
    if request_digest is None:
        failures.append("request_bounded_canonical_json")

    if failures:
        return {
            "schema_version": SCHEMA_VERSION,
            "decision_type": OUTCOME_DECISION_TYPE,
            "policy": POLICY_VERSION,
            "outcome_recorded": False,
            "idempotent_recovery": False,
            "decision": "EXECUTOR_OUTCOME_REJECTED",
            "failed_conditions": failures,
            "request_digest": request_digest or "",
            "lease_id": str(req.get("lease_id") or ""),
            "attempt_id": str(req.get("attempt_id") or ""),
            "executor_id": str(executor_id or ""),
            "authority": "workflow_lease_bound_executor_outcome_only",
            "authorizations": {key: False for key in sorted(AUTHORIZATION_KEYS)},
        }

    path = _database_path(store_dir)
    try:
        connection = _initialize_database(path)
    except Exception as exc:
        return {
            "schema_version": SCHEMA_VERSION,
            "decision_type": OUTCOME_DECISION_TYPE,
            "policy": POLICY_VERSION,
            "outcome_recorded": False,
            "idempotent_recovery": False,
            "decision": "EXECUTOR_OUTCOME_REJECTED",
            "failed_conditions": ["executor_outcome_store_open:" + type(exc).__name__],
            "request_digest": request_digest or "",
            "lease_id": str(req.get("lease_id") or ""),
            "attempt_id": str(req.get("attempt_id") or ""),
            "executor_id": str(executor_id or ""),
            "authority": "workflow_lease_bound_executor_outcome_only",
            "authorizations": {key: False for key in sorted(AUTHORIZATION_KEYS)},
        }

    status = "store_error"
    outcome_receipt: Dict[str, Any] = {}
    failures = []
    try:
        connection.execute("BEGIN IMMEDIATE")
        row = _load_attempt_row(connection, str(req["lease_id"]))
        if row is None:
            connection.execute("ROLLBACK")
            status = "conflict"
            failures = ["attempt_not_registered"]
        else:
            try:
                attempt_receipt = json.loads(row[4])
            except (TypeError, json.JSONDecodeError):
                connection.execute("ROLLBACK")
                status = "store_error"
                failures = ["attempt_receipt_corrupt"]
            else:
                if not _verify_attempt_receipt(attempt_receipt, store_dir=store_dir):
                    connection.execute("ROLLBACK")
                    status = "store_error"
                    failures = ["attempt_receipt_verification_failed"]
                elif row[0] != req["attempt_id"]:
                    connection.execute("ROLLBACK")
                    status = "conflict"
                    failures = ["attempt_id_binding_mismatch"]
                elif row[1] != req["executor_id"]:
                    connection.execute("ROLLBACK")
                    status = "conflict"
                    failures = ["executor_binding_mismatch"]
                elif row[8] is not None:
                    connection.execute("COMMIT")
                    try:
                        prior = json.loads(row[8])
                    except (TypeError, json.JSONDecodeError):
                        status = "store_error"
                        failures = ["outcome_receipt_corrupt"]
                    else:
                        if (
                            row[5] == request_digest
                            and row[6] == terminal_status
                            and _verify_outcome_receipt(prior, store_dir=store_dir)
                        ):
                            status = "recovered"
                            outcome_receipt = prior
                        else:
                            status = "conflict"
                            failures = ["terminal_outcome_already_recorded"]
                else:
                    recorded_at = int(time.time())
                    body = {
                        "schema_version": OUTCOME_RECEIPT_SCHEMA,
                        "decision_type": OUTCOME_DECISION_TYPE,
                        "policy": POLICY_VERSION,
                        "outcome_state": "TERMINAL",
                        "request_digest": request_digest or "",
                        "lease_id": str(req["lease_id"]),
                        "attempt_id": str(req["attempt_id"]),
                        "executor_id": str(req["executor_id"]),
                        "plan_digest": str(row[2]),
                        "capability_id": str(attempt_receipt.get("capability_id") or ""),
                        "workflow_state": str(attempt_receipt.get("workflow_state") or ""),
                        "workflow_evidence_digest": str(attempt_receipt.get("workflow_evidence_digest") or ""),
                        "terminal_status": str(terminal_status),
                        "observation_kind": str(observation_kind),
                        "observation_digest": str(observation_digest or ""),
                        "evidence_ids": evidence_ids,
                        "registered_at_epoch": int(row[3]),
                        "recorded_at_epoch": recorded_at,
                        "authority_class": "executor_terminal_observation",
                        "scope": "single_registered_attempt",
                    }
                    outcome_id = safe_canonical_digest(body, max_bytes=32768)
                    if outcome_id is None:
                        connection.execute("ROLLBACK")
                        status = "store_error"
                        failures = ["outcome_receipt_bounded_json"]
                    else:
                        receipt = {
                            "outcome_id": outcome_id,
                            **body,
                            "provenance": seal_payload(
                                body, OUTCOME_RECEIPT_ISSUER, store_dir=store_dir,
                            ),
                        }
                        cursor = connection.execute(
                            """
                            UPDATE executor_attempts
                            SET outcome_request_digest = ?, terminal_status = ?,
                                recorded_at_epoch = ?, outcome_receipt_json = ?
                            WHERE lease_id = ? AND outcome_receipt_json IS NULL
                            """,
                            (
                                request_digest, terminal_status, recorded_at,
                                json.dumps(receipt, ensure_ascii=False, sort_keys=True, separators=(",", ":")),
                                req["lease_id"],
                            ),
                        )
                        if cursor.rowcount != 1:
                            connection.execute("ROLLBACK")
                            status = "conflict"
                            failures = ["terminal_outcome_race_lost"]
                        elif _fail_before_commit:
                            raise RuntimeError("injected_precommit_failure")
                        else:
                            connection.execute("COMMIT")
                            status = "recorded"
                            outcome_receipt = receipt
    except Exception as exc:
        try:
            connection.execute("ROLLBACK")
        except sqlite3.Error:
            pass
        status = "store_error"
        failures = ["executor_outcome_transaction:" + type(exc).__name__]
    finally:
        connection.close()

    recorded = status == "recorded"
    recovered = status == "recovered"
    final_status = str(outcome_receipt.get("terminal_status") or terminal_status or "")
    return {
        "schema_version": SCHEMA_VERSION,
        "decision_type": OUTCOME_DECISION_TYPE,
        "policy": POLICY_VERSION,
        "outcome_recorded": recorded,
        "idempotent_recovery": recovered,
        "decision": (
            "EXECUTOR_OUTCOME_RECORDED" if recorded
            else "EXECUTOR_OUTCOME_RECOVERED" if recovered
            else "EXECUTOR_OUTCOME_REJECTED"
        ),
        "failed_conditions": failures,
        "request_digest": request_digest or "",
        "lease_id": str(req.get("lease_id") or ""),
        "attempt_id": str(req.get("attempt_id") or ""),
        "executor_id": str(req.get("executor_id") or ""),
        "terminal_status": final_status,
        "outcome_id": str(outcome_receipt.get("outcome_id") or ""),
        "outcome_receipt": outcome_receipt,
        "authority": "workflow_lease_bound_executor_outcome_only",
        "authorizations": {key: False for key in sorted(AUTHORIZATION_KEYS)},
        "effects": {
            "outcome_state_changed": recorded,
            "stable_promoted": False,
            "truth_committed": False,
        },
        "proof_boundary": {
            "executor_reported_terminal": recorded or recovered,
            "terminal_status": final_status,
            "postcondition_proven": False,
            "claim_truth_settled": False,
            "absence_of_side_effects_proven": False,
        },
        "invariants": {
            "one_terminal_outcome_per_attempt": True,
            "raw_observation_not_stored": True,
            "outcome_may_be_recorded_after_lease_expiry": True,
            "executor_success_report_is_not_postcondition_proof": True,
            "executor_failure_report_does_not_prove_no_side_effects": True,
            "indeterminate_is_first_class_terminal_state": True,
        },
    }


def inspect_executor_outcome(
    lease_id: str,
    *,
    executor_id: str | None = None,
    store_dir: str | os.PathLike[str] | None = None,
) -> Dict[str, Any]:
    """Read F122 state without creating a second handoff or terminal report."""
    if not is_sha256_id(lease_id):
        return {"attempt_found": False, "error": "invalid_lease_id"}
    path = _database_path(store_dir)
    try:
        connection = _read_connection(path)
        try:
            row = _load_attempt_row(connection, lease_id)
        finally:
            connection.close()
    except (FileNotFoundError, ValueError, sqlite3.Error, OSError) as exc:
        return {"attempt_found": False, "error": "executor_outcome_store_read:" + type(exc).__name__}
    if row is None:
        return {"attempt_found": False, "error": "executor_attempt_not_found"}
    try:
        attempt_receipt = json.loads(row[4])
    except (TypeError, json.JSONDecodeError):
        return {"attempt_found": False, "error": "attempt_receipt_corrupt"}
    if not _verify_attempt_receipt(attempt_receipt, store_dir=store_dir):
        return {"attempt_found": False, "error": "attempt_receipt_verification_failed"}
    if executor_id is not None and row[1] != executor_id:
        return {"attempt_found": False, "error": "executor_binding_mismatch"}

    outcome_receipt: Dict[str, Any] = {}
    terminal = row[8] is not None
    if terminal:
        try:
            outcome_receipt = json.loads(row[8])
        except (TypeError, json.JSONDecodeError):
            return {"attempt_found": False, "error": "outcome_receipt_corrupt"}
        if not _verify_outcome_receipt(outcome_receipt, store_dir=store_dir):
            return {"attempt_found": False, "error": "outcome_receipt_verification_failed"}

    return {
        "attempt_found": True,
        "outcome_terminal": terminal,
        "decision": "EXECUTOR_OUTCOME_TERMINAL" if terminal else "EXECUTOR_ATTEMPT_UNRESOLVED",
        "lease_id": lease_id,
        "attempt_id": str(row[0]),
        "executor_id": str(row[1]),
        "plan_digest": str(row[2]),
        "registered_at_epoch": int(row[3]),
        "terminal_status": str(row[6]) if row[6] is not None else None,
        "recorded_at_epoch": int(row[7]) if row[7] is not None else None,
        "attempt_receipt": attempt_receipt,
        "outcome_receipt": outcome_receipt,
        "executor_handoff_claimed": False,
        "authority": "lease_bound_executor_outcome_inspection_only",
        "proof_boundary": {
            "postcondition_proven": False,
            "claim_truth_settled": False,
            "unresolved_requires_reconciliation": not terminal,
        },
        "invariants": {
            "inspection_is_read_only": True,
            "inspection_cannot_claim_executor_handoff": True,
            "registered_without_terminal_is_not_success_or_failure": True,
        },
    }


__all__ = [
    "SCHEMA_VERSION", "POLICY_VERSION", "ATTEMPT_DECISION_TYPE",
    "OUTCOME_DECISION_TYPE", "ATTEMPT_RECEIPT_SCHEMA", "OUTCOME_RECEIPT_SCHEMA",
    "ATTEMPT_RECEIPT_ISSUER", "OUTCOME_RECEIPT_ISSUER",
    "OUTCOME_DATABASE_SCHEMA_VERSION", "TERMINAL_STATUSES",
    "build_executor_attempt_request", "evaluate_executor_attempt",
    "register_executor_attempt", "build_executor_outcome_request",
    "record_executor_outcome", "inspect_executor_outcome",
]
