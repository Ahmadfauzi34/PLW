"""Deterministic adaptive routing for one-call agent work packs.

The router may choose evidence surfaces, but it never grants authority and
never executes runtime commands or source mutations.  Its decisions are kept
explicit so an agent can audit why a broader or narrower pack was selected.
"""

from __future__ import annotations

import re
from typing import Any, Dict, Iterable, List, Sequence


WORK_GOALS = (
    "auto",
    "understand",
    "change",
    "architecture",
    "performance",
    "runtime",
    "history",
)
WORK_DEPTHS = ("auto", "quick", "standard", "deep")

_GOAL_TERMS = {
    "runtime": (
        "test pass",
        "tests pass",
        "runtime",
        "run now",
        "actually run",
        "build pass",
        "lint pass",
        "berjalan",
        "jalankan",
        "lulus test",
        "lulus build",
    ),
    "performance": (
        "performance",
        "latency",
        "memory leak",
        "deopt",
        "slow",
        "cache",
        "async waterfall",
        "performa",
        "lambat",
    ),
    "architecture": (
        "architecture",
        "dependency",
        "dependencies",
        "circular",
        "cycle",
        "topology",
        "boundary",
        "arsitektur",
        "dependensi",
        "siklus",
    ),
    "change": (
        "change impact",
        "impact",
        "edit",
        "modify",
        "refactor",
        "fix",
        "patch",
        "ubah",
        "perbaiki",
        "dampak perubahan",
    ),
    "history": (
        "history",
        "historical",
        "rationale",
        "previous decision",
        "riwayat",
        "alasan sebelumnya",
        "keputusan lama",
    ),
}

_GOAL_ANALYZERS = {
    "understand": (),
    "change": (
        "topo.risk",
        "topo.circular",
        "topo.test_reachability",
        "perf.async",
        "perf.deopt",
        "perf.gc",
        "perf.cache",
    ),
    "architecture": (
        "topo.orphan",
        "topo.entrypoint",
        "topo.circular",
        "topo.risk",
        "topo.test_reachability",
        "hott.isomorphism",
        "hott.sheaf",
        "hott.homotopy",
        "hott.manifold",
    ),
    "performance": (
        "perf.async",
        "perf.deopt",
        "perf.gc",
        "perf.cache",
        "topo.risk",
    ),
    "runtime": ("topo.entrypoint", "topo.test_reachability", "topo.risk"),
    "history": (),
}

_SEVERITY_ORDER = {"high": 0, "medium": 1, "low": 2, "info": 3}


def _normalized_text(value: str) -> str:
    return " ".join(re.findall(r"[a-z0-9_]+", value.casefold()))


def _matching_terms(task: str, terms: Sequence[str]) -> List[str]:
    normalized = _normalized_text(task)
    return [term for term in terms if _normalized_text(term) in normalized]


def resolve_work_goal(
    task: str,
    requested_goal: str = "auto",
    requested_claims: Iterable[str] = (),
) -> Dict[str, Any]:
    """Resolve an evidence-routing goal without treating inference as proof."""
    normalized_goal = str(requested_goal or "auto").strip().lower()
    if normalized_goal not in WORK_GOALS:
        return {
            "error": "invalid_work_goal",
            "requested_goal": requested_goal,
            "supported_goals": list(WORK_GOALS),
        }
    if normalized_goal != "auto":
        return {
            "goal": normalized_goal,
            "selection_source": "explicit",
            "signals": [f"explicit_goal:{normalized_goal}"],
            "confidence": 1.0,
            "authority": "evidence_routing_only",
        }

    claims = {str(value) for value in requested_claims}
    if claims & {"runtime_test_result", "runtime_behavior"}:
        return {
            "goal": "runtime",
            "selection_source": "claim_obligation",
            "signals": sorted(claims & {"runtime_test_result", "runtime_behavior"}),
            "confidence": 1.0,
            "authority": "evidence_routing_only",
        }
    if "architecture_invariant" in claims:
        return {
            "goal": "architecture",
            "selection_source": "claim_obligation",
            "signals": ["architecture_invariant"],
            "confidence": 1.0,
            "authority": "evidence_routing_only",
        }
    if claims & {"dependency_structure", "static_test_structure"}:
        return {
            "goal": "change",
            "selection_source": "claim_obligation",
            "signals": sorted(claims & {"dependency_structure", "static_test_structure"}),
            "confidence": 1.0,
            "authority": "evidence_routing_only",
        }
    if claims & {"historical_rationale", "historical_decision"}:
        return {
            "goal": "history",
            "selection_source": "claim_obligation",
            "signals": sorted(claims & {"historical_rationale", "historical_decision"}),
            "confidence": 1.0,
            "authority": "evidence_routing_only",
        }

    for goal in ("runtime", "performance", "architecture", "change", "history"):
        matches = _matching_terms(task, _GOAL_TERMS[goal])
        if matches:
            return {
                "goal": goal,
                "selection_source": "bounded_task_signal",
                "signals": [f"task_term:{value}" for value in matches[:4]],
                "confidence": 0.75,
                "authority": "evidence_routing_only",
                "inference_is_not_claim_proof": True,
            }
    return {
        "goal": "understand",
        "selection_source": "safe_default",
        "signals": ["no_specialized_signal"],
        "confidence": 0.5,
        "authority": "evidence_routing_only",
        "inference_is_not_claim_proof": True,
    }


def build_adaptive_work_plan(
    task: str,
    requested_goal: str,
    requested_depth: str,
    requested_claims: Iterable[str],
    target_count: int,
    max_findings: int,
) -> Dict[str, Any]:
    """Build a bounded, observable plan for a one-call work pack."""
    route = resolve_work_goal(task, requested_goal, requested_claims)
    if route.get("error"):
        return route

    normalized_depth = str(requested_depth or "auto").strip().lower()
    if normalized_depth not in WORK_DEPTHS:
        return {
            "error": "invalid_work_depth",
            "requested_depth": requested_depth,
            "supported_depths": list(WORK_DEPTHS),
        }
    if normalized_depth == "auto":
        goal = route["goal"]
        normalized_depth = (
            "quick" if goal in ("understand", "history") and target_count <= 1 else "standard"
        )
        depth_source = "adaptive_default"
    else:
        depth_source = "explicit"

    goal = route["goal"]
    include_target_briefs = target_count > 0
    include_analysis_summary = normalized_depth != "quick" or goal in (
        "change",
        "architecture",
        "performance",
        "runtime",
    )
    analyzers = list(_GOAL_ANALYZERS.get(goal, ()))
    if normalized_depth == "deep":
        analyzers = ["*"]

    finding_limit = 0
    if include_analysis_summary and goal not in ("understand", "history"):
        finding_limit = min(max_findings, 100 if normalized_depth == "deep" else 24)

    equivalent_surfaces = ["context"]
    if include_analysis_summary:
        equivalent_surfaces.append("analyze:summary")
    equivalent_surfaces.extend(f"brief:{index + 1}" for index in range(target_count))

    return {
        "goal": goal,
        "goal_selection": route,
        "depth": normalized_depth,
        "depth_selection_source": depth_source,
        "stages": [
            "bounded_context",
            *( ["analysis_summary"] if include_analysis_summary else [] ),
            *( ["target_briefs"] if include_target_briefs else [] ),
            *( ["bounded_findings"] if finding_limit else [] ),
            "proof_gate",
        ],
        "include_target_briefs": include_target_briefs,
        "include_analysis_summary": include_analysis_summary,
        "finding_analyzers": analyzers,
        "finding_limit": finding_limit,
        "call_reduction": {
            "external_tool_calls": 1,
            "equivalent_separate_calls": len(equivalent_surfaces),
            "avoided_follow_up_calls": max(0, len(equivalent_surfaces) - 1),
            "equivalent_surfaces": equivalent_surfaces,
            "canonical_graph_builds": 1,
        },
        "authority": {
            "route_evidence": True,
            "execute_runtime": False,
            "mutate_source": False,
            "mutate_external_repository": False,
            "grant_workflow_authority": False,
            "commit_truth": False,
        },
        "state_effect_contract": {
            "local_derived_cache_or_provenance_may_change": True,
            "canonical_memory_or_fiber_change_authorized": False,
            "source_or_repository_change_authorized": False,
        },
    }


def select_work_findings(
    analyzer_output: Dict[str, Any],
    analyzer_names: Sequence[str],
    target_paths: Sequence[str],
    limit: int,
) -> Dict[str, Any]:
    """Select a deterministic bounded finding projection for the chosen goal."""
    if limit <= 0:
        return {"selected": [], "selected_count": 0, "eligible_count": 0, "truncated": False}

    include_all = "*" in analyzer_names
    allowed = set(analyzer_names)
    targets = {str(path).replace("\\", "/") for path in target_paths}
    eligible: List[Dict[str, Any]] = []
    for analyzer_name, result in sorted((analyzer_output.get("results") or {}).items()):
        if not include_all and analyzer_name not in allowed:
            continue
        for finding in result.get("findings", []) or []:
            row = {"analyzer": analyzer_name, **finding}
            path = str(row.get("file", "")).replace("\\", "/")
            row["target_match"] = path in targets
            eligible.append(row)

    eligible.sort(
        key=lambda row: (
            0 if row.get("target_match") else 1,
            _SEVERITY_ORDER.get(str(row.get("severity", "info")), 4),
            str(row.get("analyzer", "")),
            str(row.get("file", "")),
            str(row.get("type", "")),
        )
    )
    selected = eligible[:limit]
    return {
        "selected": selected,
        "selected_count": len(selected),
        "eligible_count": len(eligible),
        "truncated": len(eligible) > len(selected),
        "limit": limit,
    }
