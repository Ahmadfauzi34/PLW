"""Proof-transition registry for PLW claim recovery.

The registry turns a *proof gap* into a bounded set of valid next transitions.
It is a reference machine, not an executor: no shell command is run here and no
claim is promoted to true by this module.  A transition only describes the
minimum authority/evidence that can legitimately move a blocked obligation to
a state that can be validated again.

Design rules:
- transition selection is evidence-kind aware;
- lower-cost structured/read-only transitions are preferred;
- domain memory is valid for historical/continuity obligations only;
- runtime truth requires external execution evidence, never static/memory
  substitution;
- raw Bash remains an escape hatch, but it is not the default transition when a
  narrower PLW capability exists.
"""
from __future__ import annotations

import hashlib
import json
from typing import Any, Dict, Iterable, List, Optional, Sequence, Set, Tuple

from core.context_accountability import record_accountability
from core.decision_lineage import record_lineage_node

REGISTRY_POLICY = "proof_transition_registry_v1"
RESPONSIBLE_COMPONENT = "core.proof_transitions.compile_proof_transitions"
RESPONSIBLE_ROLE = "proof_transition_custodian"

# Cost is deliberately ordinal.  It is a ranking hint, not a latency/token
# promise.  mutation_risk=0 means observational/read-only from PLW's point of
# view; external execution can still mutate the target program and therefore is
# explicitly marked unknown/high.
_TRANSITIONS: Dict[str, Dict[str, Any]] = {
    "recover_current_source": {
        "capability": "context.source.recover",
        "interface": "plw context",
        "authority_domain": "current_source",
        "produces": ["exact_current_source_witness"],
        "side_effect_class": "read_only",
        "execution_authority": "plw",
        "auto_execute_allowed": False,
        "cost": {"context": 2, "compute": 1, "mutation_risk": 0},
        "validation": "exact source witness must be present in the next Truth Floor for the same target/snapshot",
    },
    "recover_dependency_witness": {
        "capability": "graph.dependency.recover",
        "interface": "plw context",
        "authority_domain": "current_graph",
        "produces": ["dependency_graph_witness", "exact_current_source_witness"],
        "side_effect_class": "read_only",
        "execution_authority": "plw",
        "auto_execute_allowed": False,
        "cost": {"context": 2, "compute": 1, "mutation_risk": 0},
        "validation": "next claim gate must bind the dependency witness to the current graph_content_signature",
    },
    "recover_architecture_analyzer_witness": {
        "capability": "analyzer.architecture.inspect",
        "interface": "plw check",
        "authority_domain": "current_snapshot_analyzer",
        "produces": ["current_snapshot_analyzer_witness"],
        "side_effect_class": "read_only",
        "execution_authority": "plw",
        "auto_execute_allowed": False,
        "cost": {"context": 2, "compute": 2, "mutation_risk": 0},
        "validation": "required analyzer result_sha256 values must be present for the current SharedGraph snapshot",
    },
    "recover_static_test_analyzer_witness": {
        "capability": "analyzer.test_reachability.inspect",
        "interface": "plw check",
        "authority_domain": "current_snapshot_analyzer",
        "produces": ["static_test_reachability_witness"],
        "side_effect_class": "read_only",
        "execution_authority": "plw",
        "auto_execute_allowed": False,
        "cost": {"context": 2, "compute": 2, "mutation_risk": 0},
        "validation": "topo.test_reachability witness must be present; it still cannot satisfy runtime pass/fail",
    },
    "recover_exact_memory": {
        "capability": "memory.exact.get",
        "interface": "plw memory get",
        "authority_domain": "domain_memory_history",
        "produces": ["exact_historical_memory_witness"],
        "side_effect_class": "read_only",
        "execution_authority": "plw",
        "auto_execute_allowed": False,
        "cost": {"context": 1, "compute": 1, "mutation_risk": 0},
        "validation": "exact memory ID/content hash must satisfy the historical Truth Floor; current source retains precedence",
    },
    "verify_historical_memory_against_current_source": {
        "capability": "memory.current_source.verify",
        "interface": "plw context",
        "authority_domain": "current_source_plus_history",
        "produces": ["verified_historical_memory_witness", "exact_current_source_witness"],
        "side_effect_class": "read_only",
        "execution_authority": "plw",
        "auto_execute_allowed": False,
        "cost": {"context": 2, "compute": 1, "mutation_risk": 0},
        "validation": "historical observation must be compared against current source; memory may not override current state",
    },
    "obtain_runtime_validation": {
        "capability": "runtime.execute_then_observe",
        "interface": "external shell/test runner + plw compact-output + plw attest-runtime",
        "authority_domain": "current_runtime_observation",
        "produces": ["current_runtime_execution_attestation"],
        "side_effect_class": "external_execution_unknown",
        "execution_authority": "agent_or_host_shell",
        "auto_execute_allowed": False,
        "cost": {"context": 2, "compute": 3, "mutation_risk": 3},
        "validation": (
            "execution must be current and scoped to the claim; compact-output preserves/references raw stdout/stderr, "
            "attest-runtime binds output SHA + exit code + truth scope + graph snapshot + target, and the next claim gate "
            "must revalidate it; static analysis or memory cannot substitute for the execution observation"
        ),
    },
}

# Which transition types are admissible for each proof obligation.  This is the
# anti-substitution boundary: an otherwise valid transition can still be invalid
# for a particular claim kind.
_CLAIM_ALLOWED: Dict[str, Set[str]] = {
    "current_source_fact": {"recover_current_source"},
    "static_behavior": {"recover_current_source"},
    "dependency_structure": {"recover_dependency_witness", "recover_current_source"},
    "architecture_invariant": {"recover_architecture_analyzer_witness", "recover_current_source"},
    "static_test_structure": {"recover_static_test_analyzer_witness", "recover_current_source"},
    "historical_rationale": {"recover_exact_memory", "verify_historical_memory_against_current_source", "recover_current_source"},
    "runtime_test_result": {"obtain_runtime_validation"},
    "runtime_behavior": {"obtain_runtime_validation"},
}


def _transition_id(claim_type: str, transition_type: str, target: str, graph_signature: str) -> str:
    payload = json.dumps(
        {
            "claim_type": claim_type,
            "transition_type": transition_type,
            "target": target,
            "graph_content_signature": graph_signature,
            "policy": REGISTRY_POLICY,
        },
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    )
    return "sha256:" + hashlib.sha256(payload.encode("utf-8")).hexdigest()


def transition_identity(claim_type: str, transition_type: str, target: str, graph_signature: str) -> str:
    """Public deterministic transition identity used by attestations/outcome memory."""
    return _transition_id(claim_type, transition_type, target, graph_signature)


def transition_spec(transition_type: str) -> Dict[str, Any]:
    """Return a copy of one registry transition spec without exposing mutability."""
    spec = _TRANSITIONS.get(str(transition_type or ""), {})
    return json.loads(json.dumps(spec)) if spec else {}


def _cost_key(item: Dict[str, Any]) -> Tuple[int, int, int, str]:
    cost = item.get("cost", {}) or {}
    return (
        int(cost.get("mutation_risk", 9)),
        int(cost.get("context", 9)),
        int(cost.get("compute", 9)),
        str(item.get("transition_type") or ""),
    )


def _infer_needed_transition_types(obligation: Dict[str, Any]) -> List[str]:
    claim_type = str(obligation.get("claim_type") or "")
    missing = {str(value) for value in obligation.get("missing", []) or []}
    candidates: List[str] = []

    if "exact_current_source_witness" in missing:
        candidates.append("recover_current_source")
    if "stable_dependency_graph_witness" in missing:
        candidates.append("recover_dependency_witness")
    if any(value.startswith("analyzer:") for value in missing):
        if claim_type == "static_test_structure":
            candidates.append("recover_static_test_analyzer_witness")
        elif claim_type == "architecture_invariant":
            candidates.append("recover_architecture_analyzer_witness")
    if "exact_or_verified_historical_memory_witness" in missing:
        candidates.extend(["recover_exact_memory", "verify_historical_memory_against_current_source"])
    if "current_runtime_execution_evidence" in missing:
        candidates.append("obtain_runtime_validation")

    # Stable de-duplication.
    return list(dict.fromkeys(candidates))


def _target_for_transition(
    transition_type: str,
    obligation: Dict[str, Any],
    truth_floor: Dict[str, Any],
    target_paths: Sequence[str],
) -> str:
    if transition_type in {"recover_exact_memory", "verify_historical_memory_against_current_source"}:
        memory_floor = truth_floor.get("memory_floor", {}) or {}
        unresolved = memory_floor.get("unresolved", []) or memory_floor.get("unresolved_memories", []) or []
        if unresolved:
            first = unresolved[0]
            if isinstance(first, dict):
                return str(first.get("id") or first.get("file") or "historical_memory")
            return str(first)
        return "historical_memory"
    if target_paths:
        return str(target_paths[0])
    return str(obligation.get("claim_type") or "claim")


def _command_hint(transition_type: str, target: str, claim_type: str) -> str:
    if transition_type == "recover_current_source":
        return f"plw context <query> . --target {target} --budget <larger-N>"
    if transition_type == "recover_dependency_witness":
        return f"plw context <dependency-query> . --target {target} --budget <larger-N>"
    if transition_type == "recover_architecture_analyzer_witness":
        return "plw check . --json"
    if transition_type == "recover_static_test_analyzer_witness":
        return "plw check . --analyzers topo.test_reachability --json"
    if transition_type == "recover_exact_memory":
        return f"plw memory get {target}"
    if transition_type == "verify_historical_memory_against_current_source":
        return f"plw context <historical-query> . --target {target if target != 'historical_memory' else '<file>'}"
    if transition_type == "obtain_runtime_validation":
        if claim_type == "runtime_test_result":
            return "Run the narrowest relevant test command, pipe stdout/stderr through `plw compact-output --command '<test-command>'`, then `plw attest-runtime <output-id> --exit-code <code> --command '<test-command>' --claim runtime_test_result --root . --target <file>`."
        return "Run the narrowest relevant runtime reproduction, pipe stdout/stderr through `plw compact-output --command '<runtime-command>'`, then `plw attest-runtime <output-id> --exit-code <code> --command '<runtime-command>' --claim runtime_behavior --root . --target <file>`."
    return ""


def compile_proof_transitions(
    *,
    claim_obligations: Dict[str, Any],
    truth_floor: Dict[str, Any],
    graph_content_signature: Optional[str],
    target_paths: Optional[Sequence[str]] = None,
    accountability_store_dir: Optional[str] = None,
    parent_lineage_ids: Optional[Sequence[str]] = None,
    truth_scope: Optional[str] = None,
) -> Dict[str, Any]:
    """Compile blocked proof obligations into valid next-transition candidates."""
    graph_signature = str(graph_content_signature or "")
    targets = [str(v) for v in (target_paths or []) if v]
    blocked = set(str(v) for v in claim_obligations.get("blocked_claims", []) or [])
    obligations = list(claim_obligations.get("proof_obligations", []) or [])

    candidates: List[Dict[str, Any]] = []
    rejected_substitutions: List[Dict[str, Any]] = []

    for obligation in obligations:
        claim_type = str(obligation.get("claim_type") or "")
        if claim_type not in blocked or bool(obligation.get("satisfied")):
            continue
        allowed_types = _CLAIM_ALLOWED.get(claim_type, set())
        needed_types = _infer_needed_transition_types(obligation)

        for transition_type in needed_types:
            spec = _TRANSITIONS.get(transition_type)
            if not spec:
                continue
            if transition_type not in allowed_types:
                rejected_substitutions.append({
                    "claim_type": claim_type,
                    "transition_type": transition_type,
                    "reason": "transition_evidence_kind_not_admissible_for_claim",
                })
                continue
            target = _target_for_transition(transition_type, obligation, truth_floor, targets)
            candidate = {
                "transition_id": _transition_id(claim_type, transition_type, target, graph_signature),
                "transition_type": transition_type,
                "claim_type": claim_type,
                "target": target,
                "precondition": {
                    "claim_is_blocked": True,
                    "missing": list(obligation.get("missing", []) or []),
                    "graph_content_signature": graph_signature or None,
                },
                **spec,
                "command_hint": _command_hint(transition_type, target, claim_type),
            }
            candidates.append(candidate)

        # Make anti-substitution explicit for runtime claims even when nothing
        # attempted to use memory/static analysis in this invocation.
        if claim_type in {"runtime_test_result", "runtime_behavior"}:
            rejected_substitutions.extend([
                {
                    "claim_type": claim_type,
                    "transition_type": "recover_exact_memory",
                    "reason": "historical_memory_cannot_satisfy_current_runtime_truth",
                },
                {
                    "claim_type": claim_type,
                    "transition_type": "recover_architecture_analyzer_witness",
                    "reason": "static_analyzer_cannot_satisfy_current_runtime_truth",
                },
            ])

    # De-duplicate by transition identity then order by bounded risk/cost.
    by_id: Dict[str, Dict[str, Any]] = {}
    for item in candidates:
        by_id.setdefault(str(item["transition_id"]), item)
    ordered = sorted(by_id.values(), key=_cost_key)
    for rank, item in enumerate(ordered, 1):
        item["rank"] = rank
        item["preferred"] = rank == 1

    status = "transitions_required" if blocked and ordered else (
        "blocked_without_registered_transition" if blocked else "no_transition_required"
    )
    decision = {
        "decision_type": "proof_transition_compilation",
        "responsible_component": RESPONSIBLE_COMPONENT,
        "responsible_role": RESPONSIBLE_ROLE,
        "policy": REGISTRY_POLICY,
        "input_state": {
            "claim_decision_id": (claim_obligations.get("ledger", {}) or {}).get("id"),
            "truth_floor_decision_id": (truth_floor.get("ledger", {}) or {}).get("id"),
            "graph_content_signature": graph_signature or None,
            "target_paths": targets,
        },
        "blocked_claims": sorted(blocked),
        "candidate_transition_ids": [item["transition_id"] for item in ordered],
        "rejected_substitutions": rejected_substitutions,
        "invariants": {
            "registry_does_not_execute_transitions": True,
            "transition_does_not_assert_truth": True,
            "post_transition_revalidation_required": True,
            "memory_transition_only_for_memory_admissible_claims": True,
            "runtime_truth_requires_runtime_authority": True,
            "raw_shell_is_escape_hatch_not_default": True,
        },
    }
    ledger = record_accountability(decision, store_dir=accountability_store_dir)
    lineage_parents = list(parent_lineage_ids or [])
    for item in ordered:
        lineage = record_lineage_node(
            node_type="proof_transition",
            reference_type="transition_id",
            reference_id=str(item.get("transition_id") or ""),
            parent_ids=lineage_parents,
            graph_content_signature=graph_signature or None,
            truth_scope=truth_scope,
            metadata={
                "claim_type": str(item.get("claim_type") or ""),
                "transition_type": str(item.get("transition_type") or ""),
                "authority_domain": str(item.get("authority_domain") or ""),
                "rank": int(item.get("rank") or 0),
                "preferred": bool(item.get("preferred")),
            },
        )
        item["lineage"] = lineage
    return {
        "schema_version": "proof-transitions-v1",
        "policy": REGISTRY_POLICY,
        "responsible_component": RESPONSIBLE_COMPONENT,
        "responsible_role": RESPONSIBLE_ROLE,
        "authority": "transition_reference_only",
        "status": status,
        "blocked_claims": sorted(blocked),
        "candidates": ordered,
        "preferred_transition": ordered[0] if ordered else None,
        "rejected_substitutions": rejected_substitutions,
        "ledger": ledger,
        "invariants": decision["invariants"],
    }


def transition_guard_prompt(registry: Dict[str, Any]) -> str:
    preferred = registry.get("preferred_transition") or {}
    if not preferred:
        return ""
    lines = [
        "[VALID PROOF TRANSITION]",
        f"claim={preferred.get('claim_type')} transition={preferred.get('transition_type')}",
        f"authority={preferred.get('authority_domain')} side_effect={preferred.get('side_effect_class')}",
        f"NEXT={preferred.get('command_hint')}",
        "Re-run/re-evaluate the claim gate after the transition; the transition itself is not proof.",
    ]
    ledger = registry.get("ledger", {}) or {}
    if ledger.get("id"):
        lines.append(f"AUDIT=plw accountability {ledger.get('id')}")
    return "\n".join(lines) + "\n\n"


__all__ = [
    "REGISTRY_POLICY",
    "compile_proof_transitions",
    "transition_guard_prompt",
    "transition_identity",
    "transition_spec",
]
