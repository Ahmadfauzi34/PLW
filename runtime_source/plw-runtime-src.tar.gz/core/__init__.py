"""
Core Domain — Shared Infrastructure, Registry, Synthesizer & Safety
"""

from core.shared_graph import (
    build_shared_graph,
    discover_source_files,
    graph_content_signature,
    DEFAULT_IGNORE_DIRS,
    SOURCE_EXTENSIONS,
)
from core.graph_cache import (
    CACHE_MODES,
    build_cached_shared_graph,
    clear_graph_cache,
    get_graph_cache_status,
)
from core.analyzer_cache import (
    run_cached_analyzers,
    clear_analyzer_cache,
    get_analyzer_cache_status,
)
from core.analyzer_registry import (
    ANALYZER_REGISTRY,
    register_analyzer,
    run_analyzers,
    get_available_analyzers,
)
from core.synthesizer import (
    synthesize_topological_integrity,
    encode_topological_invariants,
    establish_baseline,
    load_baseline,
    steer_decoder,
)
from core.context_optimizer import build_context_pack
from core.command_output import (
    POLICY_VERSION as COMMAND_OUTPUT_POLICY_VERSION,
    OUTPUT_KINDS as COMMAND_OUTPUT_KINDS,
    classify_command,
    compact_command_output,
    recover_raw_output,
)
from core.command_telemetry import (
    TELEMETRY_SCHEMA_VERSION as COMMAND_OUTPUT_TELEMETRY_SCHEMA_VERSION,
    summarize_telemetry as summarize_command_output_telemetry,
)
from core.context_accountability import (
    ACCOUNTABILITY_SCHEMA_VERSION as CONTEXT_ACCOUNTABILITY_SCHEMA_VERSION,
    load_accountability,
    list_accountability_decisions,
)
from core.truth_delivery import (
    TRUTH_DELIVERY_POLICY,
    plan_proactive_truth_delivery,
    finalize_truth_delivery,
)
from core.truth_floor import (
    TRUTH_FLOOR_POLICY,
    plan_truth_floor,
    evaluate_truth_floor,
    fail_closed_prompt,
)
from core.safety import (
    check_memory_association_safety,
    check_betti_preservation,
    check_fiber_state_safety,
)
from core.deprecation import (
    deprecated_tool,
    DEPRECATION_MAP,
)
from core.capability_lifecycle import (
    evaluate_transition as evaluate_capability_transition,
    lifecycle_invariants as capability_lifecycle_invariants,
)
from core.capability_workflow import (
    build_decision_envelope as build_capability_workflow_envelope,
)
from core.capability_delivery import (
    build_delivery_accountability as build_capability_delivery_accountability,
    record_delivery_accountability as record_capability_delivery_accountability,
)
from core.capability_accountability_chain import (
    query_accountability_chain as query_capability_accountability_chain,
)
from core.capability_action_proposal import (
    build_action_request as build_capability_action_request,
    build_action_proposal as build_capability_action_proposal,
    record_action_proposal as record_capability_action_proposal,
)
from core.capability_action_authorization import (
    build_authorization_request as build_capability_action_authorization_request,
    build_action_authorization as build_capability_action_authorization,
    record_action_authorization as record_capability_action_authorization,
)
from core.capability_action_authority import (
    issue_authorization_assertion as issue_capability_action_authorization,
    verify_authorization_assertion as verify_capability_action_authorization,
)
from core.capability_action_gate import (
    build_gate_request as build_capability_action_gate_request,
    evaluate_authorized_action_gate as evaluate_capability_action_gate,
    record_authorized_action_gate as record_capability_action_gate,
)
from core.capability_action_dry_run import (
    build_dry_run_request as build_capability_action_dry_run_request,
    evaluate_action_dry_run as evaluate_capability_action_dry_run,
    record_action_dry_run as record_capability_action_dry_run,
)
from core.capability_action_preflight import (
    issue_preflight_freshness_assertion as issue_capability_action_preflight_freshness,
    build_preflight_request as build_capability_action_preflight_request,
    evaluate_action_preflight as evaluate_capability_action_preflight,
    record_action_preflight as record_capability_action_preflight,
)
from core.capability_action_lease import (
    build_action_lease_request as build_capability_action_lease_request,
    evaluate_action_lease as evaluate_capability_action_lease,
    acquire_action_lease as acquire_capability_action_lease,
    inspect_action_lease as inspect_capability_action_lease,
)
from core.capability_executor_outcome import (
    build_executor_attempt_request as build_capability_executor_attempt_request,
    evaluate_executor_attempt as evaluate_capability_executor_attempt,
    register_executor_attempt as register_capability_executor_attempt,
    build_executor_outcome_request as build_capability_executor_outcome_request,
    record_executor_outcome as record_capability_executor_outcome,
    inspect_executor_outcome as inspect_capability_executor_outcome,
)
from core.capability_executor_adapter import (
    ExecutorAdapter as CapabilityExecutorAdapter,
    build_adapter_dispatch_request as build_capability_adapter_dispatch_request,
    evaluate_adapter_dispatch as evaluate_capability_adapter_dispatch,
    prepare_adapter_dispatch as prepare_capability_adapter_dispatch,
    build_adapter_observation as build_capability_adapter_observation,
    record_adapter_observation as record_capability_adapter_observation,
    inspect_adapter_dispatch as inspect_capability_adapter_dispatch,
    inspect_adapter_observation as inspect_capability_adapter_observation,
    invoke_executor_adapter as invoke_capability_executor_adapter,
    reconcile_executor_adapter as reconcile_capability_executor_adapter,
)
from core.capability_relevance import (
    build_relevance_request as build_capability_relevance_request,
    evaluate_relevance_request as evaluate_capability_relevance,
    build_workflow_context as build_relevant_capability_workflow_context,
    build_relevance_accountability as build_capability_relevance_accountability,
    record_relevance_accountability as record_capability_relevance_accountability,
)

__all__ = [
    "build_shared_graph",
    "discover_source_files",
    "graph_content_signature",
    "DEFAULT_IGNORE_DIRS",
    "SOURCE_EXTENSIONS",
    "CACHE_MODES",
    "build_cached_shared_graph",
    "clear_graph_cache",
    "get_graph_cache_status",
    "run_cached_analyzers",
    "clear_analyzer_cache",
    "get_analyzer_cache_status",
    "ANALYZER_REGISTRY",
    "register_analyzer",
    "run_analyzers",
    "get_available_analyzers",
    "synthesize_topological_integrity",
    "encode_topological_invariants",
    "establish_baseline",
    "load_baseline",
    "steer_decoder",
    "build_context_pack",
    "COMMAND_OUTPUT_POLICY_VERSION",
    "COMMAND_OUTPUT_KINDS",
    "classify_command",
    "compact_command_output",
    "recover_raw_output",
    "COMMAND_OUTPUT_TELEMETRY_SCHEMA_VERSION",
    "summarize_command_output_telemetry",
    "CONTEXT_ACCOUNTABILITY_SCHEMA_VERSION",
    "load_accountability",
    "list_accountability_decisions",
    "TRUTH_DELIVERY_POLICY",
    "plan_proactive_truth_delivery",
    "finalize_truth_delivery",
    "TRUTH_FLOOR_POLICY",
    "plan_truth_floor",
    "evaluate_truth_floor",
    "fail_closed_prompt",
    "check_memory_association_safety",
    "check_betti_preservation",
    "check_fiber_state_safety",
    "deprecated_tool",
    "DEPRECATION_MAP",
    "evaluate_capability_transition",
    "capability_lifecycle_invariants",
    "build_capability_workflow_envelope",
    "build_capability_delivery_accountability",
    "record_capability_delivery_accountability",
    "query_capability_accountability_chain",
    "build_capability_action_request",
    "build_capability_action_proposal",
    "record_capability_action_proposal",
    "build_capability_action_authorization_request",
    "build_capability_action_authorization",
    "record_capability_action_authorization",
    "issue_capability_action_authorization",
    "verify_capability_action_authorization",
    "build_capability_action_gate_request",
    "evaluate_capability_action_gate",
    "record_capability_action_gate",
    "build_capability_action_dry_run_request",
    "evaluate_capability_action_dry_run",
    "record_capability_action_dry_run",
    "issue_capability_action_preflight_freshness",
    "build_capability_action_preflight_request",
    "evaluate_capability_action_preflight",
    "record_capability_action_preflight",
    "build_capability_action_lease_request",
    "evaluate_capability_action_lease",
    "acquire_capability_action_lease",
    "inspect_capability_action_lease",
    "build_capability_executor_attempt_request",
    "evaluate_capability_executor_attempt",
    "register_capability_executor_attempt",
    "build_capability_executor_outcome_request",
    "record_capability_executor_outcome",
    "inspect_capability_executor_outcome",
    "CapabilityExecutorAdapter",
    "build_capability_adapter_dispatch_request",
    "evaluate_capability_adapter_dispatch",
    "prepare_capability_adapter_dispatch",
    "build_capability_adapter_observation",
    "record_capability_adapter_observation",
    "inspect_capability_adapter_dispatch",
    "inspect_capability_adapter_observation",
    "invoke_capability_executor_adapter",
    "reconcile_capability_executor_adapter",
    "build_capability_relevance_request",
    "evaluate_capability_relevance",
    "build_relevant_capability_workflow_context",
    "build_capability_relevance_accountability",
    "record_capability_relevance_accountability",
]
