"""Proof-constrained shadow decision policy.

This module ranks only transitions that were already admitted by the deterministic
Proof Transition Registry. It is deliberately *not* a full MDP: it may consume
state-conditioned empirical transition and Q/value priors, but Markov sufficiency
and Bellman optimality are not proven. The policy remains a shadow comparator and
never replaces proof legality or truth validation.

Hard boundaries:
- cannot add actions outside the registry's valid action set;
- cannot change transition legality;
- cannot execute a transition;
- cannot settle a claim or alter truth state;
- action probabilities are strategy probabilities, never truth confidence;
- v1 shadow ranking never replaces deterministic registry ranking.
"""
from __future__ import annotations

import hashlib
import json
import math
from typing import Any, Dict, List, Optional, Sequence, Tuple

from core.context_accountability import record_accountability

SCHEMA_VERSION = "shadow-policy-v1"
POLICY_VERSION = "proof_constrained_shadow_policy_v1"
RESPONSIBLE_COMPONENT = "core.shadow_policy.evaluate_shadow_policy"
RESPONSIBLE_ROLE = "shadow_policy_custodian"


def _clamp(value: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, float(value)))


def _state_fingerprint(candidates: Sequence[Dict[str, Any]], blocked_claims: Sequence[str]) -> str:
    # No raw query/target text is included. Transition IDs are already content-addressed
    # identities from the proof registry; missing evidence kinds are schema labels.
    payload = {
        "blocked_claims": sorted(str(v) for v in blocked_claims if v),
        "actions": [
            {
                "transition_id": str(item.get("transition_id") or ""),
                "claim_type": str(item.get("claim_type") or ""),
                "transition_type": str(item.get("transition_type") or ""),
                "missing": sorted(str(v) for v in ((item.get("precondition") or {}).get("missing", []) or [])),
            }
            for item in candidates
        ],
        "policy": POLICY_VERSION,
    }
    raw = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    return "sha256:" + hashlib.sha256(raw).hexdigest()


def _cost_burden(cost: Dict[str, Any]) -> float:
    # Ordinal burden only; this is not a latency/token estimate.
    context = max(0.0, min(3.0, float(cost.get("context", 3))))
    compute = max(0.0, min(3.0, float(cost.get("compute", 3))))
    mutation = max(0.0, min(3.0, float(cost.get("mutation_risk", 3))))
    return _clamp((context + compute + 2.0 * mutation) / 12.0)


def _candidate_features(candidate: Dict[str, Any]) -> Dict[str, Any]:
    q_prior = candidate.get("q_value_prior", {}) or {}
    state_prior = candidate.get("state_conditioned_prior", {}) or {}
    global_prior = candidate.get("outcome_memory_prior", {}) or {}

    if q_prior.get("available"):
        visits = max(0, int(q_prior.get("visits", 0) or 0))
        q_value = float(q_prior.get("q_value", 0.0) or 0.0)
        # Convert unbounded-ish strategy value into a bounded preference feature.
        # This remains action utility, never truth confidence.
        empirical_quality = _clamp(0.5 + 0.5 * math.tanh(q_value))
        attempts = visits
        empirical_settlement = float((state_prior or {}).get("settlement_rate", 0.5) or 0.5)
        empirical_progress = empirical_quality
        experience_source = "proof_constrained_q_value_model"
    else:
        if state_prior.get("available"):
            prior = state_prior
            experience_source = "state_conditioned_transition_model"
        else:
            prior = global_prior
            experience_source = "global_transition_outcome_memory" if global_prior.get("available") else "neutral_prior"
        attempts = max(0, int(prior.get("attempts", 0) or 0))
        settlement_rate = prior.get("settlement_rate")
        progress_rate = prior.get("mean_proof_progress")
        if progress_rate is None and state_prior.get("available"):
            progress_rate = settlement_rate
        empirical_settlement = _clamp(float(settlement_rate)) if settlement_rate is not None else 0.5
        empirical_progress = _clamp(float(progress_rate)) if progress_rate is not None else empirical_settlement
        empirical_quality = 0.70 * empirical_settlement + 0.30 * empirical_progress

    # Evidence confidence grows slowly so a handful of outcomes cannot dominate
    # deterministic safety/cost structure.
    evidence_weight = attempts / (attempts + 4.0) if attempts else 0.0
    posterior_quality = (1.0 - evidence_weight) * 0.5 + evidence_weight * empirical_quality
    burden = _cost_burden(candidate.get("cost", {}) or {})

    # The utility is intentionally bounded and interpretable. It is a policy score,
    # not a probability that the claim is true.
    utility = posterior_quality - 0.20 * burden
    return {
        "attempts": attempts,
        "empirical_settlement_rate": round(_clamp(empirical_settlement), 6),
        "empirical_proof_progress": round(_clamp(empirical_progress), 6),
        "evidence_weight": round(evidence_weight, 6),
        "posterior_strategy_quality": round(posterior_quality, 6),
        "ordinal_cost_burden": round(burden, 6),
        "utility": round(utility, 6),
        "experience_source": experience_source,
        "q_value": q_prior.get("q_value") if q_prior.get("available") else None,
        "q_value_semantics": "strategy_value_not_truth_confidence" if q_prior.get("available") else None,
        "markov_sufficiency_proven": False if experience_source in {"state_conditioned_transition_model", "proof_constrained_q_value_model"} else None,
    }


def _softmax(values: Sequence[float], temperature: float = 0.20) -> List[float]:
    if not values:
        return []
    temp = max(0.05, float(temperature))
    peak = max(values)
    weights = [math.exp((value - peak) / temp) for value in values]
    total = sum(weights) or 1.0
    return [weight / total for weight in weights]


def evaluate_shadow_policy(
    *,
    proof_transitions: Dict[str, Any],
    accountability_store_dir: Optional[str] = None,
) -> Dict[str, Any]:
    """Evaluate an advisory policy over the registry's already-valid actions."""
    candidates = list(proof_transitions.get("candidates", []) or [])
    blocked_claims = list(proof_transitions.get("blocked_claims", []) or [])
    deterministic = proof_transitions.get("preferred_transition") or {}
    deterministic_id = str(deterministic.get("transition_id") or "") or None
    state_id = _state_fingerprint(candidates, blocked_claims)
    has_q_value_model = any(bool((item.get("q_value_prior", {}) or {}).get("available")) for item in candidates)
    has_state_conditioned_model = any(bool((item.get("state_conditioned_prior", {}) or {}).get("available")) for item in candidates)
    if has_q_value_model:
        model_family = "proof_constrained_q_value_shadow_policy"
        mdp_status = "q_value_over_empirical_state_model_markov_sufficiency_not_proven"
    elif has_state_conditioned_model:
        model_family = "state_conditioned_empirical_shadow_policy"
        mdp_status = "state_conditioned_empirical_model_markov_sufficiency_not_proven"
    else:
        model_family = "one_step_empirical_shadow_policy"
        mdp_status = "not_full_mdp_no_state_conditioned_transition_model"

    if not candidates:
        return {
            "schema_version": SCHEMA_VERSION,
            "policy": POLICY_VERSION,
            "model_family": model_family,
            "mdp_status": mdp_status,
            "authority": "strategy_advisory_only",
            "status": "no_valid_actions",
            "state_fingerprint": state_id,
            "valid_action_count": 0,
            "deterministic_preferred_transition_id": deterministic_id,
            "shadow_preferred_transition": None,
            "action_distribution": [],
            "diverges_from_deterministic": False,
            "invariants": _invariants(),
        }

    rows: List[Dict[str, Any]] = []
    for candidate in candidates:
        features = _candidate_features(candidate)
        rows.append({
            "transition_id": str(candidate.get("transition_id") or ""),
            "transition_type": str(candidate.get("transition_type") or ""),
            "claim_type": str(candidate.get("claim_type") or ""),
            "deterministic_rank": int(candidate.get("rank", 999) or 999),
            "features": features,
            "utility": float(features["utility"]),
        })

    probabilities = _softmax([row["utility"] for row in rows])
    for row, probability in zip(rows, probabilities):
        row["policy_probability"] = round(probability, 6)

    ordered = sorted(
        rows,
        key=lambda row: (-float(row["utility"]), int(row["deterministic_rank"]), str(row["transition_id"])),
    )
    rank_by_id = {row["transition_id"]: index for index, row in enumerate(ordered, 1)}
    for row in rows:
        row["shadow_rank"] = rank_by_id[row["transition_id"]]
        row["probability_semantics"] = "strategy_action_probability_not_truth_confidence"
    rows.sort(key=lambda row: int(row["shadow_rank"]))

    shadow = rows[0]
    shadow_preferred = {
        "transition_id": shadow["transition_id"],
        "transition_type": shadow["transition_type"],
        "claim_type": shadow["claim_type"],
        "shadow_rank": 1,
        "policy_probability": shadow["policy_probability"],
        "utility": round(float(shadow["utility"]), 6),
    }
    decision = {
        "decision_type": "shadow_transition_policy_evaluation",
        "responsible_component": RESPONSIBLE_COMPONENT,
        "responsible_role": RESPONSIBLE_ROLE,
        "policy": POLICY_VERSION,
        "state_fingerprint": state_id,
        "valid_transition_ids": [str(item.get("transition_id") or "") for item in candidates],
        "deterministic_preferred_transition_id": deterministic_id,
        "shadow_preferred_transition_id": shadow["transition_id"],
        "diverges_from_deterministic": bool(deterministic_id and shadow["transition_id"] != deterministic_id),
        "utilities": [
            {
                "transition_id": row["transition_id"],
                "utility": round(float(row["utility"]), 6),
                "policy_probability": row["policy_probability"],
            }
            for row in rows
        ],
        "invariants": _invariants(),
    }
    ledger = record_accountability(decision, store_dir=accountability_store_dir)
    return {
        "schema_version": SCHEMA_VERSION,
        "policy": POLICY_VERSION,
        "model_family": model_family,
        "mdp_status": mdp_status,
        "authority": "strategy_advisory_only",
        "status": "shadow_ranked",
        "state_fingerprint": state_id,
        "valid_action_count": len(candidates),
        "deterministic_preferred_transition_id": deterministic_id,
        "shadow_preferred_transition": shadow_preferred,
        "action_distribution": rows,
        "diverges_from_deterministic": decision["diverges_from_deterministic"],
        "ledger": ledger,
        "invariants": decision["invariants"],
    }


def _invariants() -> Dict[str, Any]:
    return {
        "consumes_registry_valid_actions_only": True,
        "cannot_add_or_remove_valid_transitions": True,
        "cannot_change_transition_validity": True,
        "cannot_execute_transitions": True,
        "cannot_satisfy_claim_obligations": True,
        "cannot_commit_proof_state": True,
        "probability_is_not_truth_confidence": True,
        "deterministic_registry_ranking_remains_authoritative_in_v1": True,
        "full_mdp_not_claimed_without_state_conditioned_transition_model": True,
        "state_conditioned_frequency_is_not_truth_confidence": True,
        "markov_sufficiency_not_assumed_from_state_abstraction": True,
        "raw_query_not_stored_in_policy_ledger": True,
    }


__all__ = [
    "SCHEMA_VERSION",
    "POLICY_VERSION",
    "RESPONSIBLE_COMPONENT",
    "RESPONSIBLE_ROLE",
    "evaluate_shadow_policy",
]
