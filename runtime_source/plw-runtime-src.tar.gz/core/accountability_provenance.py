"""Store-bound provenance seals for capability-governance accountability records.

SHA-256 content addressing detects mutation but cannot identify who produced a
record.  This module adds a domain-separated HMAC seal.  Production deployments
should provide ``PLW_ACCOUNTABILITY_PROVENANCE_KEY`` from a protected authority
service.  The local reference machine provisions a mode-0600 store key so the
same contracts remain executable without external dependencies.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import secrets
import stat
from pathlib import Path
from core.runtime_paths import state_path
from typing import Any, Dict, Mapping

from core.capability_contracts import exact_keys, safe_canonical_digest


PROVENANCE_SCHEMA = "plw-accountability-provenance-v1"
PROVENANCE_ALGORITHM = "HMAC-SHA256"
TRUST_DOMAIN = "plw-capability-governance-v1"
PROVENANCE_KEYS = frozenset({
    "schema_version", "algorithm", "trust_domain", "issuer", "key_id",
    "payload_digest", "mac",
})

RELEVANCE_ISSUER = "plw.workflow.relevance-accountability.v1"
DELIVERY_ISSUER = "plw.workflow.delivery-accountability.v1"
PROPOSAL_ISSUER = "plw.workflow.action-proposal.v1"
AUTHORIZATION_ISSUER = "plw.workflow.action-authorization.v1"
GATE_ISSUER = "plw.workflow.authorized-action-gate.v1"
DRY_RUN_ISSUER = "plw.workflow.action-dry-run.v1"
AUTHORITY_ISSUER = "plw.authority.explicit-action-grant.v1"
PREFLIGHT_ISSUER = "plw.authority.action-preflight.v1"
PREFLIGHT_RECORD_ISSUER = "plw.workflow.action-preflight-record.v1"

_DEFAULT_STORE = state_path("context_accountability")
_KEY_FILE = ".plw_provenance_hmac_key"
_RESERVED_RECORD_KEYS = frozenset({"decision_id", "recorded_at", "provenance"})


def _store_directory(store_dir: str | os.PathLike[str] | None) -> Path:
    configured = os.environ.get("PLW_ACCOUNTABILITY_DIR")
    return Path(store_dir or configured or _DEFAULT_STORE).resolve()


def _environment_key() -> bytes | None:
    raw = os.environ.get("PLW_ACCOUNTABILITY_PROVENANCE_KEY")
    if raw is None:
        return None
    try:
        if raw.startswith("hex:"):
            key = bytes.fromhex(raw[4:])
        elif raw.startswith("base64:"):
            key = base64.b64decode(raw[7:], validate=True)
        else:
            key = raw.encode("utf-8")
    except (ValueError, UnicodeError):
        raise ValueError("Invalid PLW accountability provenance key encoding") from None
    if len(key) < 32:
        raise ValueError("PLW accountability provenance key must contain at least 32 bytes")
    return key


def _read_key(path: Path) -> bytes:
    flags = os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0)
    fd = os.open(path, flags)
    try:
        info = os.fstat(fd)
        if not stat.S_ISREG(info.st_mode):
            raise ValueError("Accountability provenance key is not a regular file")
        if info.st_mode & 0o077:
            raise PermissionError("Accountability provenance key permissions are too broad")
        key = os.read(fd, 65)
    finally:
        os.close(fd)
    if len(key) != 32:
        raise ValueError("Invalid accountability provenance key length")
    return key


def _key(store_dir: str | os.PathLike[str] | None, *, create: bool) -> bytes:
    configured = _environment_key()
    if configured is not None:
        return configured

    directory = _store_directory(store_dir)
    key_path = directory / _KEY_FILE
    if key_path.exists():
        return _read_key(key_path)
    if not create:
        raise FileNotFoundError("Accountability provenance key is unavailable")

    directory.mkdir(parents=True, exist_ok=True, mode=0o700)
    key = secrets.token_bytes(32)
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0)
    try:
        fd = os.open(key_path, flags, 0o600)
    except FileExistsError:
        return _read_key(key_path)
    try:
        written = os.write(fd, key)
        if written != len(key):
            raise OSError("Short accountability provenance key write")
        os.fsync(fd)
    finally:
        os.close(fd)
    return key


def _key_id(key: bytes) -> str:
    return "sha256:" + hashlib.sha256(key).hexdigest()


def _mac_input(fields: Mapping[str, Any]) -> bytes:
    return json.dumps(dict(fields), ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def seal_payload(
    payload: Mapping[str, Any],
    issuer: str,
    *,
    store_dir: str | os.PathLike[str] | None = None,
) -> Dict[str, Any]:
    """Create a detached, domain-separated provenance proof for a bounded payload."""
    body = dict(payload)
    digest = safe_canonical_digest(body, max_bytes=262144)
    if digest is None:
        raise ValueError("Provenance payload is not bounded canonical JSON")
    if not isinstance(issuer, str) or not issuer or len(issuer) > 128:
        raise ValueError("Invalid provenance issuer")
    key = _key(store_dir, create=True)
    core = {
        "schema_version": PROVENANCE_SCHEMA,
        "algorithm": PROVENANCE_ALGORITHM,
        "trust_domain": TRUST_DOMAIN,
        "issuer": issuer,
        "key_id": _key_id(key),
        "payload_digest": digest,
    }
    mac = hmac.new(key, _mac_input(core), hashlib.sha256).hexdigest()
    return {**core, "mac": "hmac-sha256:" + mac}


def verify_payload(
    payload: Mapping[str, Any],
    proof: Any,
    expected_issuer: str,
    *,
    store_dir: str | os.PathLike[str] | None = None,
) -> bool:
    """Verify exact proof shape, issuer, payload digest, key identity, and MAC."""
    if not exact_keys(proof, PROVENANCE_KEYS):
        return False
    assert isinstance(proof, dict)
    if (
        proof.get("schema_version") != PROVENANCE_SCHEMA
        or proof.get("algorithm") != PROVENANCE_ALGORITHM
        or proof.get("trust_domain") != TRUST_DOMAIN
        or proof.get("issuer") != expected_issuer
    ):
        return False
    digest = safe_canonical_digest(dict(payload), max_bytes=262144)
    if digest is None or proof.get("payload_digest") != digest:
        return False
    try:
        key = _key(store_dir, create=False)
    except (OSError, ValueError):
        return False
    if proof.get("key_id") != _key_id(key):
        return False
    core = {key_name: proof[key_name] for key_name in PROVENANCE_KEYS if key_name != "mac"}
    expected = "hmac-sha256:" + hmac.new(key, _mac_input(core), hashlib.sha256).hexdigest()
    return isinstance(proof.get("mac"), str) and hmac.compare_digest(proof["mac"], expected)


def seal_record(
    payload: Mapping[str, Any],
    issuer: str,
    *,
    store_dir: str | os.PathLike[str] | None = None,
) -> Dict[str, Any]:
    body = dict(payload)
    if _RESERVED_RECORD_KEYS & set(body):
        raise ValueError("Accountability payload contains reserved record metadata")
    return {**body, "provenance": seal_payload(body, issuer, store_dir=store_dir)}


def verify_record(
    record: Mapping[str, Any],
    expected_issuer: str,
    *,
    store_dir: str | os.PathLike[str] | None = None,
) -> bool:
    body = dict(record)
    proof = body.pop("provenance", None)
    body.pop("decision_id", None)
    body.pop("recorded_at", None)
    return verify_payload(body, proof, expected_issuer, store_dir=store_dir)


def record_provenanced(
    payload: Mapping[str, Any],
    issuer: str,
    *,
    store_dir: str | os.PathLike[str] | None = None,
) -> Dict[str, Any]:
    """Seal and persist a record while keeping storage failures observable."""
    try:
        sealed = seal_record(payload, issuer, store_dir=store_dir)
        from core.context_accountability import record_accountability
        return record_accountability(sealed, store_dir=store_dir)
    except Exception as exc:
        return {
            "available": False,
            "id": "",
            "decision_id": "",
            "reason": f"accountability_provenance_write_failed:{type(exc).__name__}",
        }


__all__ = [
    "PROVENANCE_SCHEMA", "PROVENANCE_ALGORITHM", "TRUST_DOMAIN",
    "RELEVANCE_ISSUER", "DELIVERY_ISSUER", "PROPOSAL_ISSUER",
    "AUTHORIZATION_ISSUER", "GATE_ISSUER", "DRY_RUN_ISSUER",
    "AUTHORITY_ISSUER", "PREFLIGHT_ISSUER", "PREFLIGHT_RECORD_ISSUER",
    "seal_payload", "verify_payload", "seal_record", "verify_record", "record_provenanced",
]
