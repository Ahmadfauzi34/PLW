"""Accountability link from relevance audit to advisory workflow delivery outcome.

F112 records what happened *after* an F111 relevance decision: included, omitted by
budget/source grounding, denied by relevance, or rejected as invalid.  Records are
content-addressed metadata only; they store a digest of the final context block, not
raw prompt/source text, and grant no execution or promotion authority.
"""
from __future__ import annotations

import hashlib
import json
from typing import Any, Dict, Mapping

from core.accountability_provenance import (
    DELIVERY_ISSUER,
    RELEVANCE_ISSUER,
    record_provenanced,
    verify_record,
)
from core.capability_contracts import exact_keys, no_effect_authorizations, normalize_mapping, safe_canonical_digest
from core.capability_relevance import (
    ACCOUNTABILITY_DECISION_TYPE as RELEVANCE_DECISION_TYPE,
    ACCOUNTABILITY_POLICY as RELEVANCE_POLICY,
    ACCOUNTABILITY_RECORD_KEYS as RELEVANCE_RECORD_KEYS,
    ACCOUNTABILITY_SCHEMA as RELEVANCE_SCHEMA,
)
from core.context_accountability import load_accountability

SCHEMA_VERSION = "capability-workflow-delivery-v1"
POLICY_VERSION = "capability_workflow_delivery_accountability_v1"
DECISION_TYPE = "capability_workflow_delivery"
_REQUIRED_AUTH = {
    "transition_execution",
    "runtime_execution",
    "external_patch",
    "stable_promotion",
    "truth_commit",
}
_ALLOWED_OMISSION_REASONS = {"budget_omitted", "source_grounding_floor"}
_ALLOWED_INVALID_REASONS = {"invalid_envelope", "authority_not_advisory_only"}
ACCOUNTABILITY_RECORD_KEYS = frozenset({
    "schema_version", "decision_type", "policy", "relevance_accountability_id",
    "capability_id", "request_digest", "workflow_evidence_digest",
    "delivery_outcome", "delivery_reason", "workflow_marker_present",
    "rendered_chars", "context_block_chars", "context_block_digest",
    "delivery_metadata_digest", "authority", "authorizations", "invariants",
    "provenance", "decision_id", "recorded_at",
})


def _sha_text(value: str) -> str:
    return "sha256:" + hashlib.sha256(str(value).encode("utf-8")).hexdigest()


def _sha_mapping(value: Mapping[str, Any]) -> str:
    digest = safe_canonical_digest(dict(value), max_bytes=65536)
    if digest is None:
        raise ValueError("delivery metadata is not bounded canonical JSON")
    return digest



def _load_relevance(decision_id: str, store_dir: str | None) -> Dict[str, Any]:
    record = load_accountability(decision_id, store_dir=store_dir)
    if not exact_keys(record, RELEVANCE_RECORD_KEYS):
        raise ValueError("relevance accountability schema is not exact")
    if record.get("schema_version") != RELEVANCE_SCHEMA:
        raise ValueError("relevance accountability schema drift")
    if record.get("policy") != RELEVANCE_POLICY:
        raise ValueError("relevance accountability policy drift")
    if record.get("decision_type") != RELEVANCE_DECISION_TYPE:
        raise ValueError("accountability id is not an F111 relevance decision")
    if record.get("authority") != "workflow_relevance_accountability_only":
        raise ValueError("relevance accountability authority drift")
    if not no_effect_authorizations(record.get("authorizations")):
        raise ValueError("relevance accountability gained authority")
    if not verify_record(record, RELEVANCE_ISSUER, store_dir=store_dir):
        raise ValueError("relevance accountability provenance invalid")
    return record


def _validate_link(relevance: Mapping[str, Any], workflow_context: Mapping[str, Any]) -> None:
    decision = workflow_context.get("relevance_decision")
    envelope = workflow_context.get("envelope")
    if not isinstance(decision, dict) or not isinstance(envelope, dict):
        raise ValueError("workflow context lacks relevance decision/envelope binding")
    if decision.get("request_digest") != relevance.get("request_digest"):
        raise ValueError("delivery request digest does not match relevance accountability")
    if decision.get("capability_id") != relevance.get("capability_id"):
        raise ValueError("delivery capability does not match relevance accountability")
    if decision.get("relevant") is not relevance.get("relevant"):
        raise ValueError("delivery relevance flag does not match accountability")
    if envelope.get("capability_id") != relevance.get("capability_id"):
        raise ValueError("delivery envelope capability binding mismatch")
    if envelope.get("state") != relevance.get("workflow_state"):
        raise ValueError("delivery envelope state binding mismatch")
    if envelope.get("evidence_digest") != relevance.get("workflow_evidence_digest"):
        raise ValueError("delivery envelope evidence binding mismatch")


def _classify(relevance: Mapping[str, Any], workflow_info: Mapping[str, Any], marker_present: bool) -> str:
    included = workflow_info.get("included") is True
    reason = str(workflow_info.get("reason") or "")
    relevant = relevance.get("relevant") is True

    if included:
        if not relevant or reason != "explicit_relevant_advisory_envelope" or not marker_present:
            raise ValueError("included workflow metadata/context marker mismatch")
        return "INCLUDED"
    if marker_present:
        raise ValueError("workflow marker present while metadata says not included")
    if not relevant:
        if reason != "not_relevant":
            raise ValueError("denied relevance has unexpected delivery reason")
        return "DENIED"
    if reason in _ALLOWED_OMISSION_REASONS:
        return "BUDGET_OMITTED"
    if reason in _ALLOWED_INVALID_REASONS:
        return "INVALID"
    raise ValueError("unrecognized workflow delivery outcome")


def build_delivery_accountability(
    relevance_accountability_id: str,
    workflow_context: Mapping[str, Any] | None,
    context_pack: Mapping[str, Any] | None,
    *,
    store_dir: str | None = None,
) -> Dict[str, Any]:
    """Build a bounded delivery audit bound to an existing F111 relevance record."""
    relevance = _load_relevance(relevance_accountability_id, store_dir)
    workflow_context, workflow_context_valid = normalize_mapping(workflow_context)
    pack, pack_valid = normalize_mapping(context_pack)
    if not workflow_context_valid or not pack_valid:
        raise ValueError("workflow delivery input is not a mapping")
    _validate_link(relevance, workflow_context)

    info = pack.get("capability_workflow")
    if not isinstance(info, dict):
        raise ValueError("context pack lacks capability_workflow delivery metadata")
    context_block = pack.get("context_block")
    if not isinstance(context_block, str):
        raise ValueError("context block must be text")
    marker_present = "[CAPABILITY-WORKFLOW]" in context_block
    outcome = _classify(relevance, info, marker_present)
    rendered_chars = info.get("rendered_chars")
    if rendered_chars is not None and (type(rendered_chars) is not int or rendered_chars < 0):
        raise ValueError("invalid rendered_chars metadata")

    return {
        "schema_version": SCHEMA_VERSION,
        "decision_type": DECISION_TYPE,
        "policy": POLICY_VERSION,
        "relevance_accountability_id": str(relevance_accountability_id),
        "capability_id": relevance.get("capability_id"),
        "request_digest": relevance.get("request_digest"),
        "workflow_evidence_digest": relevance.get("workflow_evidence_digest"),
        "delivery_outcome": outcome,
        "delivery_reason": str(info.get("reason") or ""),
        "workflow_marker_present": marker_present,
        "rendered_chars": int(rendered_chars or 0),
        "context_block_chars": len(context_block),
        "context_block_digest": _sha_text(context_block),
        "delivery_metadata_digest": _sha_mapping(info),
        "authority": "workflow_delivery_accountability_only",
        "authorizations": {key: False for key in sorted(_REQUIRED_AUTH)},
        "invariants": {
            "relevance_accountability_required": True,
            "raw_prompt_not_stored": True,
            "raw_source_not_stored": True,
            "delivery_record_does_not_change_prompt": True,
            "delivery_record_does_not_change_relevance": True,
            "transition_execution": False,
            "runtime_execution": False,
            "external_patch": False,
            "stable_promotion": False,
            "truth_commit": False,
        },
    }


def record_delivery_accountability(
    relevance_accountability_id: str,
    workflow_context: Mapping[str, Any] | None,
    context_pack: Mapping[str, Any] | None,
    *,
    store_dir: str | None = None,
) -> Dict[str, Any]:
    payload = build_delivery_accountability(
        relevance_accountability_id, workflow_context, context_pack, store_dir=store_dir
    )
    receipt = record_provenanced(payload, DELIVERY_ISSUER, store_dir=store_dir)
    return {
        **receipt,
        "decision_type": DECISION_TYPE,
        "delivery_outcome": payload["delivery_outcome"],
        "relevance_accountability_id": payload["relevance_accountability_id"],
        "authority": "workflow_delivery_accountability_reference_only",
    }


__all__ = [
    "SCHEMA_VERSION",
    "POLICY_VERSION",
    "DECISION_TYPE",
    "ACCOUNTABILITY_RECORD_KEYS",
    "build_delivery_accountability",
    "record_delivery_accountability",
]
