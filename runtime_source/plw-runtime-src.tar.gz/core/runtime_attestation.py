"""Runtime evidence attestation for PLW proof transitions.

This module never executes commands.  It turns an already-stored command output
observation plus explicit execution metadata into a content-addressed runtime
witness.  An attestation is admissible only inside the same truth scope and
SharedGraph snapshot, and (for targeted claims) for an overlapping target.

Raw stdout/stderr and raw command text are intentionally not stored here.
"""

from __future__ import annotations

import datetime
import hashlib
import json
import os
import re
import tempfile
from pathlib import Path
from core.runtime_paths import state_path
from typing import Any, Dict, Iterable, List, Optional, Sequence

from core.command_output import raw_output_available, recover_raw_output, get_output_behavior_metrics
from core.command_telemetry import command_fingerprint
from core.context_accountability import record_accountability
from core.decision_lineage import record_lineage_node
from core.proof_transitions import transition_identity, transition_spec

SCHEMA_VERSION = "runtime-attestation-v1"
POLICY_VERSION = "scoped_runtime_evidence_attestation_v1"
RESPONSIBLE_COMPONENT = "core.runtime_attestation.create_runtime_attestation"
RESPONSIBLE_ROLE = "runtime_evidence_custodian"
SUPPORTED_CLAIMS = {"runtime_test_result", "runtime_behavior"}

DEFAULT_ATTESTATION_DIR = state_path("runtime_attestations")


def _utc_now() -> str:
    return datetime.datetime.now(datetime.timezone.utc).isoformat().replace("+00:00", "Z")


def _store_directory(store_dir: Optional[str | os.PathLike[str]]) -> Path:
    env_dir = os.environ.get("PLW_RUNTIME_ATTESTATION_DIR")
    return Path(store_dir or env_dir or DEFAULT_ATTESTATION_DIR).expanduser().resolve()


def _normalize_targets(values: Optional[Iterable[str]]) -> List[str]:
    out: List[str] = []
    seen = set()
    for value in values or []:
        item = os.path.normpath(str(value)).replace("\\", "/")
        if item.startswith("./"):
            item = item[2:]
        if item and item not in seen:
            seen.add(item)
            out.append(item)
    return sorted(out)


def _validate_sha256_id(value: str, *, name: str) -> str:
    text = str(value or "").strip().lower()
    digest = text.split(":", 1)[1] if text.startswith("sha256:") else text
    if not re.fullmatch(r"[0-9a-f]{64}", digest):
        raise ValueError(f"{name} must be a SHA-256 id")
    return f"sha256:{digest}"


def _attestation_id(payload: Dict[str, Any]) -> str:
    encoded = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return "sha256:" + hashlib.sha256(encoded).hexdigest()


def _write_cell(record: Dict[str, Any], store_dir: Optional[str | os.PathLike[str]]) -> Dict[str, Any]:
    directory = _store_directory(store_dir)
    digest = str(record["attestation_id"]).split(":", 1)[1]
    target = directory / f"attest-{digest}.json"
    try:
        directory.mkdir(parents=True, exist_ok=True, mode=0o700)
        try:
            os.chmod(directory, 0o700)
        except OSError:
            pass
        if not target.exists():
            fd, tmp_name = tempfile.mkstemp(prefix=".attest-", suffix=".json", dir=str(directory))
            os.close(fd)
            tmp = Path(tmp_name)
            try:
                tmp.write_text(json.dumps(record, ensure_ascii=False, sort_keys=True), encoding="utf-8")
                try:
                    os.chmod(tmp, 0o600)
                except OSError:
                    pass
                os.replace(tmp, target)
            finally:
                if tmp.exists():
                    try:
                        tmp.unlink()
                    except OSError:
                        pass
        return {"available": True, "id": record["attestation_id"], "path": str(target)}
    except Exception as exc:
        return {
            "available": False,
            "id": record["attestation_id"],
            "error": f"runtime_attestation_store_failed:{type(exc).__name__}",
        }


def create_runtime_attestation(
    *,
    output_id: str,
    exit_code: int,
    command: str,
    claim_type: str,
    truth_scope: str,
    graph_content_signature: str,
    target_paths: Optional[Sequence[str]] = None,
    output_store_dir: Optional[str | os.PathLike[str]] = None,
    attestation_store_dir: Optional[str | os.PathLike[str]] = None,
    accountability_store_dir: Optional[str] = None,
    source_proof_state_binding: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Create an immutable witness for an execution performed outside PLW."""
    claim = str(claim_type or "").strip()
    if claim not in SUPPORTED_CLAIMS:
        raise ValueError(f"Unsupported runtime attestation claim type: {claim_type}")
    scope = str(truth_scope or "").strip()
    if not scope or scope == "unscoped":
        raise ValueError("Runtime attestation requires a stable --truth-scope or active fiber")
    graph_sig = _validate_sha256_id(graph_content_signature, name="graph_content_signature")
    normalized_output = _validate_sha256_id(output_id, name="output_id")
    try:
        code = int(exit_code)
    except (TypeError, ValueError):
        raise ValueError("exit_code must be an integer")

    # Verify that exact raw evidence exists and hashes correctly at attestation time.
    raw = recover_raw_output(normalized_output, store_dir=output_store_dir, telemetry=False)
    raw_sha = "sha256:" + hashlib.sha256(raw).hexdigest()
    if raw_sha != normalized_output:
        raise ValueError("Recovered runtime output does not match output_id")

    targets = _normalize_targets(target_paths)
    command_head = os.path.basename((str(command or "").strip().split() or [""])[0]).lower()
    transition_type = "obtain_runtime_validation"
    transition_target = targets[0] if targets else claim
    transition_id = transition_identity(claim, transition_type, transition_target, graph_sig)
    transition_cost = (transition_spec(transition_type).get("cost", {}) or {})
    binding = source_proof_state_binding or {}
    source_state = {
        "available": bool(binding.get("source_state_class_id") and binding.get("source_state_instance_id")),
        "source_state_class_id": binding.get("source_state_class_id"),
        "source_state_instance_id": binding.get("source_state_instance_id"),
        "intent_id": binding.get("intent_id"),
        "transition_lineage_id": binding.get("transition_lineage_id"),
        "authority": "strategy_state_binding_only",
    }
    stable_payload = {
        "schema_version": SCHEMA_VERSION,
        "policy": POLICY_VERSION,
        "claim_type": claim,
        "truth_scope": scope,
        "graph_content_signature": graph_sig,
        "target_paths": targets,
        "command_head": command_head,
        "command_fingerprint": command_fingerprint(command),
        "exit_code": code,
        "output_id": normalized_output,
        "raw_output_sha256": raw_sha,
        "authority_domain": "current_runtime_observation",
        "transition_id": transition_id,
        "transition_type": transition_type,
        "transition_cost": transition_cost,
        "source_proof_state": source_state,
    }
    attestation_id = _attestation_id(stable_payload)
    policy_cost_observation = get_output_behavior_metrics(
        normalized_output, command=command, store_dir=output_store_dir
    )
    record = {
        **stable_payload,
        "attestation_id": attestation_id,
        "created_at": _utc_now(),
        "policy_cost_observation": policy_cost_observation,
        "execution_interpretation": (
            "process_exit_success" if code == 0 else "process_exit_nonzero"
        ),
        "limitations": {
            "attestation_does_not_infer_semantics": True,
            "exit_zero_is_not_universal_behavioral_correctness": True,
            "valid_only_for_same_truth_scope_and_graph_snapshot": True,
            "environment_identity_not_fully_modeled": True,
            "raw_command_not_stored": True,
            "raw_output_not_duplicated_in_attestation": True,
            "source_state_binding_is_policy_provenance_not_truth": True,
        },
    }
    lineage_ref = record_lineage_node(
        node_type="runtime_attestation",
        reference_type="attestation_id",
        reference_id=attestation_id,
        parent_ids=[source_state.get("transition_lineage_id")] if source_state.get("transition_lineage_id") else [],
        graph_content_signature=graph_sig,
        truth_scope=scope,
        metadata={
            "claim_type": claim,
            "transition_type": transition_type,
            "output_id": normalized_output,
            "exit_code": code,
        },
    )
    record["lineage"] = lineage_ref
    stored = _write_cell(record, attestation_store_dir)
    decision = {
        "decision_type": "runtime_evidence_attestation",
        "responsible_component": RESPONSIBLE_COMPONENT,
        "responsible_role": RESPONSIBLE_ROLE,
        "policy": POLICY_VERSION,
        "attestation_id": attestation_id,
        "claim_type": claim,
        "truth_scope": scope,
        "graph_content_signature": graph_sig,
        "target_paths": targets,
        "output_id": normalized_output,
        "exit_code": code,
        "transition_id": transition_id,
        "transition_type": transition_type,
        "lineage_id": lineage_ref.get("id"),
        "invariants": record["limitations"],
    }
    ledger = record_accountability(decision, store_dir=accountability_store_dir)
    return {**record, "store": stored, "ledger": ledger}


def _load_cells(store_dir: Optional[str | os.PathLike[str]]) -> List[Dict[str, Any]]:
    directory = _store_directory(store_dir)
    if not directory.is_dir():
        return []
    records: List[Dict[str, Any]] = []
    for path in sorted(directory.glob("attest-*.json")):
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            continue
        if not isinstance(data, dict) or data.get("schema_version") != SCHEMA_VERSION:
            continue
        records.append(data)
    return records



def find_runtime_attestation_attempts(
    *,
    truth_scope: Optional[str],
    target_paths: Optional[Sequence[str]] = None,
    claim_types: Optional[Sequence[str]] = None,
    attestation_store_dir: Optional[str | os.PathLike[str]] = None,
    output_store_dir: Optional[str | os.PathLike[str]] = None,
) -> List[Dict[str, Any]]:
    """Return explicit execution attempts relevant to this scope/target, even if stale.

    This surface exists for transition-outcome learning.  It does not make stale
    evidence admissible: the normal admission function still enforces snapshot
    equality.
    """
    scope = str(truth_scope or "unscoped")
    if scope == "unscoped":
        return []
    targets = set(_normalize_targets(target_paths))
    requested_claims = set(str(v) for v in (claim_types or []) if v)
    out: List[Dict[str, Any]] = []
    for item in _load_cells(attestation_store_dir):
        if item.get("truth_scope") != scope:
            continue
        claim = str(item.get("claim_type") or "")
        if requested_claims and claim not in requested_claims:
            continue
        att_targets = set(_normalize_targets(item.get("target_paths", [])))
        if targets and not (targets & att_targets):
            continue
        output_id = str(item.get("output_id") or "")
        out.append({
            "attestation_id": item.get("attestation_id"),
            "claim_type": claim,
            "truth_scope": scope,
            "graph_content_signature": item.get("graph_content_signature"),
            "target_paths": sorted(att_targets),
            "command_head": item.get("command_head"),
            "command_fingerprint": item.get("command_fingerprint"),
            "exit_code": item.get("exit_code"),
            "execution_interpretation": item.get("execution_interpretation"),
            "output_id": output_id,
            "authority_domain": "current_runtime_observation",
            "raw_output_recoverable": raw_output_available(output_id, store_dir=output_store_dir),
            "transition_id": item.get("transition_id"),
            "transition_type": item.get("transition_type"),
            "transition_cost": item.get("transition_cost", {}),
            "policy_cost_observation": item.get("policy_cost_observation", {}),
            "source_proof_state": item.get("source_proof_state", {}),
            "lineage": item.get("lineage", {}),
        })
    return out


def find_admissible_runtime_attestations(
    *,
    truth_scope: Optional[str],
    graph_content_signature: Optional[str],
    target_paths: Optional[Sequence[str]] = None,
    claim_types: Optional[Sequence[str]] = None,
    attestation_store_dir: Optional[str | os.PathLike[str]] = None,
    output_store_dir: Optional[str | os.PathLike[str]] = None,
) -> List[Dict[str, Any]]:
    """Return only attestations admissible for the current proof state."""
    scope = str(truth_scope or "unscoped")
    graph_sig = str(graph_content_signature or "")
    if scope == "unscoped" or not graph_sig:
        return []
    targets = set(_normalize_targets(target_paths))
    requested_claims = set(str(v) for v in (claim_types or []) if v)
    out: List[Dict[str, Any]] = []
    for item in _load_cells(attestation_store_dir):
        if item.get("truth_scope") != scope:
            continue
        if item.get("graph_content_signature") != graph_sig:
            continue
        claim = str(item.get("claim_type") or "")
        if requested_claims and claim not in requested_claims:
            continue
        att_targets = set(_normalize_targets(item.get("target_paths", [])))
        if targets and not (targets & att_targets):
            # Targeted claim must have a targeted attestation; an unspecified
            # execution cannot silently become project-wide proof.
            continue
        output_id = str(item.get("output_id") or "")
        # Creation already verified the exact SHA. Admission only checks that the
        # content-addressed raw witness still exists, avoiding a full decompression
        # on every context call. Exact recovery re-verifies SHA before use.
        if not raw_output_available(output_id, store_dir=output_store_dir):
            continue
        out.append({
            "attestation_id": item.get("attestation_id"),
            "claim_type": claim,
            "truth_scope": scope,
            "graph_content_signature": graph_sig,
            "target_paths": sorted(att_targets),
            "command_head": item.get("command_head"),
            "command_fingerprint": item.get("command_fingerprint"),
            "exit_code": item.get("exit_code"),
            "execution_interpretation": item.get("execution_interpretation"),
            "output_id": output_id,
            "authority_domain": "current_runtime_observation",
            "raw_output_recoverable": True,
            "transition_id": item.get("transition_id"),
            "transition_type": item.get("transition_type"),
            "transition_cost": item.get("transition_cost", {}),
            "policy_cost_observation": item.get("policy_cost_observation", {}),
            "source_proof_state": item.get("source_proof_state", {}),
            "lineage": item.get("lineage", {}),
        })
    return out


def find_runtime_attestation_lineages_for_output(
    output_id: str, *, attestation_store_dir: Optional[str | os.PathLike[str]] = None
) -> List[str]:
    """Return exact attestation lineage ids referencing one content-addressed output."""
    normalized = _validate_sha256_id(output_id, name="output_id")
    ids: List[str] = []
    for item in _load_cells(attestation_store_dir):
        if str(item.get("output_id") or "") != normalized:
            continue
        lid = str((item.get("lineage") or {}).get("id") or "")
        if lid and lid not in ids:
            ids.append(lid)
    return ids


__all__ = [
    "SCHEMA_VERSION",
    "POLICY_VERSION",
    "SUPPORTED_CLAIMS",
    "create_runtime_attestation",
    "find_runtime_attestation_attempts",
    "find_admissible_runtime_attestations",
    "find_runtime_attestation_lineages_for_output",
]
