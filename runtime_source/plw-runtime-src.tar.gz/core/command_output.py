"""Conservative command-output compaction for PLW.

This module sits *after* a Linux command has executed.  It never executes the
command itself.  The raw observation remains recoverable from a content-
addressed local store while the LLM-facing representation is compacted only
when the command family has a conservative, evidence-preserving transform.

Policy:
- exact/arbitrary: preserve output verbatim; never hard-truncate.
- search: reorganize repeated file prefixes without dropping a match.
- repetitive: run-length encode only consecutive identical lines.
- binary/undecodable-ish: preserve/externalize; do not infer semantics.

The hard rule is that a token budget is advisory for command output.  If a
lossless/conservative representation still exceeds the budget, PLW reports
that fact instead of silently deleting evidence.
"""

from __future__ import annotations

import gzip
import hashlib
import json
import math
import os
import re
import tempfile
from pathlib import Path
from core.runtime_paths import state_path
from typing import Any, Dict, Iterable, List, Optional, Tuple

from core.command_telemetry import (
    command_fingerprint,
    record_observation_event,
    record_recovery_event,
    summarize_telemetry,
    summarize_output_behavior,
    summarize_output_behaviors,
)
from core.context_accountability import record_accountability
from core.decision_lineage import record_lineage_node

POLICY_VERSION = "conservative_command_output_v1"
OUTPUT_KINDS = ("auto", "exact", "search", "repetitive", "arbitrary")
DEFAULT_BUDGET_TOKENS = 1200
DEFAULT_MAX_STORE_ENTRIES = 64
DEFAULT_MAX_STORE_BYTES = 64 * 1024 * 1024

DEFAULT_OUTPUT_STORE = state_path("command_outputs")

_SEARCH_COMMANDS = {"rg", "ripgrep", "grep", "egrep", "fgrep", "find", "fd"}
_EXACT_COMMANDS = {"cat", "sed", "head", "tail", "less", "git"}
_REPETITIVE_COMMANDS = {
    "pytest",
    "jest",
    "vitest",
    "mocha",
    "npm",
    "pnpm",
    "yarn",
    "bun",
    "pip",
    "pip3",
    "uv",
    "cargo",
    "make",
    "cmake",
    "ninja",
    "gradle",
    "gradlew",
    "mvn",
    "tsc",
    "eslint",
    "ruff",
}


def _estimate_tokens(text: str) -> int:
    return int(math.ceil(len(text) / 4.0)) if text else 0


def _command_head(command: str) -> str:
    value = str(command or "").strip()
    if not value:
        return ""
    # This is classification only, not shell parsing/execution.  Strip common
    # env/command prefixes conservatively and use the first remaining token.
    parts = value.split()
    i = 0
    while i < len(parts) and ("=" in parts[i] and not parts[i].startswith(("./", "/"))):
        i += 1
    if i < len(parts) and parts[i] in {"env", "command", "sudo"}:
        i += 1
    if i >= len(parts):
        return ""
    return os.path.basename(parts[i]).lower()


def classify_command(command: str, requested_kind: str = "auto") -> str:
    kind = str(requested_kind or "auto").strip().lower()
    if kind not in OUTPUT_KINDS:
        raise ValueError(f"Unsupported output kind: {requested_kind}")
    if kind != "auto":
        return kind

    head = _command_head(command)
    if head in _SEARCH_COMMANDS:
        return "search"
    if head == "git":
        # Diff/show/blame are source/change evidence; preserve exactly.
        return "exact"
    if head in _EXACT_COMMANDS:
        return "exact"
    if head in _REPETITIVE_COMMANDS:
        return "repetitive"
    return "arbitrary"


def _search_group_key(line: str) -> Optional[Tuple[str, str]]:
    """Return (file, remainder) for common rg/grep result lines.

    No line is discarded if parsing fails; the caller emits it verbatim in an
    ungrouped section.  We intentionally do not try to interpret arbitrary
    colons in every command's output.
    """
    # rg/grep with line number: path:123:payload
    m = re.match(r"^(.*?):(\d+):(.*)$", line)
    if m and m.group(1):
        return m.group(1), f"{m.group(2)}:{m.group(3)}"

    # grep -R style without line number: path:payload.  Require a path-ish
    # prefix so arbitrary diagnostic lines are not rewritten.
    if ":" in line:
        prefix, rest = line.split(":", 1)
        if prefix and ("/" in prefix or "\\" in prefix or "." in os.path.basename(prefix)):
            return prefix, rest
    return None


def _compact_search(text: str) -> Tuple[str, Dict[str, Any]]:
    lines = text.splitlines()
    trailing_newline = text.endswith("\n")
    groups: List[Tuple[Optional[str], List[str]]] = []
    current_key: Optional[str] = None
    current_values: List[str] = []

    def flush() -> None:
        nonlocal current_key, current_values
        if current_values:
            groups.append((current_key, current_values))
        current_key = None
        current_values = []

    parsed_count = 0
    for line in lines:
        parsed = _search_group_key(line)
        if parsed is None:
            flush()
            groups.append((None, [line]))
            continue
        file_path, remainder = parsed
        parsed_count += 1
        if current_values and current_key != file_path:
            flush()
        current_key = file_path
        current_values.append(remainder)
    flush()

    out: List[str] = []
    for key, values in groups:
        if key is None:
            out.extend(values)
            continue
        out.append(f"[{key}]")
        out.extend(values)

    compacted = "\n".join(out)
    if trailing_newline and compacted:
        compacted += "\n"

    return compacted, {
        "input_lines": len(lines),
        "search_result_lines": len(lines),
        "parsed_match_lines": parsed_count,
        "matches_omitted": 0,
        "reordered": False,
        "grouping": "consecutive_file_prefix",
    }


def _compact_repetitive(text: str) -> Tuple[str, Dict[str, Any]]:
    lines = text.splitlines()
    trailing_newline = text.endswith("\n")
    out: List[str] = []
    runs_collapsed = 0
    lines_represented = 0

    i = 0
    while i < len(lines):
        line = lines[i]
        j = i + 1
        while j < len(lines) and lines[j] == line:
            j += 1
        count = j - i
        lines_represented += count
        marker = f"[PLW repeated consecutively x{count}; exact raw available via recovery]"
        raw_run_chars = (len(line) * count) + max(0, count - 1)
        compact_run_chars = len(line) + 1 + len(marker)
        if count >= 3 and compact_run_chars < raw_run_chars:
            out.append(line)
            out.append(marker)
            runs_collapsed += 1
        else:
            out.extend(lines[i:j])
        i = j

    compacted = "\n".join(out)
    if trailing_newline and compacted:
        compacted += "\n"

    return compacted, {
        "input_lines": len(lines),
        "represented_lines": lines_represented,
        "runs_collapsed": runs_collapsed,
        "unique_evidence_lines_omitted": 0,
        "ordering_preserved": True,
        "transform": "consecutive_identical_run_length",
    }


def _store_directory(store_dir: Optional[str | os.PathLike[str]]) -> Path:
    env_dir = os.environ.get("PLW_COMMAND_OUTPUT_DIR")
    return Path(store_dir or env_dir or DEFAULT_OUTPUT_STORE).expanduser().resolve()


def _gc_store(directory: Path, *, keep: Optional[Path] = None) -> Dict[str, int]:
    files = []
    try:
        for path in directory.glob("sha256-*.gz"):
            try:
                st = path.stat()
            except OSError:
                continue
            files.append((st.st_mtime_ns, st.st_size, path))
    except OSError:
        return {"entries_removed": 0, "bytes_removed": 0}

    files.sort()  # oldest first
    total_bytes = sum(size for _, size, _ in files)
    removed = 0
    removed_bytes = 0

    while len(files) > DEFAULT_MAX_STORE_ENTRIES or total_bytes > DEFAULT_MAX_STORE_BYTES:
        _, size, path = files.pop(0)
        if keep is not None and path == keep and files:
            files.append((path.stat().st_mtime_ns, size, path))
            files.sort()
            continue
        if keep is not None and path == keep and not files:
            break
        try:
            path.unlink()
            removed += 1
            removed_bytes += size
            total_bytes -= size
        except OSError:
            pass

    return {"entries_removed": removed, "bytes_removed": removed_bytes}


def store_raw_output(raw: bytes, store_dir: Optional[str | os.PathLike[str]] = None) -> Dict[str, Any]:
    digest = hashlib.sha256(raw).hexdigest()
    output_id = f"sha256:{digest}"
    directory = _store_directory(store_dir)
    target = directory / f"sha256-{digest}.gz"

    try:
        directory.mkdir(parents=True, exist_ok=True, mode=0o700)
        try:
            os.chmod(directory, 0o700)
        except OSError:
            pass

        if not target.exists():
            fd, tmp_name = tempfile.mkstemp(prefix=".cmdout-", suffix=".gz", dir=str(directory))
            os.close(fd)
            tmp = Path(tmp_name)
            try:
                with gzip.open(tmp, "wb", compresslevel=6) as handle:
                    handle.write(raw)
                try:
                    os.chmod(tmp, 0o600)
                except OSError:
                    pass
                os.replace(tmp, target)
            finally:
                if tmp.exists():
                    try:
                        tmp.unlink()
                    except OSError:
                        pass
        try:
            os.chmod(target, 0o600)
        except OSError:
            pass
        gc = _gc_store(directory, keep=target)
        return {
            "available": True,
            "id": output_id,
            "sha256": digest,
            "raw_bytes": len(raw),
            "stored_compressed_bytes": target.stat().st_size,
            "gc": gc,
        }
    except Exception as exc:
        return {
            "available": False,
            "id": output_id,
            "sha256": digest,
            "raw_bytes": len(raw),
            "error": f"command_output_store_failed:{type(exc).__name__}",
        }


def recover_raw_output(
    output_id: str,
    store_dir: Optional[str | os.PathLike[str]] = None,
    *,
    telemetry: bool = True,
    parent_lineage_ids: Optional[Iterable[str]] = None,
) -> bytes:
    value = str(output_id or "").strip()
    digest = value.split(":", 1)[1] if value.startswith("sha256:") else value
    if not re.fullmatch(r"[0-9a-fA-F]{64}", digest):
        raise ValueError("Invalid command output recovery id")
    digest = digest.lower()
    path = _store_directory(store_dir) / f"sha256-{digest}.gz"
    if not path.is_file():
        raise FileNotFoundError(f"Command output recovery id not found: sha256:{digest}")
    with gzip.open(path, "rb") as handle:
        raw = handle.read()
    actual = hashlib.sha256(raw).hexdigest()
    if actual != digest:
        raise ValueError("Recovered command output failed SHA-256 verification")
    if telemetry:
        record_recovery_event(
            store_directory=_store_directory(store_dir),
            output_id=f"sha256:{digest}",
        )
    parents = [str(v) for v in (parent_lineage_ids or []) if v]
    if parents:
        record_lineage_node(
            node_type="output_recovery",
            reference_type="output_id",
            reference_id=f"sha256:{digest}",
            parent_ids=parents,
            metadata={"linkage_basis": "explicit_or_exact_attestation_lineage", "telemetry_recorded": bool(telemetry)},
        )
    return raw



def raw_output_available(
    output_id: str,
    store_dir: Optional[str | os.PathLike[str]] = None,
) -> bool:
    """Cheap availability check; exact SHA verification still happens on recovery."""
    value = str(output_id or "").strip()
    digest = value.split(":", 1)[1] if value.startswith("sha256:") else value
    if not re.fullmatch(r"[0-9a-fA-F]{64}", digest):
        return False
    return (_store_directory(store_dir) / f"sha256-{digest.lower()}.gz").is_file()


def get_command_output_telemetry(
    store_dir: Optional[str | os.PathLike[str]] = None,
) -> Dict[str, Any]:
    """Summarize behavioral signals without exposing raw commands or stdout."""
    return summarize_telemetry(_store_directory(store_dir))


def get_output_behavior_metrics(
    output_id: str,
    *,
    command: str = "",
    command_fingerprint_value: Optional[str] = None,
    store_dir: Optional[str | os.PathLike[str]] = None,
) -> Dict[str, Any]:
    """Return privacy-bounded command cost signals for policy learning.

    Callers that only retain a privacy-safe command fingerprint can pass it
    directly; raw command text is never required for delayed reconciliation.
    """
    fp = str(command_fingerprint_value or "").strip() or (command_fingerprint(command) if command else None)
    return summarize_output_behavior(
        _store_directory(store_dir),
        output_id=str(output_id or ""),
        command_fingerprint_value=fp,
    )

def get_output_behavior_metrics_batch(
    requests: Iterable[Dict[str, Any]],
    *,
    store_dir: Optional[str | os.PathLike[str]] = None,
) -> List[Dict[str, Any]]:
    """Batch privacy-bounded behavior metrics from one telemetry snapshot."""
    return summarize_output_behaviors(_store_directory(store_dir), requests)


def compact_command_output(
    raw: bytes,
    *,
    command: str = "",
    kind: str = "auto",
    budget_tokens: int = DEFAULT_BUDGET_TOKENS,
    store: bool = True,
    store_dir: Optional[str | os.PathLike[str]] = None,
    telemetry: bool = True,
    parent_lineage_ids: Optional[Iterable[str]] = None,
) -> Dict[str, Any]:
    selected_kind = classify_command(command, kind)
    raw_sha = hashlib.sha256(raw).hexdigest()
    binary = b"\x00" in raw[:8192]
    text = raw.decode("utf-8", errors="replace")
    decode_replacements = text.count("\ufffd")

    if binary:
        selected_kind = "arbitrary"
        compacted = text
        transform = {
            "binary_detected": True,
            "semantic_compaction_applied": False,
            "reason": "binary_or_nul_content",
        }
    elif selected_kind == "search":
        candidate, transform = _compact_search(text)
        transform["candidate_characters"] = len(candidate)
        if len(candidate) < len(text):
            compacted = candidate
            transform["semantic_compaction_applied"] = True
            transform["transform_reverted_no_savings"] = False
        else:
            compacted = text
            transform["semantic_compaction_applied"] = False
            transform["transform_reverted_no_savings"] = candidate != text
    elif selected_kind == "repetitive":
        candidate, transform = _compact_repetitive(text)
        transform["candidate_characters"] = len(candidate)
        if len(candidate) < len(text):
            compacted = candidate
            transform["semantic_compaction_applied"] = True
            transform["transform_reverted_no_savings"] = False
        else:
            compacted = text
            transform["semantic_compaction_applied"] = False
            transform["transform_reverted_no_savings"] = candidate != text
    else:
        compacted = text
        transform = {
            "semantic_compaction_applied": False,
            "reason": "exact_preservation_policy" if selected_kind == "exact" else "arbitrary_preservation_policy",
        }

    raw_tokens = _estimate_tokens(text)
    compacted_tokens = _estimate_tokens(compacted)
    budget = max(1, int(budget_tokens))
    recovery = (
        store_raw_output(raw, store_dir=store_dir)
        if store
        else {
            "available": False,
            "id": f"sha256:{raw_sha}",
            "sha256": raw_sha,
            "raw_bytes": len(raw),
            "reason": "storage_disabled",
        }
    )
    if recovery.get("available"):
        recovery["command"] = f"plw recover-output {recovery['id']}"

    telemetry_result: Dict[str, Any] = {
        "recorded": False,
        "reason": "telemetry_disabled",
    }
    if telemetry:
        recorded = record_observation_event(
            store_directory=_store_directory(store_dir),
            command=command,
            command_head=_command_head(command),
            kind=selected_kind,
            output_id=str(recovery.get("id") or f"sha256:{raw_sha}"),
            raw_tokens=raw_tokens,
            compacted_tokens=compacted_tokens,
            tokens_saved=max(0, raw_tokens - compacted_tokens),
            within_budget=compacted_tokens <= budget,
            semantic_compaction_applied=bool(transform.get("semantic_compaction_applied")),
            recovery_available=bool(recovery.get("available")),
        )
        telemetry_result = {
            "recorded": bool(recorded.get("recorded")),
            "authority": "advisory_only",
        }
        if recorded.get("error"):
            telemetry_result["error"] = recorded.get("error")

    compacted_sha = hashlib.sha256(compacted.encode("utf-8")).hexdigest()
    command_accountability_decision = {
        "decision_type": "command_output_representation",
        "responsible_component": "core.command_output.compact_command_output",
        "responsible_role": "command_output_custodian",
        "policy": POLICY_VERSION,
        "input_state": {
            "command_head": _command_head(command),
            "command_fingerprint": command_fingerprint(command),
            "kind": selected_kind,
            "raw_sha256": f"sha256:{raw_sha}",
            "raw_estimated_tokens": raw_tokens,
            "budget_tokens": budget,
        },
        "representation": {
            "compacted_sha256": f"sha256:{compacted_sha}",
            "compacted_estimated_tokens": compacted_tokens,
            "estimated_tokens_saved": max(0, raw_tokens - compacted_tokens),
            "semantic_compaction_applied": bool(transform.get("semantic_compaction_applied")),
            "within_budget": compacted_tokens <= budget,
            "transform_metadata": transform,
        },
        "evidence_debt": {
            "evidence_omitted_for_budget": False,
            "hard_truncation_applied": False,
            "raw_exactness_externalized": bool(transform.get("semantic_compaction_applied")),
        },
        "invariants": {
            "budget_is_advisory": True,
            "search_matches_omitted": int(transform.get("matches_omitted", 0) or 0),
            "unique_evidence_lines_omitted": int(transform.get("unique_evidence_lines_omitted", 0) or 0),
            "raw_command_stored_in_ledger": False,
            "raw_output_stored_in_ledger": False,
        },
        "recovery_obligation": {
            "required_when": "exact formatting/raw ordering is correctness-relevant or compact representation is insufficient",
            "output_id": str(recovery.get("id") or f"sha256:{raw_sha}"),
            "available": bool(recovery.get("available")),
            "command": recovery.get("command"),
        },
    }
    command_accountability_ref = record_accountability(command_accountability_decision)
    lineage_ref = record_lineage_node(
        node_type="command_output_representation",
        reference_type="accountability_decision",
        reference_id=str(command_accountability_ref.get("id") or ""),
        parent_ids=parent_lineage_ids or [],
        metadata={
            "output_id": str(recovery.get("id") or f"sha256:{raw_sha}"),
            "kind": selected_kind,
            "semantic_compaction_applied": bool(transform.get("semantic_compaction_applied")),
            "raw_estimated_tokens": int(raw_tokens),
            "compacted_estimated_tokens": int(compacted_tokens),
            "estimated_tokens_saved": max(0, raw_tokens - compacted_tokens),
        },
    )
    accountability = {
        "responsible_component": command_accountability_decision["responsible_component"],
        "responsible_role": command_accountability_decision["responsible_role"],
        "policy": POLICY_VERSION,
        "evidence_debt": command_accountability_decision["evidence_debt"],
        "recovery_obligation": command_accountability_decision["recovery_obligation"],
        "ledger": command_accountability_ref,
        "lineage": lineage_ref,
    }

    return {
        "schema_version": "command-output-v1",
        "policy": POLICY_VERSION,
        "command": command,
        "kind": selected_kind,
        "raw": {
            "sha256": raw_sha,
            "bytes": len(raw),
            "characters": len(text),
            "estimated_tokens": raw_tokens,
            "decode_replacement_characters": decode_replacements,
        },
        "compacted": {
            "characters": len(compacted),
            "estimated_tokens": compacted_tokens,
            "characters_saved": max(0, len(text) - len(compacted)),
            "estimated_tokens_saved": max(0, raw_tokens - compacted_tokens),
            "within_budget": compacted_tokens <= budget,
            "budget_tokens": budget,
            "hard_truncation_applied": False,
            "evidence_omitted_for_budget": False,
            **transform,
        },
        "accountability": accountability,
        "recovery": recovery,
        "telemetry": telemetry_result,
        "output": compacted,
    }


__all__ = [
    "POLICY_VERSION",
    "OUTPUT_KINDS",
    "DEFAULT_BUDGET_TOKENS",
    "classify_command",
    "compact_command_output",
    "store_raw_output",
    "recover_raw_output",
    "raw_output_available",
    "get_command_output_telemetry",
    "get_output_behavior_metrics",
    "get_output_behavior_metrics_batch",
]
