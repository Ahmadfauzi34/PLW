"""Compact advisory envelope for the experimental capability lifecycle."""
from __future__ import annotations

from typing import Any, Dict, Mapping

from core.capability_contracts import is_sha256_id, no_effect_authorizations, safe_canonical_digest
from core.capability_lifecycle import LEGAL_TRANSITIONS, POLICY_VERSION, evaluate_transition

SCHEMA_VERSION = "capability-workflow-envelope-v1"
ADAPTER_POLICY = "capability_workflow_adapter_v1"


def _digest(evidence: Mapping[str, Any]) -> str:
    digest = safe_canonical_digest(dict(evidence), max_bytes=65536)
    if digest is None:
        raise ValueError("Workflow evidence is not bounded canonical JSON")
    return digest


def _action(known: bool, legal: list[str], allowed: list[str]) -> Dict[str, Any]:
    if not known:
        return {"kind": "INVALID_STATE", "target": None}
    if not legal:
        return {"kind": "NONE_TERMINAL", "target": None}
    if len(allowed) == 1:
        return {"kind": "PROPOSE_TRANSITION", "target": allowed[0]}
    if len(allowed) > 1:
        return {"kind": "CHOOSE_ALLOWED_TRANSITION", "target": None}
    return {"kind": "COLLECT_EVIDENCE", "target": None}


def build_decision_envelope(
    capability_id: str,
    current_state: str,
    evidence: Mapping[str, Any] | None = None,
) -> Dict[str, Any]:
    """Describe legal next work without executing a lifecycle transition."""
    if evidence is None:
        evidence = {}
    elif not isinstance(evidence, Mapping):
        raise ValueError("Workflow evidence must be a mapping")
    else:
        try:
            evidence = dict(evidence)
        except Exception:
            raise ValueError("Workflow evidence must be a mapping") from None
    state = str(current_state or "")
    known = state in LEGAL_TRANSITIONS
    legal = list(LEGAL_TRANSITIONS.get(state, ()))
    allowed: list[str] = []
    blocked: Dict[str, list[str]] = {}
    for target in legal:
        result = evaluate_transition(capability_id, state, target, evidence)
        if result["transition_allowed"]:
            allowed.append(target)
        else:
            failures = list(result["failed_conditions"])
            blocked[target] = failures
    return {
        "schema_version": SCHEMA_VERSION,
        "policy": ADAPTER_POLICY,
        "lifecycle_policy": POLICY_VERSION,
        "capability_id": str(capability_id or ""),
        "state": state,
        "state_known": known,
        "terminal": known and not legal,
        "legal_targets": legal,
        "allowed_targets": allowed,
        "blocked_targets": blocked,
        "next_action": _action(known, legal, allowed),
        "evidence_digest": _digest(evidence),
        "authority": "advisory_workflow_only",
        "authorizations": {
            "transition_execution": False,
            "runtime_execution": False,
            "external_patch": False,
            "stable_promotion": False,
            "truth_commit": False,
        },
    }


def render_context_advisory(context: Mapping[str, Any] | None, char_cap: int) -> tuple[str, Dict[str, Any]]:
    """Render an explicitly relevant advisory envelope for a bounded context pack."""
    if context is None:
        context = {}
    elif not isinstance(context, Mapping):
        return "", {"requested": True, "relevant": False, "included": False, "reason": "invalid_context"}
    else:
        try:
            context = dict(context)
        except Exception:
            return "", {"requested": True, "relevant": False, "included": False, "reason": "invalid_context"}
    relevant, envelope = context.get("relevant") is True, context.get("envelope")
    info: Dict[str, Any] = {"requested": True, "relevant": relevant, "included": False}
    if not relevant or not isinstance(envelope, dict):
        info["reason"] = "not_relevant" if not relevant else "invalid_envelope"
        return "", info
    legal = envelope.get("legal_targets")
    allowed = envelope.get("allowed_targets")
    blocked = envelope.get("blocked_targets")
    action = envelope.get("next_action")
    safe = (
        envelope.get("schema_version") == SCHEMA_VERSION
        and envelope.get("policy") == ADAPTER_POLICY
        and envelope.get("lifecycle_policy") == POLICY_VERSION
        and envelope.get("authority") == "advisory_workflow_only"
        and no_effect_authorizations(envelope.get("authorizations"))
        and isinstance(envelope.get("capability_id"), str)
        and len(envelope["capability_id"]) <= 128
        and isinstance(envelope.get("state"), str)
        and type(envelope.get("state_known")) is bool
        and type(envelope.get("terminal")) is bool
        and isinstance(legal, list)
        and len(legal) <= 32
        and all(isinstance(value, str) and len(value) <= 128 for value in legal)
        and isinstance(allowed, list)
        and len(allowed) <= 32
        and all(isinstance(value, str) and len(value) <= 128 for value in allowed)
        and set(allowed) <= set(legal)
        and isinstance(blocked, dict)
        and len(blocked) <= 32
        and all(
            isinstance(target, str)
            and len(target) <= 128
            and isinstance(failures, list)
            and len(failures) <= 32
            and all(isinstance(failure, str) and len(failure) <= 256 for failure in failures)
            for target, failures in blocked.items()
        )
        and isinstance(action, dict)
        and set(action) == {"kind", "target"}
        and isinstance(action.get("kind"), str)
        and (action.get("target") is None or isinstance(action.get("target"), str))
        and is_sha256_id(envelope.get("evidence_digest"))
    )
    if not safe:
        info["reason"] = "authority_not_advisory_only"
        return "", info
    clean = lambda value, n=64: " ".join(str(value or "").split())[:n]
    allowed_text = ",".join(clean(v, 32) for v in allowed[:3]) or "-"
    blocked_text = []
    for target, failures in list(blocked.items())[:2]:
        blocked_text.append(f"{clean(target,32)}:{clean((failures or [''])[0],64)}")
    lines = [
        "[CAPABILITY-WORKFLOW]",
        f"id={clean(envelope.get('capability_id'))}; state={clean(envelope.get('state'),32)}; allowed={allowed_text}",
        f"next={clean(action.get('kind'),32)}:{clean(action.get('target'),32) or '-'}",
    ]
    if blocked_text:
        lines.append("blocked=" + " | ".join(blocked_text))
    lines += [
        f"evidence={clean(envelope.get('evidence_digest'),72)}",
        "authority=advisory_only; execute/patch/stable/truth=false",
        "[/CAPABILITY-WORKFLOW]",
    ]
    block = "\n".join(lines) + "\n"
    if type(char_cap) is not int or char_cap <= 0 or len(block) > char_cap:
        info.update({"reason": "budget_omitted", "rendered_chars": len(block)})
        return "", info
    info.update({"included": True, "reason": "explicit_relevant_advisory_envelope", "rendered_chars": len(block), "state": clean(envelope.get("state"), 32), "evidence_digest": clean(envelope.get("evidence_digest"), 72)})
    return block, info


__all__ = ["SCHEMA_VERSION", "ADAPTER_POLICY", "build_decision_envelope", "render_context_advisory"]
