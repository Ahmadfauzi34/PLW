"""F138.5 evidence-driven PLW capability matching.

Consumes target-grounded F138.4 evidence classes and projects candidate PLW
capabilities by expected information gain. Task wording is not used as a
selector. This layer is read-only and never executes or authorizes a capability.
"""
from __future__ import annotations

from typing import Any, Dict, Iterable, List, Mapping

from core.semantic_affordance import describe_command

SCHEMA_VERSION = "evidence-driven-capability-selection-v1"
POLICY = "evidence-class-to-capability-contract-not-task-keyword-v1"

# Match only stable machine-readable evidence classes emitted by F138.4.
# coverage is epistemic, not an execution/proof claim.
_RULES: Dict[str, List[Dict[str, Any]]] = {
    "semantic_scope": [
        {"capability": "context", "coverage": "PARTIAL_STATIC", "score": 0.95,
         "role": "collect bounded graph-grounded source witnesses around the resolved target"},
        {"capability": "outline", "coverage": "PARTIAL_STATIC", "score": 0.82,
         "role": "expose target symbols/exports and structural sections"},
        {"capability": "brief", "coverage": "PARTIAL_STATIC", "score": 0.78,
         "role": "combine target structure and dependency impact for agent inspection"},
    ],
    "runtime_regression": [
        {"capability": "validation-plan", "coverage": "PREPARATORY", "score": 0.88,
         "role": "bound scenarios that should be observed; does not run them"},
        {"capability": "attest-runtime", "coverage": "BINDS_EXTERNAL_OBSERVATION", "score": 0.80,
         "role": "bind externally produced runtime output after execution elsewhere"},
    ],
    "external_contract": [
        {"capability": "context", "coverage": "PARTIAL_LOCAL", "score": 0.68,
         "role": "recover local wrappers/call sites; external API semantics still require an external source or runtime witness"},
    ],
    "dependency_resolution": [
        {"capability": "kan", "coverage": "INFERENTIAL_ONLY", "score": 0.72,
         "role": "project expected structural neighbors without converting imputation into source truth"},
        {"capability": "context", "coverage": "PARTIAL_STATIC", "score": 0.65,
         "role": "recover nearby source evidence that may explain unresolved dependency paths"},
    ],
    "state_effect_semantics": [
        {"capability": "context", "coverage": "PARTIAL_STATIC", "score": 0.90,
         "role": "collect state mutation, ownership, transaction and call-site witnesses"},
        {"capability": "impact", "coverage": "PARTIAL_STATIC", "score": 0.76,
         "role": "bound downstream surfaces where repeated effects may propagate"},
        {"capability": "validation-plan", "coverage": "PREPARATORY", "score": 0.70,
         "role": "prepare scenario observations for duplicate/transaction effects"},
    ],
    "concurrency_ordering": [
        {"capability": "validation-plan", "coverage": "PREPARATORY", "score": 0.86,
         "role": "bound ordering/interleaving scenarios that require observation"},
        {"capability": "attest-runtime", "coverage": "BINDS_EXTERNAL_OBSERVATION", "score": 0.78,
         "role": "bind exact externally produced ordering/runtime output"},
        {"capability": "context", "coverage": "PARTIAL_STATIC", "score": 0.66,
         "role": "collect async/locking/queue source witnesses but not runtime ordering"},
    ],
    "postcondition_observation": [
        {"capability": "validation-plan", "coverage": "PREPARATORY", "score": 0.92,
         "role": "bound scenarios required to observe the requested postcondition"},
        {"capability": "validation-result", "coverage": "ACCEPTS_EXISTING_RESULT", "score": 0.74,
         "role": "accept content-bound validator result only after runtime evidence already exists"},
    ],
}

_DIRECT_COVERAGE = {"DIRECT", "BINDS_EXTERNAL_OBSERVATION", "ACCEPTS_EXISTING_RESULT"}


def _candidate(row: Mapping[str, Any], evidence_class: str) -> Dict[str, Any]:
    name = str(row.get("capability") or "")
    contract = describe_command(name)
    return {
        "capability": name,
        "evidence_class": evidence_class,
        "coverage": str(row.get("coverage") or "UNKNOWN"),
        "score": float(row.get("score") or 0.0),
        "role": str(row.get("role") or ""),
        "expected_information_gain": list(contract.get("information_gain", []) or []),
        "canonical_concepts": list(contract.get("canonical_concepts", []) or []),
        "does_not_prove": list(contract.get("does_not_prove", []) or []),
        "skill_path": contract.get("read_before_use"),
        "state_change": bool(contract.get("state_change", False)),
        "contract_known": bool(contract.get("known", False)),
    }


def build_capability_selection(evidence_need_derivation: Mapping[str, Any]) -> Dict[str, Any]:
    stage = str(evidence_need_derivation.get("stage") or "")
    selected_targets = list(evidence_need_derivation.get("selected_targets", []) or [])
    needs = [row for row in evidence_need_derivation.get("evidence_needed", []) or [] if isinstance(row, Mapping)]
    base: Dict[str, Any] = {
        "schema_version": SCHEMA_VERSION,
        "policy": POLICY,
        "source_stage": stage,
        "selected_targets": selected_targets,
        "task_text_used_for_selection": False,
        "selection_basis": "machine_readable_evidence_class_plus_capability_contract",
        "need_matches": [],
        "candidate_capabilities": [],
        "uncovered_needs": [],
        "authority": {
            "read_only": True,
            "selects_candidate_capabilities": True,
            "chooses_agent_action": False,
            "executes_capability": False,
            "grants_state_change": False,
            "semantic_ownership_proven": False,
            "behavioral_correctness_proven": False,
            "commit_truth": False,
        },
    }
    if stage != "EVIDENCE_NEEDS_DERIVED" or not needs:
        base.update({
            "stage": "CAPABILITY_SELECTION_BLOCKED_EVIDENCE_NEEDS_NOT_READY",
            "blocked_reason": "target-grounded evidence needs must be derived before capability matching",
            "next_reasoning": "resolve the target and derive evidence needs first",
        })
        return base

    all_candidates: Dict[str, Dict[str, Any]] = {}
    need_matches: List[Dict[str, Any]] = []
    uncovered: List[Dict[str, Any]] = []
    for need in needs:
        evidence_class = str(need.get("evidence_class") or "")
        rules = _RULES.get(evidence_class, [])
        candidates = [_candidate(row, evidence_class) for row in rules]
        candidates.sort(key=lambda row: (-float(row["score"]), str(row["capability"])))
        direct = any(str(row.get("coverage")) in _DIRECT_COVERAGE for row in candidates)
        if not candidates:
            uncovered.append({
                "evidence_class": evidence_class or "UNCLASSIFIED",
                "need": need.get("need"),
                "reason": "no_registered_PLW_capability_contract_matches_this_evidence_class",
            })
        elif not direct:
            uncovered.append({
                "evidence_class": evidence_class,
                "need": need.get("need"),
                "reason": "available_PLW_candidates_are_partial_or_preparatory; additional external/runtime evidence may still be required",
            })
        need_matches.append({
            "evidence_class": evidence_class,
            "need": need.get("need"),
            "reason": need.get("reason"),
            "direct_satisfaction_available": direct,
            "candidates": candidates,
        })
        for candidate in candidates:
            name = str(candidate["capability"])
            existing = all_candidates.get(name)
            if existing is None:
                all_candidates[name] = {
                    **candidate,
                    "covers_evidence_classes": [evidence_class],
                    "aggregate_score": float(candidate["score"]),
                }
            else:
                if evidence_class not in existing["covers_evidence_classes"]:
                    existing["covers_evidence_classes"].append(evidence_class)
                existing["aggregate_score"] = round(float(existing["aggregate_score"]) + float(candidate["score"]), 6)
                existing["score"] = max(float(existing["score"]), float(candidate["score"]))

    ranked = list(all_candidates.values())
    ranked.sort(key=lambda row: (-len(row.get("covers_evidence_classes", [])), -float(row.get("aggregate_score", 0.0)), str(row.get("capability"))))
    for row in ranked:
        row["covers_evidence_classes"] = sorted(set(row.get("covers_evidence_classes", [])))

    base.update({
        "stage": "CAPABILITY_CANDIDATES_PROJECTED",
        "need_matches": need_matches,
        "candidate_capabilities": ranked,
        "uncovered_needs": uncovered,
        "summary": {
            "evidence_need_count": len(needs),
            "candidate_capability_count": len(ranked),
            "uncovered_need_count": len(uncovered),
            "all_needs_directly_satisfied": len(uncovered) == 0,
        },
        "next_reasoning": "The agent should inspect candidate information gain, skill contracts, current evidence and uncovered needs before choosing any call. Candidate projection is not execution authority.",
    })
    return base


__all__ = ["SCHEMA_VERSION", "POLICY", "build_capability_selection"]
