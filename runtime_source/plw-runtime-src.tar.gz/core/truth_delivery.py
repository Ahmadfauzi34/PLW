"""Proactive truth-delivery policy for PLW bounded context.

A bounded context projection may omit authoritative evidence to preserve the
reasoning budget.  Omission creates evidence debt, but debt is *dormant* while
that evidence is not yet appropriate for the current task.  This module decides
when a prior debt becomes due and should be brought back proactively.

The policy is deliberately conservative:
- no embedding/similarity-only activation;
- no automatic budget increase;
- no source-of-truth replacement;
- only exact/strong path re-entry or direct graph-boundary crossings activate
  proactive delivery;
- at most a small number of prior omitted files are promoted per context call.

The source code remains authoritative.  Accountability ledgers are only records
of representation decisions and are never treated as facts about the codebase.
"""

from __future__ import annotations

import hashlib
import os
import re
from typing import Any, Dict, Iterable, List, Optional, Set, Tuple

from core.context_accountability import list_accountability_decisions, record_accountability

TRUTH_DELIVERY_POLICY = "proactive_truth_delivery_v1"
RESPONSIBLE_COMPONENT = "core.truth_delivery.plan_proactive_truth_delivery"
RESPONSIBLE_ROLE = "proactive_truth_delivery_custodian"
MAX_PRIOR_DECISIONS = 64
DEFAULT_MAX_PROACTIVE_TARGETS = 2

_TOKEN_RE = re.compile(r"[A-Za-z][A-Za-z0-9_\-]*")
_GENERIC_TERMS = {
    "app", "src", "file", "code", "source", "service", "component", "module",
    "test", "spec", "index", "main", "util", "utils", "helper", "helpers",
    "ts", "tsx", "js", "jsx", "py",
}


def _normalize_path(value: str) -> str:
    normalized = os.path.normpath(str(value or "")).replace("\\", "/")
    if normalized.startswith("./"):
        normalized = normalized[2:]
    return normalized


def _path_terms(value: str) -> Set[str]:
    path = _normalize_path(value).lower()
    terms: Set[str] = set()
    for token in _TOKEN_RE.findall(path.replace("/", " ").replace(".", " ")):
        token = token.lower().strip("-_")
        if len(token) >= 4 and token not in _GENERIC_TERMS:
            terms.add(token)
        for part in re.split(r"[-_]", token):
            if len(part) >= 4 and part not in _GENERIC_TERMS:
                terms.add(part)
    return terms


def _query_terms(value: str) -> Set[str]:
    terms: Set[str] = set()
    for token in _TOKEN_RE.findall(str(value or "").lower()):
        token = token.strip("-_")
        if len(token) >= 4 and token not in _GENERIC_TERMS:
            terms.add(token)
        for part in re.split(r"[-_]", token):
            if len(part) >= 4 and part not in _GENERIC_TERMS:
                terms.add(part)
    return terms


def _resolve_paths(values: Iterable[str], vertices: Set[str]) -> List[str]:
    resolved: List[str] = []
    for raw in values:
        target = _normalize_path(raw)
        if not target:
            continue
        if target in vertices:
            resolved.append(target)
            continue
        matches = [v for v in vertices if v.endswith("/" + target) or v == target]
        if len(matches) == 1:
            resolved.append(matches[0])
    # deterministic, stable de-duplication
    seen: Set[str] = set()
    result: List[str] = []
    for value in resolved:
        if value not in seen:
            seen.add(value)
            result.append(value)
    return result


def _direct_neighbors(shared_graph: Dict[str, Any], targets: Iterable[str]) -> Set[str]:
    wanted = set(targets)
    neighbors: Set[str] = set()
    for edge in shared_graph.get("edges", []) or []:
        if not isinstance(edge, (list, tuple)) or len(edge) < 2:
            continue
        src, dst = str(edge[0]), str(edge[1])
        if src in wanted:
            neighbors.add(dst)
        if dst in wanted:
            neighbors.add(src)
    return neighbors


def _strong_query_reentry(query: str, path: str) -> Tuple[bool, float, List[str]]:
    q_lower = str(query or "").lower()
    p = _normalize_path(path).lower()
    basename = os.path.basename(p)
    stem = basename.rsplit(".", 1)[0] if "." in basename else basename

    if p and p in q_lower:
        return True, 1.0, ["full_path_mentioned"]
    if basename and len(basename) >= 5 and basename in q_lower:
        return True, 0.95, ["basename_mentioned"]
    if stem and len(stem) >= 5 and stem in q_lower:
        return True, 0.9, ["filename_stem_mentioned"]

    q_terms = _query_terms(query)
    p_terms = _path_terms(path)
    overlap = sorted(q_terms & p_terms)
    # Require at least two distinctive terms.  A single semantic word such as
    # "auth" is deliberately insufficient for automatic promotion.
    if len(overlap) >= 2:
        score = min(0.85, 0.55 + 0.1 * len(overlap))
        return True, score, ["distinctive_path_term_overlap", *overlap[:4]]
    return False, 0.0, overlap


def _graph_signature(shared_graph: Dict[str, Any]) -> Optional[str]:
    cache = shared_graph.get("cache", {}) if isinstance(shared_graph, dict) else {}
    value = cache.get("graph_content_signature") if isinstance(cache, dict) else None
    if value:
        return str(value)
    # The optimizer's provenance normally carries this signature.  If the graph
    # has no cache signature we decline cross-decision activation rather than
    # inventing a weaker identity here.
    return None


def plan_proactive_truth_delivery(
    shared_graph: Dict[str, Any],
    query: str,
    *,
    explicit_targets: Optional[List[str]] = None,
    accountability_store_dir: Optional[str] = None,
    max_proactive_targets: int = DEFAULT_MAX_PROACTIVE_TARGETS,
    truth_scope: Optional[str] = None,
) -> Dict[str, Any]:
    """Evaluate dormant evidence debt against the *current* task boundary.

    Returns a plan only.  The caller decides whether to pass proactive targets
    into the normal context optimizer.  No source is read here and no budget is
    increased.
    """
    signature = _graph_signature(shared_graph)
    scope = str(truth_scope or "unscoped")
    scoped = scope != "unscoped"
    vertices = {str(v) for v in shared_graph.get("vertices", []) or []}
    resolved_explicit = _resolve_paths(explicit_targets or [], vertices)
    direct_neighbors = _direct_neighbors(shared_graph, resolved_explicit)

    base_result: Dict[str, Any] = {
        "schema_version": "truth-delivery-v1",
        "policy": TRUTH_DELIVERY_POLICY,
        "responsible_component": RESPONSIBLE_COMPONENT,
        "responsible_role": RESPONSIBLE_ROLE,
        "authority": "delivery_policy_only",
        "enabled": True,
        "graph_content_signature": signature,
        "explicit_targets": resolved_explicit,
        "truth_scope": scope,
        "scope_is_explicit": scoped,
        "cross_task_ambiguity": not scoped,
        "proactive_targets": [],
        "naturally_due_targets": [],
        "activated_debts": [],
        "status": "no_due_debt",
        "budget_increase_tokens": 0,
        "invariants": {
            "omission_means_not_yet_appropriate_not_irrelevant": True,
            "source_remains_authority": True,
            "no_embedding_only_activation": True,
            "no_budget_increase": True,
            "max_proactive_targets": max(0, int(max_proactive_targets)),
            "automatic_cross_boundary_delivery_requires_scope": True,
        },
    }
    if not signature or not vertices:
        base_result["status"] = "unavailable_without_stable_graph_signature"
        return base_result

    decisions = list_accountability_decisions(
        store_dir=accountability_store_dir,
        decision_type="budgeted_context_projection",
        limit=MAX_PRIOR_DECISIONS,
        newest_first=True,
    )
    deliveries = list_accountability_decisions(
        store_dir=accountability_store_dir,
        decision_type="proactive_truth_delivery",
        limit=MAX_PRIOR_DECISIONS,
        newest_first=True,
    )

    # Settlement is scoped to one reasoning task/fiber and one immutable graph
    # snapshot. Once authoritative evidence has been delivered in that scope,
    # later bounded projections may omit it without automatically pushing it
    # again; the conversation/fiber is expected to retain the delivered witness.
    # A source change (new graph signature) or task/fiber switch reopens the cycle.
    latest_delivery_at: Dict[str, str] = {}
    for delivery in deliveries:
        input_state = delivery.get("input_state", {}) if isinstance(delivery, dict) else {}
        if str(input_state.get("graph_content_signature") or "") != signature:
            continue
        if str(input_state.get("truth_scope") or "unscoped") != scope:
            continue
        recorded_at = str(delivery.get("recorded_at") or "")
        for path in delivery.get("delivery", {}).get("delivered_targets", []) or []:
            normalized = _normalize_path(str(path))
            if normalized and recorded_at > latest_delivery_at.get(normalized, ""):
                latest_delivery_at[normalized] = recorded_at

    latest_debt: Dict[str, Dict[str, Any]] = {}
    for decision in decisions:
        input_state = decision.get("input_state", {}) if isinstance(decision, dict) else {}
        if str(input_state.get("graph_content_signature") or "") != signature:
            continue
        if str(input_state.get("truth_scope") or "unscoped") != scope:
            continue
        debt = decision.get("evidence_debt", {}) if isinstance(decision, dict) else {}
        candidate_paths = {_normalize_path(str(p)) for p in debt.get("omitted_candidate_paths", []) or []}
        project_paths = {_normalize_path(str(p)) for p in debt.get("omitted_project_paths", []) or []}
        recorded_at = str(decision.get("recorded_at") or "")
        decision_id = str(decision.get("decision_id") or "")
        for path in sorted((candidate_paths | project_paths) - {""}):
            if path not in vertices or path in latest_debt:
                continue  # newest-first: first debt for this path is authoritative
            latest_debt[path] = {
                "path": path,
                "source_liability_decision": decision_id,
                "recorded_at": recorded_at,
                "debt_class": "candidate" if path in candidate_paths else "project",
                "debt_bonus": 12 if path in candidate_paths else 0,
            }

    candidates: Dict[str, Dict[str, Any]] = {}
    natural: Dict[str, Dict[str, Any]] = {}
    explicit_set = set(resolved_explicit)

    for path, debt_record in latest_debt.items():
        debt_recorded_at = str(debt_record.get("recorded_at") or "")
        if latest_delivery_at.get(path):
            continue

        triggers: List[str] = []
        score = float(debt_record.get("debt_bonus", 0))
        strength = 0.0

        if path in explicit_set:
            triggers.append("explicit_target_reentry")
            score += 100.0
            strength = 1.0
        elif scoped and path in direct_neighbors:
            triggers.append("explicit_target_direct_graph_boundary")
            score += 85.0
            strength = 0.95

        lexical_due, lexical_strength, lexical_reasons = _strong_query_reentry(query, path)
        if scoped and lexical_due:
            triggers.extend(lexical_reasons)
            score += 65.0 * lexical_strength
            strength = max(strength, lexical_strength)

        if not triggers:
            continue

        record = {
            "path": path,
            "score": round(score, 4),
            "activation_strength": round(strength, 4),
            "triggers": sorted(set(triggers)),
            "source_liability_decision": debt_record.get("source_liability_decision"),
            "debt_class": debt_record.get("debt_class"),
            "debt_recorded_at": debt_recorded_at,
            "last_delivery_at": latest_delivery_at.get(path),
        }
        if path in explicit_set:
            natural[path] = record
        else:
            candidates[path] = record

    ordered = sorted(candidates.values(), key=lambda item: (-float(item["score"]), str(item["path"])))
    limit = max(0, int(max_proactive_targets))
    promoted = ordered[:limit]
    natural_due = sorted(natural.values(), key=lambda item: (-float(item["score"]), str(item["path"])))

    base_result["proactive_targets"] = [item["path"] for item in promoted]
    base_result["naturally_due_targets"] = [item["path"] for item in natural_due]
    base_result["activated_debts"] = natural_due + promoted
    if natural_due or promoted:
        base_result["status"] = "debt_due"
    elif not scoped:
        base_result["status"] = "scope_required_for_cross_boundary_delivery"
    return base_result


def finalize_truth_delivery(
    plan: Dict[str, Any],
    *,
    selected_paths: Iterable[str],
    current_context_decision_id: Optional[str] = None,
    accountability_store_dir: Optional[str] = None,
) -> Dict[str, Any]:
    """Record whether activated truth debt was actually delivered."""
    selected = {str(path) for path in selected_paths}
    proactive = [str(p) for p in plan.get("proactive_targets", []) or []]
    natural = [str(p) for p in plan.get("naturally_due_targets", []) or []]
    due = list(dict.fromkeys(natural + proactive))
    delivered = [p for p in due if p in selected]
    unresolved = [p for p in due if p not in selected]

    result = dict(plan)
    result.update({
        "due_targets": due,
        "delivered_targets": delivered,
        "unresolved_due_targets": unresolved,
        "delivery_status": (
            "not_triggered" if not due else "delivered" if not unresolved else "delivery_incomplete"
        ),
        "current_context_decision_id": current_context_decision_id,
    })
    if not due:
        result["ledger"] = {"available": False, "reason": "no_due_debt"}
        return result

    source_decisions = sorted({
        str(item.get("source_liability_decision"))
        for item in plan.get("activated_debts", []) or []
        if item.get("source_liability_decision")
    })
    decision = {
        "decision_type": "proactive_truth_delivery",
        "responsible_component": RESPONSIBLE_COMPONENT,
        "responsible_role": RESPONSIBLE_ROLE,
        "policy": TRUTH_DELIVERY_POLICY,
        "input_state": {
            "graph_content_signature": plan.get("graph_content_signature"),
            "truth_scope": plan.get("truth_scope", "unscoped"),
            "source_liability_decisions": source_decisions,
            "current_context_decision_id": current_context_decision_id,
        },
        "activation": {
            "activated_debts": plan.get("activated_debts", []),
            "proactive_targets": proactive,
            "naturally_due_targets": natural,
        },
        "delivery": {
            "due_targets": due,
            "delivered_targets": delivered,
            "unresolved_due_targets": unresolved,
            "budget_increase_tokens": 0,
        },
        "rights_and_duties": {
            "llm_right": "correctness-relevant authoritative evidence must be recoverable before claim",
            "filter_duty": "track omitted evidence debt and surface it when relevance becomes current",
            "delivery_duty": "promote due evidence before the claim boundary without silently increasing budget",
        },
        "invariants": {
            "omission_means_not_yet_appropriate_not_irrelevant": True,
            "source_remains_authority": True,
            "no_embedding_only_activation": True,
            "no_budget_increase": True,
            "delivery_does_not_prove_completeness": True,
        },
        "recovery_obligation": {
            "required_if_delivery_incomplete": bool(unresolved),
            "required_transition": "recover_targeted_evidence_before_claim",
            "targets": unresolved,
        },
    }
    ledger = record_accountability(decision, store_dir=accountability_store_dir)
    result["ledger"] = ledger
    return result


__all__ = [
    "TRUTH_DELIVERY_POLICY",
    "RESPONSIBLE_COMPONENT",
    "RESPONSIBLE_ROLE",
    "plan_proactive_truth_delivery",
    "finalize_truth_delivery",
]
