"""Content-addressed causal decision lineage for PLW.

Lineage records only *explicit* parent/child links between representation,
transition, attestation, and recovery decisions.  It never infers causality from
semantic similarity, temporal proximity, or shared filenames.

The lineage is an audit/reference surface, not truth evidence.  It cannot change
claim settlement, transition legality, or proof-state commit.
"""
from __future__ import annotations

import datetime
import hashlib
import json
import os
import re
import tempfile
from pathlib import Path
from core.runtime_paths import state_path
from typing import Any, Dict, Iterable, List, Optional

SCHEMA_VERSION = "decision-lineage-v1"
POLICY_VERSION = "explicit_parent_causal_lineage_v1"
RESPONSIBLE_ROLE = "decision_lineage_custodian"
DEFAULT_LINEAGE_DIR = state_path("decision_lineage")
MAX_TRACE_NODES = 256


def _now() -> str:
    return datetime.datetime.now(datetime.timezone.utc).isoformat().replace("+00:00", "Z")


def _dir(store_dir: Optional[str | os.PathLike[str]] = None) -> Path:
    env = os.environ.get("PLW_DECISION_LINEAGE_DIR")
    return Path(store_dir or env or DEFAULT_LINEAGE_DIR).expanduser().resolve()


def _sha_text(value: str) -> str:
    return "sha256:" + hashlib.sha256(str(value or "").encode("utf-8")).hexdigest()


def _canonical(payload: Dict[str, Any]) -> bytes:
    return json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def _id(payload: Dict[str, Any]) -> str:
    return "sha256:" + hashlib.sha256(_canonical(payload)).hexdigest()


def _normalize_id(value: str) -> str:
    text = str(value or "").strip().lower()
    digest = text.split(":", 1)[1] if text.startswith("sha256:") else text
    if not re.fullmatch(r"[0-9a-f]{64}", digest):
        raise ValueError("lineage id must be SHA-256")
    return "sha256:" + digest


def _safe_metadata(metadata: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    """Keep only bounded scalar/list metadata; caller must not supply raw evidence."""
    src = metadata or {}
    out: Dict[str, Any] = {}
    for key, value in src.items():
        k = str(key)
        if value is None or isinstance(value, (bool, int, float)):
            out[k] = value
        elif isinstance(value, str):
            # Permit IDs/enums only; reject long free text defensively.
            out[k] = value if len(value) <= 160 else _sha_text(value)
        elif isinstance(value, list):
            vals = []
            for item in value[:32]:
                if item is None or isinstance(item, (bool, int, float)):
                    vals.append(item)
                elif isinstance(item, str):
                    vals.append(item if len(item) <= 160 else _sha_text(item))
            out[k] = vals
    return out


def record_lineage_node(
    *,
    node_type: str,
    reference_type: str,
    reference_id: str,
    parent_ids: Optional[Iterable[str]] = None,
    graph_content_signature: Optional[str] = None,
    truth_scope: Optional[str] = None,
    metadata: Optional[Dict[str, Any]] = None,
    store_dir: Optional[str | os.PathLike[str]] = None,
) -> Dict[str, Any]:
    parents: List[str] = []
    seen = set()
    for value in parent_ids or []:
        try:
            lid = _normalize_id(value)
        except ValueError:
            continue
        if lid not in seen:
            seen.add(lid); parents.append(lid)
    stable = {
        "schema_version": SCHEMA_VERSION,
        "policy": POLICY_VERSION,
        "node_type": str(node_type or "unknown"),
        "reference_type": str(reference_type or "unknown"),
        "reference_id": str(reference_id or ""),
        "parent_ids": sorted(parents),
        "graph_content_signature": str(graph_content_signature or "") or None,
        "truth_scope_fingerprint": _sha_text(str(truth_scope)) if truth_scope else None,
        "metadata": _safe_metadata(metadata),
        "authority": "causal_lineage_reference_only",
        "invariants": {
            "explicit_parent_links_only": True,
            "semantic_similarity_is_not_causality": True,
            "temporal_proximity_is_not_causality": True,
            "does_not_change_claim_settlement": True,
            "does_not_change_transition_legality": True,
            "does_not_commit_proof_state": True,
            "raw_query_not_stored": True,
            "raw_command_not_stored": True,
            "raw_output_not_stored": True,
            "raw_truth_scope_not_stored": True,
        },
    }
    lineage_id = _id(stable)
    record = {**stable, "lineage_id": lineage_id, "recorded_at": _now()}
    directory = _dir(store_dir)
    path = directory / f"lineage-{lineage_id.split(':',1)[1]}.json"
    try:
        directory.mkdir(parents=True, exist_ok=True, mode=0o700)
        if not path.exists():
            fd, tmp_name = tempfile.mkstemp(prefix=".lineage-", suffix=".json", dir=str(directory)); os.close(fd)
            tmp = Path(tmp_name)
            try:
                tmp.write_text(json.dumps(record, ensure_ascii=False, sort_keys=True), encoding="utf-8")
                try: os.chmod(tmp, 0o600)
                except OSError: pass
                os.replace(tmp, path)
            finally:
                if tmp.exists():
                    try: tmp.unlink()
                    except OSError: pass
        return {"available": True, "id": lineage_id, "lineage_id": lineage_id, "command": f"plw lineage {lineage_id}"}
    except Exception as exc:
        return {"available": False, "id": lineage_id, "lineage_id": lineage_id, "reason": f"lineage_write_failed:{type(exc).__name__}"}


def load_lineage_node(lineage_id: str, *, store_dir: Optional[str | os.PathLike[str]] = None) -> Dict[str, Any]:
    lid = _normalize_id(lineage_id)
    path = _dir(store_dir) / f"lineage-{lid.split(':',1)[1]}.json"
    if not path.is_file():
        raise FileNotFoundError(f"Decision lineage not found: {lid}")
    data = json.loads(path.read_text(encoding="utf-8"))
    stable = dict(data); stable.pop("lineage_id", None); stable.pop("recorded_at", None)
    if _id(stable) != lid:
        raise ValueError("Decision lineage hash mismatch")
    return data


def find_lineage_by_reference(
    reference_id: str, *, reference_type: Optional[str] = None,
    store_dir: Optional[str | os.PathLike[str]] = None, limit: int = 64,
) -> List[Dict[str, Any]]:
    directory = _dir(store_dir)
    if not directory.is_dir(): return []
    out: List[Dict[str, Any]] = []
    for path in sorted(directory.glob("lineage-*.json"), reverse=True):
        try: data = json.loads(path.read_text(encoding="utf-8"))
        except Exception: continue
        if str(data.get("reference_id") or "") != str(reference_id or ""): continue
        if reference_type and data.get("reference_type") != reference_type: continue
        out.append(data)
        if len(out) >= max(1, int(limit)): break
    return out


def trace_lineage(
    lineage_id: str, *, store_dir: Optional[str | os.PathLike[str]] = None,
    max_nodes: int = MAX_TRACE_NODES,
) -> Dict[str, Any]:
    root = _normalize_id(lineage_id)
    queue = [root]; seen = set(); nodes: List[Dict[str, Any]] = []; missing: List[str] = []
    while queue and len(nodes) < max(1, int(max_nodes)):
        lid = queue.pop(0)
        if lid in seen: continue
        seen.add(lid)
        try: node = load_lineage_node(lid, store_dir=store_dir)
        except Exception:
            missing.append(lid); continue
        nodes.append(node)
        for parent in node.get("parent_ids", []) or []:
            if parent not in seen: queue.append(parent)
    return {
        "schema_version": SCHEMA_VERSION,
        "policy": POLICY_VERSION,
        "root_lineage_id": root,
        "node_count": len(nodes),
        "nodes": nodes,
        "missing_parent_ids": sorted(set(missing)),
        "causal_semantics": "only explicit parent links are causal lineage; absent links remain unknown",
        "authority": "causal_lineage_reference_only",
        "invariants": {
            "semantic_similarity_is_not_causality": True,
            "lineage_is_not_truth_evidence": True,
            "lineage_is_not_transition_validity": True,
        },
    }


def build_lineage_index(*, store_dir: Optional[str | os.PathLike[str]] = None, limit: int = 4096) -> Dict[str, Any]:
    directory = _dir(store_dir)
    nodes: Dict[str, Dict[str, Any]] = {}
    children: Dict[str, List[str]] = {}
    references: Dict[tuple[str, str], List[str]] = {}
    if directory.is_dir():
        for path in sorted(directory.glob("lineage-*.json"))[-max(1, int(limit)):]:
            try:
                data = json.loads(path.read_text(encoding="utf-8"))
                lid = str(data.get("lineage_id") or "")
                if not lid:
                    continue
                stable = dict(data); stable.pop("lineage_id", None); stable.pop("recorded_at", None)
                if _id(stable) != lid:
                    continue
            except Exception:
                continue
            nodes[lid] = data
            references.setdefault((str(data.get("reference_type") or ""), str(data.get("reference_id") or "")), []).append(lid)
            for parent in data.get("parent_ids", []) or []:
                children.setdefault(str(parent), []).append(lid)
    return {
        "nodes": nodes,
        "children": children,
        "references": references,
        "node_count": len(nodes),
        "authority": "causal_lineage_reference_only",
    }


def descendants_from_index(root_lineage_id: str, index: Dict[str, Any], *, max_nodes: int = MAX_TRACE_NODES) -> List[Dict[str, Any]]:
    root = _normalize_id(root_lineage_id)
    nodes = index.get("nodes", {}) or {}
    children = index.get("children", {}) or {}
    queue = list(children.get(root, []) or [])
    seen = set(); out: List[Dict[str, Any]] = []
    while queue and len(out) < max(1, int(max_nodes)):
        lid = str(queue.pop(0))
        if lid in seen:
            continue
        seen.add(lid)
        node = nodes.get(lid)
        if node:
            out.append(node)
        queue.extend(children.get(lid, []) or [])
    return out


__all__ = [
    "SCHEMA_VERSION", "POLICY_VERSION", "DEFAULT_LINEAGE_DIR",
    "record_lineage_node", "load_lineage_node", "find_lineage_by_reference", "trace_lineage",
    "build_lineage_index", "descendants_from_index",
]
