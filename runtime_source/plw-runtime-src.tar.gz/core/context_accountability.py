"""Content-addressed accountability ledger for PLW context filtering.

The ledger records *decisions about representation*, never raw source text or raw
shell commands.  Its purpose is to make token savings auditable: when evidence
is omitted or compacted, a named component/policy owns that decision and carries
a recovery obligation.
"""

from __future__ import annotations

import datetime
import hashlib
import json
import os
import tempfile
from pathlib import Path
from core.runtime_paths import state_path
from typing import Any, Dict, List, Mapping, Optional

ACCOUNTABILITY_SCHEMA_VERSION = "context-accountability-v1"
DEFAULT_ACCOUNTABILITY_DIR = state_path("context_accountability")


def _utc_now() -> str:
    return datetime.datetime.now(datetime.timezone.utc).isoformat().replace("+00:00", "Z")


def _directory(store_dir: Optional[str | os.PathLike[str]] = None) -> Path:
    env = os.environ.get("PLW_ACCOUNTABILITY_DIR")
    return Path(store_dir or env or DEFAULT_ACCOUNTABILITY_DIR).resolve()


def _canonical_payload(payload: Mapping[str, Any]) -> bytes:
    return json.dumps(dict(payload), sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def accountability_id(payload: Mapping[str, Any]) -> str:
    return "sha256:" + hashlib.sha256(_canonical_payload(payload)).hexdigest()


def _validate_id(value: str) -> str:
    raw = str(value or "")
    if raw.startswith("sha256:"):
        raw = raw.split(":", 1)[1]
    if len(raw) != 64 or any(ch not in "0123456789abcdefABCDEF" for ch in raw):
        raise ValueError("Invalid accountability decision id")
    return raw.lower()


def record_accountability(
    decision: Dict[str, Any],
    *,
    store_dir: Optional[str | os.PathLike[str]] = None,
) -> Dict[str, Any]:
    """Persist one accountability decision atomically; failure never blocks analysis."""
    if not isinstance(decision, dict):
        raise TypeError("decision must be a dict")
    if "decision_id" in decision or "recorded_at" in decision:
        raise ValueError("decision contains reserved accountability metadata")

    canonical = dict(decision)
    canonical.setdefault("schema_version", ACCOUNTABILITY_SCHEMA_VERSION)
    canonical.setdefault("authority", "representation_decision_only")
    decision_id = accountability_id(canonical)
    digest = decision_id.split(":", 1)[1]
    directory = _directory(store_dir)
    target = directory / f"decision_{digest}.json"
    temp_path: Optional[str] = None

    try:
        directory.mkdir(parents=True, exist_ok=True, mode=0o700)
        payload = {
            **canonical,
            "decision_id": decision_id,
            "recorded_at": _utc_now(),
        }
        with tempfile.NamedTemporaryFile(
            mode="w",
            encoding="utf-8",
            dir=directory,
            prefix=".accountability_",
            suffix=".tmp",
            delete=False,
        ) as handle:
            temp_path = handle.name
            json.dump(payload, handle, ensure_ascii=False, sort_keys=True, indent=2)
            handle.flush()
            os.fsync(handle.fileno())
        try:
            os.chmod(temp_path, 0o600)
        except OSError:
            pass
        os.replace(temp_path, target)
        temp_path = None
        try:
            os.chmod(target, 0o600)
        except OSError:
            pass
        return {
            "available": True,
            "id": decision_id,
            "decision_id": decision_id,
            "store": str(directory),
            "command": f"plw accountability {decision_id}",
        }
    except Exception as exc:
        return {
            "available": False,
            "id": decision_id,
            "decision_id": decision_id,
            "reason": f"accountability_write_failed:{type(exc).__name__}",
        }
    finally:
        if temp_path and os.path.exists(temp_path):
            try:
                os.unlink(temp_path)
            except OSError:
                pass


def load_accountability(
    decision_id: str,
    *,
    store_dir: Optional[str | os.PathLike[str]] = None,
) -> Dict[str, Any]:
    digest = _validate_id(decision_id)
    path = _directory(store_dir) / f"decision_{digest}.json"
    if not path.is_file():
        raise FileNotFoundError(f"Accountability decision not found: sha256:{digest}")
    with open(path, "r", encoding="utf-8") as handle:
        payload = json.load(handle)
    if not isinstance(payload, dict):
        raise ValueError("Invalid accountability payload")
    canonical_id = f"sha256:{digest}"
    if payload.get("decision_id") != canonical_id:
        raise ValueError("Accountability decision id/path mismatch")
    if not isinstance(payload.get("recorded_at"), str) or not payload["recorded_at"]:
        raise ValueError("Invalid accountability recording timestamp")
    expected = dict(payload)
    expected.pop("decision_id", None)
    expected.pop("recorded_at", None)
    calculated = accountability_id(expected)
    if calculated != canonical_id:
        raise ValueError("Accountability ledger hash mismatch")
    return payload


def list_accountability_decisions(
    *,
    store_dir: Optional[str | os.PathLike[str]] = None,
    decision_type: Optional[str] = None,
    limit: int = 64,
    newest_first: bool = True,
) -> List[Dict[str, Any]]:
    """List validated representation decisions without exposing raw evidence.

    Invalid/corrupt cells are skipped.  The bounded list is intentionally small
    because this ledger is an audit surface, not a database/query engine.
    """
    directory = _directory(store_dir)
    try:
        paths = [p for p in directory.glob("decision_*.json") if p.is_file()]
    except OSError:
        return []
    try:
        paths.sort(key=lambda p: p.stat().st_mtime_ns, reverse=bool(newest_first))
    except OSError:
        paths.sort(key=lambda p: p.name, reverse=bool(newest_first))

    results: List[Dict[str, Any]] = []
    max_items = max(0, int(limit))
    for path in paths:
        if max_items and len(results) >= max_items:
            break
        digest = path.stem.replace("decision_", "", 1)
        try:
            payload = load_accountability(f"sha256:{digest}", store_dir=directory)
        except Exception:
            continue
        if decision_type is not None and payload.get("decision_type") != decision_type:
            continue
        results.append(payload)
    return results


__all__ = [
    "ACCOUNTABILITY_SCHEMA_VERSION",
    "DEFAULT_ACCOUNTABILITY_DIR",
    "accountability_id",
    "record_accountability",
    "load_accountability",
    "list_accountability_decisions",
]
