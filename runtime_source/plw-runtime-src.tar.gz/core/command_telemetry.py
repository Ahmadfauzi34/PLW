"""Local behavioral telemetry for PLW command-output compaction.

Telemetry is deliberately *not* a source of truth and never changes compaction
policy automatically.  It records enough privacy-preserving signals to answer:

- Are compacted observations frequently recovered?
- Is the same command fingerprint being observed repeatedly?
- Are search commands repeatedly re-issued?
- How often does conservative output remain over budget?
- Are token savings material end-to-end?

Raw commands and raw output are never written to telemetry.  Command identity is
a SHA-256 fingerprint over whitespace-normalized command text; only the command
head (e.g. ``rg`` or ``pytest``) is retained for coarse aggregation.

Each event is an immutable JSON cell written atomically into the same runtime
scope as command-output recovery.  This avoids a shared append file and therefore
keeps concurrent writers independent without requiring a platform-specific lock.
"""

from __future__ import annotations

import datetime
import hashlib
import json
import os
import tempfile
import uuid
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

TELEMETRY_SCHEMA_VERSION = "command-output-telemetry-v1"
DEFAULT_MAX_EVENTS = 2048
MIN_OBSERVATIONS_FOR_PRESSURE = 8


def _utc_now() -> str:
    return datetime.datetime.now(datetime.timezone.utc).isoformat().replace("+00:00", "Z")


def normalize_command_for_fingerprint(command: str) -> str:
    """Normalize insignificant whitespace without attempting shell parsing."""
    return " ".join(str(command or "").strip().split())


def command_fingerprint(command: str) -> str:
    normalized = normalize_command_for_fingerprint(command)
    return "sha256:" + hashlib.sha256(normalized.encode("utf-8")).hexdigest()


def _telemetry_directory(store_directory: Path) -> Path:
    return store_directory / "telemetry"


def _event_path(directory: Path, event_type: str) -> Path:
    # Timestamp prefix keeps lexical order close to event order. UUID removes
    # collisions between concurrent processes.
    stamp = datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    return directory / f"{stamp}-{event_type}-{uuid.uuid4().hex}.json"


def _atomic_json_write(path: Path, payload: Dict[str, Any]) -> None:
    directory = path.parent
    directory.mkdir(parents=True, exist_ok=True, mode=0o700)
    try:
        os.chmod(directory, 0o700)
    except OSError:
        pass

    fd, tmp_name = tempfile.mkstemp(prefix=".telemetry-", suffix=".tmp", dir=str(directory))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
            handle.flush()
            os.fsync(handle.fileno())
        try:
            os.chmod(tmp_name, 0o600)
        except OSError:
            pass
        os.replace(tmp_name, path)
        try:
            os.chmod(path, 0o600)
        except OSError:
            pass
    finally:
        if os.path.exists(tmp_name):
            try:
                os.unlink(tmp_name)
            except OSError:
                pass


def _gc_events(directory: Path, max_events: int = DEFAULT_MAX_EVENTS) -> Dict[str, int]:
    try:
        files = sorted(
            (p for p in directory.glob("*.json") if p.is_file()),
            key=lambda p: p.name,
        )
    except OSError:
        return {"events_removed": 0}

    remove_count = max(0, len(files) - max(1, int(max_events)))
    removed = 0
    for path in files[:remove_count]:
        try:
            path.unlink()
            removed += 1
        except OSError:
            pass
    return {"events_removed": removed}


def record_observation_event(
    *,
    store_directory: Path,
    command: str,
    command_head: str,
    kind: str,
    output_id: str,
    raw_tokens: int,
    compacted_tokens: int,
    tokens_saved: int,
    within_budget: bool,
    semantic_compaction_applied: bool,
    recovery_available: bool,
) -> Dict[str, Any]:
    directory = _telemetry_directory(store_directory)
    payload: Dict[str, Any] = {
        "schema_version": TELEMETRY_SCHEMA_VERSION,
        "event_type": "observation",
        "observed_at": _utc_now(),
        "command_fingerprint": command_fingerprint(command),
        "command_head": str(command_head or ""),
        "kind": str(kind or "arbitrary"),
        "output_id": str(output_id or ""),
        "raw_tokens": max(0, int(raw_tokens)),
        "compacted_tokens": max(0, int(compacted_tokens)),
        "tokens_saved": max(0, int(tokens_saved)),
        "within_budget": bool(within_budget),
        "semantic_compaction_applied": bool(semantic_compaction_applied),
        "recovery_available": bool(recovery_available),
    }
    path = _event_path(directory, "observation")
    try:
        _atomic_json_write(path, payload)
        gc = _gc_events(directory)
        return {
            "recorded": True,
            "event_type": "observation",
            "event_file": path.name,
            "command_fingerprint": payload["command_fingerprint"],
            "gc": gc,
        }
    except Exception as exc:
        return {
            "recorded": False,
            "event_type": "observation",
            "command_fingerprint": payload["command_fingerprint"],
            "error": f"telemetry_write_failed:{type(exc).__name__}",
        }


def record_recovery_event(*, store_directory: Path, output_id: str) -> Dict[str, Any]:
    directory = _telemetry_directory(store_directory)
    payload: Dict[str, Any] = {
        "schema_version": TELEMETRY_SCHEMA_VERSION,
        "event_type": "recovery",
        "observed_at": _utc_now(),
        "output_id": str(output_id or ""),
    }
    path = _event_path(directory, "recovery")
    try:
        _atomic_json_write(path, payload)
        gc = _gc_events(directory)
        return {
            "recorded": True,
            "event_type": "recovery",
            "event_file": path.name,
            "gc": gc,
        }
    except Exception as exc:
        return {
            "recorded": False,
            "event_type": "recovery",
            "error": f"telemetry_write_failed:{type(exc).__name__}",
        }


def _load_events(directory: Path) -> tuple[List[Dict[str, Any]], int]:
    telemetry_dir = _telemetry_directory(directory)
    events: List[Dict[str, Any]] = []
    invalid = 0
    try:
        paths = sorted(p for p in telemetry_dir.glob("*.json") if p.is_file())
    except OSError:
        return [], 0

    for path in paths:
        try:
            with open(path, "r", encoding="utf-8") as handle:
                payload = json.load(handle)
            if not isinstance(payload, dict) or payload.get("schema_version") != TELEMETRY_SCHEMA_VERSION:
                invalid += 1
                continue
            if payload.get("event_type") not in {"observation", "recovery"}:
                invalid += 1
                continue
            events.append(payload)
        except Exception:
            invalid += 1
    return events, invalid



def _summarize_output_behavior_from_events(
    events: List[Dict[str, Any]],
    invalid: int,
    *,
    output_id: str,
    command_fingerprint_value: Optional[str] = None,
) -> Dict[str, Any]:
    observations = [e for e in events if e.get("event_type") == "observation"]
    recoveries = [e for e in events if e.get("event_type") == "recovery"]
    output = str(output_id or "")
    matching_output = [e for e in observations if str(e.get("output_id") or "") == output]
    latest = matching_output[-1] if matching_output else {}
    fp = str(command_fingerprint_value or latest.get("command_fingerprint") or "")
    same_command = [e for e in observations if fp and str(e.get("command_fingerprint") or "") == fp]
    output_recoveries = [e for e in recoveries if str(e.get("output_id") or "") == output]
    same_command_raw_tokens_total = sum(max(0, int(e.get("raw_tokens") or 0)) for e in same_command)
    same_command_compacted_tokens_total = sum(max(0, int(e.get("compacted_tokens") or 0)) for e in same_command)
    same_command_tokens_saved_total = sum(max(0, int(e.get("tokens_saved") or 0)) for e in same_command)
    return {
        "available": bool(latest),
        "authority": "behavioral_policy_cost_observation_only",
        "output_id": output if output else None,
        "command_fingerprint": fp or None,
        "kind": str(latest.get("kind") or "arbitrary") if latest else None,
        "raw_tokens": max(0, int(latest.get("raw_tokens") or 0)) if latest else None,
        "compacted_tokens": max(0, int(latest.get("compacted_tokens") or 0)) if latest else None,
        "tokens_saved": max(0, int(latest.get("tokens_saved") or 0)) if latest else None,
        "within_budget": latest.get("within_budget") if latest else None,
        "semantic_compaction_applied": latest.get("semantic_compaction_applied") if latest else None,
        "same_command_observations": len(same_command),
        "repeat_observations": max(0, len(same_command) - 1),
        "same_command_raw_tokens_total": same_command_raw_tokens_total,
        "same_command_compacted_tokens_total": same_command_compacted_tokens_total,
        "same_command_tokens_saved_total": same_command_tokens_saved_total,
        "output_recoveries": len(output_recoveries),
        "invalid_telemetry_cells": int(invalid),
        "invariants": {
            "raw_command_not_exposed": True,
            "raw_output_not_exposed": True,
            "not_truth_evidence": True,
            "snapshot_at_observation_time": True,
        },
    }


def summarize_output_behavior(
    store_directory: Path,
    *,
    output_id: str,
    command_fingerprint_value: Optional[str] = None,
) -> Dict[str, Any]:
    """Return privacy-bounded cost/recovery signals for one exact output."""
    events, invalid = _load_events(store_directory)
    return _summarize_output_behavior_from_events(
        events, invalid, output_id=output_id,
        command_fingerprint_value=command_fingerprint_value,
    )


def summarize_output_behaviors(
    store_directory: Path,
    requests: Iterable[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    """Batch behavior summaries from one immutable telemetry snapshot."""
    events, invalid = _load_events(store_directory)
    return [
        _summarize_output_behavior_from_events(
            events,
            invalid,
            output_id=str(req.get("output_id") or ""),
            command_fingerprint_value=str(req.get("command_fingerprint") or "") or None,
        )
        for req in requests or []
    ]

def summarize_telemetry(store_directory: Path) -> Dict[str, Any]:
    events, invalid = _load_events(store_directory)
    observations = [e for e in events if e.get("event_type") == "observation"]
    recoveries = [e for e in events if e.get("event_type") == "recovery"]

    by_command: Dict[str, List[Dict[str, Any]]] = {}
    by_output: Dict[str, List[Dict[str, Any]]] = {}
    by_kind: Dict[str, Dict[str, int]] = {}

    total_raw_tokens = 0
    total_compacted_tokens = 0
    total_saved = 0
    over_budget = 0

    for event in observations:
        fingerprint = str(event.get("command_fingerprint") or "")
        by_command.setdefault(fingerprint, []).append(event)
        output_id = str(event.get("output_id") or "")
        if output_id:
            by_output.setdefault(output_id, []).append(event)
        kind = str(event.get("kind") or "arbitrary")
        stats = by_kind.setdefault(
            kind,
            {"observations": 0, "recoveries": 0, "repeat_observations": 0, "over_budget": 0, "tokens_saved": 0},
        )
        stats["observations"] += 1
        raw_tokens = max(0, int(event.get("raw_tokens") or 0))
        compacted_tokens = max(0, int(event.get("compacted_tokens") or 0))
        saved = max(0, int(event.get("tokens_saved") or 0))
        total_raw_tokens += raw_tokens
        total_compacted_tokens += compacted_tokens
        total_saved += saved
        stats["tokens_saved"] += saved
        if event.get("within_budget") is False:
            over_budget += 1
            stats["over_budget"] += 1

    repeated_command_observations = 0
    repeated_search_observations = 0
    repeated_output_observations = 0
    for fingerprint, grouped in by_command.items():
        repeats = max(0, len(grouped) - 1)
        repeated_command_observations += repeats
        if grouped:
            kind = str(grouped[0].get("kind") or "arbitrary")
            by_kind.setdefault(kind, {"observations": 0, "recoveries": 0, "repeat_observations": 0, "over_budget": 0, "tokens_saved": 0})[
                "repeat_observations"
            ] += repeats
            if kind == "search":
                repeated_search_observations += repeats

    for output_id, grouped in by_output.items():
        repeated_output_observations += max(0, len(grouped) - 1)

    recovered_output_ids: Dict[str, int] = {}
    for event in recoveries:
        output_id = str(event.get("output_id") or "")
        if not output_id:
            continue
        recovered_output_ids[output_id] = recovered_output_ids.get(output_id, 0) + 1
        source_events = by_output.get(output_id, [])
        if source_events:
            kind = str(source_events[-1].get("kind") or "arbitrary")
            stats = by_kind.setdefault(
                kind,
                {"observations": 0, "recoveries": 0, "repeat_observations": 0, "over_budget": 0, "tokens_saved": 0},
            )
            stats["recoveries"] += 1

    observation_count = len(observations)
    recovery_count = len(recoveries)
    recovery_rate = recovery_count / max(1, observation_count)
    repeat_rate = repeated_command_observations / max(1, observation_count)
    search_observations = by_kind.get("search", {}).get("observations", 0)
    search_repeat_rate = repeated_search_observations / max(1, int(search_observations or 0))
    over_budget_rate = over_budget / max(1, observation_count)
    savings_rate = total_saved / max(1, total_raw_tokens)

    if observation_count < MIN_OBSERVATIONS_FOR_PRESSURE:
        pressure = "insufficient_data"
        reasons = [f"need_at_least_{MIN_OBSERVATIONS_FOR_PRESSURE}_observations"]
    else:
        reasons: List[str] = []
        if recovery_rate >= 0.25:
            reasons.append("high_recovery_rate")
        if search_observations >= 4 and search_repeat_rate >= 0.35:
            reasons.append("high_repeated_search_rate")
        if repeat_rate >= 0.40:
            reasons.append("high_repeated_command_rate")
        pressure = "review_compaction_policy" if reasons else "no_behavioral_pressure_detected"

    kind_summary: Dict[str, Any] = {}
    for kind, stats in sorted(by_kind.items()):
        obs = int(stats.get("observations", 0))
        kind_summary[kind] = {
            **stats,
            "recovery_rate": round(int(stats.get("recoveries", 0)) / max(1, obs), 4),
            "repeat_rate": round(int(stats.get("repeat_observations", 0)) / max(1, obs), 4),
            "over_budget_rate": round(int(stats.get("over_budget", 0)) / max(1, obs), 4),
        }

    return {
        "schema_version": TELEMETRY_SCHEMA_VERSION,
        "authority": {
            "role": "behavioral_observation_only",
            "auto_policy_mutation": False,
            "raw_commands_stored": False,
            "raw_output_stored_in_telemetry": False,
            "scope": "global_runtime_store",
            "cross_task_ambiguity": True,
            "interpretation": "repeat/recovery signals are review cues, not proof of bad pruning",
        },
        "events": {
            "valid": len(events),
            "invalid": invalid,
            "observations": observation_count,
            "recoveries": recovery_count,
        },
        "efficiency": {
            "raw_estimated_tokens": total_raw_tokens,
            "compacted_estimated_tokens": total_compacted_tokens,
            "estimated_tokens_saved": total_saved,
            "estimated_savings_rate": round(savings_rate, 4),
            "over_budget_observations": over_budget,
            "over_budget_rate": round(over_budget_rate, 4),
        },
        "behavior": {
            "unique_command_fingerprints": len(by_command),
            "repeated_command_observations": repeated_command_observations,
            "repeated_command_rate": round(repeat_rate, 4),
            "repeated_output_observations": repeated_output_observations,
            "search_observations": int(search_observations or 0),
            "repeated_search_observations": repeated_search_observations,
            "repeated_search_rate": round(search_repeat_rate, 4),
            "unique_recovered_outputs": len(recovered_output_ids),
            "recovery_rate": round(recovery_rate, 4),
        },
        "by_kind": kind_summary,
        "pressure": {
            "status": pressure,
            "reasons": reasons,
            "minimum_observations": MIN_OBSERVATIONS_FOR_PRESSURE,
            "automatic_action": "none",
        },
    }


__all__ = [
    "TELEMETRY_SCHEMA_VERSION",
    "DEFAULT_MAX_EVENTS",
    "MIN_OBSERVATIONS_FOR_PRESSURE",
    "normalize_command_for_fingerprint",
    "command_fingerprint",
    "record_observation_event",
    "record_recovery_event",
    "summarize_output_behavior",
    "summarize_output_behaviors",
    "summarize_telemetry",
]
