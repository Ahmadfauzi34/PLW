"""F116 explicit authorization receipt bound to one verified F114 proposal.

The receipt proves a caller granted permission for exactly one audited proposal.
It does not execute the lifecycle transition or any other side effect.
"""
from __future__ import annotations

from typing import Any, Dict, Mapping

from core.accountability_provenance import (
    AUTHORIZATION_ISSUER,
    PROPOSAL_ISSUER,
    record_provenanced,
    verify_record,
)
from core.capability_action_authority import (
    AUTHORITY_CLASS,
    verify_authorization_assertion,
)
from core.capability_action_proposal import (
    ACTION_KIND,
    ACCOUNTABILITY_RECORD_KEYS as PROPOSAL_RECORD_KEYS,
    DECISION_TYPE as PROPOSAL_DECISION_TYPE,
    SCHEMA_VERSION as PROPOSAL_SCHEMA,
    POLICY_VERSION as PROPOSAL_POLICY,
    build_action_proposal,
)
from core.capability_contracts import (
    bounded_text,
    exact_keys,
    is_sha256_id,
    no_effect_authorizations,
    normalize_mapping,
    safe_canonical_digest,
)
from core.context_accountability import load_accountability

SCHEMA_VERSION = "capability-workflow-action-authorization-v1"
POLICY_VERSION = "single_proposal_explicit_authorization_v1"
DECISION_TYPE = "capability_workflow_action_authorization"
_REQUIRED_EFFECTS = {
    "transition_execution", "runtime_execution", "external_patch", "stable_promotion", "truth_commit"
}
_ALLOWED_REQUEST_KEYS = {
    "schema_version", "policy", "proposal_accountability_id", "proposal_request_digest",
    "capability_id", "caller_authorizes", "action_kind", "target_state", "expected_state",
    "envelope_evidence_digest", "authorization_scope", "authority", "authorizations",
    "authority_assertion",
}
ACCOUNTABILITY_RECORD_KEYS = frozenset({
    "schema_version", "decision_type", "policy", "authorization_granted",
    "decision", "failed_conditions", "request_digest",
    "proposal_accountability_id", "proposal_request_digest", "capability_id",
    "workflow_state", "workflow_evidence_digest", "authorized_action",
    "authority_assertion_digest", "authorization_principal", "authorization_nonce",
    "authorization_expires_at_epoch", "authorization_grant", "authority",
    "authorizations", "effects", "invariants", "provenance", "decision_id",
    "recorded_at",
})


def build_authorization_request(
    proposal_accountability_id: str,
    proposal_request: Mapping[str, Any] | None,
    authority_assertion: Mapping[str, Any] | None = None,
) -> Dict[str, Any]:
    """Build a request around a separately issued authority assertion."""
    proposal_req, _ = normalize_mapping(proposal_request)
    assertion, assertion_valid = normalize_mapping(authority_assertion)
    return {
        "schema_version": SCHEMA_VERSION,
        "policy": POLICY_VERSION,
        "proposal_accountability_id": str(proposal_accountability_id or ""),
        "proposal_request_digest": safe_canonical_digest(proposal_req) or "",
        "capability_id": str(proposal_req.get("capability_id") or ""),
        "caller_authorizes": assertion_valid and bool(assertion),
        "action_kind": str(proposal_req.get("action_kind") or ""),
        "target_state": str(proposal_req.get("target_state") or ""),
        "expected_state": str(proposal_req.get("expected_state") or ""),
        "envelope_evidence_digest": str(proposal_req.get("envelope_evidence_digest") or ""),
        "authorization_scope": "single_proposal",
        "authority_assertion": assertion,
        "authority": "action_authorization_request_only",
        "authorizations": {key: False for key in sorted(_REQUIRED_EFFECTS)},
    }


def build_action_authorization(
    request: Mapping[str, Any] | None,
    proposal_request: Mapping[str, Any] | None,
    envelope: Mapping[str, Any] | None,
    *,
    store_dir: str | None = None,
) -> Dict[str, Any]:
    """Return a bounded authorization receipt decision without executing the action."""
    req, request_mapping_valid = normalize_mapping(request)
    proposal_req, proposal_mapping_valid = normalize_mapping(proposal_request)
    env, envelope_mapping_valid = normalize_mapping(envelope)
    failures: list[str] = []
    if not request_mapping_valid: failures.append("request_mapping")
    if not proposal_mapping_valid: failures.append("proposal_request_mapping")
    if not envelope_mapping_valid: failures.append("workflow_envelope_mapping")
    unknown = sorted(set(req) - _ALLOWED_REQUEST_KEYS)
    if unknown: failures.append("unknown_request_fields:" + ",".join(unknown))
    if req.get("schema_version") != SCHEMA_VERSION: failures.append("schema_version")
    if req.get("policy") != POLICY_VERSION: failures.append("policy")
    if req.get("caller_authorizes") is not True: failures.append("caller_authorizes_is_true")
    if req.get("authorization_scope") != "single_proposal": failures.append("authorization_scope")
    if req.get("authority") != "action_authorization_request_only" or not no_effect_authorizations(req.get("authorizations")):
        failures.append("request_has_no_execution_effect")
    proposal_digest = safe_canonical_digest(proposal_req)
    request_digest = safe_canonical_digest(req)
    if proposal_digest is None or req.get("proposal_request_digest") != proposal_digest:
        failures.append("proposal_request_digest")
    if request_digest is None:
        failures.append("request_bounded_canonical_json")

    proposal_id = str(req.get("proposal_accountability_id") or "")
    stored: Dict[str, Any] = {}
    if not proposal_id:
        failures.append("proposal_accountability_id")
    elif not is_sha256_id(proposal_id):
        failures.append("proposal_accountability_id")
    else:
        try:
            stored = load_accountability(proposal_id, store_dir=store_dir)
        except (ValueError, FileNotFoundError, OSError, TypeError):
            failures.append("proposal_record")

    recomputed = build_action_proposal(proposal_req, env, store_dir=store_dir)
    if recomputed.get("proposal_ready") is not True:
        failures.append("proposal_revalidation_ready")
    if stored:
        required = (
            exact_keys(stored, PROPOSAL_RECORD_KEYS),
            stored.get("schema_version") == PROPOSAL_SCHEMA,
            stored.get("policy") == PROPOSAL_POLICY,
            stored.get("decision_type") == PROPOSAL_DECISION_TYPE,
            stored.get("proposal_ready") is True,
            stored.get("decision") == "ACTION_PROPOSAL_READY",
            stored.get("authority") == "workflow_action_proposal_only",
            no_effect_authorizations(stored.get("authorizations")),
            verify_record(stored, PROPOSAL_ISSUER, store_dir=store_dir),
        )
        if not all(required): failures.append("proposal_record_contract")
        fields = (
            "request_digest", "chain_digest", "delivery_accountability_id", "relevance_accountability_id",
            "capability_id", "workflow_state", "workflow_evidence_digest", "proposed_action",
        )
        if any(stored.get(key) != recomputed.get(key) for key in fields): failures.append("proposal_revalidation_binding")
        requirement = stored.get("authorization_requirement") if isinstance(stored.get("authorization_requirement"), dict) else {}
        if requirement.get("required") is not True or requirement.get("granted") is not False or requirement.get("authority_class") != AUTHORITY_CLASS:
            failures.append("proposal_requires_separate_authorization")

    bindings = (
        (req.get("capability_id"), proposal_req.get("capability_id"), recomputed.get("capability_id"), "capability_binding"),
        (req.get("action_kind"), proposal_req.get("action_kind"), recomputed.get("proposed_action", {}).get("kind"), "action_kind_binding"),
        (req.get("target_state"), proposal_req.get("target_state"), recomputed.get("proposed_action", {}).get("target_state"), "target_state_binding"),
        (req.get("expected_state"), proposal_req.get("expected_state"), recomputed.get("workflow_state"), "state_binding"),
        (req.get("envelope_evidence_digest"), proposal_req.get("envelope_evidence_digest"), recomputed.get("workflow_evidence_digest"), "evidence_digest_binding"),
    )
    for requested, proposed, verified, label in bindings:
        if requested != proposed or requested != verified: failures.append(label)
    if req.get("action_kind") != ACTION_KIND: failures.append("supported_action_kind")
    for key in ("capability_id", "target_state", "expected_state"):
        if not bounded_text(req.get(key), maximum=128): failures.append(key)
    if not is_sha256_id(req.get("envelope_evidence_digest")): failures.append("envelope_evidence_digest")

    assertion = req.get("authority_assertion")
    assertion_valid, assertion_failures = verify_authorization_assertion(
        assertion, proposal_id, proposal_req, store_dir=store_dir
    )
    if not assertion_valid:
        failures.extend(assertion_failures)
    assertion_map = assertion if isinstance(assertion, dict) else {}
    assertion_digest = safe_canonical_digest(assertion)
    if assertion_digest is None:
        failures.append("authority_assertion_digest")

    granted = not failures
    return {
        "schema_version": SCHEMA_VERSION,
        "decision_type": DECISION_TYPE,
        "policy": POLICY_VERSION,
        "authorization_granted": granted,
        "decision": "ACTION_AUTHORIZATION_GRANTED" if granted else "ACTION_AUTHORIZATION_REJECTED",
        "failed_conditions": failures,
        "request_digest": request_digest or "",
        "proposal_accountability_id": proposal_id,
        "proposal_request_digest": proposal_digest or "",
        "capability_id": str(req.get("capability_id") or ""),
        "workflow_state": str(req.get("expected_state") or ""),
        "workflow_evidence_digest": str(req.get("envelope_evidence_digest") or ""),
        "authorized_action": {"kind": str(req.get("action_kind") or ""), "target_state": str(req.get("target_state") or "")},
        "authority_assertion_digest": assertion_digest or "",
        "authorization_principal": str(assertion_map.get("principal_id") or ""),
        "authorization_nonce": str(assertion_map.get("nonce") or ""),
        "authorization_expires_at_epoch": assertion_map.get("expires_at_epoch"),
        "authorization_grant": {
            "authority_class": AUTHORITY_CLASS,
            "scope": "single_proposal",
            "granted": granted,
            "principal_id": str(assertion_map.get("principal_id") or ""),
            "assertion_digest": assertion_digest or "",
        },
        "authority": "workflow_action_authorization_receipt_only",
        "authorizations": {key: False for key in sorted(_REQUIRED_EFFECTS)},
        "effects": {
            "transition_executed": False,
            "runtime_executed": False,
            "external_patch_applied": False,
            "stable_promoted": False,
            "truth_committed": False,
        },
        "invariants": {
            "explicit_literal_authorization_required": True,
            "signed_principal_authority_required": True,
            "short_lived_nonce_bound_assertion_required": True,
            "single_proposal_binding": True,
            "proposal_revalidation_required": True,
            "authorization_is_not_execution": True,
        },
    }


def record_action_authorization(
    request: Mapping[str, Any] | None,
    proposal_request: Mapping[str, Any] | None,
    envelope: Mapping[str, Any] | None,
    *,
    store_dir: str | None = None,
) -> Dict[str, Any]:
    payload = build_action_authorization(request, proposal_request, envelope, store_dir=store_dir)
    receipt = record_provenanced(payload, AUTHORIZATION_ISSUER, store_dir=store_dir)
    return {
        **receipt,
        "decision_type": DECISION_TYPE,
        "authorization_granted": payload["authorization_granted"],
        "authority": "workflow_action_authorization_reference_only",
    }


__all__ = [
    "SCHEMA_VERSION", "POLICY_VERSION", "DECISION_TYPE", "AUTHORITY_CLASS", "ACCOUNTABILITY_RECORD_KEYS",
    "build_authorization_request", "build_action_authorization", "record_action_authorization",
]
