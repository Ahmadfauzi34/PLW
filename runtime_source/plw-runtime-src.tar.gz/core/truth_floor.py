"""Truth Floor — minimum witness gate for bounded PLW context.

This layer does not create facts.  It validates whether a bounded projection has
actually delivered the minimum evidence required by currently-due truth debt.
Current source remains authoritative for current-code claims.  Domain memory is
continuity/historical evidence: it may become due, but it never overrides current
source and stale/orphaned memories only create verification obligations.
"""
from __future__ import annotations

import hashlib
import re
from typing import Any, Dict, Iterable, List, Optional, Set

from core.context_accountability import list_accountability_decisions, record_accountability

TRUTH_FLOOR_POLICY = "truth_floor_v1_source_authority_memory_continuity"
RESPONSIBLE_COMPONENT = "core.truth_floor.evaluate_truth_floor"
RESPONSIBLE_ROLE = "truth_floor_custodian"
MAX_PRIOR_DECISIONS = 128
_HISTORY_TERMS = {
    "history", "historical", "previous", "previously", "before", "decision", "decisions",
    "reason", "rationale", "memory", "remember", "prior", "earlier", "past",
    "sebelum", "sebelumnya", "dulu", "riwayat", "keputusan", "alasan", "memori",
}
_TOKEN_RE = re.compile(r"[A-Za-z0-9_]+")


def _history_intent(query: str) -> bool:
    terms = {token.lower() for token in _TOKEN_RE.findall(query or "")}
    return bool(terms & _HISTORY_TERMS)


def _memory_projection_signature(memory_context: Dict[str, Any]) -> str:
    retrieval = memory_context.get("retrieval", {}) if isinstance(memory_context, dict) else {}
    projection = retrieval.get("projection", {}) if isinstance(retrieval, dict) else {}
    for key in ("snapshot_signature", "store_sha256", "canonical_store_sha256"):
        value = projection.get(key) if isinstance(projection, dict) else None
        if value:
            return str(value)
    return ""


def _prior_due_memory_ids(
    memory_context: Dict[str, Any],
    *,
    graph_signature: str,
    truth_scope: str,
    accountability_store_dir: Optional[str] = None,
) -> Set[str]:
    """Reactivate memory debt only when the same record is retrieved again.

    This is deliberately stronger than embedding similarity: prior omission alone
    is not enough; the current deterministic memory projection must surface the
    same memory ID again in the same task/snapshot scope.
    """
    current_ids = {
        str(item.get("id"))
        for item in (memory_context.get("memories", []) if isinstance(memory_context, dict) else [])
        if item.get("id")
    }
    if not current_ids or truth_scope == "unscoped":
        return set()

    decisions = list_accountability_decisions(
        store_dir=accountability_store_dir,
        decision_type="budgeted_context_projection",
        limit=MAX_PRIOR_DECISIONS,
        newest_first=True,
    )
    debt_ids: Set[str] = set()
    for decision in decisions:
        input_state = decision.get("input_state", {}) if isinstance(decision, dict) else {}
        if str(input_state.get("graph_content_signature") or "") != graph_signature:
            continue
        if str(input_state.get("truth_scope") or "unscoped") != truth_scope:
            continue
        debt = decision.get("evidence_debt", {}) if isinstance(decision, dict) else {}
        for field in ("omitted_memory_ids", "truncated_memory_ids"):
            for memory_id in debt.get(field, []) or []:
                mid = str(memory_id)
                if mid in current_ids:
                    debt_ids.add(mid)
    return debt_ids


def plan_truth_floor(
    *,
    query: str,
    graph_signature: str,
    truth_scope: Optional[str],
    memory_context: Optional[Dict[str, Any]],
    accountability_store_dir: Optional[str] = None,
) -> Dict[str, Any]:
    memory_context = memory_context or {}
    scope = str(truth_scope or "unscoped")
    history_intent = _history_intent(query)
    retrieved = list(memory_context.get("memories", []) or [])
    reactivated = _prior_due_memory_ids(
        memory_context,
        graph_signature=graph_signature,
        truth_scope=scope,
        accountability_store_dir=accountability_store_dir,
    )

    target_primary = {
        str(item.get("id"))
        for item in retrieved
        if item.get("id")
        and bool(
            (item.get("retrieval_match", {}) or {})
            .get("rank_vector", {})
            .get("target_primary", False)
        )
    }

    # Historical/decision queries have a stronger continuity obligation: a
    # target-primary memory witness is due even without prior omission debt.
    required_memory_ids = set(reactivated)
    if history_intent:
        required_memory_ids.update(target_primary)
        if not required_memory_ids and retrieved:
            # deterministic top-ranked memory witness; max one extra floor item
            required_memory_ids.add(str(retrieved[0].get("id")))

    excluded = list((memory_context.get("retrieval", {}) or {}).get("freshness_exclusions", []) or [])
    relevant_stale = [
        item for item in excluded
        if str(item.get("freshness")) in {"stale", "orphaned", "resolved", "superseded"}
        and (item.get("target_primary") or item.get("file"))
    ]

    return {
        "schema_version": "truth-floor-plan-v1",
        "policy": TRUTH_FLOOR_POLICY,
        "responsible_role": RESPONSIBLE_ROLE,
        "truth_scope": scope,
        "graph_content_signature": graph_signature,
        "memory_projection_signature": _memory_projection_signature(memory_context),
        "history_intent": history_intent,
        "required_memory_ids": sorted(required_memory_ids),
        "memory_debt_reactivated_ids": sorted(reactivated),
        "target_primary_memory_ids": sorted(target_primary),
        "freshness_exclusions_relevant": relevant_stale,
        "invariants": {
            "current_source_is_authority": True,
            "memory_never_overrides_current_source": True,
            "memory_omission_is_not_irrelevance": True,
            "stale_memory_creates_verification_duty_not_current_fact": True,
            "embedding_similarity_alone_cannot_make_memory_due": True,
        },
    }


def evaluate_truth_floor(
    *,
    plan: Dict[str, Any],
    pack: Dict[str, Any],
    truth_delivery: Dict[str, Any],
    detail: str,
    accountability_store_dir: Optional[str] = None,
) -> Dict[str, Any]:
    allocation = (pack.get("budget", {}) or {}).get("allocation", {}) or {}
    source_witnesses = {
        str(item.get("file")): item
        for item in allocation.get("source_witnesses", []) or []
        if item.get("file")
    }
    due_source = list(dict.fromkeys(
        [str(path) for path in truth_delivery.get("due_targets", []) or []]
        + [str(path) for path in pack.get("selection", {}).get("resolved_targets", []) or []]
    ))
    selected_paths = set(pack.get("selection", {}).get("selected_paths", []) or [])

    source_unresolved: List[Dict[str, Any]] = []
    source_delivered: List[str] = []
    for path in due_source:
        witness = source_witnesses.get(path, {})
        selected = path in selected_paths
        exact_lines = int(witness.get("included_source_lines", 0))
        if selected and (detail != "source" or exact_lines >= 1):
            source_delivered.append(path)
        else:
            source_unresolved.append({
                "file": path,
                "selected": selected,
                "included_source_lines": exact_lines,
                "reason": "missing_exact_source_witness" if selected else "due_source_not_selected",
            })

    included_memories = list((pack.get("memory_context", {}) or {}).get("memories", []) or [])
    included_by_id = {str(item.get("id")): item for item in included_memories if item.get("id")}
    required_memory = [str(mid) for mid in plan.get("required_memory_ids", []) or []]
    memory_unresolved: List[Dict[str, Any]] = []
    memory_delivered: List[str] = []
    for memory_id in required_memory:
        item = included_by_id.get(memory_id)
        if item is None:
            memory_unresolved.append({"id": memory_id, "reason": "due_memory_not_in_context"})
            continue
        if plan.get("history_intent") and item.get("content_truncated"):
            memory_unresolved.append({
                "id": memory_id,
                "reason": "historical_memory_witness_truncated",
                "content_sha256": item.get("content_sha256"),
            })
            continue
        memory_delivered.append(memory_id)

    stale_relevant = list(plan.get("freshness_exclusions_relevant", []) or [])
    source_ok = not source_unresolved
    memory_hard_required = bool(plan.get("history_intent"))
    memory_ok_for_history = not memory_unresolved and not (
        memory_hard_required and bool(stale_relevant)
    )

    current_source_claims_allowed = source_ok
    historical_claims_allowed = source_ok and (not memory_hard_required or memory_ok_for_history)

    required_transitions: List[Dict[str, Any]] = []
    for item in source_unresolved:
        required_transitions.append({
            "type": "recover_current_source",
            "target": item["file"],
            "command": f"plw context <query> . --target {item['file']} --budget <larger-N>",
        })
    for item in memory_unresolved:
        required_transitions.append({
            "type": "recover_exact_memory",
            "target": item["id"],
            "command": f"plw memory get {item['id']}",
        })
    if stale_relevant and plan.get("history_intent"):
        for item in stale_relevant[:3]:
            required_transitions.append({
                "type": "verify_historical_memory_against_current_source",
                "target": item.get("file") or item.get("id"),
                "command": f"plw context <query> . --target {item.get('file') or '<file>'}",
            })

    if not source_ok or (memory_hard_required and not memory_ok_for_history):
        status = "recovery_required"
    elif stale_relevant or memory_unresolved:
        status = "satisfied_with_memory_advisory"
    else:
        status = "satisfied"

    decision = {
        "decision_type": "truth_floor_validation",
        "responsible_component": RESPONSIBLE_COMPONENT,
        "responsible_role": RESPONSIBLE_ROLE,
        "policy": TRUTH_FLOOR_POLICY,
        "input_state": {
            "truth_scope": plan.get("truth_scope", "unscoped"),
            "graph_content_signature": plan.get("graph_content_signature"),
            "memory_projection_signature": plan.get("memory_projection_signature"),
            "context_decision_id": (pack.get("accountability", {}) or {}).get("ledger", {}).get("id"),
            "truth_delivery_decision_id": (truth_delivery.get("ledger", {}) or {}).get("id"),
        },
        "source_floor": {
            "due_targets": due_source,
            "delivered_targets": source_delivered,
            "unresolved": source_unresolved,
            "minimum_witness": "selected path + >=1 exact current-source line when detail=source",
        },
        "memory_floor": {
            "role": "historical_continuity_and_procedural_evidence_not_current_source_authority",
            "history_intent": bool(plan.get("history_intent")),
            "required_ids": required_memory,
            "delivered_ids": memory_delivered,
            "unresolved": memory_unresolved,
            "freshness_exclusions_relevant": stale_relevant,
            "current_source_precedence": True,
        },
        "claim_gate": {
            "current_source_claims_allowed": current_source_claims_allowed,
            "historical_or_rationale_claims_allowed": historical_claims_allowed,
            "context_may_be_presented_as_complete": status == "satisfied",
        },
        "required_transitions": required_transitions,
        "invariants": plan.get("invariants", {}),
    }
    ledger = record_accountability(decision, store_dir=accountability_store_dir)
    return {
        "schema_version": "truth-floor-v1",
        "policy": TRUTH_FLOOR_POLICY,
        "responsible_component": RESPONSIBLE_COMPONENT,
        "responsible_role": RESPONSIBLE_ROLE,
        "authority": "validation_gate_only",
        "status": status,
        "truth_scope": plan.get("truth_scope", "unscoped"),
        "source_floor": decision["source_floor"],
        "memory_floor": decision["memory_floor"],
        "claim_gate": decision["claim_gate"],
        "required_transitions": required_transitions,
        "ledger": ledger,
        "invariants": plan.get("invariants", {}),
    }


def fail_closed_prompt(truth_floor: Dict[str, Any]) -> str:
    """Minimal prompt when a mandatory floor is not satisfied."""
    source_targets = [item.get("file") for item in truth_floor.get("source_floor", {}).get("unresolved", [])]
    memory_ids = [item.get("id") for item in truth_floor.get("memory_floor", {}).get("unresolved", [])]
    lines = [
        "[TRUTH FLOOR UNSATISFIED]",
        "Do not make a correctness/history claim from this bounded context yet.",
        f"source_due_unresolved={','.join(str(x) for x in source_targets if x) or 'none'}",
        f"memory_due_unresolved={','.join(str(x) for x in memory_ids if x) or 'none'}",
        "Current source remains authority; domain memory is historical continuity evidence and must be verified against current source.",
    ]
    for transition in truth_floor.get("required_transitions", [])[:4]:
        lines.append(f"RECOVER {transition.get('type')}: {transition.get('command')}")
    ledger = truth_floor.get("ledger", {}) or {}
    if ledger.get("id"):
        lines.append(f"AUDIT=plw accountability {ledger.get('id')}")
    return "\n".join(lines) + "\n"


__all__ = [
    "TRUTH_FLOOR_POLICY",
    "plan_truth_floor",
    "evaluate_truth_floor",
    "fail_closed_prompt",
]
