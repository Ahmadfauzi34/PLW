"""Predictive semantic contracts and deterministic skill handoff for PLW.

This layer adapts PLW-local vocabulary to established technical concepts an
unfamiliar model is likely to know from pretraining.  It does not execute tools,
change source, grant authority, or assert that a future transition will succeed.
It only describes expected information gain and the next documentation read.
"""
from __future__ import annotations

import re
from typing import Any, Dict, Iterable, Mapping

SCHEMA_VERSION = "plw-semantic-affordance-v1"
POLICY = "predictive-semantics-not-execution-authority-v1"


def _contract(
    local_name: str,
    canonical: Iterable[str],
    similar: Iterable[str],
    different: Iterable[str],
    before: str,
    missing: str,
    gain: Iterable[str],
    outcomes: Iterable[str],
    does_not_prove: Iterable[str],
    skill: str,
    *,
    state_change: bool = False,
) -> Dict[str, Any]:
    return {
        "local_name": local_name,
        "canonical_concepts": list(canonical),
        "nearest_known_abstractions": list(similar),
        "different_from": list(different),
        "epistemic_gap": {"before": before, "missing": missing},
        "information_gain": list(gain),
        "possible_outcomes": list(outcomes),
        "does_not_prove": list(does_not_prove),
        "read_before_use": skill,
        "state_change": bool(state_change),
    }


# These are semantic anchors, not executable schemas.  Keep names technical and
# reusable so an unfamiliar model can map PLW concepts onto pretrained knowledge.
COMMAND_CONTRACTS: Dict[str, Dict[str, Any]] = {
    "topology": _contract(
        "Target Codebase Topology Bootstrap",
        ["directed dependency graph", "import graph", "graph reachability", "fan-in/fan-out centrality", "strongly connected components"],
        ["module dependency graph", "static architecture map", "IDE dependency graph"],
        ["runtime call graph", "execution trace", "test coverage", "behavioral proof"],
        "An unfamiliar repository is present but the model has no grounded structural map of its file-to-file dependency space.",
        "Entrypoints, tests, import edges, hubs, SCCs, boundaries, unresolved imports, and external dependency surfaces needed before target-specific reasoning.",
        ["repository structural map", "dependency hubs", "cycle surfaces", "import-resolution gaps", "entrypoint/test surfaces"],
        ["TARGET_STRUCTURAL_ORIENTATION_READY", "EMPTY_OR_UNRESOLVED_REPOSITORY"],
        ["runtime behavior", "semantic ownership", "correctness", "postcondition", "truth"],
        "skills/target-codebase-topology-workflow.md",
    ),
    "resolve-target": _contract(
        "Target Resolution and Structural Relevance",
        ["entity resolution", "information retrieval", "dependency graph neighborhood", "reverse dependency reachability", "test/entrypoint reachability"],
        ["symbol/file search", "graph-grounded candidate ranking", "IDE find references"],
        ["semantic ownership proof", "runtime call graph", "behavioral correctness", "capability selection"],
        "Repository topology is known but the task has not yet been grounded to one or more code nodes.",
        "Which bounded file candidates are supported by task/path hints plus graph evidence, including ambiguity and structural neighborhood.",
        ["candidate target files", "ranking evidence", "direct dependency neighborhood", "affected entrypoints", "reachable tests"],
        ["RESOLVED", "MULTI_TARGET_RESOLVED", "AMBIGUOUS", "UNRESOLVED"],
        ["semantic ownership", "runtime behavior", "PLW capability necessity", "postcondition", "truth"],
        "skills/target-resolution-workflow.md",
    ),
    "work": _contract(
        "Adaptive Work Pack",
        ["static program analysis", "graph reachability", "bounded information retrieval", "proof-state routing"],
        ["query planning", "program slicing", "dependency-aware context retrieval"],
        ["generic search", "source mutation", "runtime execution"],
        "A repository task exists after or alongside structural orientation, but the task target and relevant transitive evidence are not yet bounded.",
        "Which target nodes/source evidence matter, what remains unknown, and which technical evidence need justifies any specialized capability.",
        ["target-oriented evidence", "bounded source context", "target blast radius", "proof gaps", "deterministic skill handoff"],
        ["READY", "RECOVERY_REQUIRED", "BLOCKED"],
        ["runtime behavior", "source correctness", "postcondition", "truth"],
        "skills/adaptive-agent-workflow.md",
    ),
    "context": _contract(
        "Bounded Context Pack",
        ["program slicing", "graph-grounded retrieval", "evidence provenance"],
        ["static slicing", "dependency-aware retrieval"],
        ["full repository dump", "runtime observation"],
        "The model has a question but local context may omit relevant transitive evidence.",
        "A bounded, source-grounded evidence set with explicit omission/recovery metadata.",
        ["selected source witnesses", "evidence roles", "recoverable omissions"],
        ["CONTEXT_READY", "RECOVERY_REQUIRED"],
        ["runtime behavior", "postcondition", "truth"],
        "skills/context-and-proof-workflow.md",
    ),
    "impact": _contract(
        "Topological Impact Projection",
        ["dependency graph reachability", "change impact analysis", "reverse dependency closure"],
        ["call-graph reachability", "blast-radius analysis"],
        ["grep", "text similarity", "runtime tracing"],
        "A code target is known but transitive affected surfaces are not.",
        "Graph-grounded upstream/downstream and test reachability.",
        ["direct/transitive dependents", "test reachability", "boundary exposure"],
        ["IMPACT_PROJECTED", "TARGET_UNRESOLVED"],
        ["actual runtime effect", "behavioral correctness"],
        "skills/code-change-and-session-workflow.md",
    ),
    "simplify": _contract(
        "Local Simplification Frontier",
        ["duplicate-code analysis", "local refactoring frontier", "structural redundancy detection"],
        ["clone detection", "refactoring opportunity analysis"],
        ["automatic refactor", "global optimization"],
        "The code works but it is unknown whether newly introduced local redundancy remains.",
        "Bounded simplification candidates and whether a local recommendation remains.",
        ["remaining candidates", "recommended local candidates", "frontier state"],
        ["FRONTIER_REACHED", "LOCAL_SIMPLIFICATION_RECOMMENDED"],
        ["semantic equivalence of arbitrary rewrites", "runtime performance"],
        "skills/code-change-and-session-workflow.md",
    ),
    "angular-anchors": _contract(
        "Angular Semantic Ownership Anchors",
        ["static framework metadata analysis", "symbol ownership", "template binding analysis"],
        ["AST metadata extraction", "component ownership mapping"],
        ["rendered DOM identity", "runtime geometry"],
        "Angular source exists but ownership of selectors/templates/bindings is not explicitly proven.",
        "Static component/template/member ownership and unresolved ambiguity.",
        ["component owners", "binding witnesses", "proof classes"],
        ["EXACT", "STRUCTURAL", "UNRESOLVED"],
        ["rendered identity", "geometry", "runtime behavior"],
        "skills/angular-semantic-ownership-workflow.md",
    ),
    "ui-reference": _contract(
        "UI Geometry Mapping + Geometry↔Code Correspondence",
        ["scene graph", "spatial relationship graph", "bounding-box collision detection", "bipartite correspondence", "provenance mapping"],
        ["DOM layout inspector", "UI ownership mapping", "scene-graph correspondence", "layout diagnostics"],
        ["topology merge", "screenshot recognition", "automated source mutation", "root-cause proof"],
        "A rendered page, scenario set, baseline/candidate render pair, diagnosed UI bug, or counterfactually supported cause candidate exists but the agent lacks a precise spatial map, code ownership, runtime reproduction, bounded fix target, or exact-scenario post-fix verification.",
        "Scenario-bound UI hierarchy, responsive mapping, cross-revision geometry diff, evidence-graded bug candidates, UI↔code correspondence, bounded topology projection, Chromium/CDP reproduction, counterfactual candidate isolation, bounded fix planning, and exact-scenario post-fix verification.",
        ["UI hierarchy", "spatial collisions", "responsive scenario matrix", "cross-revision geometry change", "bug candidate lifecycle", "code owner mapping", "structural cause candidates", "runtime reproduction result", "counterfactual intervention support", "bounded fix target", "post-fix exact-scenario result", "freshness/proof class"],
        ["MAPPED", "SCENARIO_MAPPED", "GEOMETRY_DIFFED", "DISCOVERED", "SUPPORTED", "REPRODUCED", "BOUND", "COUNTERFACTUAL_SUPPORT_FOUND", "FIX_PLANNED", "FIX_VERIFIED", "FIX_FAILED", "FIX_SCOPE_UNSAFE", "INCONCLUSIVE", "EXACT", "STRUCTURAL", "UNRESOLVED"],
        ["root-cause proof", "postcondition proof", "mutation authority", "truth"],
        "skills/geometry-correspondence-workflow.md",
    ),
    "geometric-impact": _contract(
        "Targeted Geometric Constraint Impact",
        ["spatial constraint evaluation", "geometric collision detection", "dependency impact projection"],
        ["layout constraint solving", "bounding-box intersection", "program impact analysis"],
        ["computer vision recognition", "global screenshot regression"],
        "A rendered-space issue is known but affected UI/code surfaces are not bounded.",
        "Constraint violations and topology-backed affected surfaces for the exact scenario.",
        ["overlap/containment/alignment violations", "selected UI surfaces", "code impact projection"],
        ["VIOLATION", "SATISFIED", "UNRESOLVED"],
        ["behavioral correctness", "postcondition"],
        "skills/geometric-impact-projection-workflow.md",
    ),
    "validation-plan": _contract(
        "Scenario Validation Planning",
        ["test selection", "scenario coverage planning", "risk-based verification"],
        ["targeted regression selection", "coverage planning"],
        ["test execution", "evidence collection"],
        "Impact is known but the bounded scenarios that should be validated are not.",
        "A recoverable scenario set and explicit omitted variations.",
        ["selected scenarios", "variation gaps", "recovery path"],
        ["PLANNED", "RECOVERY_REQUIRED"],
        ["test result", "proof coverage", "truth"],
        "skills/scenario-validation-planning-workflow.md",
    ),
    "validation-evidence": _contract(
        "Scenario-Bound Validation Evidence",
        ["test evidence binding", "provenance verification", "scenario identity"],
        ["test result attestation", "evidence provenance"],
        ["proof completion", "test execution"],
        "Validator evidence exists but it is not yet bound to the exact planned scenario.",
        "Whether evidence is observed, missing, conflicting, unplanned, and provenance-bound.",
        ["scenario observation state", "evidence provenance", "conflicts/missing evidence"],
        ["OBSERVED", "MISSING", "CONFLICTING", "UNPLANNED"],
        ["proof-obligation coverage", "postcondition", "truth"],
        "skills/scenario-validation-evidence-workflow.md",
    ),
    "validation-coverage": _contract(
        "Proof-Obligation Coverage / Re-Derivation",
        ["proof obligation tracking", "coverage analysis", "witness consistency", "semantic re-derivation", "execution provenance"],
        ["requirements traceability", "coverage matrix", "evidence-to-obligation projection"],
        ["postcondition proof", "truth commit", "validator execution"],
        "Scenario-bound evidence exists (legacy F129 or execution-backed F139), but it is unknown which explicit obligations it satisfies under the correct provenance authority.",
        "Fresh covered/partial/missing/conflicting obligation states, witness groups, provenance-specific coverage, and next evidence gaps.",
        ["coverage state", "missing obligations", "execution provenance coverage", "next evidence gaps"],
        ["COVERED", "PARTIAL", "MISSING", "CONFLICTING"],
        ["postcondition", "truth", "runtime execution"],
        "skills/validation-proof-obligation-workflow.md",
    ),
    "postcondition-proof": _contract(
        "Postcondition Proof Assembly",
        ["postcondition verification", "evidence conjunction", "revision freshness", "proof state assembly"],
        ["design-by-contract verification", "requirements satisfaction", "proof obligation discharge"],
        ["source mutation attestation", "stable promotion", "truth commit", "runtime execution"],
        "F139 evidence and fresh F140 coverage exist, but the intended postcondition has not yet been evaluated against an exact change identity, revision, scenario expectations, and critical check outcomes.",
        "Whether the declared postcondition is PROVEN, DISPROVEN, UNRESOLVED, CONFLICTING, or STALE under the verified evidence scope.",
        ["postcondition proof state", "scenario/check expectation comparisons", "revision freshness", "proof boundaries"],
        ["PROVEN", "DISPROVEN", "UNRESOLVED", "CONFLICTING", "STALE"],
        ["source mutation applied", "stable promotion", "truth commit"],
        "skills/postcondition-proof-assembly-workflow.md",
    ),
    "fullstack-state": _contract(
        "Full-Stack Validated State Composition",
        ["authority composition", "cross-domain compatibility", "revision freshness", "scenario identity", "proof provenance"],
        ["multi-authority proof composition", "typed evidence conjunction", "compatibility checking"],
        ["graph merge", "evidence voting", "truth commit", "stable promotion", "source mutation attestation"],
        "Topology, geometry, correspondence, behavior, and F141 postcondition authorities exist separately but have not been checked for exact revision/scenario/freshness compatibility.",
        "A bounded VALIDATED/REJECTED/UNRESOLVED/CONFLICTING/STALE composition state while preserving every authority domain separately.",
        ["cross-authority compatibility", "revision/scenario freshness", "geometry constraint state", "correspondence proof policy", "behavior/postcondition lineage"],
        ["VALIDATED", "REJECTED", "UNRESOLVED", "CONFLICTING", "STALE"],
        ["truth commit", "stable promotion", "source mutation attestation", "authority merger"],
        "skills/full-stack-validated-state-workflow.md",
    ),
    "validation-request": _contract(
        "Validation Execution Request",
        ["work request handoff", "bounded job specification", "content-addressed request identity"],
        ["job specification", "test execution request"],
        ["authorization", "dispatch", "runtime execution"],
        "Unresolved obligations exist but no bounded validator work item has been materialized.",
        "An exact request identity binding scenarios, validator, executor, and operation.",
        ["request_id", "request-set digest", "witness grouping"],
        ["REQUESTED", "REJECTED"],
        ["authorization", "execution", "result"],
        "skills/validation-execution-request-workflow.md",
    ),
    "validation-authorization": _contract(
        "Exact Validation Authorization Binding",
        ["capability authorization", "signed grant", "least-authority binding"],
        ["capability token", "authorization grant"],
        ["lease", "execution", "result"],
        "An exact validation request exists but no principal grant is bound to it.",
        "A signed authorization bound to one exact request identity.",
        ["authorization binding", "expiry", "principal lineage"],
        ["AUTHORIZED_BOUND", "REJECTED"],
        ["lease acquisition", "dispatch", "runtime execution"],
        "skills/validation-authorization-binding-workflow.md",
        state_change=True,
    ),
    "validation-lease": _contract(
        "Single-Use Validation Lease",
        ["lease", "single-use capability", "atomic claim", "idempotency"],
        ["distributed lease", "compare-and-swap style claim"],
        ["attempt", "dispatch", "runtime execution"],
        "Authorization exists but exclusive single-use consumption has not been established.",
        "Exactly one durable lease winner with expiry and replay semantics.",
        ["lease identity", "single-winner consumption", "expiry/replay state"],
        ["ACQUIRED", "RECOVERED", "REJECTED"],
        ["attempt", "dispatch", "validator result"],
        "skills/validation-execution-lease-workflow.md",
        state_change=True,
    ),
    "validation-attempt": _contract(
        "Durable Validation Attempt Registration",
        ["single assignment", "durable attempt record", "pre-execution barrier"],
        ["write-ahead attempt registration", "idempotent job attempt"],
        ["runtime dispatch", "validator execution"],
        "A lease exists but there is no durable record identifying the sole execution attempt.",
        "One exact attempt identity recoverable across crash/retry.",
        ["attempt identity", "parent lease binding", "exact recovery"],
        ["REGISTERED", "RECOVERED", "REJECTED"],
        ["dispatch state", "runtime result"],
        "skills/validation-attempt-workflow.md",
        state_change=True,
    ),
    "validation-dispatch": _contract(
        "Validation Dispatch Intent",
        ["durable intent record", "write-ahead coordination", "single assignment", "idempotent recovery"],
        ["write-ahead intent", "outbox-style coordination"],
        ["runtime dispatch", "redo log"],
        "An attempt exists but no durable pre-execution intent records the next handoff.",
        "A single dispatch intent bound to the exact attempt without claiming host execution.",
        ["dispatch-intent identity", "crash-safe local commitment"],
        ["PREPARED", "RECOVERED", "REJECTED"],
        ["external effect", "validator execution", "result"],
        "skills/validation-dispatch-intent-workflow.md",
        state_change=True,
    ),
    "validation-runtime": _contract(
        "Runtime Dispatch Reconciliation",
        ["distributed systems reconciliation", "ambiguous external effects", "durable handoff", "no-blind-retry"],
        ["outbox reconciliation", "at-least-once ambiguity handling"],
        ["evidence acceptance", "postcondition proof"],
        "A local dispatch intent exists but actual host delivery/effect state is unknown or ambiguous.",
        "Durable handoff state and append-only observations without blind redispatch.",
        ["handoff identity", "runtime observations", "reconciliation requirement"],
        ["PENDING", "NOT_FOUND", "UNKNOWN", "RESOLVED"],
        ["accepted evidence", "postcondition", "truth"],
        "skills/validation-runtime-dispatch-workflow.md",
        state_change=True,
    ),
    "validation-result": _contract(
        "Validation Result Evidence Acceptance",
        ["artifact attestation", "content-addressed integrity", "provenance verification", "lineage binding"],
        ["artifact verification", "signed provenance checking"],
        ["test runner", "validator execution", "proof completion"],
        "A runtime result was observed but the returned content is not yet admissible evidence for the exact request.",
        "Whether exact result content and execution lineage are valid evidence.",
        ["content binding", "scenario binding", "validator/executor lineage", "acceptance receipt"],
        ["ACCEPTED", "REJECTED", "UNRESOLVED"],
        ["proof-obligation coverage", "postcondition", "truth"],
        "skills/validation-result-evidence-acceptance-workflow.md",
        state_change=True,
    ),
    "validation-scenario-bind": _contract(
        "Execution-Backed Scenario Evidence Binding",
        ["scenario-bound evidence", "provenance binding", "execution lineage", "evidence normalization"],
        ["test-result provenance binding", "trace-to-scenario association", "artifact lineage projection"],
        ["validator execution", "proof-obligation coverage", "postcondition proof"],
        "F138 accepted exact runtime-result content, but it is not yet bound into the selected F128 scenario evidence space.",
        "A read-only scenario binding that preserves F138/F137 execution provenance and F129-style observed/missing semantics.",
        ["scenario binding", "execution-backed observation identity", "requested/observed check accounting", "provenance v2"],
        ["BOUND", "REJECTED"],
        ["proof-obligation coverage", "postcondition", "truth"],
        "skills/execution-backed-scenario-evidence-workflow.md",
    ),
}


# Complete the public PLW surface with concise technical anchors.  These entries
# keep rarely used commands from becoming opaque private vocabulary.
COMMAND_CONTRACTS.update({
    "evidence-needs": _contract(
        "Target-Grounded Evidence-Need Derivation",
        ["epistemic gap analysis", "evidence requirements", "static-vs-runtime evidence boundary", "test reachability vs coverage"],
        ["requirements traceability", "proof obligation discovery", "diagnostic gap analysis"],
        ["PLW capability selection", "execution planning", "semantic ownership proof", "behavioral correctness proof"],
        "Target nodes are structurally grounded but the evidence required to answer the task is not yet explicit.",
        "Which claims remain unsupported by current graph/source evidence and what technical evidence categories would close them.",
        ["known target facts", "explicit unknown claims", "technical evidence requirements"],
        ["EVIDENCE_NEEDS_DERIVED", "EVIDENCE_NEED_BLOCKED_TARGET_UNRESOLVED"],
        ["which tool should be called", "runtime behavior", "postcondition", "truth"],
        "skills/evidence-need-derivation-workflow.md",
    ),
    "capability-match": _contract(
        "Evidence-Driven Capability Matching",
        ["information gain", "capability matching", "evidence coverage", "set cover over evidence requirements"],
        ["planner operator selection", "diagnostic test selection", "information-gain action ranking"],
        ["task-keyword routing", "capability execution", "authorization", "proof completion"],
        "Target-grounded evidence requirements are explicit but no PLW capability has yet been matched to those requirements.",
        "Which registered capabilities can add information for each evidence class, which are only partial/preparatory, and which needs remain uncovered.",
        ["candidate capabilities", "expected information gain", "coverage role", "uncovered evidence needs", "exact skill paths"],
        ["CAPABILITY_CANDIDATES_PROJECTED", "CAPABILITY_SELECTION_BLOCKED_EVIDENCE_NEEDS_NOT_READY"],
        ["which action the agent must take", "capability success", "runtime behavior", "postcondition", "truth"],
        "skills/evidence-driven-capability-selection-workflow.md",
    ),
    "semantic": _contract(
        "Semantic Affordance Introspection",
        ["ontology alignment", "capability introspection", "predictive semantics"],
        ["API capability discovery", "type-class documentation"],
        ["tool execution", "planner authority"],
        "A PLW-local term or task-to-capability mapping is not yet understood.",
        "Canonical technical meaning, information gain, proof limits, and exact skill route.",
        ["technical anchors", "epistemic gap", "skill path"],
        ["DESCRIBED", "ROUTED", "UNKNOWN"],
        ["the described command result", "execution authority"],
        "skills/semantic-affordance-workflow.md",
    ),
    "transitions": _contract(
        "Proof Transition Registry",
        ["state machine transitions", "proof-state recovery", "precondition routing"],
        ["workflow state machine", "recovery transition registry"],
        ["transition execution", "proof itself"],
        "A claim is blocked but the admissible next proof transition is unknown.",
        "Registered candidate transitions, cost/risk order, and command hints.",
        ["candidate transitions", "preferred recovery transition"],
        ["TRANSITIONS_REQUIRED", "NO_TRANSITION_REQUIRED", "BLOCKED"],
        ["post-transition proof", "execution authority"],
        "skills/context-and-proof-workflow.md",
    ),
    "kan": _contract(
        "Kan-Style Structural Imputation",
        ["Kan extension", "structural completion", "categorical neighborhood inference"],
        ["left/right Kan extension", "graph neighborhood completion"],
        ["source truth", "runtime evidence"],
        "A structural role is incomplete and neighboring graph structure may constrain a useful imputation.",
        "Bounded left/right structural guidance with explicit inference status.",
        ["imputed topology", "constraint guidance"],
        ["IMPUTED", "NO_MATCH", "UNRESOLVED"],
        ["source fact", "runtime behavior"],
        "skills/analysis-output-reference.md",
    ),
    "check": _contract(
        "Static Analyzer Check",
        ["static analysis", "lint-style analyzer registry", "code quality diagnostics"],
        ["compiler/linter diagnostics", "static bug finding"],
        ["runtime test", "formal proof"],
        "The repository is available but registered static findings have not been projected.",
        "Analyzer findings and failures over one canonical graph.",
        ["static findings", "analyzer health"],
        ["FINDINGS", "CLEAN", "ANALYZER_ERROR"],
        ["runtime correctness", "postcondition"],
        "skills/analysis-output-reference.md",
    ),
    "steer": _contract(
        "Topology Steering Advice",
        ["architecture diagnostics", "graph invariant guidance", "dependency steering"],
        ["architecture linting", "dependency rule guidance"],
        ["automatic mutation", "authorization"],
        "Topology findings exist but their bounded architectural guidance is not summarized.",
        "Non-authorizing steering guidance grounded in topology/analyzer evidence.",
        ["steering recommendations", "topology rationale"],
        ["GUIDANCE_AVAILABLE", "NO_GUIDANCE"],
        ["safe mutation", "runtime effect"],
        "skills/analysis-output-reference.md",
    ),
    "brief": _contract(
        "Target Code Brief",
        ["program slice summary", "dependency impact summary", "symbol outline"],
        ["code intelligence brief", "IDE symbol/dependency summary"],
        ["full repository context", "runtime trace"],
        "A target file is known but its structure and local/transitive impact are not summarized together.",
        "Combined outline and impact evidence for one target.",
        ["outline", "impact", "target existence"],
        ["BRIEF_READY", "TARGET_UNRESOLVED"],
        ["behavioral correctness"],
        "skills/code-change-and-session-workflow.md",
    ),
    "outline": _contract(
        "Source Structure Outline",
        ["symbol indexing", "source outline", "static structure extraction"],
        ["IDE document symbols", "AST outline"],
        ["dependency impact", "runtime behavior"],
        "A source file is known but its internal symbol/structure surface is not bounded.",
        "Functions/classes/exports and structural outline.",
        ["source symbols", "structural sections"],
        ["OUTLINE_READY", "TARGET_UNRESOLVED"],
        ["transitive impact", "runtime behavior"],
        "skills/code-change-and-session-workflow.md",
    ),
    "compact-output": _contract(
        "Bounded Output Compaction",
        ["loss-aware summarization", "recoverable projection", "content-addressed output storage"],
        ["structured log compaction", "recoverable summary"],
        ["evidence deletion", "truth reduction"],
        "A tool result is too large for current context but may be needed later.",
        "Compact projection plus recovery identity for omitted raw output.",
        ["bounded projection", "recovery pointer", "omission telemetry"],
        ["COMPACTED", "UNCHANGED"],
        ["irrelevance of omitted data"],
        "skills/tool-call-and-cli-workflow.md",
    ),
    "recover-output": _contract(
        "Raw Output Recovery",
        ["content-addressed retrieval", "lossless artifact recovery"],
        ["CAS lookup", "log artifact retrieval"],
        ["new execution", "recomputation"],
        "A compacted result omitted details needed for the current claim.",
        "The exact stored raw output identified by its digest.",
        ["raw output", "lineage metadata"],
        ["RECOVERED", "NOT_FOUND"],
        ["freshness beyond stored artifact"],
        "skills/tool-call-and-cli-workflow.md",
    ),
    "attest-runtime": _contract(
        "Runtime Output Attestation",
        ["execution attestation", "result provenance", "command/exit-code binding"],
        ["build/test attestation", "signed run metadata"],
        ["runtime execution", "truth commit"],
        "An external runtime command was executed but its output is not yet bound to a claim lineage.",
        "Attestation binding command, exit code, output identity, and claim type.",
        ["runtime witness", "claim lineage"],
        ["ATTESTED", "REJECTED"],
        ["the command was correct", "postcondition"],
        "skills/context-and-proof-workflow.md",
        state_change=True,
    ),
    "output-telemetry": _contract(
        "Output Telemetry",
        ["observability telemetry", "output-volume accounting", "recovery metrics"],
        ["logging metrics", "artifact telemetry"],
        ["proof", "execution result"],
        "It is unknown how command outputs are being compacted/recovered over time.",
        "Read-only output volume and recovery telemetry.",
        ["output counts", "compaction/recovery metrics"],
        ["TELEMETRY_READY"],
        ["semantic correctness"],
        "skills/analysis-output-reference.md",
    ),
    "transition-memory": _contract(
        "Transition Outcome Memory",
        ["experience replay", "transition outcome statistics", "episodic policy evidence"],
        ["reinforcement-learning transition history", "experience buffer"],
        ["policy authority", "Q-value truth"],
        "Past transition outcomes may matter but are not summarized for the current state class.",
        "Historical transition outcome aggregates.",
        ["outcome frequencies", "delayed-cost observations"],
        ["SUMMARY_READY"],
        ["future outcome", "execution authority"],
        "skills/analysis-output-reference.md",
    ),
    "transition-model": _contract(
        "State Transition Model",
        ["Markov transition model", "empirical state transition estimation"],
        ["MDP transition model", "state-machine statistics"],
        ["deterministic future prediction", "authorization"],
        "Empirical next-state behavior is unknown for a recorded state class.",
        "Observed transition distribution and uncertainty.",
        ["transition probabilities/counts", "state-class observations"],
        ["MODEL_READY", "INSUFFICIENT_DATA"],
        ["guaranteed next state"],
        "skills/analysis-output-reference.md",
    ),
    "q-values": _contract(
        "Empirical Q-Value Summary",
        ["reinforcement learning Q-values", "state-action value estimation"],
        ["tabular Q-learning diagnostics", "policy value estimate"],
        ["proof", "permission to act"],
        "Historical action utility is unknown for a state class.",
        "Empirical value estimates from recorded transition outcomes.",
        ["state-action values", "sample/support metadata"],
        ["VALUES_READY", "INSUFFICIENT_DATA"],
        ["optimality", "safe execution"],
        "skills/analysis-output-reference.md",
    ),
    "reconcile-outcomes": _contract(
        "Delayed Outcome Reconciliation",
        ["delayed reward attribution", "outcome reconciliation", "credit assignment"],
        ["RL delayed reward", "eventual outcome joining"],
        ["runtime dispatch reconciliation", "truth commit"],
        "A prior transition has delayed outcome/cost records that are not yet joined.",
        "Joined delayed costs/outcomes and optional accountability record.",
        ["reconciled outcome", "delayed cost attribution"],
        ["RECONCILED", "NO_MATCH"],
        ["future success"],
        "skills/analysis-output-reference.md",
    ),
    "lineage": _contract(
        "Decision Lineage Trace",
        ["provenance DAG", "causal lineage", "decision traceability"],
        ["audit trail", "provenance graph traversal"],
        ["truth", "runtime observation"],
        "A decision/evidence identifier exists but its parent provenance chain is unclear.",
        "Traceable parent/child decision lineage.",
        ["lineage nodes", "parent references"],
        ["LINEAGE_READY", "NOT_FOUND"],
        ["semantic validity of each parent"],
        "skills/context-and-proof-workflow.md",
    ),
    "accountability": _contract(
        "Evidence Accountability Record",
        ["audit logging", "evidence debt accounting", "responsibility attribution"],
        ["audit record", "provenance ledger"],
        ["execution authority", "truth"],
        "A context/proof decision exists but its omissions and responsible component are not visible.",
        "Accountability record including evidence debt and recovery metadata.",
        ["decision record", "evidence debt", "responsible role"],
        ["RECORD_READY", "NOT_FOUND"],
        ["claim truth"],
        "skills/context-and-proof-workflow.md",
    ),
    "accountability-chain": _contract(
        "Verified Accountability Chain",
        ["audit-chain verification", "provenance chain validation"],
        ["append-only audit chain", "provenance DAG verification"],
        ["runtime proof", "authorization"],
        "One accountability record is known but the upstream chain has not been verified.",
        "Verified bounded parent chain and integrity diagnostics.",
        ["chain nodes", "integrity status"],
        ["CHAIN_VERIFIED", "CHAIN_BROKEN", "NOT_FOUND"],
        ["underlying claim truth"],
        "skills/capability-governance-workflow.md",
    ),
    "action-lease": _contract(
        "Atomic Action Lease",
        ["lease", "single-use nonce", "atomic claim", "idempotency"],
        ["distributed lease", "single-consumer claim"],
        ["executor success", "postcondition"],
        "An authorized action gate exists but exclusive executor-start authority has not been atomically consumed.",
        "One bounded single-use executor lease or exact recovery.",
        ["lease receipt", "expiry", "executor binding"],
        ["LEASED", "RECOVERED", "REJECTED"],
        ["executor started", "effect succeeded"],
        "skills/atomic-execution-lease-workflow.md",
        state_change=True,
    ),
    "action-outcome": _contract(
        "Lease-Bound Executor Attempt/Outcome",
        ["durable attempt registration", "executor outcome log", "crash ambiguity"],
        ["job attempt state machine", "write-ahead execution record"],
        ["external effect proof", "postcondition"],
        "A lease exists but executor attempt/outcome state is not durably separated.",
        "Attempt registration and terminal/indeterminate executor outcome state.",
        ["attempt identity", "outcome state", "crash ambiguity"],
        ["ATTEMPT_REGISTERED", "SUCCEEDED", "FAILED", "INDETERMINATE"],
        ["postcondition", "truth"],
        "skills/lease-bound-executor-outcome-workflow.md",
        state_change=True,
    ),
    "action-adapter": _contract(
        "Executor Adapter Reconciliation",
        ["external effect reconciliation", "outbox pattern", "no-blind-retry"],
        ["distributed job dispatch", "eventual reconciliation"],
        ["exactly-once guarantee", "postcondition proof"],
        "An executor attempt exists but concrete host dispatch/result state may be ambiguous.",
        "Durable dispatch intent plus append-only adapter observations/reconciliation.",
        ["dispatch intent", "adapter observation", "reconciliation state"],
        ["PENDING", "NOT_FOUND", "UNKNOWN", "RESOLVED"],
        ["exactly-once external effects", "truth"],
        "skills/executor-adapter-reconciliation-workflow.md",
        state_change=True,
    ),
    "runtime-ui-reference": _contract(
        "Runtime Geometry Provenance Binding",
        ["runtime provenance", "snapshot attestation", "content-addressed capture"],
        ["artifact provenance", "runtime capture receipt"],
        ["browser execution", "geometry validity"],
        "A geometry snapshot exists but its runtime-capture provenance is not bound.",
        "F123 runtime observation bound to the exact geometry snapshot digest.",
        ["capture provenance", "snapshot digest binding"],
        ["BOUND", "UNRESOLVED"],
        ["geometric correctness", "behavioral validity"],
        "skills/runtime-geometry-capture-workflow.md",
    ),
    "install": _contract(
        "Portable CLI Installation",
        ["CLI deployment", "executable bootstrap", "PATH installation"],
        ["command-line tool installation"],
        ["repository mutation", "runtime proof"],
        "The packaged PLW entrypoint exists but is not exposed at the requested binary location.",
        "Installed launcher/binary location and bootstrap status.",
        ["installation path", "launcher status"],
        ["INSTALLED", "REJECTED"],
        ["tool correctness"],
        "skills/tool-call-and-cli-workflow.md",
        state_change=True,
    ),
    "memory": _contract(
        "Semantic/Episodic Memory Operations",
        ["episodic memory", "semantic memory", "retrieval", "association graph"],
        ["knowledge store", "retrieval-augmented memory"],
        ["source truth", "automatic authority"],
        "Historical continuity may be useful but is not part of current source evidence.",
        "Scoped memory retrieval/storage/association with provenance boundaries.",
        ["memory records", "associations", "retrieval evidence"],
        ["RETRIEVED", "STORED", "NO_MATCH"],
        ["current source truth", "runtime behavior"],
        "skills/context-and-proof-workflow.md",
        state_change=True,
    ),
    "fiber": _contract(
        "Task Fiber / Context Transport",
        ["task-local state", "context transport", "section/fiber isolation"],
        ["continuation-local context", "task workspace"],
        ["source mutation", "proof"],
        "Long-running work needs scoped context continuity or transport between task states.",
        "Fiber state, lifted memory, sections, or bounded transport candidates.",
        ["fiber state", "transported context", "section status"],
        ["ACTIVE", "TRANSPORTED", "NO_MATCH"],
        ["claim truth", "execution authority"],
        "skills/code-change-and-session-workflow.md",
        state_change=True,
    ),
})


# Strong task signals intentionally name technical concepts rather than PLW-local
# branding.  Earlier rows win when several domains appear in the same task.
_SKILL_ROUTES = (
    ("skills/validation-result-evidence-acceptance-workflow.md", "validation-result", ("accepted evidence", "evidence acceptance", "runtime result", "validator result", "result evidence")),
    ("skills/execution-backed-scenario-evidence-workflow.md", "validation-scenario-bind", ("scenario binding", "execution-backed evidence", "accepted result scenario", "provenance v2", "runtime evidence binding")),
    ("skills/validation-runtime-dispatch-workflow.md", "validation-runtime", ("runtime reconcile", "runtime reconciliation", "blind retry", "handoff", "not_found", "ambiguous external effect")),
    ("skills/validation-dispatch-intent-workflow.md", "validation-dispatch", ("dispatch intent", "pre-execution intent", "write-ahead intent")),
    ("skills/validation-attempt-workflow.md", "validation-attempt", ("attempt registration", "durable attempt")),
    ("skills/validation-execution-lease-workflow.md", "validation-lease", ("validation lease", "single-use lease")),
    ("skills/validation-authorization-binding-workflow.md", "validation-authorization", ("validation authorization", "principal approval", "signed grant")),
    ("skills/validation-execution-request-workflow.md", "validation-request", ("validation request", "validator work item")),
    ("skills/validation-proof-obligation-workflow.md", "validation-coverage", ("proof obligation", "coverage gap", "obligation coverage")),
    ("skills/scenario-validation-evidence-workflow.md", "validation-evidence", ("scenario evidence", "validator evidence", "conflicting evidence")),
    ("skills/scenario-validation-planning-workflow.md", "validation-plan", ("validation scenario", "scenario plan", "targeted validation")),
    ("skills/geometric-impact-projection-workflow.md", "geometric-impact", ("overlap", "containment", "alignment", "layout bug", "visual bug", "geometric impact", "geometry constraint")),
    ("skills/geometry-correspondence-workflow.md", "ui-reference", ("ui code", "ui↔code", "ui-code", "geometry snapshot", "rendered geometry", "correspondence")),
    ("skills/angular-semantic-ownership-workflow.md", "angular-anchors", ("angular selector", "template binding", "component owner", "angular ownership")),
    ("skills/external-corpus-audit-workflow.md", "work", ("external repository", "external repo", "corpus audit")),
    ("skills/code-change-and-session-workflow.md", "impact", ("refactor", "change impact", "edit", "modify", "patch", "perbaiki", "ubah")),
    ("skills/context-and-proof-workflow.md", "context", ("proof gap", "claim evidence", "evidence recovery", "prove", "buktikan")),
)


def _normalize(value: str) -> str:
    return " ".join(re.findall(r"[a-z0-9_↔-]+", str(value or "").casefold()))


def describe_command(command: str) -> Dict[str, Any]:
    name = str(command or "").strip().lower().replace("_", "-")
    contract = COMMAND_CONTRACTS.get(name)
    if contract is None:
        return {
            "schema_version": SCHEMA_VERSION,
            "policy": POLICY,
            "command": name,
            "known": False,
            "error": "semantic_contract_not_registered",
            "authority": "descriptive_only",
            "available_commands": sorted(COMMAND_CONTRACTS),
        }
    return {
        "schema_version": SCHEMA_VERSION,
        "policy": POLICY,
        "command": name,
        "known": True,
        **contract,
        "authority": "descriptive_only",
        "invariants": {
            "description_does_not_execute_command": True,
            "predicted_outcomes_are_not_observed_results": True,
            "semantic_similarity_does_not_transfer_authority": True,
        },
    }


def route_task_semantics(task: str, *, goal: str = "auto") -> Dict[str, Any]:
    normalized = _normalize(task)
    for skill, command, terms in _SKILL_ROUTES:
        matches = [term for term in terms if _normalize(term) in normalized]
        if matches:
            contract = describe_command(command)
            return {
                "schema_version": SCHEMA_VERSION,
                "policy": POLICY,
                "route_found": True,
                "selection_source": "bounded_task_signal",
                "signals": matches[:4],
                "skill_path": skill,
                "capability": command,
                "canonical_concepts": contract.get("canonical_concepts", []),
                "epistemic_gap": contract.get("epistemic_gap", {}),
                "information_gain": contract.get("information_gain", []),
                "does_not_prove": contract.get("does_not_prove", []),
                "authority": "documentation_routing_only",
            }
    fallback = {
        "runtime": ("skills/context-and-proof-workflow.md", "context"),
        "performance": ("skills/adaptive-agent-workflow.md", "work"),
        "architecture": ("skills/context-and-proof-workflow.md", "context"),
        "change": ("skills/code-change-and-session-workflow.md", "impact"),
        "history": ("skills/context-and-proof-workflow.md", "context"),
        "understand": ("skills/adaptive-agent-workflow.md", "work"),
        "auto": ("skills/adaptive-agent-workflow.md", "work"),
    }.get(str(goal or "auto").lower(), ("skills/adaptive-agent-workflow.md", "work"))
    contract = describe_command(fallback[1])
    return {
        "schema_version": SCHEMA_VERSION,
        "policy": POLICY,
        "route_found": True,
        "selection_source": "goal_fallback",
        "signals": [f"goal:{goal}"],
        "skill_path": fallback[0],
        "capability": fallback[1],
        "canonical_concepts": contract.get("canonical_concepts", []),
        "epistemic_gap": contract.get("epistemic_gap", {}),
        "information_gain": contract.get("information_gain", []),
        "does_not_prove": contract.get("does_not_prove", []),
        "authority": "documentation_routing_only",
    }


def _command_from_hint(command_hint: Any) -> str | None:
    text = str(command_hint or "").strip()
    if not text:
        return None
    tokens = text.replace("`", "").split()
    if "plw" in tokens:
        index = tokens.index("plw")
        if index + 1 < len(tokens):
            return tokens[index + 1].strip().lower().replace("_", "-")
    for token in tokens:
        candidate = token.strip().lower().replace("_", "-")
        if candidate in COMMAND_CONTRACTS:
            return candidate
    return None


def build_work_semantics(
    task: str,
    *,
    goal: str,
    work_status: str,
    preferred_transition: Mapping[str, Any] | None = None,
    target_resolution_state: str | None = None,
    evidence_need_stage: str | None = None,
    capability_selection_stage: str | None = None,
) -> Dict[str, Any]:
    """Describe why PLW mattered and deterministically hand off the next skill read."""
    resolution_state = str(target_resolution_state or "").upper()
    target_grounded = resolution_state in {"RESOLVED", "MULTI_TARGET_RESOLVED"}
    if resolution_state and not target_grounded:
        contract = describe_command("resolve-target")
        orientation = {
            "schema_version": SCHEMA_VERSION,
            "policy": POLICY,
            "current_epistemic_gap": contract.get("epistemic_gap", {}),
            "canonical_concepts": contract.get("canonical_concepts", []),
            "nearest_known_abstractions": contract.get("nearest_known_abstractions", []),
            "different_from": contract.get("different_from", []),
            "expected_information_gain": contract.get("information_gain", []),
            "possible_outcomes_not_predictions": contract.get("possible_outcomes", []),
            "does_not_prove": contract.get("does_not_prove", []),
            "why_not_manual_reasoning": [
                "Task wording can match several files without establishing ownership.",
                "Graph neighborhood and entrypoint/test reachability disambiguate structural relevance.",
                "An unresolved target should block specialized capability selection rather than trigger keyword routing.",
            ],
            "authority": "predictive_semantics_only",
        }
        return {
            "semantic_orientation": orientation,
            "skill_handoff": {
                "required_read": True,
                "required_before_next_capability": True,
                "skill_path": contract.get("read_before_use"),
                "capability": "resolve-target",
                "trigger": "target_resolution_" + resolution_state.lower(),
                "why_read": "Ground the task to bounded graph nodes before any specialized capability is selected.",
                "canonical_concepts": contract.get("canonical_concepts", []),
                "after_read": "resolve or explicitly disambiguate the target, then derive evidence needs; this is not execution authority",
                "authority": "documentation_handoff_only",
            },
        }

    if target_grounded:
        derived = str(evidence_need_stage or "") == "EVIDENCE_NEEDS_DERIVED"
        command = "capability-match" if derived else "evidence-needs"
        contract = describe_command(command)
        selection_done = str(capability_selection_stage or "") == "CAPABILITY_CANDIDATES_PROJECTED"
        epistemic_gap = (
            {
                "before": "Target-grounded evidence requirements and candidate capability mappings are already available.",
                "missing": "The agent has not yet chosen whether any candidate information source is justified, and uncovered evidence needs may still require non-PLW or runtime evidence.",
            }
            if derived and selection_done else contract.get("epistemic_gap", {})
        )
        return {
            "semantic_orientation": {
                "schema_version": SCHEMA_VERSION,
                "policy": POLICY,
                "current_epistemic_gap": epistemic_gap,
                "canonical_concepts": contract.get("canonical_concepts", []),
                "nearest_known_abstractions": contract.get("nearest_known_abstractions", []),
                "different_from": contract.get("different_from", []),
                "expected_information_gain": contract.get("information_gain", []),
                "possible_outcomes_not_predictions": contract.get("possible_outcomes", []),
                "does_not_prove": contract.get("does_not_prove", []),
                "why_not_manual_reasoning": [
                    "A resolved target and explicit evidence gap should drive capability consideration, not task wording.",
                    "Candidate capabilities may be partial or preparatory and must expose uncovered evidence needs.",
                    "Capability projection is advisory information for the agent and never execution authority.",
                ],
                "authority": "predictive_semantics_only",
            },
            "skill_handoff": {
                "required_read": True,
                "required_before_next_capability": True,
                "skill_path": contract.get("read_before_use"),
                "capability": command,
                "trigger": "evidence_needs_derived" if derived else "target_grounded_evidence_gap_stage",
                "why_read": (
                    "Compare explicit evidence classes against registered capability contracts before the agent chooses a call."
                    if derived else
                    "Derive known/unknown/evidence-needed from the grounded target before selecting a specialized capability."
                ),
                "canonical_concepts": contract.get("canonical_concepts", []),
                "after_read": (
                    "inspect candidate information gain and uncovered needs; the agent still chooses whether to call anything"
                    if derived else
                    "derive the evidence needs first; capability matching is a separate stage"
                ),
                "authority": "documentation_handoff_only",
            },
        }

    routed = route_task_semantics(task, goal=goal)
    preferred = preferred_transition or {}
    hinted_command = _command_from_hint(preferred.get("command_hint"))
    hinted_contract = describe_command(hinted_command) if hinted_command else None
    if hinted_contract and hinted_contract.get("known"):
        skill_path = str(hinted_contract["read_before_use"])
        capability = str(hinted_contract["command"])
        trigger = "preferred_proof_transition"
        required = True
        contract = hinted_contract
    else:
        skill_path = str(routed["skill_path"])
        capability = str(routed["capability"])
        trigger = str(routed["selection_source"])
        # A specialized task signal or any recovery state requires an exact read.
        required = work_status == "recovery_required" or trigger == "bounded_task_signal"
        contract = describe_command(capability)

    orientation = {
        "schema_version": SCHEMA_VERSION,
        "policy": POLICY,
        "current_epistemic_gap": contract.get("epistemic_gap", {}),
        "canonical_concepts": contract.get("canonical_concepts", []),
        "nearest_known_abstractions": contract.get("nearest_known_abstractions", []),
        "different_from": contract.get("different_from", []),
        "expected_information_gain": contract.get("information_gain", []),
        "possible_outcomes_not_predictions": contract.get("possible_outcomes", []),
        "does_not_prove": contract.get("does_not_prove", []),
        "why_not_manual_reasoning": [
            "Local context can omit transitive graph or provenance evidence.",
            "A plausible model inference is not equivalent to a tool-grounded witness.",
            "The contract exposes recoverable omissions instead of treating absence as irrelevance.",
        ],
        "authority": "predictive_semantics_only",
    }
    handoff = {
        "required_read": required,
        "required_before_next_capability": required,
        "skill_path": skill_path,
        "capability": capability,
        "trigger": trigger,
        "why_read": (
            "Read this exact module before choosing/invoking the next specialized capability; "
            "it defines the capability's evidence gain, proof limits, and valid transitions."
        ),
        "canonical_concepts": contract.get("canonical_concepts", []),
        "after_read": "decide whether the capability is justified; the handoff is not execution authority",
        "authority": "documentation_handoff_only",
    }
    return {"semantic_orientation": orientation, "skill_handoff": handoff}


__all__ = [
    "SCHEMA_VERSION", "POLICY", "COMMAND_CONTRACTS",
    "describe_command", "route_task_semantics", "build_work_semantics",
]
