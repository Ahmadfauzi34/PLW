"""F117 verifier that turns one F116 receipt into a bounded executable-intent gate.

An open gate proves the exact authorized proposal is eligible for a later executor.
This module never performs the lifecycle transition or any other side effect.
"""
from __future__ import annotations

from typing import Any, Dict, Mapping

from core.accountability_provenance import AUTHORIZATION_ISSUER, GATE_ISSUER, record_provenanced, verify_record
from core.capability_action_authorization import (
    ACCOUNTABILITY_RECORD_KEYS as AUTH_RECORD_KEYS,
    AUTHORITY_CLASS,
    DECISION_TYPE as AUTH_DECISION_TYPE,
    POLICY_VERSION as AUTH_POLICY,
    SCHEMA_VERSION as AUTH_SCHEMA,
    build_action_authorization,
)
from core.capability_contracts import (
    bounded_text,
    exact_keys,
    is_sha256_id,
    no_effect_results,
    no_effect_authorizations,
    normalize_mapping,
    safe_canonical_digest,
)
from core.context_accountability import load_accountability

SCHEMA_VERSION = "capability-workflow-authorized-action-gate-v1"
POLICY_VERSION = "revalidated_authorization_execution_gate_v1"
DECISION_TYPE = "capability_workflow_authorized_action_gate"
_REQUIRED_EFFECTS = {
    "transition_execution", "runtime_execution", "external_patch", "stable_promotion", "truth_commit"
}
_ALLOWED_REQUEST_KEYS = {
    "schema_version", "policy", "authorization_accountability_id", "authorization_request_digest",
    "proposal_request_digest", "capability_id", "caller_requests_execution_gate", "action_kind",
    "target_state", "expected_state", "envelope_evidence_digest", "authority", "authorizations",
}
ACCOUNTABILITY_RECORD_KEYS = frozenset({
    "schema_version", "decision_type", "policy", "gate_open", "decision",
    "failed_conditions", "request_digest", "authorization_accountability_id",
    "authorization_request_digest", "proposal_accountability_id",
    "proposal_request_digest", "capability_id", "workflow_state",
    "workflow_evidence_digest", "executable_intent", "authority_assertion_digest",
    "authorization_principal", "authorization_nonce", "authorization_expires_at_epoch",
    "executor_handoff", "authority", "authorizations", "effects", "invariants",
    "provenance", "decision_id", "recorded_at",
})


def build_gate_request(
    authorization_accountability_id: str,
    authorization_request: Mapping[str, Any] | None,
    proposal_request: Mapping[str, Any] | None,
) -> Dict[str, Any]:
    """Build an explicit gate request. Construction starts no execution."""
    auth_req, _ = normalize_mapping(authorization_request)
    proposal_req, _ = normalize_mapping(proposal_request)
    return {
        "schema_version": SCHEMA_VERSION,
        "policy": POLICY_VERSION,
        "authorization_accountability_id": str(authorization_accountability_id or ""),
        "authorization_request_digest": safe_canonical_digest(auth_req) or "",
        "proposal_request_digest": safe_canonical_digest(proposal_req) or "",
        "capability_id": str(auth_req.get("capability_id") or ""),
        "caller_requests_execution_gate": True,
        "action_kind": str(auth_req.get("action_kind") or ""),
        "target_state": str(auth_req.get("target_state") or ""),
        "expected_state": str(auth_req.get("expected_state") or ""),
        "envelope_evidence_digest": str(auth_req.get("envelope_evidence_digest") or ""),
        "authority": "authorized_action_gate_request_only",
        "authorizations": {key: False for key in sorted(_REQUIRED_EFFECTS)},
    }


def evaluate_authorized_action_gate(
    request: Mapping[str, Any] | None,
    authorization_request: Mapping[str, Any] | None,
    proposal_request: Mapping[str, Any] | None,
    envelope: Mapping[str, Any] | None,
    *,
    store_dir: str | None = None,
) -> Dict[str, Any]:
    """Revalidate an F116 receipt and return a side-effect-free execution gate."""
    req, request_mapping_valid = normalize_mapping(request)
    auth_req, authorization_mapping_valid = normalize_mapping(authorization_request)
    proposal_req, proposal_mapping_valid = normalize_mapping(proposal_request)
    failures: list[str] = []
    if not request_mapping_valid: failures.append("request_mapping")
    if not authorization_mapping_valid: failures.append("authorization_request_mapping")
    if not proposal_mapping_valid: failures.append("proposal_request_mapping")
    unknown = sorted(set(req) - _ALLOWED_REQUEST_KEYS)
    if unknown: failures.append("unknown_request_fields:" + ",".join(unknown))
    if req.get("schema_version") != SCHEMA_VERSION: failures.append("schema_version")
    if req.get("policy") != POLICY_VERSION: failures.append("policy")
    if req.get("caller_requests_execution_gate") is not True: failures.append("caller_requests_execution_gate_is_true")
    if req.get("authority") != "authorized_action_gate_request_only" or not no_effect_authorizations(req.get("authorizations")):
        failures.append("request_has_no_execution_effect")
    authorization_digest = safe_canonical_digest(auth_req)
    proposal_digest = safe_canonical_digest(proposal_req)
    request_digest = safe_canonical_digest(req)
    if authorization_digest is None or req.get("authorization_request_digest") != authorization_digest:
        failures.append("authorization_request_digest")
    if proposal_digest is None or req.get("proposal_request_digest") != proposal_digest:
        failures.append("proposal_request_digest")
    if request_digest is None: failures.append("request_bounded_canonical_json")

    receipt_id = str(req.get("authorization_accountability_id") or "")
    stored: Dict[str, Any] = {}
    if not receipt_id:
        failures.append("authorization_accountability_id")
    elif not is_sha256_id(receipt_id):
        failures.append("authorization_accountability_id")
    else:
        try:
            stored = load_accountability(receipt_id, store_dir=store_dir)
        except (ValueError, FileNotFoundError, OSError, TypeError):
            failures.append("authorization_receipt_record")

    recomputed = build_action_authorization(auth_req, proposal_req, envelope, store_dir=store_dir)
    if recomputed.get("authorization_granted") is not True:
        failures.append("authorization_revalidation_granted")

    if stored:
        grant = stored.get("authorization_grant") if isinstance(stored.get("authorization_grant"), dict) else {}
        required = (
            exact_keys(stored, AUTH_RECORD_KEYS),
            stored.get("schema_version") == AUTH_SCHEMA,
            stored.get("policy") == AUTH_POLICY,
            stored.get("decision_type") == AUTH_DECISION_TYPE,
            stored.get("authorization_granted") is True,
            stored.get("decision") == "ACTION_AUTHORIZATION_GRANTED",
            stored.get("authority") == "workflow_action_authorization_receipt_only",
            no_effect_authorizations(stored.get("authorizations")),
            no_effect_results(stored.get("effects")),
            verify_record(stored, AUTHORIZATION_ISSUER, store_dir=store_dir),
            grant.get("authority_class") == AUTHORITY_CLASS,
            grant.get("scope") == "single_proposal",
            grant.get("granted") is True,
        )
        if not all(required): failures.append("authorization_receipt_contract")
        fields = (
            "request_digest", "proposal_accountability_id", "proposal_request_digest", "capability_id",
            "workflow_state", "workflow_evidence_digest", "authorized_action", "authorization_grant",
            "authority_assertion_digest", "authorization_principal", "authorization_nonce",
            "authorization_expires_at_epoch",
        )
        if any(stored.get(key) != recomputed.get(key) for key in fields):
            failures.append("authorization_revalidation_binding")

    action = recomputed.get("authorized_action") if isinstance(recomputed.get("authorized_action"), dict) else {}
    bindings = (
        (req.get("capability_id"), recomputed.get("capability_id"), "capability_binding"),
        (req.get("action_kind"), action.get("kind"), "action_kind_binding"),
        (req.get("target_state"), action.get("target_state"), "target_state_binding"),
        (req.get("expected_state"), recomputed.get("workflow_state"), "state_binding"),
        (req.get("envelope_evidence_digest"), recomputed.get("workflow_evidence_digest"), "evidence_digest_binding"),
    )
    for requested, verified, label in bindings:
        if requested != verified: failures.append(label)
    for key in ("capability_id", "target_state", "expected_state"):
        if not bounded_text(req.get(key), maximum=128): failures.append(key)
    if not is_sha256_id(req.get("envelope_evidence_digest")): failures.append("envelope_evidence_digest")

    gate_open = not failures
    return {
        "schema_version": SCHEMA_VERSION,
        "decision_type": DECISION_TYPE,
        "policy": POLICY_VERSION,
        "gate_open": gate_open,
        "decision": "AUTHORIZED_ACTION_GATE_OPEN" if gate_open else "AUTHORIZED_ACTION_GATE_CLOSED",
        "failed_conditions": failures,
        "request_digest": request_digest or "",
        "authorization_accountability_id": receipt_id,
        "authorization_request_digest": authorization_digest or "",
        "proposal_accountability_id": recomputed.get("proposal_accountability_id"),
        "proposal_request_digest": proposal_digest or "",
        "capability_id": str(req.get("capability_id") or ""),
        "workflow_state": str(req.get("expected_state") or ""),
        "workflow_evidence_digest": str(req.get("envelope_evidence_digest") or ""),
        "executable_intent": {"kind": str(req.get("action_kind") or ""), "target_state": str(req.get("target_state") or "")},
        "authority_assertion_digest": recomputed.get("authority_assertion_digest"),
        "authorization_principal": recomputed.get("authorization_principal"),
        "authorization_nonce": recomputed.get("authorization_nonce"),
        "authorization_expires_at_epoch": recomputed.get("authorization_expires_at_epoch"),
        "executor_handoff": {
            "required": True,
            "authority_class": AUTHORITY_CLASS,
            "eligible": gate_open,
            "execution_started": False,
        },
        "authority": "workflow_authorized_action_gate_only",
        "authorizations": {key: False for key in sorted(_REQUIRED_EFFECTS)},
        "effects": {
            "transition_executed": False,
            "runtime_executed": False,
            "external_patch_applied": False,
            "stable_promoted": False,
            "truth_committed": False,
        },
        "invariants": {
            "authorization_receipt_revalidation_required": True,
            "single_authorized_proposal_binding": True,
            "open_gate_is_not_execution": True,
            "separate_executor_required": True,
        },
    }


def record_authorized_action_gate(
    request: Mapping[str, Any] | None,
    authorization_request: Mapping[str, Any] | None,
    proposal_request: Mapping[str, Any] | None,
    envelope: Mapping[str, Any] | None,
    *,
    store_dir: str | None = None,
) -> Dict[str, Any]:
    payload = evaluate_authorized_action_gate(request, authorization_request, proposal_request, envelope, store_dir=store_dir)
    receipt = record_provenanced(payload, GATE_ISSUER, store_dir=store_dir)
    return {
        **receipt,
        "decision_type": DECISION_TYPE,
        "gate_open": payload["gate_open"],
        "authority": "workflow_authorized_action_gate_reference_only",
    }


__all__ = [
    "SCHEMA_VERSION", "POLICY_VERSION", "DECISION_TYPE", "ACCOUNTABILITY_RECORD_KEYS",
    "build_gate_request", "evaluate_authorized_action_gate", "record_authorized_action_gate",
]
