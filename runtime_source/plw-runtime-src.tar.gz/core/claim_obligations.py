"""Claim-aware proof obligations for bounded PLW context.

This module does not decide whether a claim is true.  It classifies the kind of
claim the current query is asking the agent to make, then checks whether the
minimum *kind-correct* witnesses are present.  Current source/graph/analyzers
remain authority for the current code snapshot; domain memory is continuity and
historical rationale evidence only.
"""
from __future__ import annotations

import hashlib
import json
import re
from typing import Any, Dict, Iterable, List, Optional, Sequence, Set, Tuple

from core.context_accountability import record_accountability

CLAIM_POLICY = "claim_aware_proof_obligations_v1"
RESPONSIBLE_COMPONENT = "core.claim_obligations.evaluate_claim_obligations"
RESPONSIBLE_ROLE = "claim_obligation_custodian"
_TOKEN_RE = re.compile(r"[A-Za-z0-9_]+")

_HISTORY = {
    "history", "historical", "previous", "previously", "before", "decision", "decisions",
    "reason", "rationale", "prior", "earlier", "past", "remember", "memory",
    "sebelum", "sebelumnya", "dulu", "riwayat", "keputusan", "alasan", "memori", "kenapa",
}
_DEPENDENCY = {
    "dependency", "dependencies", "depends", "dependent", "dependents", "import", "imports",
    "upstream", "downstream", "impact", "reference", "references", "caller", "callers",
    "dependensi", "ketergantungan", "bergantung", "impor", "dampak", "referensi",
}
_ARCHITECTURE = {
    "architecture", "architectural", "topology", "topological", "invariant", "invariants",
    "betti", "cycle", "cycles", "circular", "boundary", "boundaries", "manifold", "sheaf",
    "arsitektur", "topologi", "siklus", "batas", "invarian",
}
_TEST = {
    "test", "tests", "testing", "spec", "specs", "coverage", "reachability", "pytest", "jest",
    "vitest", "unit", "integration", "uji", "pengujian", "cakupan",
}
_RUNTIME_RESULT = {
    "pass", "passes", "passed", "passing", "fail", "fails", "failed", "failing", "green", "red",
    "executed", "execution", "runtime", "actually", "current", "sekarang", "lulus", "gagal", "berhasil",
}
_BEHAVIOR = {
    "behavior", "behaviour", "behaves", "return", "returns", "output", "result", "works", "work",
    "function", "functionality", "perilaku", "fungsi", "hasil", "bekerja", "kerja",
}
_CYCLE = {"cycle", "cycles", "circular", "siklus"}
_BOUNDARY = {"boundary", "boundaries", "batas", "sheaf"}
_BETTI = {"betti", "topology", "topological", "topologi", "manifold", "invariant", "invariants", "invarian"}


def _terms(query: str) -> Set[str]:
    return {token.lower() for token in _TOKEN_RE.findall(query or "")}


def _claim(claim_type: str, confidence: float, cues: Iterable[str], *, hard: bool = True) -> Dict[str, Any]:
    return {
        "type": claim_type,
        "confidence": round(float(confidence), 4),
        "cues": sorted({str(v) for v in cues if v}),
        "hard_obligation": bool(hard),
    }


def classify_claim_intent(query: str) -> Dict[str, Any]:
    terms = _terms(query)
    claims: List[Dict[str, Any]] = []

    history = terms & _HISTORY
    dependency = terms & _DEPENDENCY
    architecture = terms & _ARCHITECTURE
    test = terms & _TEST
    runtime = terms & _RUNTIME_RESULT
    behavior = terms & _BEHAVIOR

    if history:
        claims.append(_claim("historical_rationale", 0.98, history))
    if dependency:
        claims.append(_claim("dependency_structure", 0.95, dependency))
    if architecture:
        claims.append(_claim("architecture_invariant", 0.95, architecture))
    if test:
        if runtime:
            claims.append(_claim("runtime_test_result", 1.0, test | runtime))
        else:
            claims.append(_claim("static_test_structure", 0.92, test))
    if behavior:
        if runtime and not test:
            claims.append(_claim("runtime_behavior", 0.96, behavior | runtime))
        elif not test:
            claims.append(_claim("static_behavior", 0.88, behavior))

    # A bounded current-source fact is the safe default, but do not add it to a
    # purely historical query because the history obligation already requires
    # source precedence through the Truth Floor.
    if not claims:
        claims.append(_claim("current_source_fact", 0.70, ["default_current_source_fact"], hard=False))

    # Stable de-duplication by claim type.
    seen: Set[str] = set()
    unique: List[Dict[str, Any]] = []
    for item in claims:
        if item["type"] not in seen:
            seen.add(item["type"])
            unique.append(item)

    return {
        "schema_version": "claim-intent-v1",
        "query_terms": sorted(terms),
        "claims": unique,
        "invariants": {
            "classification_is_not_truth": True,
            "ambiguous_default_is_advisory_current_source_fact": True,
            "runtime_result_requires_execution_evidence": True,
        },
    }


def _analyzer_hash(value: Dict[str, Any]) -> str:
    payload = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return "sha256:" + hashlib.sha256(payload.encode("utf-8")).hexdigest()


def _resolve_target_paths(pack: Dict[str, Any]) -> List[str]:
    selection = pack.get("selection", {}) or {}
    values = list(selection.get("resolved_targets", []) or [])
    if not values:
        values = list(selection.get("selected_paths", []) or [])[:3]
    return [str(v) for v in values]



def _exact_source_witnesses(pack: Dict[str, Any], targets: Sequence[str]) -> List[Dict[str, Any]]:
    allocation = (pack.get("budget", {}) or {}).get("allocation", {}) or {}
    witnesses = list(allocation.get("source_witnesses", []) or [])
    wanted = set(targets)
    result: List[Dict[str, Any]] = []
    for item in witnesses:
        path = str(item.get("file") or "")
        if wanted and path not in wanted:
            continue
        if int(item.get("included_source_lines", 0) or 0) < 1:
            continue
        result.append({
            "type": "exact_current_source",
            "file": path,
            "included_source_lines": int(item.get("included_source_lines", 0) or 0),
            "candidate_source_lines": int(item.get("candidate_source_lines", 0) or 0),
        })
    return result

def _dependency_witness(shared_graph: Dict[str, Any], targets: Sequence[str]) -> Dict[str, Any]:
    wanted = set(targets)
    edges: List[Dict[str, Any]] = []
    edge_details = shared_graph.get("edge_details", {}) or {}
    for edge in shared_graph.get("edges", []) or []:
        if not isinstance(edge, (list, tuple)) or len(edge) < 2:
            continue
        src, dst = str(edge[0]), str(edge[1])
        if wanted and src not in wanted and dst not in wanted:
            continue
        key_candidates = [f"{src}->{dst}", f"{src}|{dst}", (src, dst)]
        detail: Any = None
        if isinstance(edge_details, dict):
            for key in key_candidates:
                if key in edge_details:
                    detail = edge_details[key]
                    break
        edges.append({"source": src, "target": dst, "detail": detail})

    graph_signature = (shared_graph.get("cache", {}) or {}).get("graph_content_signature")
    return {
        "model": "resolved_relative_import_graph",
        "graph_content_signature": graph_signature,
        "targets": list(targets),
        "incident_edge_count": len(edges),
        "incident_edges": edges[:32],
        "edge_list_truncated": len(edges) > 32,
        "absence_scope": (
            "An incident_edge_count of 0 is evidence only for supported resolved relative-import edges "
            "in this complete graph snapshot; it is not proof of no runtime/dynamic/external dependency."
        ),
    }


def _required_architecture_analyzers(query_terms: Set[str]) -> List[str]:
    required: List[str] = []
    if query_terms & _CYCLE:
        required.extend(["topo.circular", "hott.manifold"])
    if query_terms & _BOUNDARY:
        required.append("hott.sheaf")
    if query_terms & _BETTI:
        required.append("hott.manifold")
    if not required:
        required.extend(["hott.sheaf", "hott.manifold"])
    return list(dict.fromkeys(required))


def _analyzer_witnesses(analyzer_output: Dict[str, Any], analyzer_names: Sequence[str]) -> Tuple[List[Dict[str, Any]], List[str]]:
    results = analyzer_output.get("results", {}) or {}
    succeeded = set(analyzer_output.get("analyzers_succeeded", []) or [])
    witnesses: List[Dict[str, Any]] = []
    missing: List[str] = []
    for name in analyzer_names:
        result = results.get(name)
        if name not in succeeded or not isinstance(result, dict):
            missing.append(name)
            continue
        witnesses.append({
            "analyzer": name,
            "result_sha256": _analyzer_hash(result),
            "summary": result.get("summary", {}),
            "model": result.get("model") or result.get("topological_model"),
        })
    return witnesses, missing


def evaluate_claim_obligations(
    *,
    query: str,
    shared_graph: Dict[str, Any],
    analyzer_output: Dict[str, Any],
    pack: Dict[str, Any],
    truth_floor: Dict[str, Any],
    runtime_attestations: Optional[Sequence[Dict[str, Any]]] = None,
    accountability_store_dir: Optional[str] = None,
) -> Dict[str, Any]:
    intent = classify_claim_intent(query)
    query_terms = set(intent.get("query_terms", []) or [])
    targets = _resolve_target_paths(pack)
    floor_gate = truth_floor.get("claim_gate", {}) or {}
    source_allowed = bool(floor_gate.get("current_source_claims_allowed", True))
    history_allowed = bool(floor_gate.get("historical_or_rationale_claims_allowed", True))

    obligations: List[Dict[str, Any]] = []
    blocked: List[str] = []
    allowed: List[str] = []
    required_transitions: List[Dict[str, Any]] = []

    for request in intent.get("claims", []) or []:
        claim_type = str(request.get("type"))
        hard = bool(request.get("hard_obligation", True))
        satisfied = True
        witnesses: List[Dict[str, Any]] = []
        missing: List[str] = []
        scope_limits: List[str] = []

        if claim_type in {"current_source_fact", "static_behavior"}:
            exact_source = _exact_source_witnesses(pack, targets)
            if source_allowed and exact_source:
                witnesses.extend(exact_source)
            else:
                satisfied = False
                missing.append("exact_current_source_witness")

        elif claim_type == "dependency_structure":
            if not source_allowed:
                satisfied = False
                missing.append("exact_current_source_witness")
            dep = _dependency_witness(shared_graph, targets)
            if dep.get("graph_content_signature") and targets:
                witnesses.append({"type": "dependency_graph", **dep})
                scope_limits.append(dep.get("absence_scope", ""))
            else:
                satisfied = False
                missing.append("stable_dependency_graph_witness")

        elif claim_type == "architecture_invariant":
            if not source_allowed:
                satisfied = False
                missing.append("exact_current_source_witness")
            names = _required_architecture_analyzers(query_terms)
            analyzer_witnesses, analyzer_missing = _analyzer_witnesses(analyzer_output, names)
            witnesses.extend({"type": "current_snapshot_analyzer", **item} for item in analyzer_witnesses)
            if analyzer_missing:
                satisfied = False
                missing.extend(f"analyzer:{name}" for name in analyzer_missing)
            scope_limits.append("Analyzer output is structural/static evidence for the current SharedGraph snapshot, not runtime execution proof.")

        elif claim_type == "static_test_structure":
            analyzer_witnesses, analyzer_missing = _analyzer_witnesses(analyzer_output, ["topo.test_reachability"])
            witnesses.extend({"type": "static_test_reachability", **item} for item in analyzer_witnesses)
            if analyzer_missing:
                satisfied = False
                missing.append("analyzer:topo.test_reachability")
            scope_limits.append("static_test_import_reachability is not runtime statement/branch coverage and does not prove tests passed.")

        elif claim_type == "historical_rationale":
            if history_allowed:
                witnesses.append({
                    "type": "domain_memory_continuity_floor",
                    "status": "satisfied",
                    "current_source_precedence": True,
                    "memory_role": "historical_continuity_not_current_source_authority",
                })
            else:
                satisfied = False
                missing.append("exact_or_verified_historical_memory_witness")
            scope_limits.append("Domain memory can support history/rationale but never overrides current source for current-state claims.")

        elif claim_type in {"runtime_test_result", "runtime_behavior"}:
            # Runtime truth may be discharged only by a scoped, current-snapshot
            # execution attestation. Static analysis and historical memory remain
            # inadmissible substitutes. The attestation is evidence, not a semantic
            # conclusion: exit 0/non-zero must still be interpreted for the claim.
            runtime_witnesses = [
                item for item in (runtime_attestations or [])
                if str(item.get("claim_type") or "") == claim_type
                and item.get("raw_output_recoverable") is True
                and item.get("authority_domain") == "current_runtime_observation"
            ]
            if runtime_witnesses:
                witnesses.extend({"type": "runtime_execution_attestation", **item} for item in runtime_witnesses)
                scope_limits.append(
                    "Runtime attestation proves a scoped execution observation for the current graph snapshot; "
                    "it does not by itself infer universal behavioral correctness."
                )
            else:
                satisfied = False
                missing.append("current_runtime_execution_evidence")
                scope_limits.append("Static source, graph/analyzers, and domain memory cannot prove a current runtime result.")
                required_transitions.append({
                    "type": "obtain_runtime_validation",
                    "claim_type": claim_type,
                    "command": (
                        "Run the narrowest relevant test/runtime command, preserve stdout/stderr with "
                        "`plw compact-output --command '<command>'`, then bind it with "
                        "`plw attest-runtime <output-id> --exit-code <code> --command '<command>' "
                        "--claim <runtime-claim> --root . --target <file>`."
                    ),
                })

        if not satisfied and claim_type not in {"runtime_test_result", "runtime_behavior"}:
            if claim_type == "dependency_structure":
                required_transitions.append({
                    "type": "recover_dependency_witness",
                    "claim_type": claim_type,
                    "command": "plw context <dependency-query> . --target <file> --budget <larger-N>",
                })
            elif claim_type == "architecture_invariant":
                required_transitions.append({
                    "type": "recover_architecture_analyzer_witness",
                    "claim_type": claim_type,
                    "command": "plw check . --json",
                })
            else:
                required_transitions.extend(truth_floor.get("required_transitions", []) or [])

        obligations.append({
            "claim_type": claim_type,
            "confidence": request.get("confidence"),
            "cues": request.get("cues", []),
            "hard_obligation": hard,
            "satisfied": bool(satisfied),
            "witnesses": witnesses,
            "missing": sorted(set(missing)),
            "scope_limits": [value for value in scope_limits if value],
        })
        if satisfied:
            allowed.append(claim_type)
        elif hard:
            blocked.append(claim_type)

    # Stable de-dup transitions; commands can repeat when multiple claims share a floor.
    transition_seen: Set[str] = set()
    transitions: List[Dict[str, Any]] = []
    for item in required_transitions:
        key = json.dumps(item, ensure_ascii=False, sort_keys=True)
        if key not in transition_seen:
            transition_seen.add(key)
            transitions.append(item)

    status = "recovery_required" if blocked else "satisfied"
    decision = {
        "decision_type": "claim_aware_proof_obligations",
        "responsible_component": RESPONSIBLE_COMPONENT,
        "responsible_role": RESPONSIBLE_ROLE,
        "policy": CLAIM_POLICY,
        "input_state": {
            "query_fingerprint": "sha256:" + hashlib.sha256((query or "").encode("utf-8")).hexdigest(),
            "graph_content_signature": (shared_graph.get("cache", {}) or {}).get("graph_content_signature"),
            "truth_floor_decision_id": (truth_floor.get("ledger", {}) or {}).get("id"),
            "context_decision_id": (pack.get("accountability", {}) or {}).get("ledger", {}).get("id"),
            "target_paths": targets,
        },
        "requested_claims": [item.get("type") for item in intent.get("claims", []) or []],
        "allowed_claims": allowed,
        "blocked_claims": blocked,
        "proof_obligations": obligations,
        "required_transitions": transitions,
        "memory_contract": {
            "role": "continuity_history_and_procedural_evidence",
            "cannot_satisfy_current_runtime_result": True,
            "cannot_override_current_source": True,
            "historical_claims_require_truth_floor_memory_witness": True,
        },
        "invariants": {
            "claim_gate_does_not_assert_truth": True,
            "witness_kind_must_match_claim_kind": True,
            "static_test_reachability_is_not_test_execution": True,
            "runtime_claims_require_current_execution_evidence": True,
            "runtime_execution_evidence_must_be_scoped_and_snapshot_bound": True,
            "runtime_attestation_does_not_infer_semantic_correctness": True,
            "memory_is_not_current_runtime_authority": True,
        },
    }
    ledger = record_accountability(decision, store_dir=accountability_store_dir)
    return {
        "schema_version": "claim-obligations-v1",
        "policy": CLAIM_POLICY,
        "responsible_component": RESPONSIBLE_COMPONENT,
        "responsible_role": RESPONSIBLE_ROLE,
        "authority": "proof_obligation_gate_only",
        "status": status,
        "requested_claims": decision["requested_claims"],
        "allowed_claims": allowed,
        "blocked_claims": blocked,
        "proof_obligations": obligations,
        "required_transitions": transitions,
        "memory_contract": decision["memory_contract"],
        "ledger": ledger,
        "invariants": decision["invariants"],
    }


def claim_guard_prompt(claim_gate: Dict[str, Any]) -> str:
    blocked = claim_gate.get("blocked_claims", []) or []
    lines = [
        "[CLAIM PROOF OBLIGATION UNSATISFIED]",
        "The bounded evidence below may still be useful, but do not assert the blocked claim type(s) yet.",
        f"blocked_claims={','.join(str(v) for v in blocked) or 'none'}",
        "A matching witness type is required; do not substitute memory/static analysis for runtime evidence.",
    ]
    for transition in (claim_gate.get("required_transitions", []) or [])[:4]:
        lines.append(f"RECOVER {transition.get('type')}: {transition.get('command')}")
    ledger = claim_gate.get("ledger", {}) or {}
    if ledger.get("id"):
        lines.append(f"AUDIT=plw accountability {ledger.get('id')}")
    return "\n".join(lines) + "\n\n"


__all__ = [
    "CLAIM_POLICY",
    "classify_claim_intent",
    "evaluate_claim_obligations",
    "claim_guard_prompt",
]
