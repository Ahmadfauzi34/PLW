"""Binary-safe PLW runtime path resolution.

Mutable state and caches must never default beside the executable/source tree or
inside the analyzed target repository.  PLW_HOME is the explicit portable
operator override; otherwise XDG locations are used with user-home fallbacks.
"""
from __future__ import annotations

import os
from pathlib import Path
from typing import Iterable


def _clean_env(name: str) -> str | None:
    value = os.environ.get(name)
    if value is None:
        return None
    value = value.strip()
    return value or None


def plw_home() -> Path | None:
    value = _clean_env("PLW_HOME")
    return Path(value).expanduser().resolve() if value else None


def state_root() -> Path:
    explicit = _clean_env("PLW_STATE_HOME")
    if explicit:
        return Path(explicit).expanduser().resolve()
    home = plw_home()
    if home is not None:
        return (home / "state").resolve()
    xdg = _clean_env("XDG_STATE_HOME")
    base = Path(xdg).expanduser() if xdg else Path.home() / ".local" / "state"
    return (base / "plw").resolve()


def cache_root() -> Path:
    explicit = _clean_env("PLW_CACHE_HOME")
    if explicit:
        return Path(explicit).expanduser().resolve()
    home = plw_home()
    if home is not None:
        return (home / "cache").resolve()
    xdg = _clean_env("XDG_CACHE_HOME")
    base = Path(xdg).expanduser() if xdg else Path.home() / ".cache"
    return (base / "plw").resolve()


def state_path(*parts: str) -> Path:
    return state_root().joinpath(*parts)


def cache_path(*parts: str) -> Path:
    return cache_root().joinpath(*parts)


def ensure_private_directory(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True, mode=0o700)
    try:
        os.chmod(path, 0o700)
    except OSError:
        pass
    return path


__all__ = [
    "plw_home",
    "state_root",
    "cache_root",
    "state_path",
    "cache_path",
    "ensure_private_directory",
]
