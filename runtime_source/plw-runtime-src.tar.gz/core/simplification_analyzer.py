"""Proof-guided structural simplification analysis over canonical PLW anatomy.

This module does not rewrite code. Python rules use AST witnesses; TS/JS rules
consume the same SharedGraph source snapshot through bounded lexical witnesses.
Behavioral equivalence remains a separate proof obligation.
"""
from __future__ import annotations

import ast
import hashlib
import json
import os
import re
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

SIMPLIFICATION_SCHEMA_VERSION = "self-simplification-v13-js-frontend-reuse"
DEFAULT_IGNORES = {
    ".git", "__pycache__", "data", "node_modules", "dist", "coverage",
}


def _sha(value: str) -> str:
    return f"sha256:{hashlib.sha256(value.encode('utf-8')).hexdigest()}"


def _graph_signature(graph: Dict[str, Any]) -> str:
    from core.shared_graph import graph_content_signature
    return graph_content_signature(graph)


def _canonical_language_inventory(graph: Dict[str, Any]) -> Dict[str, Any]:
    """Describe reference coverage separately from semantic-rule coverage."""
    suffix_counts = {".ts": 0, ".tsx": 0, ".js": 0, ".jsx": 0, ".py": 0}
    for raw_path in graph.get("vertices", []) or []:
        path = str(raw_path)
        for suffix in suffix_counts:
            if path.endswith(suffix):
                suffix_counts[suffix] += 1
                break
    observed = [suffix for suffix, count in suffix_counts.items() if count]
    semantic_frontends = {
        ".py": "python_ast",
        ".ts": "js_lexical_v1_try_catch_terminal_return",
        ".tsx": "js_lexical_v1_try_catch_terminal_return",
        ".js": "js_lexical_v1_try_catch_terminal_return",
        ".jsx": "js_lexical_v1_try_catch_terminal_return",
    }
    uncovered = [suffix for suffix in observed if suffix not in semantic_frontends]
    python_count = suffix_counts[".py"]
    return {
        "reference_source_counts": suffix_counts,
        "reference_observed_extensions": observed,
        "semantic_rule_frontends": semantic_frontends,
        "reference_covered_but_semantic_rules_pending": uncovered,
        "zero_candidate_is_clean_evidence": not (python_count == 0 and bool(uncovered)),
        "zero_candidate_interpretation": (
            "NOT_CLEAN_EVIDENCE_SEMANTIC_FRONTEND_UNAVAILABLE"
            if python_count == 0 and uncovered
            else "CANDIDATE_RESULT_APPLIES_TO_ACTIVE_SEMANTIC_FRONTEND_ONLY"
        ),
    }


JS_SEMANTIC_EXTENSIONS = (".ts", ".tsx", ".js", ".jsx")


def _canonical_js_source_snapshot(graph: Dict[str, Any], root: Path) -> List[Tuple[str, str, str]]:
    """Return stable TS/JS source plus one shared length-preserving code mask."""
    file_map = graph.get("file_map", {}) or {}
    rows: List[Tuple[str, str, str]] = []
    for raw_path in graph.get("vertices", []) or []:
        path = str(raw_path)
        source = file_map.get(raw_path)
        if path.endswith(JS_SEMANTIC_EXTENSIONS) and isinstance(source, str):
            rows.append((_relative_graph_path(path, root), source, _mask_js_noncode(source)))
    rows.sort(key=lambda row: row[0])
    return rows


def _mask_js_noncode(source: str) -> str:
    """Length-preserving conservative mask for comments and string/template literals."""
    out, i, n = list(source), 0, len(source)
    while i < n:
        c = source[i]
        if c == "/" and i + 1 < n and source[i + 1] in ("/", "*"):
            block = source[i + 1] == "*"
            out[i] = out[i + 1] = " "
            i += 2
            while i < n:
                if block and source[i] == "*" and i + 1 < n and source[i + 1] == "/":
                    out[i] = out[i + 1] = " "; i += 2; break
                if not block and source[i] == "\n":
                    break
                if source[i] != "\n":
                    out[i] = " "
                i += 1
            continue
        if c in ("'", '"', "`"):
            quote, escaped = c, False
            out[i] = " "; i += 1
            while i < n:
                ch = source[i]
                if ch != "\n":
                    out[i] = " "
                if escaped:
                    escaped = False
                elif ch == "\\":
                    escaped = True
                elif ch == quote:
                    i += 1; break
                i += 1
            continue
        i += 1
    return "".join(out)


def _matching_js_brace(masked: str, start: int) -> int:
    if start < 0 or start >= len(masked) or masked[start] != "{":
        return -1
    depth = 0
    for idx, char in enumerate(masked[start:], start):
        depth += char == "{"
        depth -= char == "}"
        if depth == 0:
            return idx
    return -1


def _js_nonthrowing_literal(expr: str) -> bool:
    value = expr.strip()
    if re.fullmatch(r"(?:true|false|null)|[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?", value):
        return True
    if len(value) < 2 or value[0] != value[-1] or value[0] not in ("'", '"', "`"):
        return False
    return "\n" not in value and "\r" not in value and (value[0] != "`" or "${" not in value)


def _terminal_js_return(source: str, masked: str, body_start: int, body_end: int) -> Optional[Dict[str, Any]]:
    segment = masked[body_start:body_end]
    match = re.search(r"\breturn\b(?P<expr>[^;{}]*)\;\s*$", segment, flags=re.S)
    if not match or re.search(r"\breturn\b", segment[:match.start()]):
        return None
    raw_expr = source[body_start + match.start("expr"):body_start + match.end("expr")].strip()
    if not _js_nonthrowing_literal(raw_expr):
        return None
    return {"expression": raw_expr, "expression_fingerprint": _sha(raw_expr)}


def _enclosing_js_function_name(masked: str, position: int) -> str:
    pattern = re.compile(r"(?:async\s+)?function\s+([A-Za-z_$][A-Za-z0-9_$]*)\s*\([^)]*\)\s*(?:\:[^{]+)?\{")
    candidates = []
    for match in pattern.finditer(masked, 0, position):
        close = _matching_js_brace(masked, masked.find("{", match.start(), match.end()))
        if close >= position:
            candidates.append((close, match.group(1)))
    return candidates[-1][1] if candidates else "<local-try-catch>"


def _js_candidate_row(
    *, rel: str, masked: str, position: int, line_start: int, line_end: int,
    kind: str, identity: Dict[str, Any], witness: Dict[str, Any], proof_rule: str,
    validation: List[str],
) -> Dict[str, Any]:
    name = _enclosing_js_function_name(masked, position)
    return _candidate(
        identity={"file": rel, "kind": kind, "function": name, "line": line_start, **identity},
        kind=kind, files=[rel], names=[name],
        members=[_member(rel, name, line_start, line_end, private=True)], estimated_loc=1,
        witness=witness, proof_rule=proof_rule, validation=validation,
    )


def _js_try_catch_terminal_return_candidates(*, sources: List[Tuple[str, str, str]]) -> List[Dict[str, Any]]:
    """Find identical non-throwing terminal returns in one try/catch pair."""
    candidates: List[Dict[str, Any]] = []
    for rel, source, masked in sources:
        for match in re.finditer(r"\btry\s*\{", masked):
            try_open = masked.find("{", match.start(), match.end())
            try_close = _matching_js_brace(masked, try_open)
            if try_close < 0:
                continue
            cursor = try_close + 1
            while cursor < len(masked) and masked[cursor].isspace(): cursor += 1
            catch_match = re.match(r"catch\s*(?:\([^)]*\))?\s*\{", masked[cursor:])
            if not catch_match:
                continue
            catch_open = cursor + catch_match.group(0).rfind("{")
            catch_close = _matching_js_brace(masked, catch_open)
            if catch_close < 0:
                continue
            after = catch_close + 1
            while after < len(masked) and masked[after].isspace(): after += 1
            if masked.startswith("finally", after) or "/" in masked[try_open + 1:catch_close]:
                continue
            try_ret = _terminal_js_return(source, masked, try_open + 1, try_close)
            catch_ret = _terminal_js_return(source, masked, catch_open + 1, catch_close)
            if not try_ret or not catch_ret or try_ret["expression"] != catch_ret["expression"]:
                continue
            line_start = source.count("\n", 0, match.start()) + 1
            line_end = source.count("\n", 0, catch_close) + 1
            candidates.append(_js_candidate_row(
                rel=rel, masked=masked, position=match.start(), line_start=line_start, line_end=line_end,
                kind="js_try_catch_identical_terminal_return",
                identity={"expr": try_ret["expression_fingerprint"]},
                witness={
                    "type": "js_try_catch_identical_terminal_return_v1",
                    "same_owner_file": True, "terminal_return_expression_identical": True,
                    "return_expression_nonthrowing_literal": True,
                    "return_expression_fingerprint": try_ret["expression_fingerprint"],
                    "try_prefix_preserved": True, "catch_prefix_preserved": True,
                    "catch_boundary_preserved": True, "finally_absent": True,
                    "prior_return_absent_in_try_and_catch_prefix": True,
                    "regex_or_division_token_absent_in_candidate_span": True,
                    "authority": "bounded_js_lexical_control_flow_witness_only",
                },
                proof_rule="hoist only the identical non-throwing terminal return after try/catch while preserving both prefixes and the catch boundary",
                validation=[
                    "preserve try-prefix side effects and await ordering",
                    "preserve catch exception swallowing and catch-prefix side effects",
                    "do not move a potentially throwing return expression outside the catch boundary",
                    "run affected TS/Angular tests and reference-machine topology/context checks",
                ],
            ))
    return candidates


def _js_terminal_literal_temporary_candidates(*, sources: List[Tuple[str, str, str]]) -> List[Dict[str, Any]]:
    """Find a terminal ``const x = <literal>; return x;`` using the shared mask."""
    candidates: List[Dict[str, Any]] = []
    pattern = re.compile(
        r"\bconst\s+(?P<name>[A-Za-z_$][A-Za-z0-9_$]*)(?:\s*:\s*[^=;{}]+)?\s*=(?P<expr>[^;{}]+);"
        r"\s*return\s+(?P=name)\s*;"
    )
    for rel, source, masked in sources:
        for match in pattern.finditer(masked):
            after = match.end()
            while after < len(masked) and masked[after].isspace(): after += 1
            if after >= len(masked) or masked[after] != "}":
                continue
            raw_expr = source[match.start("expr"):match.end("expr")].strip()
            if not _js_nonthrowing_literal(raw_expr):
                continue
            name = match.group("name")
            line_start = source.count("\n", 0, match.start()) + 1
            line_end = source.count("\n", 0, match.end()) + 1
            candidates.append(_js_candidate_row(
                rel=rel, masked=masked, position=match.start(), line_start=line_start, line_end=line_end,
                kind="js_terminal_literal_temporary",
                identity={"binding": name, "expr": _sha(raw_expr)},
                witness={
                    "type": "js_terminal_literal_temporary_v1", "same_owner_file": True,
                    "adjacent_assignment_return": True, "const_binding": True,
                    "returned_name_matches_assignment": True, "return_expression_nonthrowing_literal": True,
                    "terminal_return_in_same_block": True, "shared_mask_js_noncode_reused": True,
                    "shared_nonthrowing_literal_predicate_reused": True, "shared_function_labeling_reused": True,
                    "authority": "bounded_js_lexical_terminal_temporary_witness_only",
                },
                proof_rule="inline only an adjacent terminal const bound to a non-throwing literal into its return statement",
                validation=[
                    "preserve literal value and return ordering",
                    "do not inline calls/member access/object literals or other potentially throwing expressions",
                    "do not claim debugger/line-event equivalence",
                    "run affected TS/Angular tests when applying a target patch",
                ],
            ))
    return candidates

def _canonical_python_source_snapshot(root: Path) -> Tuple[Dict[str, Any], List[Tuple[str, str]]]:
    """Return Python sources from the canonical SharedGraph discovery snapshot.

    Simplification owns semantic rules, not filesystem discovery.  The graph
    builder is therefore the single source inventory/content authority.  This
    keeps the Python self-host frontend aligned with the same ownership and
    topology snapshot used by the rest of PLW and avoids a second scan/read
    path inside the simplifier.
    """
    from core.shared_graph import DEFAULT_IGNORE_DIRS as GRAPH_DEFAULT_IGNORE_DIRS
    from core.shared_graph import build_shared_graph

    ignored = set(GRAPH_DEFAULT_IGNORE_DIRS) | set(DEFAULT_IGNORES)
    graph = build_shared_graph(
        str(root),
        ignore_dirs=ignored,
        include_tool_source=True,
    )
    file_map = graph.get("file_map", {}) or {}
    sources: List[Tuple[str, str]] = []
    for raw_path in graph.get("vertices", []) or []:
        path = str(raw_path)
        if not path.endswith(".py"):
            continue
        source = file_map.get(raw_path)
        if not isinstance(source, str):
            continue
        sources.append((_relative_graph_path(path, root), source))
    sources.sort(key=lambda row: row[0])
    return graph, sources


def _relative(path: Path, root: Path) -> str:
    return path.resolve().relative_to(root.resolve()).as_posix()


def _without_docstring(body: List[ast.stmt]) -> List[ast.stmt]:
    if body:
        first = body[0]
        if (
            isinstance(first, ast.Expr)
            and isinstance(first.value, ast.Constant)
            and isinstance(first.value.value, str)
        ):
            return body[1:]
    return body


def _function_body_fingerprint(node: ast.AST) -> str:
    body = _without_docstring(list(getattr(node, "body", [])))
    normalized = ast.dump(
        ast.Module(body=body, type_ignores=[]),
        include_attributes=False,
        annotate_fields=True,
    )
    return _sha(normalized)


def _signature(node: ast.FunctionDef | ast.AsyncFunctionDef) -> str:
    return ast.unparse(node.args) if hasattr(ast, "unparse") else node.name


def _member(rel: str, name: str, start: int, end: int, *, private: Optional[bool] = None) -> Dict[str, Any]:
    return {
        "file": rel, "name": name, "line_start": int(start), "line_end": int(end),
        "loc": int(end) - int(start) + 1, "private": name.startswith("_") if private is None else bool(private),
    }


def _candidate(
    *, identity: Dict[str, Any], kind: str, files: List[str], names: List[str],
    members: List[Dict[str, Any]], estimated_loc: int, witness: Dict[str, Any],
    proof_rule: str, validation: List[str], duplicate_loc: int = 0,
) -> Dict[str, Any]:
    """Canonical candidate envelope shared by semantic simplification rules."""
    return {
        "candidate_id": _sha(json.dumps(identity, sort_keys=True)),
        "kind": kind, "files": files, "names": names, "members": members,
        "member_count": len(members), "estimated_removable_loc": int(estimated_loc),
        "estimated_removable_duplicate_loc": int(duplicate_loc),
        "semantic_witness": witness,
        "proof_obligation": {"required": True, "rule": proof_rule, "validation": validation},
    }


def _complexity_metrics(tree: ast.AST) -> Dict[str, int]:
    counters = {
        "ast_nodes": 0,
        "branches": 0,
        "loops": 0,
        "try_blocks": 0,
        "functions": 0,
        "classes": 0,
    }
    for node in ast.walk(tree):
        counters["ast_nodes"] += 1
        if isinstance(node, (ast.If, ast.IfExp, ast.Match)):
            counters["branches"] += 1
        elif isinstance(node, (ast.For, ast.AsyncFor, ast.While)):
            counters["loops"] += 1
        elif isinstance(node, ast.Try):
            counters["try_blocks"] += 1
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            counters["functions"] += 1
        elif isinstance(node, ast.ClassDef):
            counters["classes"] += 1
    return counters




def _pure_local_constant_condition(node: ast.AST) -> bool:
    """Return True only for conservative side-effect-free branch predicates.

    V1 intentionally accepts only local-name comparisons against literal
    constants/containers.  Removing such a condition cannot suppress a call,
    attribute access, subscription, or user-defined coercion performed by the
    predicate itself.
    """
    if not isinstance(node, ast.Compare) or len(node.ops) != 1 or len(node.comparators) != 1:
        return False
    if not isinstance(node.left, ast.Name):
        return False
    right = node.comparators[0]
    if isinstance(node.ops[0], (ast.Eq, ast.NotEq, ast.Is, ast.IsNot)):
        return isinstance(right, ast.Constant)
    if isinstance(node.ops[0], (ast.In, ast.NotIn)) and isinstance(right, (ast.Tuple, ast.List, ast.Set)):
        return all(isinstance(item, ast.Constant) for item in right.elts)
    return False




def _function_parameters(node: ast.FunctionDef | ast.AsyncFunctionDef) -> Optional[List[str]]:
    """Return simple positional parameter names or None for complex signatures.

    Forwarding-wrapper V1 intentionally excludes defaults, keyword-only
    parameters, varargs and kwargs.  This makes one-to-one argument forwarding
    mechanically checkable without reasoning about call binding semantics.
    """
    args = node.args
    if args.vararg is not None or args.kwarg is not None or args.kwonlyargs:
        return None
    if args.defaults or args.kw_defaults:
        return None
    return [arg.arg for arg in [*args.posonlyargs, *args.args]]


def _direct_forward_call_witness(
    fn: ast.FunctionDef | ast.AsyncFunctionDef,
    body: List[ast.stmt],
) -> Optional[Dict[str, Any]]:
    """Return a mechanical witness for a pure direct forwarding wrapper.

    V1 accepts exactly one `return callee(p1, ..., pn)` statement where the
    callee is a direct Name and every simple positional parameter is forwarded
    once, in order, without constants, transformations or keyword injection.
    """
    params = _function_parameters(fn)
    if params is None or len(body) != 1:
        return None
    stmt = body[0]
    if not isinstance(stmt, ast.Return) or not isinstance(stmt.value, ast.Call):
        return None
    call = stmt.value
    if not isinstance(call.func, ast.Name) or call.func.id == fn.name:
        return None
    if call.keywords or len(call.args) != len(params):
        return None
    forwarded: List[str] = []
    for expected, arg in zip(params, call.args):
        if not isinstance(arg, ast.Name) or arg.id != expected:
            return None
        forwarded.append(arg.id)
    return {
        "callee": call.func.id,
        "parameters": params,
        "forwarded_arguments": forwarded,
        "argument_forwarding_exact": True,
        "call_transformations_present": False,
    }


def _forwarding_wrapper_candidates(*, trees: List[Tuple[str, ast.AST]]) -> List[Dict[str, Any]]:
    """Find mechanically witnessed direct forwarding wrappers.

    Private wrappers can be simplification candidates when their proof surface
    is local.  Public wrappers are surfaced as structural debt but are deferred
    because the callable name itself may be a compatibility/API contract.
    """
    candidates: List[Dict[str, Any]] = []
    for rel, tree in trees:
        for fn in ast.walk(tree):
            if not isinstance(fn, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            body = _without_docstring(list(fn.body))
            witness = _direct_forward_call_witness(fn, body)
            if witness is None:
                continue
            start = int(fn.lineno)
            end = int(getattr(fn, "end_lineno", fn.lineno))
            private = fn.name.startswith("_")
            witness_payload = {
                "file": rel,
                "function": fn.name,
                "callee": witness["callee"],
                "parameters": witness["parameters"],
                "private": private,
            }
            candidates.append(_candidate(
                identity=witness_payload, kind="direct_forwarding_wrapper", files=[rel], names=[fn.name],
                members=[_member(rel, fn.name, start, end, private=private)], estimated_loc=max(1, end - start + 1),
                witness={"type": "direct_parameter_forwarding_wrapper", **witness, "wrapper_private": private,
                         "public_surface_contract_risk": not private, "authority": "syntactic_local_forwarding_witness_only"},
                proof_rule="remove only after all local wrapper call sites are redirected to the witnessed callee",
                validation=["preserve public callable surface; public wrappers defer by default",
                            "re-run affected context/kernel fixtures", "re-run kernel CLI/integration smoke",
                            "compare against stable reference contract"],
            ))
    return candidates



def _sequence_control_transfer_free(statements: List[ast.stmt]) -> bool:
    """Conservative witness for helper-extractable direct statement sequences.

    V1 permits ordinary assignments and nested local loops/branches, but rejects
    control transfer, scope mutation, async suspension, imports and nested
    definitions.  This proves only that the repeated block has the same AST and
    no obvious non-local control transfer; helper extraction still requires
    regression/reference validation because the call frame changes.
    """
    banned = (
        ast.Return, ast.Raise, ast.Break, ast.Continue,
        ast.Yield, ast.YieldFrom, ast.Await,
        ast.Global, ast.Nonlocal,
        ast.Import, ast.ImportFrom,
        ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef,
    )
    return not any(isinstance(node, banned) for stmt in statements for node in ast.walk(stmt))


def _sequence_name_flow(statements: List[ast.stmt]) -> Dict[str, List[str]]:
    loaded: set[str] = set()
    stored: set[str] = set()
    for stmt in statements:
        for node in ast.walk(stmt):
            if isinstance(node, ast.Name):
                if isinstance(node.ctx, ast.Load):
                    loaded.add(node.id)
                elif isinstance(node.ctx, (ast.Store, ast.Del)):
                    stored.add(node.id)
    return {
        "loaded_names": sorted(loaded),
        "assigned_names": sorted(stored),
        "external_name_candidates": sorted(loaded - stored),
    }


def _direct_body_sequence_windows(
    fn: ast.FunctionDef | ast.AsyncFunctionDef,
    *,
    min_statements: int = 3,
    max_statements: int = 8,
) -> List[Dict[str, Any]]:
    body = _without_docstring(list(fn.body))
    rows: List[Dict[str, Any]] = []
    max_len = min(max_statements, len(body))
    for length in range(max_len, min_statements - 1, -1):
        for offset in range(0, len(body) - length + 1):
            statements = body[offset:offset + length]
            if not _sequence_control_transfer_free(statements):
                continue
            normalized = ast.dump(
                ast.Module(body=statements, type_ignores=[]),
                include_attributes=False,
                annotate_fields=True,
            )
            start = int(statements[0].lineno)
            end = int(getattr(statements[-1], "end_lineno", statements[-1].lineno))
            rows.append({
                "function": fn.name,
                "function_private": fn.name.startswith("_"),
                "offset": offset,
                "statement_count": length,
                "line_start": start,
                "line_end": end,
                "loc_span": end - start + 1,
                "normalized_ast": normalized,
                "sequence_fingerprint": _sha(normalized),
                "name_flow": _sequence_name_flow(statements),
            })
    return rows


def _repeated_statement_sequence_candidates(*, trees: List[Tuple[str, ast.AST]]) -> List[Dict[str, Any]]:
    """Find exact direct-body statement sequences repeated across functions in one owner.

    The detector is intentionally owner-local.  It never proposes cross-file
    extraction, and it does not claim helper extraction is behaviorally
    equivalent merely because statement ASTs match.
    """
    candidates: List[Dict[str, Any]] = []
    for rel, tree in trees:
        top_level_functions = [
            node for node in getattr(tree, "body", [])
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
        ]
        grouped: Dict[str, List[Dict[str, Any]]] = {}
        for fn in top_level_functions:
            for row in _direct_body_sequence_windows(fn):
                grouped.setdefault(row["sequence_fingerprint"], []).append(row)

        raw: List[Dict[str, Any]] = []
        for fingerprint, occurrences in grouped.items():
            distinct_functions = sorted({row["function"] for row in occurrences})
            if len(distinct_functions) < 2:
                continue
            # One occurrence per function is sufficient for V1 and avoids
            # inflating support when a function repeats the same sequence twice.
            chosen: List[Dict[str, Any]] = []
            seen_functions: set[str] = set()
            for row in sorted(occurrences, key=lambda r: (r["function"], r["line_start"])):
                if row["function"] in seen_functions:
                    continue
                seen_functions.add(row["function"])
                chosen.append(row)
            if len(chosen) < 2:
                continue
            statement_count = int(chosen[0]["statement_count"])
            min_span = min(int(row["loc_span"]) for row in chosen)
            repeated_span_total = sum(int(row["loc_span"]) for row in chosen)
            estimated_helper_loc = min_span + 2  # def/signature + conservative return/packing allowance
            estimated_callsite_loc = len(chosen)
            estimated_net_reduction = max(
                0,
                repeated_span_total - estimated_helper_loc - estimated_callsite_loc,
            )
            name_flow = chosen[0]["name_flow"]
            witness_payload = {
                "file": rel,
                "functions": sorted(row["function"] for row in chosen),
                "sequence_fingerprint": fingerprint,
                "statement_count": statement_count,
            }
            raw.append(_candidate(
                identity=witness_payload, kind="repeated_direct_statement_sequence", files=[rel],
                names=sorted(row["function"] for row in chosen),
                members=[_member(rel, row["function"], row["line_start"], row["line_end"],
                                 private=row["function_private"]) for row in chosen],
                estimated_loc=estimated_net_reduction,
                witness={"type": "same_owner_exact_direct_statement_sequence", "same_owner_file": True,
                         "direct_function_body_only": True, "repeated_sequence_ast_identical": True,
                         "control_transfer_free_under_v1": True, "statement_count": statement_count,
                         "occurrence_count": len(chosen), "sequence_fingerprint": fingerprint,
                         "repeated_span_total_loc": repeated_span_total, "estimated_helper_loc": estimated_helper_loc,
                         "estimated_callsite_loc": estimated_callsite_loc,
                         "estimated_net_loc_reduction": estimated_net_reduction,
                         "estimate_is_structural_not_codegen": True, **name_flow,
                         "helper_extraction_changes_call_frame": True,
                         "authority": "syntactic_repeated_sequence_witness_only"},
                proof_rule="extract only to a private same-owner helper with explicit inputs/outputs and preserve every occurrence",
                validation=["preserve public function signatures", "preserve occurrence count and execution order",
                            "re-run affected domain fixtures", "re-run kernel CLI/integration smoke",
                            "compare against stable reference contract"],
            ))

        # Keep maximal representatives.  Sub-windows with the same occurrence
        # function set and wholly-contained source ranges add noise but no new
        # simplification information.
        raw.sort(key=lambda row: (-int(row["semantic_witness"]["statement_count"]), -int(row["member_count"]), row["candidate_id"]))
        accepted: List[Dict[str, Any]] = []
        for row in raw:
            functions = tuple(row["names"])
            contained = False
            for previous in accepted:
                if tuple(previous["names"]) != functions:
                    continue
                previous_by_name = {m["name"]: m for m in previous["members"]}
                if all(
                    previous_by_name[m["name"]]["line_start"] <= m["line_start"]
                    and previous_by_name[m["name"]]["line_end"] >= m["line_end"]
                    for m in row["members"]
                ):
                    contained = True
                    break
            if not contained:
                accepted.append(row)
        candidates.extend(accepted)
    return candidates




def _iter_statement_blocks(node: ast.AST) -> Iterable[List[ast.stmt]]:
    """Yield statement lists inside one function without crossing nested scopes."""
    for field_name, value in ast.iter_fields(node):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.Lambda)) and field_name != "body":
            continue
        if isinstance(value, list) and value and all(isinstance(item, ast.stmt) for item in value):
            yield value
            for item in value:
                if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                    continue
                yield from _iter_statement_blocks(item)
        elif isinstance(value, ast.AST):
            if isinstance(value, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef, ast.Lambda)):
                continue
            yield from _iter_statement_blocks(value)


def _terminal_temporary_candidates(*, trees: List[Tuple[str, ast.AST]]) -> List[Dict[str, Any]]:
    """Find adjacent ``name = expr; return name`` inside one function/block.

    The witness is intentionally syntactic.  It proves that no Python statement
    occurs between assignment and return and that the assigned local is returned
    unchanged.  It does not claim debug/trace line-event equivalence, so every
    patch still needs regression/reference validation.
    """
    candidates: List[Dict[str, Any]] = []
    for rel, tree in trees:
        for fn in ast.walk(tree):
            if not isinstance(fn, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            for block in _iter_statement_blocks(fn):
                for assign, ret in zip(block, block[1:]):
                    if not isinstance(assign, ast.Assign) or len(assign.targets) != 1:
                        continue
                    target = assign.targets[0]
                    if not isinstance(target, ast.Name):
                        continue
                    if not isinstance(ret, ast.Return) or not isinstance(ret.value, ast.Name):
                        continue
                    if ret.value.id != target.id:
                        continue
                    start = int(assign.lineno)
                    end = int(getattr(ret, "end_lineno", ret.lineno))
                    payload = {
                        "file": rel,
                        "function": fn.name,
                        "local": target.id,
                        "assign_line": start,
                        "return_line": int(ret.lineno),
                    }
                    candidates.append(_candidate(
                        identity=payload, kind="terminal_temporary_inline", files=[rel], names=[fn.name],
                        members=[_member(rel, fn.name, start, end)], estimated_loc=1,
                        witness={"type": "adjacent_terminal_local_assignment_return", "same_function": True,
                                 "same_statement_block": True, "adjacent_statements": True, "single_name_assignment": True,
                                 "returned_name_matches_assignment": True, "local_name": target.id,
                                 "rhs_ast": ast.dump(assign.value, include_attributes=False),
                                 "debug_line_event_equivalence_not_claimed": True,
                                 "authority": "syntactic_terminal_temporary_witness_only"},
                        proof_rule="inline only when assignment/return stay adjacent and stable behavior tests remain equivalent",
                        validation=["preserve expression evaluation order and exception behavior", "re-run affected domain fixtures",
                                    "re-run stable critical fixtures", "re-run kernel CLI/integration smoke"],
                    ))
    return candidates


def _literal_dict_keys(node: ast.AST) -> Optional[List[str]]:
    if not isinstance(node, ast.Dict) or not node.keys:
        return None
    keys: List[str] = []
    for key in node.keys:
        if not isinstance(key, ast.Constant) or not isinstance(key.value, str):
            return None
        keys.append(key.value)
    return keys


def _parallel_payload_candidates(*, trees: List[Tuple[str, ast.AST]]) -> List[Dict[str, Any]]:
    """Find owner-local guard/terminal dict returns with the same key contract.

    V1 is deliberately narrow: the guard must be a direct-body ``if`` without
    ``else`` whose last statement returns a literal-key dict, and the same
    function must end with another literal-key dict return using the exact same
    ordered key contract.  This witnesses duplicated payload construction only;
    normalization still needs regression proof because value evaluation order and
    early-return behavior must be preserved explicitly by the refactor.
    """
    candidates: List[Dict[str, Any]] = []
    for rel, tree in trees:
        for fn in getattr(tree, 'body', []):
            if not isinstance(fn, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            body = _without_docstring(list(fn.body))
            if len(body) < 2 or not isinstance(body[-1], ast.Return):
                continue
            terminal = body[-1]
            terminal_keys = _literal_dict_keys(terminal.value)
            if terminal_keys is None or len(terminal_keys) < 4:
                continue
            for offset, stmt in enumerate(body[:-1]):
                if not isinstance(stmt, ast.If) or stmt.orelse or not stmt.body:
                    continue
                guard_return = stmt.body[-1]
                if not isinstance(guard_return, ast.Return):
                    continue
                guard_keys = _literal_dict_keys(guard_return.value)
                if guard_keys != terminal_keys:
                    continue
                # The remaining direct-body statements are part of the non-guard
                # path.  We only surface the shape; we do not claim moving values
                # across the guard is safe.
                key_count = len(terminal_keys)
                guard_start = int(guard_return.lineno)
                guard_end = int(getattr(guard_return, 'end_lineno', guard_return.lineno))
                terminal_start = int(terminal.lineno)
                terminal_end = int(getattr(terminal, 'end_lineno', terminal.lineno))
                duplicate_payload_span = (guard_end - guard_start + 1) + (terminal_end - terminal_start + 1)
                estimated_net = max(1, min(key_count, duplicate_payload_span // 2))
                test_text = ast.unparse(stmt.test) if hasattr(ast, 'unparse') else '<guard>'
                payload = {
                    'file': rel,
                    'function': fn.name,
                    'keys': terminal_keys,
                    'guard_line': int(stmt.lineno),
                    'terminal_line': terminal_start,
                }
                candidates.append(_candidate(
                    identity=payload, kind='parallel_payload_return_normalization', files=[rel], names=[fn.name],
                    members=[_member(rel, fn.name, int(stmt.lineno), terminal_end)], estimated_loc=estimated_net,
                    witness={'type': 'same_literal_key_payload_guard_and_terminal_return', 'same_owner_file': True,
                             'same_function': True, 'guard_has_no_else': True, 'guard_condition': test_text,
                             'literal_key_contract_identical': True, 'ordered_keys': terminal_keys, 'key_count': key_count,
                             'value_expressions_may_differ': True, 'early_return_semantics_must_be_preserved': True,
                             'evaluation_order_equivalence_not_proven': True,
                             'authority': 'syntactic_payload_contract_witness_only'},
                    proof_rule='normalize payload construction only if guard evaluation, lazy branch-only work, key order, values, and return shape remain equivalent',
                    validation=['preserve exact ordered output keys', 'preserve guard-only/terminal-only side effects and I/O',
                                're-run affected domain cache/integrity fixtures', 'compare against stable reference contract'],
                ))
    return candidates

def _semantic_control_flow_candidates(
    *,
    trees: List[Tuple[str, ast.AST]],
) -> List[Dict[str, Any]]:
    """Find mechanically witnessed local control-flow simplifications.

    These are stronger than generic complexity heuristics: a candidate is only
    emitted when the branch condition is side-effect-free under the narrow V1
    predicate and the branch body is AST-identical to its fallback body.
    Even then, the analyzer proposes a candidate; regression/reference proof is
    still required before accepting a patch.
    """
    candidates: List[Dict[str, Any]] = []
    for rel, tree in trees:
        for fn in ast.walk(tree):
            if not isinstance(fn, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            for node in ast.walk(fn):
                if not isinstance(node, ast.If) or not node.body or not node.orelse:
                    continue
                # `elif` is represented as a single nested If in orelse; the
                # candidate here intentionally targets a final branch whose
                # fallback performs exactly the same work.
                if len(node.orelse) == 1 and isinstance(node.orelse[0], ast.If):
                    continue
                if not _pure_local_constant_condition(node.test):
                    continue
                body_dump = ast.dump(ast.Module(body=node.body, type_ignores=[]), include_attributes=False)
                else_dump = ast.dump(ast.Module(body=node.orelse, type_ignores=[]), include_attributes=False)
                if body_dump != else_dump:
                    continue
                start = int(node.lineno)
                end = int(getattr(node, 'end_lineno', node.lineno))
                body_start = int(getattr(node.body[0], 'lineno', start + 1))
                else_start = int(getattr(node.orelse[0], 'lineno', end))
                # Removing the condition branch preserves the fallback copy;
                # count only source lines that disappear, never the survivor.
                body_end = int(getattr(node.body[-1], 'end_lineno', body_start))
                removed_loc = max(1, body_end - start + 1)
                test_text = ast.unparse(node.test) if hasattr(ast, 'unparse') else '<pure-local-compare>'
                witness_payload = {
                    'file': rel,
                    'function': fn.name,
                    'line_start': start,
                    'line_end': end,
                    'test': test_text,
                    'body': body_dump,
                }
                candidates.append(_candidate(
                    identity=witness_payload, kind='redundant_branch_identical_body', files=[rel], names=[fn.name],
                    members=[_member(rel, fn.name, start, end)], estimated_loc=removed_loc,
                    witness={'type': 'identical_branch_body_with_pure_local_condition', 'condition': test_text,
                             'condition_side_effect_free_under_v1': True, 'branch_body_ast_identical': True,
                             'witness_sha256': _sha(body_dump + '\n' + test_text),
                             'authority': 'syntactic_local_equivalence_witness_only'},
                    proof_rule='remove redundant branch only when the surviving fallback body remains identical',
                    validation=['preserve function public signature', 're-run claim-obligation fixtures',
                                're-run kernel CLI/integration smoke', 'compare against stable reference contract'],
                ))
    return candidates

def _relative_graph_path(path: str, root: Path) -> str:
    try:
        return Path(path).resolve().relative_to(root.resolve()).as_posix()
    except Exception:
        normalized = str(path).replace("\\", "/")
        root_norm = root.resolve().as_posix().rstrip("/")
        prefix = root_norm + "/"
        return normalized[len(prefix):] if normalized.startswith(prefix) else normalized


def _proof_surface(candidate: Dict[str, Any], graph: Dict[str, Any], root: Path) -> Dict[str, Any]:
    """Estimate the amount of code/proof surface a simplification can disturb.

    This is a prioritization heuristic only.  It never proves equivalence and
    never changes the acceptance contract.
    """
    owners = set(candidate.get("files", []))
    edges = [
        (_relative_graph_path(str(a), root), _relative_graph_path(str(b), root))
        for a, b in graph.get("edges", [])
    ]
    adjacency: Dict[str, set[str]] = {}
    reverse: Dict[str, set[str]] = {}
    for source, target in edges:
        adjacency.setdefault(source, set()).add(target)
        reverse.setdefault(target, set()).add(source)

    direct: set[str] = set()
    for owner in owners:
        direct.update(adjacency.get(owner, set()))
        direct.update(reverse.get(owner, set()))
    direct.difference_update(owners)

    reached = set(owners) | set(direct)
    frontier = set(direct) or set(owners)
    for _ in range(1):  # expand to radius 2 from owners
        nxt: set[str] = set()
        for node in frontier:
            nxt.update(adjacency.get(node, set()))
            nxt.update(reverse.get(node, set()))
        nxt.difference_update(reached)
        reached.update(nxt)
        frontier = nxt
    two_hop = reached - owners

    public_members = sum(1 for member in candidate.get("members", []) if not member.get("private", False))
    owner_domains = {
        file.split("/", 1)[0] if "/" in file else "."
        for file in owners
    }
    neighborhood_domains = {
        file.split("/", 1)[0] if "/" in file else "."
        for file in owners | direct
    }
    cross_owner_domain_boundary = len(owner_domains) > 1
    test_neighbors = {
        file for file in direct
        if (
            file.endswith(("_test.py", ".spec.py", ".test.py"))
            or "/tests/" in f"/{file}"
            or file.startswith("tests/")
            or file == "fixture_check.py"
        )
    }
    fan_edges = sum(
        1 for source, target in edges
        if source in owners or target in owners
    )

    # Deliberately interpretable ordinal risk.  Large cross-domain/public
    # surfaces become expensive even when LOC savings look attractive.
    risk_units = (
        2.0 * len(owners)
        + 0.50 * len(direct)
        + 0.15 * min(len(two_hop), 12)
        + 2.5 * public_members
        + 1.5 * max(0, len(neighborhood_domains) - 1)
        + 8.0 * max(0, len(owner_domains) - 1)
        + 0.5 * len(test_neighbors)
        + 0.10 * fan_edges
    )
    risk_units = round(max(1.0, risk_units), 3)
    risk_level = "low" if risk_units < 8 else "medium" if risk_units < 18 else "high"
    return {
        "owner_file_count": len(owners),
        "direct_neighbor_count": len(direct),
        "two_hop_reachable_count": len(two_hop),
        "incident_edge_count": fan_edges,
        "public_member_count": public_members,
        "top_level_domain_count": len(neighborhood_domains),
        "owner_top_level_domains": sorted(owner_domains),
        "owner_domain_count": len(owner_domains),
        "cross_owner_domain_boundary": cross_owner_domain_boundary,
        "neutral_abstraction_owner_required": cross_owner_domain_boundary,
        "direct_test_neighbor_count": len(test_neighbors),
        "risk_units": risk_units,
        "risk_level": risk_level,
        "authority": "structural_proof_surface_estimate_only",
    }




def _witness_has(witness: Dict[str, Any], *keys: str) -> bool:
    return all(bool(witness.get(key)) for key in keys)


def _recommend_candidate(group: Dict[str, Any], surface: Dict[str, Any], execution_lane: str) -> str:
    """Apply the bounded recommendation lattice without granting proof authority."""
    kind = str(group.get("kind", ""))
    witness = group.get("semantic_witness", {}) or {}
    risk = str(surface.get("risk_level", "high"))
    removable = int(group.get("estimated_removable_loc", 0))
    if surface.get("cross_owner_domain_boundary"):
        recommendation = "defer_cross_domain_until_neutral_owner_proven"
    elif kind == "direct_forwarding_wrapper" and _witness_has(witness, "argument_forwarding_exact") and not witness.get("wrapper_private"):
        recommendation = "defer_public_api_wrapper"
    elif kind == "parallel_payload_return_normalization" and _witness_has(witness, "literal_key_contract_identical", "same_function"):
        recommendation = "defer_payload_normalization_high_proof_surface" if risk == "high" else ("defer_payload_no_positive_patch_margin" if removable <= 1 else "candidate_local_payload_normalization")
    elif kind == "terminal_temporary_inline" and _witness_has(witness, "adjacent_statements", "returned_name_matches_assignment", "same_function"):
        recommendation = "defer_stable_lane_requires_selective_promotion" if execution_lane == "stable_lane_shadow" else ("defer_terminal_temporary_high_proof_surface" if risk == "high" else "candidate_intra_function_terminal_temporary")
    elif kind == "js_try_catch_identical_terminal_return" and _witness_has(witness, "terminal_return_expression_identical", "return_expression_nonthrowing_literal", "catch_boundary_preserved", "finally_absent"):
        recommendation = "defer_js_try_catch_high_proof_surface" if risk == "high" else "candidate_js_try_catch_return_hoist"
    elif kind == "js_terminal_literal_temporary" and _witness_has(witness, "adjacent_assignment_return", "const_binding", "returned_name_matches_assignment", "return_expression_nonthrowing_literal", "terminal_return_in_same_block"):
        recommendation = "defer_js_terminal_temporary_high_proof_surface" if risk == "high" else "candidate_js_terminal_literal_temporary_inline"
    elif kind == "repeated_direct_statement_sequence" and _witness_has(witness, "repeated_sequence_ast_identical", "control_transfer_free_under_v1", "same_owner_file"):
        recommendation = "defer_sequence_no_positive_net_gain" if removable <= 0 else ("defer_sequence_high_proof_surface" if risk == "high" else "candidate_local_sequence_extraction")
    elif (kind == "redundant_branch_identical_body" and witness.get("branch_body_ast_identical")) or (kind == "direct_forwarding_wrapper" and witness.get("argument_forwarding_exact")):
        recommendation = "candidate_strong_local_witness"
    else:
        recommendation = "candidate" if risk in ("low", "medium") else "defer_until_narrower_candidates_exhausted"
    if execution_lane == "stable_lane_shadow" and recommendation.startswith("candidate"):
        return "defer_stable_lane_requires_selective_promotion"
    return recommendation



def _adjudication(disposition: str, decision: str, reopen: str, owner: Optional[str] = None) -> Dict[str, Any]:
    return {
        "disposition": disposition,
        "owner_decision": decision,
        "reopen_condition": reopen,
        "neutral_owner": owner,
    }


def _adjudicate_candidate(group: Dict[str, Any]) -> Dict[str, Any]:
    """Give already-detected F90 debt an explicit architecture disposition."""
    recommendation = str(group.get("priority", {}).get("recommendation", ""))
    names = {str(name) for name in group.get("names", [])}
    files = {str(path).replace("\\", "/") for path in group.get("files", [])}
    gain = int(group.get("estimated_removable_loc", group.get("estimated_removable_duplicate_loc", 0)))

    if recommendation == "defer_public_api_wrapper":
        return _adjudication(
            "API_PROOF_CANDIDATE", "PUBLIC_COMPATIBILITY_SURFACE_MUST_BE_PROVEN",
            "prove all callers/consumers and provide compatibility or deprecation transition before wrapper removal",
        )
    if recommendation in {"defer_payload_no_positive_patch_margin", "defer_sequence_no_positive_net_gain"}:
        return _adjudication(
            "KEEP", "NO_POSITIVE_NET_SIMPLIFICATION_GAIN",
            "reopen only if surrounding code changes create a positive measured patch margin",
        )
    if recommendation in {"defer_sequence_high_proof_surface", "defer_js_try_catch_high_proof_surface"}:
        return _adjudication(
            "DEFER", "HIGH_PROOF_SURFACE_REQUIRES_DOMAIN_SPECIFIC_REVIEW",
            "provide bounded behavioral differential and reduce or explicitly accept the affected proof surface",
        )
    if recommendation == "candidate_js_try_catch_return_hoist":
        return _adjudication(
            "DEFER", "JS_LOCAL_SEMANTIC_CANDIDATE_REQUIRES_BEHAVIORAL_PROOF",
            "apply only in a target worktree after preserving try/catch exception behavior and passing affected TS/Angular tests",
        )
    if recommendation == "candidate_js_terminal_literal_temporary_inline":
        return _adjudication(
            "DEFER", "JS_LOCAL_TERMINAL_TEMPORARY_REQUIRES_BEHAVIORAL_PROOF",
            "apply only in a target worktree after proving literal value/order preservation and passing affected TS/JS tests",
        )
    if recommendation == "defer_until_narrower_candidates_exhausted":
        if names == {"expect"} and files == {"fixture_check.py", "experimental_fixture_check.py"}:
            return _adjudication(
                "KEEP", "PROOF_LANE_INDEPENDENCE_IS_INTENTIONAL",
                "reopen only if stable and experimental proof harnesses acquire a neutral test-support layer without coupling their execution lanes",
            )
        return _adjudication(
            "DEFER", "HIGH_RISK_GENERAL_DEBT_NEEDS_MANUAL_ARCHITECTURE_PROOF",
            "supply a narrower mechanical witness or an explicit architecture review with bounded regression proof",
        )
    if recommendation == "defer_cross_domain_until_neutral_owner_proven":
        if names.issubset({"normalize_path", "_normalize_path"}) and "language_semantics.py" in files:
            return _adjudication(
                "NEUTRAL_OWNER_CANDIDATE", "EXISTING_NEUTRAL_OWNER_ALREADY_PRESENT",
                "selectively migrate remaining callers to language_semantics.normalize_path and prove cache/path identity compatibility",
                "language_semantics.normalize_path",
            )
        if names & {"_now", "_now_iso", "_utc_now", "_utc_timestamp"} and len(files) >= 8:
            return _adjudication(
                "NEUTRAL_OWNER_CANDIDATE", "NEW_NEUTRAL_CLOCK_OWNER_MAY_JUSTIFY_BROAD_DEDUP",
                "define one stdlib-only UTC timestamp contract and prove serialization/time-format compatibility across all owners",
                "UNPROVEN_UTC_TIME_SEMANTICS_OWNER",
            )
        if gain <= 6:
            return _adjudication(
                "KEEP", "LOCAL_DUPLICATION_CHEAPER_THAN_NEW_CROSS_DOMAIN_COUPLING",
                "reopen only if a neutral owner already exists or reuse expands enough to outweigh dependency cost",
            )
        return _adjudication(
            "DEFER", "CROSS_DOMAIN_SEMANTICS_NEED_NEUTRAL_OWNER_PROOF",
            "identify a neutral owner and prove domain-specific semantics remain equivalent before extraction",
        )
    return _adjudication(
        "DEFER", "UNCLASSIFIED_BY_F90_POLICY",
        "manual adjudication required before any patch",
    )

def _self_host_overlay_paths(root: Path) -> Optional[set[str]]:
    """Return F86 overlay paths when self-host lane separation is available."""
    manifest = root / "experiments" / "f86_stable_rebase_experimental_reattach.json"
    if not manifest.is_file():
        return None
    try:
        payload = json.loads(manifest.read_text(encoding="utf-8"))
    except Exception:
        return None
    if payload.get("checkpoint") != "F86":
        return None
    overlay = payload.get("overlay_files", {}) or {}
    return {str(path).replace("\\", "/") for path in overlay}


def analyze_simplification(root: str = ".") -> Dict[str, Any]:
    root_path = Path(root).resolve()
    self_host_overlay_paths = _self_host_overlay_paths(root_path)
    file_rows: List[Dict[str, Any]] = []
    functions: List[Dict[str, Any]] = []
    parsed_trees: List[Tuple[str, ast.AST]] = []
    parse_errors: List[Dict[str, str]] = []
    totals = {
        "python_files": 0,
        "source_loc": 0,
        "ast_nodes": 0,
        "branches": 0,
        "loops": 0,
        "try_blocks": 0,
        "functions": 0,
        "classes": 0,
    }

    graph, source_snapshot = _canonical_python_source_snapshot(root_path)
    js_source_snapshot = _canonical_js_source_snapshot(graph, root_path)
    language_inventory = _canonical_language_inventory(graph)
    for rel, source in source_snapshot:
        try:
            tree = ast.parse(source, filename=rel)
            parsed_trees.append((rel, tree))
        except Exception as exc:
            parse_errors.append({"file": rel, "error": type(exc).__name__})
            continue

        lines = source.splitlines()
        metrics = _complexity_metrics(tree)
        loc = len(lines)
        row = {"file": rel, "source_loc": loc, **metrics}
        file_rows.append(row)
        totals["python_files"] += 1
        totals["source_loc"] += loc
        for key in metrics:
            totals[key] += metrics[key]

        for node in ast.walk(tree):
            if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            end = int(getattr(node, "end_lineno", node.lineno))
            body_fp = _function_body_fingerprint(node)
            functions.append({
                "file": rel,
                "name": node.name,
                "signature": _signature(node),
                "line_start": int(node.lineno),
                "line_end": end,
                "loc": end - int(node.lineno) + 1,
                "body_fingerprint": body_fp,
                "private": node.name.startswith("_"),
            })

    by_fp: Dict[str, List[Dict[str, Any]]] = {}
    for row in functions:
        by_fp.setdefault(row["body_fingerprint"], []).append(row)

    duplicate_groups: List[Dict[str, Any]] = []
    for fingerprint, members in by_fp.items():
        if len(members) < 2:
            continue
        files = sorted({m["file"] for m in members})
        if len(files) < 2:
            continue
        locs = sorted((m["loc"] for m in members), reverse=True)
        removable = sum(locs[1:])
        if removable <= 0:
            continue
        names = sorted({m["name"] for m in members})
        duplicate_groups.append({
            "candidate_id": _sha(json.dumps({"fp": fingerprint, "files": files, "names": names}, sort_keys=True)),
            "kind": "exact_function_body_duplication",
            "body_fingerprint": fingerprint,
            "members": sorted(members, key=lambda m: (m["file"], m["line_start"], m["name"])),
            "member_count": len(members),
            "files": files,
            "names": names,
            "total_loc": sum(locs),
            "estimated_removable_duplicate_loc": removable,
            "proof_obligation": {
                "required": True,
                "rule": "extract/shared implementation only if callers and observable behavior remain equivalent",
                "validation": [
                    "preserve public callable surface",
                    "preserve import-resolution behavior",
                    "run affected fixtures",
                    "run kernel CLI/integration smoke",
                ],
            },
        })

    detector_specs = (
        ("semantic", _semantic_control_flow_candidates, "semantic_control_flow_candidates", "estimated_removable_semantic_loc"),
        ("forwarding", _forwarding_wrapper_candidates, "semantic_forwarding_wrapper_candidates", "estimated_removable_forwarding_loc"),
        ("sequence", _repeated_statement_sequence_candidates, "semantic_repeated_sequence_candidates", "estimated_removable_sequence_loc"),
        ("payload", _parallel_payload_candidates, "semantic_parallel_payload_candidates", "estimated_removable_payload_loc"),
        ("terminal", _terminal_temporary_candidates, "semantic_terminal_temporary_candidates", "estimated_removable_terminal_temporary_loc"),
    )
    detected = {name: detector(trees=parsed_trees) for name, detector, _, _ in detector_specs}
    js_try_catch_candidates = _js_try_catch_terminal_return_candidates(sources=js_source_snapshot)
    js_terminal_temporary_candidates = _js_terminal_literal_temporary_candidates(sources=js_source_snapshot)
    js_candidates = js_try_catch_candidates + js_terminal_temporary_candidates
    all_candidates = (
        duplicate_groups
        + [candidate for name, _, _, _ in detector_specs for candidate in detected[name]]
        + js_candidates
    )

    for group in all_candidates:
        surface = _proof_surface(group, graph, root_path)
        gain_loc = int(group.get("estimated_removable_loc", group.get("estimated_removable_duplicate_loc", 0)))
        implementation_reduction = max(1, int(group.get("member_count", 1)) - 1)
        gain_units = float(gain_loc) + 2.0 * float(implementation_reduction)
        priority = round(gain_units / (max(1.0, float(surface["risk_units"])) ** 1.2), 6)
        group["simplification_gain"] = {
            "loc_reduction": gain_loc,
            "duplicate_loc": int(group.get("estimated_removable_duplicate_loc", 0)),
            "duplicate_implementations_removed_if_extracted": implementation_reduction if group.get("kind") == "exact_function_body_duplication" else 0,
            "gain_units": round(gain_units, 3),
        }
        group["proof_surface"] = surface
        risk_level = str(surface.get("risk_level", "high"))
        cross_domain = bool(surface.get("cross_owner_domain_boundary"))
        candidate_files = {str(path).replace("\\", "/") for path in group.get("files", [])}
        if self_host_overlay_paths is None:
            execution_lane = "target"
        elif candidate_files and candidate_files.issubset(self_host_overlay_paths):
            execution_lane = "experimental_overlay"
        else:
            execution_lane = "stable_lane_shadow"
        group["execution_lane"] = execution_lane
        recommendation = _recommend_candidate(group, surface, execution_lane)
        group["priority"] = {
            "policy": "intra_function_frontier_then_existing_gates_v8",
            "score": priority,
            "higher_is_better_within_risk_gate": True,
            "risk_gate": "defer_cross_domain_and_high_surface_by_default",
            "recommendation": recommendation,
            "cross_domain_dedup_requires_neutral_abstraction_owner": cross_domain,
            "execution_lane": execution_lane,
            "stable_lane_mutation_requires_selective_promotion": execution_lane == "stable_lane_shadow",
            "does_not_prove_equivalence": True,
        }
        group["adjudication"] = _adjudicate_candidate(group)

    all_candidates.sort(
        key=lambda group: (
            1 if not str(group.get("priority", {}).get("recommendation", "")).startswith("candidate") else 0,
            1 if group.get("proof_surface", {}).get("risk_level") == "high" else 0,
            -float(group.get("priority", {}).get("score", 0.0)),
            -int(group.get("estimated_removable_loc", group.get("estimated_removable_duplicate_loc", 0))),
            group["candidate_id"],
        )
    )
    recommended_candidates = [
        group for group in all_candidates
        if str(group.get("priority", {}).get("recommendation", "")).startswith("candidate")
    ]
    recommendation_counts: Dict[str, int] = {}
    for group in all_candidates:
        label = str(group.get("priority", {}).get("recommendation", "unknown"))
        recommendation_counts[label] = recommendation_counts.get(label, 0) + 1
    if not language_inventory.get("zero_candidate_is_clean_evidence", True):
        frontier_status = "SEMANTIC_FRONTEND_COVERAGE_INCOMPLETE"
    else:
        frontier_status = (
            "LOCAL_SIMPLIFICATION_FRONTIER_REACHED"
            if not recommended_candidates
            else "LOCAL_SIMPLIFICATION_FRONTIER_OPEN"
        )
    lane_counts: Dict[str, int] = {}
    for group in all_candidates:
        lane = str(group.get("execution_lane", "target"))
        lane_counts[lane] = lane_counts.get(lane, 0) + 1
    stable_shadow_candidates = [
        group for group in all_candidates
        if group.get("execution_lane") == "stable_lane_shadow"
        and group.get("kind") == "terminal_temporary_inline"
    ]
    disposition_counts: Dict[str, int] = {}
    decision_counts: Dict[str, int] = {}
    for group in all_candidates:
        adjudication = group.get("adjudication", {}) or {}
        disposition = str(adjudication.get("disposition", "UNADJUDICATED"))
        decision = str(adjudication.get("owner_decision", "UNADJUDICATED"))
        disposition_counts[disposition] = disposition_counts.get(disposition, 0) + 1
        decision_counts[decision] = decision_counts.get(decision, 0) + 1
    unadjudicated = sum(
        1 for group in all_candidates
        if not group.get("adjudication")
        or str(group.get("adjudication", {}).get("owner_decision", "")).startswith("UNCLASSIFIED")
    )

    removable_total = sum(int(g["estimated_removable_duplicate_loc"]) for g in duplicate_groups)
    detector_metrics: Dict[str, int] = {}
    for name, _, count_key, removable_key in detector_specs:
        rows = detected[name]
        detector_metrics[count_key] = len(rows)
        detector_metrics[removable_key] = sum(int(g.get("estimated_removable_loc", 0)) for g in rows)
    detector_metrics["semantic_candidates_total"] = sum(len(rows) for rows in detected.values()) + len(js_candidates)
    detector_metrics["semantic_js_try_catch_candidates"] = len(js_try_catch_candidates)
    detector_metrics["estimated_removable_js_try_catch_loc"] = sum(int(g.get("estimated_removable_loc", 0)) for g in js_try_catch_candidates)
    detector_metrics["semantic_js_terminal_literal_temporary_candidates"] = len(js_terminal_temporary_candidates)
    detector_metrics["estimated_removable_js_terminal_literal_temporary_loc"] = sum(int(g.get("estimated_removable_loc", 0)) for g in js_terminal_temporary_candidates)
    detector_metrics["js_semantic_files_scanned"] = len(js_source_snapshot)
    detector_metrics["js_semantic_source_loc"] = sum(len(source.splitlines()) for _, source, _ in js_source_snapshot)
    return {
        "schema_version": SIMPLIFICATION_SCHEMA_VERSION,
        "root": ".",
        "language": "canonical_multi_frontend",
        "legacy_python_api_compatibility": True,
        "analysis_authority": "structural_candidate_generation_only",
        "canonical_anatomy_bridge": {
            "inventory_authority": "core.shared_graph",
            "source_content_authority": "shared_graph.file_map",
            "shared_graph_schema_version": graph.get("schema_version"),
            "shared_graph_content_signature": _graph_signature(graph),
            "semantic_frontend": "python_ast+js_lexical_v1",
            "semantic_frontend_scope": {
                "python": "existing AST rule registry",
                "ts_js": "shared lexical v1 substrate with try/catch return-hoist + terminal literal temporary rules; not exhaustive semantic coverage",
                "ts_js_rule_count": 2,
                "ts_js_shared_primitives": ["shared_graph.file_map", "_mask_js_noncode", "_js_nonthrowing_literal", "_enclosing_js_function_name"],
                "independent_second_lexer_or_scanner": False,
            },
            "single_discovery_snapshot": True,
            "independent_simplifier_filesystem_scan": False,
            "python_source_count": len(source_snapshot),
            "language_inventory": language_inventory,
        },
        "candidate_priority_policy": "intra_function_frontier_then_existing_gates_v8",
        "architectural_adjudication_policy": "f90_remaining_debt_disposition_v1",
        "self_host_scan": {
            "explicit_analyzer_mode": True,
            "ordinary_global_scan_must_exclude_tool_implementation": True,
            "stable_overlay_lane_boundary_active": self_host_overlay_paths is not None,
        },
        "cannot_assert_behavioral_equivalence": True,
        "architectural_adjudication": {
            "status": "ARCHITECTURAL_DEBT_ADJUDICATED" if unadjudicated == 0 else "ARCHITECTURAL_DEBT_AMBIGUOUS",
            "unadjudicated_candidate_count": unadjudicated,
            "disposition_counts": dict(sorted(disposition_counts.items())),
            "owner_decision_counts": dict(sorted(decision_counts.items())),
            "patches_applied_by_F90": 0,
            "meaning": "remaining debt has an explicit architecture/API/economic disposition; F90 opens no new detector frontier",
        },
        "frontier": {
            "status": frontier_status,
            "recommended_local_candidates": len(recommended_candidates),
            "remaining_candidate_count": len(all_candidates),
            "remaining_debt_by_recommendation": dict(sorted(recommendation_counts.items())),
            "candidate_count_by_execution_lane": dict(sorted(lane_counts.items())),
            "stable_lane_shadow_candidates": len(stable_shadow_candidates),
            "meaning": (
                "reference inventory is available, but one or more observed source languages lack an active semantic simplification frontend; zero candidates is not clean evidence"
                if frontier_status == "SEMANTIC_FRONTEND_COVERAGE_INCOMPLETE"
                else (
                    "no remaining mechanically recommended local-safe simplification; remaining debt needs architectural/API/high-risk/no-margin decisions"
                    if frontier_status == "LOCAL_SIMPLIFICATION_FRONTIER_REACHED"
                    else "one or more local-safe mechanically witnessed candidates remain"
                )
            ),
        },
        "metrics": {
            **totals,
            "exact_duplicate_groups": len(duplicate_groups),
            "estimated_removable_duplicate_loc": removable_total,
            **detector_metrics,
        },
        "candidates": all_candidates,
        "parse_errors": parse_errors,
        "invariants": {
            "candidate_is_not_patch": True,
            "lower_loc_is_not_equivalence": True,
            "tests_are_evidence_not_universal_equivalence": True,
            "reference_validation_required_before_accept": True,
            "highest_loc_saving_is_not_automatically_highest_priority": True,
            "proof_surface_priority_is_not_equivalence": True,
            "cross_domain_duplication_is_not_automatically_a_refactor_target": True,
            "neutral_abstraction_owner_required_before_cross_domain_dedup": True,
            "semantic_candidate_requires_mechanical_witness": True,
            "semantic_witness_is_not_regression_proof": True,
            "branch_condition_must_be_side_effect_free_before_elision": True,
            "forwarding_wrapper_requires_exact_parameter_forwarding": True,
            "public_forwarding_wrapper_is_not_auto_removable": True,
            "repeated_sequence_requires_same_owner_exact_ast": True,
            "repeated_sequence_requires_control_transfer_free_witness": True,
            "repeated_sequence_witness_does_not_prove_helper_equivalence": True,
            "repeated_sequence_raw_duplication_is_not_net_simplification": True,
            "sequence_extraction_requires_positive_estimated_net_gain": True,
            "sequence_extraction_respects_high_proof_surface_gate": True,
            "parallel_payload_requires_identical_literal_key_contract": True,
            "parallel_payload_witness_does_not_prove_value_evaluation_equivalence": True,
            "parallel_payload_normalization_respects_high_proof_surface_gate": True,
            "payload_normalization_requires_positive_patch_margin": True,
            "frontier_status_requires_zero_recommended_local_candidates": True,
            "terminal_temporary_requires_adjacent_same_block_assignment_return": True,
            "terminal_temporary_debug_line_event_equivalence_is_not_claimed": True,
            "stable_lane_candidate_requires_selective_promotion_under_F86": True,
            "remaining_debt_requires_explicit_architectural_disposition_under_F90": True,
            "F90_adjudication_does_not_authorize_patch": True,
            "js_frontend_consumes_shared_graph_source_snapshot": True,
            "js_try_catch_return_hoist_requires_nonthrowing_literal_expression": True,
            "js_try_catch_prefixes_and_catch_boundary_must_be_preserved": True,
            "js_semantic_frontend_v1_is_not_exhaustive_language_coverage": True,
            "js_rule2_reuses_v1_lexical_substrate": True,
            "js_rule2_does_not_add_independent_lexer_or_scanner": True,
            "js_terminal_literal_temporary_requires_nonthrowing_literal": True,
        },
    }


# Compatibility alias: historical callers keep the old name without creating a
# forwarding-wrapper function that would become self-host simplification debt.
analyze_python_simplification = analyze_simplification


def compare_simplification(reference_root: str, candidate_root: str) -> Dict[str, Any]:
    reference = analyze_python_simplification(reference_root)
    candidate = analyze_python_simplification(candidate_root)
    ref_metrics = reference["metrics"]
    cand_metrics = candidate["metrics"]
    keys = (
        "source_loc", "ast_nodes", "branches", "loops", "try_blocks",
        "functions", "classes", "exact_duplicate_groups",
        "estimated_removable_duplicate_loc",
        "semantic_control_flow_candidates", "semantic_forwarding_wrapper_candidates",
        "semantic_repeated_sequence_candidates", "semantic_parallel_payload_candidates", "semantic_terminal_temporary_candidates", "semantic_candidates_total", "estimated_removable_semantic_loc",
        "estimated_removable_forwarding_loc", "estimated_removable_sequence_loc", "estimated_removable_payload_loc", "estimated_removable_terminal_temporary_loc",
        "semantic_js_try_catch_candidates", "estimated_removable_js_try_catch_loc",
        "semantic_js_terminal_literal_temporary_candidates", "estimated_removable_js_terminal_literal_temporary_loc",
        "js_semantic_files_scanned", "js_semantic_source_loc",
    )
    delta = {key: int(cand_metrics.get(key, 0)) - int(ref_metrics.get(key, 0)) for key in keys}
    return {
        "schema_version": SIMPLIFICATION_SCHEMA_VERSION,
        "reference": reference,
        "candidate": candidate,
        "delta_candidate_minus_reference": delta,
        "interpretation": {
            "negative_complexity_delta_is_only_a_simplification_signal": True,
            "behavioral_equivalence_requires_separate_validation": True,
        },
    }


__all__ = [
    "SIMPLIFICATION_SCHEMA_VERSION",
    "analyze_simplification",
    "analyze_python_simplification",
    "compare_simplification",
]
