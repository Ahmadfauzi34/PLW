"""Target-codebase topology bootstrap for first-contact repository orientation.

Consumes an existing SharedGraph snapshot and projects bounded structural facts
about the target repository.  It does not select a PLW capability, mutate source,
execute runtime code, or claim behavioral correctness.
"""
from __future__ import annotations

import os
from collections import Counter, defaultdict, deque
from typing import Any, Dict, Iterable, List, Mapping, Sequence, Tuple

SCHEMA_VERSION = "target-codebase-topology-bootstrap-v1"
POLICY = "target-first-structural-orientation-v1"
DEFAULT_TOP_N = 8
MAX_TOP_N = 50


def _display(path: str, scan_root: str) -> str:
    value = str(path)
    root = str(scan_root or ".")
    try:
        if os.path.isabs(value) and os.path.isabs(root):
            rel = os.path.relpath(value, root)
            if rel != os.pardir and not rel.startswith(os.pardir + os.sep):
                return rel.replace("\\", "/")
    except (OSError, ValueError):
        pass
    root_norm = root.rstrip("/\\")
    if root_norm and value.startswith(root_norm + os.sep):
        return value[len(root_norm) + 1 :].replace("\\", "/")
    return value.replace("\\", "/")


def _bounded(values: Iterable[str], limit: int) -> Tuple[List[str], int]:
    ordered = sorted(dict.fromkeys(str(value) for value in values))
    return ordered[:limit], max(0, len(ordered) - limit)


def _weak_component_count(vertices: Sequence[str], edges: Sequence[Sequence[str]]) -> int:
    adjacency: Dict[str, set[str]] = {str(v): set() for v in vertices}
    for edge in edges:
        if len(edge) != 2:
            continue
        src, dst = str(edge[0]), str(edge[1])
        adjacency.setdefault(src, set()).add(dst)
        adjacency.setdefault(dst, set()).add(src)
    seen: set[str] = set()
    components = 0
    for start in sorted(adjacency):
        if start in seen:
            continue
        components += 1
        queue = deque([start])
        seen.add(start)
        while queue:
            node = queue.popleft()
            for nxt in sorted(adjacency.get(node, ())):
                if nxt not in seen:
                    seen.add(nxt)
                    queue.append(nxt)
    return components


def _cyclic_sccs(vertices: Sequence[str], edges: Sequence[Sequence[str]]) -> List[List[str]]:
    """Tarjan SCC projection; only cyclic SCCs are retained."""
    adjacency: Dict[str, List[str]] = {str(v): [] for v in vertices}
    self_loops: set[str] = set()
    for edge in edges:
        if len(edge) != 2:
            continue
        src, dst = str(edge[0]), str(edge[1])
        adjacency.setdefault(src, []).append(dst)
        adjacency.setdefault(dst, [])
        if src == dst:
            self_loops.add(src)
    for key in adjacency:
        adjacency[key] = sorted(set(adjacency[key]))

    index = 0
    stack: List[str] = []
    on_stack: set[str] = set()
    indices: Dict[str, int] = {}
    lowlink: Dict[str, int] = {}
    result: List[List[str]] = []

    def visit(node: str) -> None:
        nonlocal index
        indices[node] = index
        lowlink[node] = index
        index += 1
        stack.append(node)
        on_stack.add(node)
        for nxt in adjacency.get(node, []):
            if nxt not in indices:
                visit(nxt)
                lowlink[node] = min(lowlink[node], lowlink[nxt])
            elif nxt in on_stack:
                lowlink[node] = min(lowlink[node], indices[nxt])
        if lowlink[node] == indices[node]:
            component: List[str] = []
            while stack:
                current = stack.pop()
                on_stack.remove(current)
                component.append(current)
                if current == node:
                    break
            component.sort()
            if len(component) > 1 or (component and component[0] in self_loops):
                result.append(component)

    for vertex in sorted(adjacency):
        if vertex not in indices:
            visit(vertex)
    return sorted(result, key=lambda item: (-len(item), item[0] if item else ""))


def _external_package(raw_import: str) -> str:
    text = str(raw_import or "")
    if text.startswith("@"):
        parts = text.split("/")
        return "/".join(parts[:2]) if len(parts) >= 2 else text
    return text.split("/", 1)[0]


def _hub_rows(
    node_metadata: Mapping[str, Mapping[str, Any]],
    scan_root: str,
    key: str,
    limit: int,
) -> List[Dict[str, Any]]:
    ordered = sorted(
        node_metadata.items(),
        key=lambda item: (-int(item[1].get(key, 0) or 0), _display(item[0], scan_root)),
    )
    rows = []
    for path, meta in ordered:
        score = int(meta.get(key, 0) or 0)
        if score <= 0:
            continue
        rows.append({
            "file": _display(path, scan_root),
            key: score,
            "fan_in": int(meta.get("fan_in", 0) or 0),
            "fan_out": int(meta.get("fan_out", 0) or 0),
            "is_entrypoint": bool(meta.get("is_entrypoint")),
            "is_test": bool(meta.get("is_test")),
        })
        if len(rows) >= limit:
            break
    return rows


def _boundary_rows(
    boundaries: Mapping[str, Any],
    file_to_boundary: Mapping[str, str],
    scan_root: str,
    limit: int,
) -> List[Dict[str, Any]]:
    counts = Counter(str(boundary) for boundary in file_to_boundary.values())
    rows: List[Dict[str, Any]] = []
    for boundary, count in sorted(counts.items(), key=lambda item: (-item[1], item[0]))[:limit]:
        rows.append({
            "boundary": _display(boundary, scan_root),
            "file_count": int(count),
        })
    if not rows and boundaries:
        for boundary in sorted(boundaries)[:limit]:
            value = boundaries[boundary]
            count = len(value) if isinstance(value, (list, tuple, set, dict)) else 0
            rows.append({"boundary": _display(boundary, scan_root), "file_count": count})
    return rows


def build_target_topology_orientation(
    shared_graph: Mapping[str, Any],
    *,
    top_n: int = DEFAULT_TOP_N,
    include_edges: bool = False,
) -> Dict[str, Any]:
    """Project one SharedGraph into a bounded first-contact topology briefing."""
    if isinstance(top_n, bool) or not isinstance(top_n, int) or not 1 <= top_n <= MAX_TOP_N:
        raise ValueError(f"top_n must be an integer between 1 and {MAX_TOP_N}")

    scan_root = str(shared_graph.get("scan_root") or ".")
    vertices = [str(v) for v in shared_graph.get("vertices", []) or []]
    edges = [list(edge) for edge in shared_graph.get("edges", []) or [] if len(edge) == 2]
    node_metadata = shared_graph.get("node_metadata", {}) or {}
    summary = shared_graph.get("summary", {}) or {}
    unresolved = list(shared_graph.get("unresolved_imports", []) or [])
    external = list(shared_graph.get("external_imports", []) or [])
    boundaries = shared_graph.get("boundaries", {}) or {}
    file_to_boundary = shared_graph.get("file_to_boundary", {}) or {}

    entrypoints, entrypoint_omitted = _bounded(
        (_display(path, scan_root) for path, meta in node_metadata.items() if meta.get("is_entrypoint")),
        top_n,
    )
    tests, test_omitted = _bounded(
        (_display(path, scan_root) for path, meta in node_metadata.items() if meta.get("is_test")),
        top_n,
    )
    roots, root_omitted = _bounded(
        (_display(path, scan_root) for path, meta in node_metadata.items() if int(meta.get("fan_in", 0) or 0) == 0),
        top_n,
    )
    leaves, leaf_omitted = _bounded(
        (_display(path, scan_root) for path, meta in node_metadata.items() if int(meta.get("fan_out", 0) or 0) == 0),
        top_n,
    )
    isolated = [
        _display(path, scan_root)
        for path, meta in node_metadata.items()
        if int(meta.get("fan_in", 0) or 0) == 0 and int(meta.get("fan_out", 0) or 0) == 0
    ]
    cyclic_sccs = _cyclic_sccs(vertices, edges)

    unresolved_sample = []
    for item in unresolved[:top_n]:
        unresolved_sample.append({
            "importer": _display(str(item.get("importer", "")), scan_root),
            "raw_import": str(item.get("raw_import", "")),
            "reason": str(item.get("reason", "unresolved_relative_import")),
        })
    external_counts = Counter(_external_package(str(item.get("raw_import", ""))) for item in external)
    external_packages = [
        {"package": package, "import_count": count}
        for package, count in sorted(external_counts.items(), key=lambda item: (-item[1], item[0]))[:top_n]
        if package
    ]

    issues: List[Dict[str, Any]] = []
    if unresolved:
        issues.append({
            "kind": "unresolved_imports",
            "count": len(unresolved),
            "reasoning_effect": "graph reachability is incomplete across these import sites",
        })
    if cyclic_sccs:
        issues.append({
            "kind": "cyclic_dependency_surfaces",
            "count": len(cyclic_sccs),
            "reasoning_effect": "treat files in each SCC as mutually coupled for static impact reasoning",
        })
    if int(summary.get("entrypoint_count", 0) or 0) == 0 and vertices:
        issues.append({
            "kind": "entrypoint_detection_unresolved",
            "count": 0,
            "reasoning_effect": "do not infer repository execution roots from topology alone",
        })
    if int(summary.get("test_file_count", 0) or 0) == 0 and vertices:
        issues.append({
            "kind": "no_supported_test_files_detected",
            "count": 0,
            "reasoning_effect": "static test reachability cannot be assumed from this graph",
        })

    result: Dict[str, Any] = {
        "schema_version": SCHEMA_VERSION,
        "policy": POLICY,
        "stage": "TARGET_STRUCTURAL_ORIENTATION_READY",
        "scan_root": scan_root,
        "technical_model": {
            "canonical_concepts": [
                "directed dependency graph",
                "import graph",
                "graph reachability",
                "fan-in/fan-out centrality",
                "strongly connected components",
            ],
            "edge_semantics": "source file imports target file",
            "not_equivalent_to": [
                "runtime call graph",
                "behavioral execution trace",
                "test coverage",
                "proof of correctness",
            ],
        },
        "inventory": {
            "files": int(summary.get("total_files", len(vertices)) or 0),
            "internal_import_edges": int(summary.get("total_edges", len(edges)) or 0),
            "runtime_edges": int(summary.get("runtime_edge_count", 0) or 0),
            "type_only_edges": int(summary.get("type_only_edge_count", 0) or 0),
            "entrypoints": int(summary.get("entrypoint_count", 0) or 0),
            "tests": int(summary.get("test_file_count", 0) or 0),
            "boundaries": int(summary.get("total_boundaries", len(boundaries)) or 0),
            "unresolved_imports": int(summary.get("total_unresolved", len(unresolved)) or 0),
            "external_imports": int(summary.get("total_external", len(external)) or 0),
            "weak_components": _weak_component_count(vertices, edges),
            "cyclic_sccs": len(cyclic_sccs),
            "isolated_files": len(isolated),
        },
        "entrypoint_surface": {"shown": entrypoints, "omitted_count": entrypoint_omitted},
        "test_surface": {"shown": tests, "omitted_count": test_omitted},
        "high_fan_in": _hub_rows(node_metadata, scan_root, "fan_in", top_n),
        "high_fan_out": _hub_rows(node_metadata, scan_root, "fan_out", top_n),
        "graph_roots": {"shown": roots, "omitted_count": root_omitted},
        "graph_leaves": {"shown": leaves, "omitted_count": leaf_omitted},
        "cyclic_sccs": [
            {
                "size": len(component),
                "files": [_display(path, scan_root) for path in component[:top_n]],
                "omitted_count": max(0, len(component) - top_n),
            }
            for component in cyclic_sccs[:top_n]
        ],
        "boundary_surface": _boundary_rows(boundaries, file_to_boundary, scan_root, top_n),
        "import_resolution": {
            "unresolved_sample": unresolved_sample,
            "unresolved_omitted_count": max(0, len(unresolved) - len(unresolved_sample)),
            "top_external_packages": external_packages,
        },
        "reasoning_gaps": issues,
        "next_reasoning": {
            "instruction": "Resolve the user/task target against this topology before selecting a specialized capability.",
            "when_target_is_known": "inspect the target node neighborhood and transitive impact",
            "when_target_is_unknown": "use task/source evidence to resolve candidate target nodes without treating text similarity as ownership proof",
            "capability_not_selected_by_this_stage": True,
        },
        "authority": {
            "read_only": True,
            "selects_PLW_capability": False,
            "mutate_source": False,
            "execute_runtime": False,
            "commit_truth": False,
        },
    }
    if include_edges:
        result["import_edges"] = [
            {"source": _display(src, scan_root), "target": _display(dst, scan_root)}
            for src, dst in edges
        ]
    else:
        result["import_edges"] = {
            "included": False,
            "total": len(edges),
            "recovery": "use `plw topology <root> --full-edges --json` for the exact file→import→file edge list",
        }
    return result


__all__ = [
    "SCHEMA_VERSION", "POLICY", "DEFAULT_TOP_N", "MAX_TOP_N",
    "build_target_topology_orientation",
]
