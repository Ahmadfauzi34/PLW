"""F121 crash-safe, single-use execution lease reference machine.

The lease is the first state-changing boundary in the capability-action chain.
It revalidates one issuer-sealed F119 preflight, then atomically claims both the
authorization nonce and freshness nonce in one SQLite transaction.  The claim
may authorize one allowlisted executor to *start the exact bound plan*; it does
not execute that plan or grant any transition/runtime/patch/promotion/truth
effect by itself.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import sqlite3
import time
from collections.abc import Iterable, Mapping
from pathlib import Path
from typing import Any, Dict

from core.accountability_provenance import (
    PREFLIGHT_RECORD_ISSUER,
    seal_payload,
    verify_payload,
    verify_record,
)
from core.capability_action_authority import AUTHORITY_CLASS
from core.capability_action_preflight import (
    ACCOUNTABILITY_RECORD_KEYS as PREFLIGHT_RECORD_KEYS,
    DECISION_TYPE as PREFLIGHT_DECISION_TYPE,
    POLICY_VERSION as PREFLIGHT_POLICY,
    SCHEMA_VERSION as PREFLIGHT_SCHEMA,
    evaluate_action_preflight,
)
from core.capability_contracts import (
    AUTHORIZATION_KEYS,
    exact_keys,
    is_sha256_id,
    no_effect_authorizations,
    no_effect_results,
    normalize_mapping,
    safe_canonical_digest,
)
from core.context_accountability import DEFAULT_ACCOUNTABILITY_DIR, load_accountability


SCHEMA_VERSION = "capability-workflow-action-lease-v1"
POLICY_VERSION = "atomic-single-use-executor-lease-v1"
DECISION_TYPE = "capability_workflow_action_lease"
LEASE_RECEIPT_SCHEMA = "capability-workflow-action-lease-receipt-v1"
LEASE_RECEIPT_ISSUER = "plw.workflow.atomic-action-lease.v1"
LEASE_DATABASE_SCHEMA_VERSION = 1
MAX_LEASE_TTL_SECONDS = 30

_EXECUTOR_ID = re.compile(r"[A-Za-z0-9][A-Za-z0-9._:/-]{2,127}\Z")
_IDEMPOTENCY_KEY = re.compile(r"[A-Za-z0-9][A-Za-z0-9._:-]{15,127}\Z")
_ALLOWED_REQUEST_KEYS = frozenset({
    "schema_version", "policy", "preflight_accountability_id",
    "preflight_request_digest", "capability_id", "executor_id",
    "idempotency_key", "lease_ttl_seconds", "caller_requests_execution_lease",
    "authority", "authorizations",
})
_LEASE_BODY_KEYS = frozenset({
    "schema_version", "decision_type", "policy", "lease_state",
    "request_digest", "preflight_accountability_id", "preflight_request_digest",
    "plan_digest", "capability_id", "workflow_state", "workflow_evidence_digest",
    "executor_id", "idempotency_key", "authorization_nonce_digest",
    "freshness_nonce_digest", "acquired_at_epoch", "expires_at_epoch",
    "authority_class", "scope",
})
_LEASE_RECEIPT_KEYS = _LEASE_BODY_KEYS | {"lease_id", "provenance"}
_ACTUAL_EFFECTS = {
    "transition_executed": False,
    "runtime_executed": False,
    "external_patch_applied": False,
    "stable_promoted": False,
    "truth_committed": False,
}


def _nonce_digest(value: str) -> str:
    return "sha256:" + hashlib.sha256(value.encode("utf-8")).hexdigest()


def _lease_database_path(
    store_dir: str | os.PathLike[str] | None,
) -> Path:
    base = Path(
        store_dir
        or os.environ.get("PLW_ACCOUNTABILITY_DIR")
        or DEFAULT_ACCOUNTABILITY_DIR
    )
    path = base / "execution_leases.sqlite3"
    return path.expanduser().resolve()


def _initialize_database(path: Path) -> sqlite3.Connection:
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    try:
        os.chmod(path.parent, 0o700)
    except OSError:
        pass
    if path.is_symlink():
        raise ValueError("Execution lease database must not be a symbolic link")

    connection = sqlite3.connect(str(path), timeout=5.0, isolation_level=None)
    try:
        connection.execute("PRAGMA busy_timeout=5000")
        connection.execute("PRAGMA foreign_keys=ON")
        connection.execute("PRAGMA synchronous=FULL")
        connection.execute("PRAGMA journal_mode=DELETE")
        connection.execute("BEGIN IMMEDIATE")
        version = int(connection.execute("PRAGMA user_version").fetchone()[0])
        if version not in (0, LEASE_DATABASE_SCHEMA_VERSION):
            raise ValueError("Unsupported execution lease database schema")
        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS execution_leases (
                lease_id TEXT PRIMARY KEY,
                request_digest TEXT NOT NULL,
                idempotency_key TEXT NOT NULL UNIQUE,
                authorization_nonce TEXT NOT NULL UNIQUE,
                freshness_nonce TEXT NOT NULL UNIQUE,
                executor_id TEXT NOT NULL,
                acquired_at_epoch INTEGER NOT NULL,
                expires_at_epoch INTEGER NOT NULL,
                receipt_json TEXT NOT NULL
            )
            """
        )
        if version == 0:
            connection.execute(f"PRAGMA user_version={LEASE_DATABASE_SCHEMA_VERSION}")
        connection.execute("COMMIT")
        try:
            os.chmod(path, 0o600)
        except OSError:
            pass
        return connection
    except Exception:
        try:
            connection.execute("ROLLBACK")
        except sqlite3.Error:
            pass
        connection.close()
        raise


def _read_connection(path: Path) -> sqlite3.Connection:
    if not path.is_file() or path.is_symlink():
        raise FileNotFoundError("Execution lease database is unavailable")
    connection = sqlite3.connect(path.as_uri() + "?mode=ro", uri=True, timeout=5.0)
    connection.execute("PRAGMA busy_timeout=5000")
    version = int(connection.execute("PRAGMA user_version").fetchone()[0])
    if version != LEASE_DATABASE_SCHEMA_VERSION:
        connection.close()
        raise ValueError("Unsupported execution lease database schema")
    return connection


def _executor_allowlist(value: Iterable[str] | None) -> tuple[set[str], bool]:
    if value is None:
        raw = os.environ.get("PLW_EXECUTOR_ALLOWLIST", "")
        entries: Any = [item.strip() for item in raw.split(",") if item.strip()]
    elif isinstance(value, (str, bytes)):
        return set(), False
    else:
        try:
            entries = list(value)
        except TypeError:
            return set(), False
    if not entries or not all(isinstance(item, str) and _EXECUTOR_ID.fullmatch(item) for item in entries):
        return set(), False
    return set(entries), True


def build_action_lease_request(
    preflight_accountability_id: str,
    preflight_request: Mapping[str, Any] | None,
    executor_id: str,
    idempotency_key: str,
    *,
    lease_ttl_seconds: int = 15,
) -> Dict[str, Any]:
    """Build a no-effect request; request construction never consumes a nonce."""
    preflight, valid = normalize_mapping(preflight_request)
    return {
        "schema_version": SCHEMA_VERSION,
        "policy": POLICY_VERSION,
        "preflight_accountability_id": str(preflight_accountability_id or ""),
        "preflight_request_digest": safe_canonical_digest(preflight) or "",
        "capability_id": str(preflight.get("capability_id") or ""),
        "executor_id": str(executor_id or ""),
        "idempotency_key": str(idempotency_key or ""),
        "lease_ttl_seconds": lease_ttl_seconds,
        "caller_requests_execution_lease": valid and bool(preflight),
        "authority": "atomic_execution_lease_request_only",
        "authorizations": {key: False for key in sorted(AUTHORIZATION_KEYS)},
    }


def _verify_preflight_record(
    decision_id: str,
    recomputed: Mapping[str, Any],
    *,
    store_dir: str | os.PathLike[str] | None,
) -> tuple[Dict[str, Any], list[str]]:
    failures: list[str] = []
    stored: Dict[str, Any] = {}
    if not is_sha256_id(decision_id):
        return stored, ["preflight_accountability_id"]
    try:
        stored = load_accountability(decision_id, store_dir=store_dir)
    except (ValueError, FileNotFoundError, OSError, TypeError):
        return {}, ["preflight_record"]

    required = (
        exact_keys(stored, PREFLIGHT_RECORD_KEYS),
        stored.get("schema_version") == PREFLIGHT_SCHEMA,
        stored.get("policy") == PREFLIGHT_POLICY,
        stored.get("decision_type") == PREFLIGHT_DECISION_TYPE,
        stored.get("preflight_ready") is True,
        stored.get("decision") == "AUTHORIZED_ACTION_PREFLIGHT_READY",
        stored.get("authority") == "workflow_action_preflight_only",
        no_effect_authorizations(stored.get("authorizations")),
        no_effect_results(stored.get("effects")),
        verify_record(stored, PREFLIGHT_RECORD_ISSUER, store_dir=store_dir),
    )
    if not all(required):
        failures.append("preflight_record_contract")
    fields = (
        "request_digest", "dry_run_accountability_id", "dry_run_request_digest",
        "plan_digest", "capability_id", "workflow_state", "workflow_evidence_digest",
        "current_envelope_digest", "freshness_assertion_digest", "freshness_source",
        "freshness_nonce", "freshness_expires_at_epoch", "executor_handoff",
    )
    if any(stored.get(key) != recomputed.get(key) for key in fields):
        failures.append("preflight_revalidation_binding")
    return stored, failures


def evaluate_action_lease(
    request: Mapping[str, Any] | None,
    preflight_request: Mapping[str, Any] | None,
    dry_run_request: Mapping[str, Any] | None,
    gate_request: Mapping[str, Any] | None,
    authorization_request: Mapping[str, Any] | None,
    proposal_request: Mapping[str, Any] | None,
    current_envelope: Mapping[str, Any] | None,
    *,
    allowed_executor_ids: Iterable[str] | None = None,
    store_dir: str | os.PathLike[str] | None = None,
) -> Dict[str, Any]:
    """Revalidate lease eligibility without changing the nonce-consumption store."""
    req, req_valid = normalize_mapping(request)
    preflight_req, preflight_valid = normalize_mapping(preflight_request)
    dry_req, dry_valid = normalize_mapping(dry_run_request)
    gate_req, gate_valid = normalize_mapping(gate_request)
    auth_req, auth_valid = normalize_mapping(authorization_request)
    proposal_req, proposal_valid = normalize_mapping(proposal_request)
    envelope, envelope_valid = normalize_mapping(current_envelope)
    failures: list[str] = []
    for valid, label in (
        (req_valid, "request_mapping"), (preflight_valid, "preflight_request_mapping"),
        (dry_valid, "dry_run_request_mapping"), (gate_valid, "gate_request_mapping"),
        (auth_valid, "authorization_request_mapping"),
        (proposal_valid, "proposal_request_mapping"),
        (envelope_valid, "current_envelope_mapping"),
    ):
        if not valid:
            failures.append(label)

    if not exact_keys(req, _ALLOWED_REQUEST_KEYS):
        failures.append("request_exact_schema")
    unknown = sorted(set(req) - _ALLOWED_REQUEST_KEYS)
    if unknown:
        failures.append("unknown_request_fields:" + ",".join(unknown))
    if req.get("schema_version") != SCHEMA_VERSION:
        failures.append("schema_version")
    if req.get("policy") != POLICY_VERSION:
        failures.append("policy")
    if req.get("caller_requests_execution_lease") is not True:
        failures.append("caller_requests_execution_lease_is_true")
    if (
        req.get("authority") != "atomic_execution_lease_request_only"
        or not no_effect_authorizations(req.get("authorizations"))
    ):
        failures.append("request_has_no_execution_effect")

    request_digest = safe_canonical_digest(req)
    preflight_digest = safe_canonical_digest(preflight_req)
    if request_digest is None:
        failures.append("request_bounded_canonical_json")
    if preflight_digest is None or req.get("preflight_request_digest") != preflight_digest:
        failures.append("preflight_request_digest")

    executor_id = req.get("executor_id")
    allowlist, allowlist_valid = _executor_allowlist(allowed_executor_ids)
    if not isinstance(executor_id, str) or _EXECUTOR_ID.fullmatch(executor_id) is None:
        failures.append("executor_id")
    if not allowlist_valid:
        failures.append("executor_allowlist_unavailable")
    elif executor_id not in allowlist:
        failures.append("executor_not_allowlisted")
    idempotency_key = req.get("idempotency_key")
    if not isinstance(idempotency_key, str) or _IDEMPOTENCY_KEY.fullmatch(idempotency_key) is None:
        failures.append("idempotency_key")
    ttl = req.get("lease_ttl_seconds")
    if type(ttl) is not int or not (1 <= ttl <= MAX_LEASE_TTL_SECONDS):
        failures.append("lease_ttl_seconds")

    try:
        preflight = evaluate_action_preflight(
            preflight_req, dry_req, gate_req, auth_req, proposal_req, envelope,
            store_dir=str(store_dir) if store_dir is not None else None,
        )
    except Exception as exc:
        preflight = {}
        failures.append("preflight_revalidation_error:" + type(exc).__name__)
    if preflight.get("preflight_ready") is not True:
        failures.append("preflight_revalidation_ready")

    preflight_id = str(req.get("preflight_accountability_id") or "")
    _, record_failures = _verify_preflight_record(
        preflight_id, preflight, store_dir=store_dir,
    )
    failures.extend(record_failures)
    if req.get("capability_id") != preflight.get("capability_id"):
        failures.append("capability_binding")

    authority_assertion = (
        auth_req.get("authority_assertion")
        if isinstance(auth_req.get("authority_assertion"), dict)
        else {}
    )
    freshness_assertion = (
        preflight_req.get("freshness_assertion")
        if isinstance(preflight_req.get("freshness_assertion"), dict)
        else {}
    )
    authorization_nonce = authority_assertion.get("nonce")
    freshness_nonce = freshness_assertion.get("nonce")
    if not isinstance(authorization_nonce, str) or not authorization_nonce:
        failures.append("authorization_nonce_binding")
    if not isinstance(freshness_nonce, str) or not freshness_nonce:
        failures.append("freshness_nonce_binding")
    if freshness_nonce != preflight.get("freshness_nonce"):
        failures.append("freshness_nonce_preflight_binding")

    current_time = int(time.time())
    auth_expires = authority_assertion.get("expires_at_epoch")
    freshness_expires = freshness_assertion.get("expires_at_epoch")
    if type(auth_expires) is not int or auth_expires <= current_time:
        failures.append("authorization_expiry_binding")
    if type(freshness_expires) is not int or freshness_expires <= current_time:
        failures.append("freshness_expiry_binding")
    proposed_expiry = (
        min(current_time + ttl, auth_expires, freshness_expires)
        if type(ttl) is int and type(auth_expires) is int and type(freshness_expires) is int
        else current_time
    )
    if proposed_expiry <= current_time:
        failures.append("effective_lease_expiry")

    eligible = not failures
    return {
        "schema_version": SCHEMA_VERSION,
        "decision_type": DECISION_TYPE,
        "policy": POLICY_VERSION,
        "lease_eligible": eligible,
        "decision": "AUTHORIZED_ACTION_LEASE_ELIGIBLE" if eligible else "AUTHORIZED_ACTION_LEASE_REJECTED",
        "failed_conditions": failures,
        "request_digest": request_digest or "",
        "preflight_accountability_id": preflight_id,
        "preflight_request_digest": preflight_digest or "",
        "plan_digest": str(preflight.get("plan_digest") or ""),
        "capability_id": str(preflight.get("capability_id") or ""),
        "workflow_state": str(preflight.get("workflow_state") or ""),
        "workflow_evidence_digest": str(preflight.get("workflow_evidence_digest") or ""),
        "executor_id": str(executor_id or ""),
        "idempotency_key": str(idempotency_key or ""),
        "authorization_nonce_digest": _nonce_digest(authorization_nonce) if isinstance(authorization_nonce, str) else "",
        "freshness_nonce_digest": _nonce_digest(freshness_nonce) if isinstance(freshness_nonce, str) else "",
        "evaluated_at_epoch": current_time,
        "proposed_expires_at_epoch": proposed_expiry,
        "authority": "workflow_action_lease_eligibility_only",
        "authorizations": {key: False for key in sorted(AUTHORIZATION_KEYS)},
        "effects": dict(_ACTUAL_EFFECTS),
        "invariants": {
            "full_preflight_chain_revalidated": (
                preflight.get("preflight_ready") is True and not record_failures
            ),
            "allowlisted_executor_required": True,
            "eligibility_does_not_consume_nonces": True,
            "eligibility_is_not_execution": True,
        },
    }


def _verify_lease_receipt(
    receipt: Any,
    *,
    store_dir: str | os.PathLike[str] | None,
) -> bool:
    if not exact_keys(receipt, _LEASE_RECEIPT_KEYS):
        return False
    assert isinstance(receipt, dict)
    body = {key: receipt[key] for key in _LEASE_BODY_KEYS}
    lease_id = safe_canonical_digest(body, max_bytes=32768)
    return (
        lease_id is not None
        and receipt.get("lease_id") == lease_id
        and verify_payload(body, receipt.get("provenance"), LEASE_RECEIPT_ISSUER, store_dir=store_dir)
    )


def _claim_nonce_pair(
    eligibility: Mapping[str, Any],
    authorization_nonce: str,
    freshness_nonce: str,
    *,
    store_dir: str | os.PathLike[str] | None,
    fail_before_commit: bool = False,
) -> Dict[str, Any]:
    path = _lease_database_path(store_dir)
    acquired_at = int(eligibility.get("evaluated_at_epoch") or int(time.time()))
    body = {
        "schema_version": LEASE_RECEIPT_SCHEMA,
        "decision_type": DECISION_TYPE,
        "policy": POLICY_VERSION,
        "lease_state": "ACTIVE",
        "request_digest": str(eligibility.get("request_digest") or ""),
        "preflight_accountability_id": str(eligibility.get("preflight_accountability_id") or ""),
        "preflight_request_digest": str(eligibility.get("preflight_request_digest") or ""),
        "plan_digest": str(eligibility.get("plan_digest") or ""),
        "capability_id": str(eligibility.get("capability_id") or ""),
        "workflow_state": str(eligibility.get("workflow_state") or ""),
        "workflow_evidence_digest": str(eligibility.get("workflow_evidence_digest") or ""),
        "executor_id": str(eligibility.get("executor_id") or ""),
        "idempotency_key": str(eligibility.get("idempotency_key") or ""),
        "authorization_nonce_digest": _nonce_digest(authorization_nonce),
        "freshness_nonce_digest": _nonce_digest(freshness_nonce),
        "acquired_at_epoch": acquired_at,
        "expires_at_epoch": int(eligibility.get("proposed_expires_at_epoch") or acquired_at),
        "authority_class": AUTHORITY_CLASS,
        "scope": "single_plan_single_executor_start",
    }
    lease_id = safe_canonical_digest(body, max_bytes=32768)
    if lease_id is None:
        return {"status": "store_error", "failed_conditions": ["lease_receipt_bounded_json"]}
    try:
        receipt = {
            "lease_id": lease_id,
            **body,
            "provenance": seal_payload(body, LEASE_RECEIPT_ISSUER, store_dir=store_dir),
        }
        connection = _initialize_database(path)
    except Exception as exc:
        return {"status": "store_error", "failed_conditions": ["lease_store_open:" + type(exc).__name__]}

    try:
        connection.execute("BEGIN IMMEDIATE")
        existing = connection.execute(
            "SELECT request_digest, executor_id, receipt_json FROM execution_leases WHERE idempotency_key = ?",
            (body["idempotency_key"],),
        ).fetchone()
        if existing is not None:
            connection.execute("COMMIT")
            try:
                prior = json.loads(existing[2])
            except (TypeError, json.JSONDecodeError):
                return {"status": "store_error", "failed_conditions": ["lease_receipt_corrupt"]}
            if (
                existing[0] == body["request_digest"]
                and existing[1] == body["executor_id"]
                and _verify_lease_receipt(prior, store_dir=store_dir)
            ):
                return {"status": "recovered", "receipt": prior, "failed_conditions": []}
            return {"status": "conflict", "failed_conditions": ["idempotency_key_conflict"]}

        if body["expires_at_epoch"] <= int(time.time()):
            connection.execute("ROLLBACK")
            return {
                "status": "conflict",
                "failed_conditions": ["effective_lease_expired_before_commit"],
            }

        try:
            connection.execute(
                """
                INSERT INTO execution_leases (
                    lease_id, request_digest, idempotency_key, authorization_nonce,
                    freshness_nonce, executor_id, acquired_at_epoch, expires_at_epoch,
                    receipt_json
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    lease_id, body["request_digest"], body["idempotency_key"],
                    authorization_nonce, freshness_nonce, body["executor_id"],
                    body["acquired_at_epoch"], body["expires_at_epoch"],
                    json.dumps(receipt, ensure_ascii=False, sort_keys=True, separators=(",", ":")),
                ),
            )
        except sqlite3.IntegrityError:
            failures: list[str] = []
            if connection.execute(
                "SELECT 1 FROM execution_leases WHERE authorization_nonce = ?", (authorization_nonce,)
            ).fetchone():
                failures.append("authorization_nonce_already_consumed")
            if connection.execute(
                "SELECT 1 FROM execution_leases WHERE freshness_nonce = ?", (freshness_nonce,)
            ).fetchone():
                failures.append("freshness_nonce_already_consumed")
            connection.execute("ROLLBACK")
            return {"status": "conflict", "failed_conditions": failures or ["lease_unique_constraint"]}

        if fail_before_commit:
            raise RuntimeError("injected_precommit_failure")
        connection.execute("COMMIT")
        return {"status": "acquired", "receipt": receipt, "failed_conditions": []}
    except Exception as exc:
        try:
            connection.execute("ROLLBACK")
        except sqlite3.Error:
            pass
        return {"status": "store_error", "failed_conditions": ["lease_transaction:" + type(exc).__name__]}
    finally:
        connection.close()


def acquire_action_lease(
    request: Mapping[str, Any] | None,
    preflight_request: Mapping[str, Any] | None,
    dry_run_request: Mapping[str, Any] | None,
    gate_request: Mapping[str, Any] | None,
    authorization_request: Mapping[str, Any] | None,
    proposal_request: Mapping[str, Any] | None,
    current_envelope: Mapping[str, Any] | None,
    *,
    allowed_executor_ids: Iterable[str] | None = None,
    store_dir: str | os.PathLike[str] | None = None,
    _fail_before_commit: bool = False,
) -> Dict[str, Any]:
    """Atomically claim both nonces; exactly one competing request can win."""
    eligibility = evaluate_action_lease(
        request, preflight_request, dry_run_request, gate_request,
        authorization_request, proposal_request, current_envelope,
        allowed_executor_ids=allowed_executor_ids, store_dir=store_dir,
    )
    if eligibility.get("lease_eligible") is not True:
        return {
            **eligibility,
            "lease_acquired": False,
            "idempotent_recovery": False,
            "executor_start_authorized": False,
            "nonce_consumption": {"authorization": False, "freshness": False},
        }

    auth_req, _ = normalize_mapping(authorization_request)
    preflight_req, _ = normalize_mapping(preflight_request)
    authority_assertion = auth_req.get("authority_assertion") or {}
    freshness_assertion = preflight_req.get("freshness_assertion") or {}
    result = _claim_nonce_pair(
        eligibility,
        str(authority_assertion.get("nonce") or ""),
        str(freshness_assertion.get("nonce") or ""),
        store_dir=store_dir,
        fail_before_commit=_fail_before_commit,
    )
    status = result.get("status")
    acquired = status == "acquired"
    recovered = status == "recovered"
    receipt = result.get("receipt") if isinstance(result.get("receipt"), dict) else {}
    return {
        **eligibility,
        "lease_eligible": True,
        "lease_acquired": acquired,
        "idempotent_recovery": recovered,
        "executor_start_authorized": acquired,
        "decision": (
            "AUTHORIZED_ACTION_LEASE_ACQUIRED" if acquired
            else "AUTHORIZED_ACTION_LEASE_RECOVERED_NO_SECOND_START" if recovered
            else "AUTHORIZED_ACTION_LEASE_REJECTED"
        ),
        "failed_conditions": list(result.get("failed_conditions") or []),
        "lease_id": str(receipt.get("lease_id") or ""),
        "lease_receipt": receipt,
        "compare_and_swap": {
            "expected_nonce_state": "UNCONSUMED",
            "observed_transition": "UNCONSUMED_TO_LEASED" if acquired else "UNCHANGED",
            "atomic": status in {"acquired", "recovered", "conflict"},
            "durable": status in {"acquired", "recovered"},
        },
        "nonce_consumption": {
            "authorization": acquired or recovered,
            "freshness": acquired or recovered,
            "newly_consumed_by_this_call": acquired,
        },
        "authority": "workflow_atomic_execution_lease_only",
        "authorizations": {
            "executor_start": acquired,
            **{key: False for key in sorted(AUTHORIZATION_KEYS)},
        },
        "effects": {
            "lease_state_changed": acquired,
            "authorization_nonce_consumed": acquired,
            "freshness_nonce_consumed": acquired,
            **_ACTUAL_EFFECTS,
        },
        "invariants": {
            **eligibility.get("invariants", {}),
            "nonce_pair_claimed_in_one_transaction": acquired or recovered,
            "recovery_never_grants_a_second_start": True,
            "lease_acquisition_is_not_action_execution": True,
        },
    }


def inspect_action_lease(
    lease_id: str,
    *,
    executor_id: str | None = None,
    store_dir: str | os.PathLike[str] | None = None,
) -> Dict[str, Any]:
    """Read and verify one lease; inspection never grants executor-start authority."""
    if not is_sha256_id(lease_id):
        return {"lease_found": False, "error": "invalid_lease_id"}
    path = _lease_database_path(store_dir)
    try:
        connection = _read_connection(path)
        try:
            row = connection.execute(
                "SELECT receipt_json FROM execution_leases WHERE lease_id = ?", (lease_id,)
            ).fetchone()
        finally:
            connection.close()
    except (FileNotFoundError, ValueError, sqlite3.Error, OSError) as exc:
        return {"lease_found": False, "error": "lease_store_read:" + type(exc).__name__}
    if row is None:
        return {"lease_found": False, "error": "lease_not_found"}
    try:
        receipt = json.loads(row[0])
    except (TypeError, json.JSONDecodeError):
        return {"lease_found": False, "error": "lease_receipt_corrupt"}
    if not _verify_lease_receipt(receipt, store_dir=store_dir):
        return {"lease_found": False, "error": "lease_receipt_verification_failed"}
    if executor_id is not None and receipt.get("executor_id") != executor_id:
        return {"lease_found": False, "error": "executor_binding_mismatch"}
    active = type(receipt.get("expires_at_epoch")) is int and receipt["expires_at_epoch"] > int(time.time())
    return {
        "lease_found": True,
        "lease_active": active,
        "decision": "ACTION_LEASE_ACTIVE" if active else "ACTION_LEASE_EXPIRED",
        "lease_id": lease_id,
        "lease_receipt": receipt,
        "executor_start_authorized": False,
        "authority": "execution_lease_inspection_only",
        "invariants": {
            "inspection_is_read_only": True,
            "inspection_cannot_regrant_executor_start": True,
            "consumed_nonces_remain_consumed_after_expiry": True,
        },
    }


__all__ = [
    "SCHEMA_VERSION", "POLICY_VERSION", "DECISION_TYPE", "LEASE_RECEIPT_SCHEMA",
    "LEASE_RECEIPT_ISSUER", "LEASE_DATABASE_SCHEMA_VERSION", "MAX_LEASE_TTL_SECONDS",
    "build_action_lease_request", "evaluate_action_lease", "acquire_action_lease",
    "inspect_action_lease",
]
