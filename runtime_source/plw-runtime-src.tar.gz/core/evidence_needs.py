"""F138.4 target-grounded evidence-need derivation.

Derives what is known, what remains unknown, and what technical evidence would
close those gaps. This layer deliberately does not select a PLW capability,
execute code, mutate source, or claim behavioral correctness.
"""
from __future__ import annotations

import os
import re
from typing import Any, Dict, Iterable, List, Mapping

SCHEMA_VERSION = "target-evidence-need-derivation-v1"
POLICY = "target-grounded-unknowns-before-capability-selection-v1"
_GROUNDED = {"RESOLVED", "MULTI_TARGET_RESOLVED"}


def _display(path: str, root: str) -> str:
    try:
        rel = os.path.relpath(os.path.abspath(path), os.path.abspath(root))
        if rel != ".." and not rel.startswith(".." + os.sep):
            return rel.replace(os.sep, "/")
    except (TypeError, ValueError):
        pass
    return str(path).replace("\\", "/")


def _node_for_display(display: str, vertices: Iterable[str], root: str) -> str | None:
    needle = str(display).replace("\\", "/")
    for vertex in vertices:
        if _display(str(vertex), root) == needle:
            return str(vertex)
    return None


def _tokens(text: str) -> set[str]:
    return {t for t in re.findall(r"[a-zA-Z][a-zA-Z0-9_-]{2,}", str(text).lower())}


def _add_unique(rows: List[Dict[str, Any]], row: Dict[str, Any]) -> None:
    key = (row.get("evidence_class"), row.get("need"), row.get("reason"))
    if key not in {(r.get("evidence_class"), r.get("need"), r.get("reason")) for r in rows}:
        rows.append(row)


def build_evidence_need_derivation(
    shared_graph: Mapping[str, Any],
    task: str,
    target_resolution: Mapping[str, Any],
) -> Dict[str, Any]:
    if not isinstance(task, str) or not task.strip():
        raise ValueError("task must be a non-empty string")

    resolution = target_resolution.get("resolution", {}) or {}
    state = str(resolution.get("state") or "").upper()
    selected = [str(x) for x in resolution.get("selected_targets", []) or []]
    root = str(shared_graph.get("scan_root") or ".")

    base: Dict[str, Any] = {
        "schema_version": SCHEMA_VERSION,
        "policy": POLICY,
        "task": task,
        "target_resolution_state": state or "UNKNOWN",
        "selected_targets": selected,
        "known": [],
        "unknown": [],
        "evidence_needed": [],
        "authority": {
            "read_only": True,
            "selects_PLW_capability": False,
            "semantic_ownership_proven": False,
            "behavioral_correctness_proven": False,
            "execute_runtime": False,
            "mutate_source": False,
            "commit_truth": False,
        },
    }
    if state not in _GROUNDED or not selected:
        base.update({
            "stage": "EVIDENCE_NEED_BLOCKED_TARGET_UNRESOLVED",
            "blocked_reason": "target_resolution_must_be_grounded_before_evidence_need_derivation",
            "next_reasoning": "Resolve or explicitly disambiguate the target first; task wording alone must not create technical evidence requirements.",
        })
        return base

    vertices = [str(v) for v in shared_graph.get("vertices", []) or []]
    file_map = shared_graph.get("file_map", {}) or {}
    resolved_imports = shared_graph.get("resolved_imports", {}) or {}
    external_imports = shared_graph.get("external_imports", []) or []
    unresolved_imports = shared_graph.get("unresolved_imports", []) or []
    node_meta = shared_graph.get("node_metadata", {}) or {}

    known: List[Dict[str, Any]] = []
    unknown: List[Dict[str, Any]] = []
    needs: List[Dict[str, Any]] = []
    combined_source = ""
    target_nodes: List[str] = []

    for display in selected:
        node = _node_for_display(display, vertices, root)
        if not node:
            unknown.append({"claim": "selected target exists in current graph snapshot", "target": display, "reason": "target_identity_not_found_in_graph_snapshot"})
            continue
        target_nodes.append(node)
        content = str(file_map.get(node, ""))
        combined_source += "\n" + content
        meta = node_meta.get(node, {}) or {}
        imports = [_display(str(x), root) for x in resolved_imports.get(node, []) or []]
        known.append({
            "claim": "target node is present in the static dependency graph",
            "target": display,
            "evidence": {"fan_in": int(meta.get("fan_in", 0) or 0), "fan_out": int(meta.get("fan_out", 0) or 0), "direct_imports": imports[:12]},
        })
        unknown.append({"claim": "semantic implementation scope and ownership", "target": display, "reason": "static target resolution does not prove semantic ownership"})
        _add_unique(needs, {"evidence_class": "semantic_scope", "need": "semantic implementation scope evidence", "reason": "resolved file identity does not establish which symbols/state transitions implement the requested behavior"})

    # Reachable tests are useful structural evidence, but never assertion coverage.
    candidate_map = {str(row.get("file")): row for row in target_resolution.get("candidate_targets", []) or []}
    reachable_tests: List[str] = []
    for display in selected:
        ctx = (candidate_map.get(display) or {}).get("structural_context", {}) or {}
        reachable_tests.extend(str(x) for x in ctx.get("reachable_tests", []) or [])
    if reachable_tests:
        known.append({"claim": "statically reachable test files exist", "evidence": sorted(set(reachable_tests))[:16]})
        unknown.append({"claim": "tests assert the requested behavior/postcondition", "reason": "test reachability is not assertion coverage"})
        _add_unique(needs, {"evidence_class": "runtime_regression", "need": "behavioral regression observation", "reason": "reachable tests do not prove they execute or assert the requested behavior"})
    else:
        unknown.append({"claim": "regression test surface for the requested behavior", "reason": "no statically reachable test witness was found"})
        _add_unique(needs, {"evidence_class": "runtime_regression", "need": "behavioral regression observation", "reason": "no grounded test witness currently covers the target behavior"})

    # External/unresolved dependency surfaces tied to the selected target nodes.
    selected_set = set(target_nodes)
    target_external = [row for row in external_imports if isinstance(row, Mapping) and str(row.get("importer")) in selected_set]
    target_unresolved = [row for row in unresolved_imports if isinstance(row, Mapping) and str(row.get("importer")) in selected_set]
    if target_external:
        packages = sorted({str(row.get("raw_import")) for row in target_external if row.get("raw_import")})
        known.append({"claim": "target has external dependency surface", "evidence": packages[:16]})
        unknown.append({"claim": "external dependency behavioral contract", "reason": "import presence does not establish runtime/API semantics"})
        _add_unique(needs, {"evidence_class": "external_contract", "need": "external dependency contract evidence", "reason": "target behavior depends on external APIs whose semantics are not established by the import graph"})
    if target_unresolved:
        unknown.append({"claim": "complete dependency resolution", "reason": "one or more imports from the selected target are unresolved"})
        _add_unique(needs, {"evidence_class": "dependency_resolution", "need": "dependency-resolution completeness evidence", "reason": "unresolved target imports can hide relevant dependency paths"})

    task_tokens = _tokens(task)
    source_tokens = _tokens(combined_source)
    all_tokens = task_tokens | source_tokens
    state_signals = {"retry", "transaction", "commit", "rollback", "lock", "queue", "cache", "state", "payment", "charge", "idempotent", "idempotency"}
    concurrency_signals = {"async", "await", "promise", "thread", "concurrent", "race", "lock", "queue"}
    postcondition_signals = {"safe", "aman", "prevent", "avoid", "double", "duplicate", "correct", "fix", "bug", "ensure", "pastikan"}
    if all_tokens & state_signals:
        unknown.append({"claim": "state ownership, transaction boundary, and side-effect idempotency", "reason": "static source/dependency evidence cannot establish external-effect semantics"})
        _add_unique(needs, {"evidence_class": "state_effect_semantics", "need": "state ownership / transaction / idempotency evidence", "reason": "stateful or repeated-effect signals require a witness for ownership and duplicate-effect prevention"})
    if all_tokens & concurrency_signals:
        unknown.append({"claim": "concurrency and ordering behavior", "reason": "static dependency edges do not establish runtime interleavings"})
        _add_unique(needs, {"evidence_class": "concurrency_ordering", "need": "concurrency ordering evidence", "reason": "possible asynchronous/concurrent behavior requires an observed or formally justified ordering witness"})
    if task_tokens & postcondition_signals:
        unknown.append({"claim": "requested postcondition is satisfied", "reason": "the user goal is a claim, not yet an observed postcondition"})
        _add_unique(needs, {"evidence_class": "postcondition_observation", "need": "requested postcondition observation", "reason": "the requested outcome must be observed or otherwise proven after change"})

    base.update({
        "stage": "EVIDENCE_NEEDS_DERIVED",
        "known": known,
        "unknown": unknown,
        "evidence_needed": needs,
        "technical_model": {
            "canonical_concepts": ["epistemic gap analysis", "evidence requirements", "static-vs-runtime evidence boundary", "test reachability vs coverage"],
            "different_from": ["tool selection", "execution planning", "semantic ownership proof", "behavioral correctness proof"],
        },
        "next_reasoning": "Match unsatisfied evidence needs to capability contracts in a separate stage; do not infer a command from task wording here.",
    })
    return base


__all__ = ["SCHEMA_VERSION", "POLICY", "build_evidence_need_derivation"]
