"""F118 deterministic dry-run plan for one verified F117 authorized-action gate.

The dry-run is an execution *plan*, not execution evidence. It revalidates the
stored F117 gate and stops explicitly before every lifecycle/runtime side effect.
"""
from __future__ import annotations

from typing import Any, Dict, Mapping

from core.accountability_provenance import DRY_RUN_ISSUER, GATE_ISSUER, record_provenanced, verify_record
from core.capability_action_authorization import AUTHORITY_CLASS
from core.capability_action_gate import (
    ACCOUNTABILITY_RECORD_KEYS as GATE_RECORD_KEYS,
    DECISION_TYPE as GATE_DECISION_TYPE,
    POLICY_VERSION as GATE_POLICY,
    SCHEMA_VERSION as GATE_SCHEMA,
    evaluate_authorized_action_gate,
)
from core.capability_contracts import (
    bounded_text,
    exact_keys,
    is_sha256_id,
    no_effect_results,
    no_effect_authorizations,
    normalize_mapping,
    safe_canonical_digest,
)
from core.context_accountability import load_accountability

SCHEMA_VERSION = "capability-workflow-action-dry-run-v1"
POLICY_VERSION = "revalidated_gate_side_effect_free_execution_plan_v1"
DECISION_TYPE = "capability_workflow_action_executor_dry_run"
_REQUIRED_EFFECTS = {
    "transition_execution", "runtime_execution", "external_patch", "stable_promotion", "truth_commit"
}
_ALLOWED_REQUEST_KEYS = {
    "schema_version", "policy", "gate_accountability_id", "gate_request_digest",
    "authorization_request_digest", "proposal_request_digest", "capability_id",
    "caller_requests_dry_run", "action_kind", "target_state", "expected_state",
    "envelope_evidence_digest", "authority", "authorizations",
}
ACCOUNTABILITY_RECORD_KEYS = frozenset({
    "schema_version", "decision_type", "policy", "dry_run_ready", "decision",
    "failed_conditions", "request_digest", "gate_accountability_id",
    "gate_request_digest", "authorization_accountability_id",
    "authorization_request_digest", "proposal_accountability_id",
    "proposal_request_digest", "capability_id", "workflow_state",
    "workflow_evidence_digest", "authority_assertion_digest",
    "authorization_principal", "authorization_nonce", "authorization_expires_at_epoch",
    "execution_plan", "executor_handoff", "authority", "authorizations", "effects",
    "invariants", "provenance", "decision_id", "recorded_at",
})


def build_dry_run_request(
    gate_accountability_id: str,
    gate_request: Mapping[str, Any] | None,
    authorization_request: Mapping[str, Any] | None,
    proposal_request: Mapping[str, Any] | None,
) -> Dict[str, Any]:
    """Build an explicit dry-run request. Construction performs no side effect."""
    gate_req, _ = normalize_mapping(gate_request)
    auth_req, _ = normalize_mapping(authorization_request)
    proposal_req, _ = normalize_mapping(proposal_request)
    return {
        "schema_version": SCHEMA_VERSION,
        "policy": POLICY_VERSION,
        "gate_accountability_id": str(gate_accountability_id or ""),
        "gate_request_digest": safe_canonical_digest(gate_req) or "",
        "authorization_request_digest": safe_canonical_digest(auth_req) or "",
        "proposal_request_digest": safe_canonical_digest(proposal_req) or "",
        "capability_id": str(gate_req.get("capability_id") or ""),
        "caller_requests_dry_run": True,
        "action_kind": str(gate_req.get("action_kind") or ""),
        "target_state": str(gate_req.get("target_state") or ""),
        "expected_state": str(gate_req.get("expected_state") or ""),
        "envelope_evidence_digest": str(gate_req.get("envelope_evidence_digest") or ""),
        "authority": "authorized_action_dry_run_request_only",
        "authorizations": {key: False for key in sorted(_REQUIRED_EFFECTS)},
    }


def _plan(req: Mapping[str, Any], gate: Mapping[str, Any]) -> Dict[str, Any]:
    plan = {
        "mode": "DRY_RUN_ONLY",
        "action_kind": str(req.get("action_kind") or ""),
        "capability_id": str(req.get("capability_id") or ""),
        "from_state": str(req.get("expected_state") or ""),
        "target_state": str(req.get("target_state") or ""),
        "gate_accountability_id": str(req.get("gate_accountability_id") or ""),
        "gate_request_digest": str(req.get("gate_request_digest") or ""),
        "authorization_accountability_id": str(gate.get("authorization_accountability_id") or ""),
        "authorization_request_digest": str(req.get("authorization_request_digest") or ""),
        "proposal_accountability_id": str(gate.get("proposal_accountability_id") or ""),
        "proposal_request_digest": str(req.get("proposal_request_digest") or ""),
        "workflow_evidence_digest": str(req.get("envelope_evidence_digest") or ""),
        "authority_assertion_digest": str(gate.get("authority_assertion_digest") or ""),
        "authorization_principal": str(gate.get("authorization_principal") or ""),
        "authorization_nonce": str(gate.get("authorization_nonce") or ""),
        "authorization_expires_at_epoch": gate.get("authorization_expires_at_epoch"),
        "steps": [
            {"ordinal": 1, "operation": "REVALIDATE_AUTHORIZED_GATE", "effect": "NONE"},
            {"ordinal": 2, "operation": "ASSERT_STATE_AND_EVIDENCE_BINDING", "effect": "NONE"},
            {"ordinal": 3, "operation": "PREVIEW_AUTHORIZED_ACTION", "effect": "NONE"},
            {"ordinal": 4, "operation": "STOP_BEFORE_SIDE_EFFECT", "effect": "NONE"},
        ],
        "execution_started": False,
        "side_effect_boundary": "STOP_BEFORE_EXECUTION",
    }
    digest = safe_canonical_digest(plan)
    if digest is None:
        raise ValueError("Dry-run plan is not bounded canonical JSON")
    return {**plan, "plan_digest": digest}


def evaluate_action_dry_run(
    request: Mapping[str, Any] | None,
    gate_request: Mapping[str, Any] | None,
    authorization_request: Mapping[str, Any] | None,
    proposal_request: Mapping[str, Any] | None,
    envelope: Mapping[str, Any] | None,
    *,
    store_dir: str | None = None,
) -> Dict[str, Any]:
    """Return a deterministic no-side-effect execution plan for one valid F117 gate."""
    req, request_mapping_valid = normalize_mapping(request)
    gate_req, gate_mapping_valid = normalize_mapping(gate_request)
    auth_req, authorization_mapping_valid = normalize_mapping(authorization_request)
    proposal_req, proposal_mapping_valid = normalize_mapping(proposal_request)
    failures: list[str] = []
    if not request_mapping_valid: failures.append("request_mapping")
    if not gate_mapping_valid: failures.append("gate_request_mapping")
    if not authorization_mapping_valid: failures.append("authorization_request_mapping")
    if not proposal_mapping_valid: failures.append("proposal_request_mapping")
    unknown = sorted(set(req) - _ALLOWED_REQUEST_KEYS)
    if unknown: failures.append("unknown_request_fields:" + ",".join(unknown))
    if req.get("schema_version") != SCHEMA_VERSION: failures.append("schema_version")
    if req.get("policy") != POLICY_VERSION: failures.append("policy")
    if req.get("caller_requests_dry_run") is not True: failures.append("caller_requests_dry_run_is_true")
    if req.get("authority") != "authorized_action_dry_run_request_only" or not no_effect_authorizations(req.get("authorizations")):
        failures.append("request_has_no_execution_effect")
    gate_digest = safe_canonical_digest(gate_req)
    authorization_digest = safe_canonical_digest(auth_req)
    proposal_digest = safe_canonical_digest(proposal_req)
    request_digest = safe_canonical_digest(req)
    for key, value in (
        ("gate_request_digest", gate_digest),
        ("authorization_request_digest", authorization_digest),
        ("proposal_request_digest", proposal_digest),
    ):
        if value is None or req.get(key) != value: failures.append(key)
    if request_digest is None: failures.append("request_bounded_canonical_json")

    gate_id = str(req.get("gate_accountability_id") or "")
    stored: Dict[str, Any] = {}
    if not gate_id:
        failures.append("gate_accountability_id")
    elif not is_sha256_id(gate_id):
        failures.append("gate_accountability_id")
    else:
        try:
            stored = load_accountability(gate_id, store_dir=store_dir)
        except (ValueError, FileNotFoundError, OSError, TypeError):
            failures.append("authorized_gate_record")

    recomputed = evaluate_authorized_action_gate(gate_req, auth_req, proposal_req, envelope, store_dir=store_dir)
    if recomputed.get("gate_open") is not True:
        failures.append("authorized_gate_revalidation_open")

    if stored:
        handoff = stored.get("executor_handoff") if isinstance(stored.get("executor_handoff"), dict) else {}
        if not all((
            exact_keys(stored, GATE_RECORD_KEYS),
            stored.get("schema_version") == GATE_SCHEMA,
            stored.get("policy") == GATE_POLICY,
            stored.get("decision_type") == GATE_DECISION_TYPE,
            stored.get("gate_open") is True,
            stored.get("decision") == "AUTHORIZED_ACTION_GATE_OPEN",
            stored.get("authority") == "workflow_authorized_action_gate_only",
            no_effect_authorizations(stored.get("authorizations")),
            no_effect_results(stored.get("effects")),
            verify_record(stored, GATE_ISSUER, store_dir=store_dir),
            handoff.get("authority_class") == AUTHORITY_CLASS,
            handoff.get("eligible") is True,
            handoff.get("execution_started") is False,
        )):
            failures.append("authorized_gate_contract")
        fields = (
            "request_digest", "authorization_accountability_id", "authorization_request_digest",
            "proposal_accountability_id", "proposal_request_digest", "capability_id", "workflow_state",
            "workflow_evidence_digest", "executable_intent", "executor_handoff",
            "authority_assertion_digest", "authorization_principal", "authorization_nonce",
            "authorization_expires_at_epoch",
        )
        if any(stored.get(key) != recomputed.get(key) for key in fields):
            failures.append("authorized_gate_revalidation_binding")

    intent = recomputed.get("executable_intent") if isinstance(recomputed.get("executable_intent"), dict) else {}
    for requested, verified, label in (
        (req.get("capability_id"), recomputed.get("capability_id"), "capability_binding"),
        (req.get("action_kind"), intent.get("kind"), "action_kind_binding"),
        (req.get("target_state"), intent.get("target_state"), "target_state_binding"),
        (req.get("expected_state"), recomputed.get("workflow_state"), "state_binding"),
        (req.get("envelope_evidence_digest"), recomputed.get("workflow_evidence_digest"), "evidence_digest_binding"),
    ):
        if requested != verified: failures.append(label)
    for key in ("capability_id", "target_state", "expected_state"):
        if not bounded_text(req.get(key), maximum=128): failures.append(key)
    if not is_sha256_id(req.get("envelope_evidence_digest")): failures.append("envelope_evidence_digest")

    ready = not failures
    plan = _plan(req, recomputed) if ready else None
    return {
        "schema_version": SCHEMA_VERSION,
        "decision_type": DECISION_TYPE,
        "policy": POLICY_VERSION,
        "dry_run_ready": ready,
        "decision": "AUTHORIZED_ACTION_DRY_RUN_READY" if ready else "AUTHORIZED_ACTION_DRY_RUN_REJECTED",
        "failed_conditions": failures,
        "request_digest": request_digest or "",
        "gate_accountability_id": gate_id,
        "gate_request_digest": gate_digest or "",
        "authorization_accountability_id": recomputed.get("authorization_accountability_id"),
        "authorization_request_digest": authorization_digest or "",
        "proposal_accountability_id": recomputed.get("proposal_accountability_id"),
        "proposal_request_digest": proposal_digest or "",
        "capability_id": str(req.get("capability_id") or ""),
        "workflow_state": str(req.get("expected_state") or ""),
        "workflow_evidence_digest": str(req.get("envelope_evidence_digest") or ""),
        "authority_assertion_digest": recomputed.get("authority_assertion_digest"),
        "authorization_principal": recomputed.get("authorization_principal"),
        "authorization_nonce": recomputed.get("authorization_nonce"),
        "authorization_expires_at_epoch": recomputed.get("authorization_expires_at_epoch"),
        "execution_plan": plan,
        "executor_handoff": {
            "separate_executor_required": True,
            "authority_class": AUTHORITY_CLASS,
            "dry_run_only": True,
            "execution_started": False,
        },
        "authority": "workflow_action_executor_dry_run_only",
        "authorizations": {key: False for key in sorted(_REQUIRED_EFFECTS)},
        "effects": {
            "transition_executed": False,
            "runtime_executed": False,
            "external_patch_applied": False,
            "stable_promoted": False,
            "truth_committed": False,
        },
        "invariants": {
            "authorized_gate_revalidation_required": True,
            "dry_run_is_not_execution_evidence": True,
            "plan_is_deterministic": True,
            "plan_digest_binds_full_provenance": True,
            "stop_before_side_effect": True,
        },
    }


def record_action_dry_run(
    request: Mapping[str, Any] | None,
    gate_request: Mapping[str, Any] | None,
    authorization_request: Mapping[str, Any] | None,
    proposal_request: Mapping[str, Any] | None,
    envelope: Mapping[str, Any] | None,
    *,
    store_dir: str | None = None,
) -> Dict[str, Any]:
    payload = evaluate_action_dry_run(
        request, gate_request, authorization_request, proposal_request, envelope, store_dir=store_dir
    )
    receipt = record_provenanced(payload, DRY_RUN_ISSUER, store_dir=store_dir)
    return {
        **receipt,
        "decision_type": DECISION_TYPE,
        "dry_run_ready": payload["dry_run_ready"],
        "authority": "workflow_action_executor_dry_run_reference_only",
    }


__all__ = [
    "SCHEMA_VERSION", "POLICY_VERSION", "DECISION_TYPE", "ACCOUNTABILITY_RECORD_KEYS",
    "build_dry_run_request", "evaluate_action_dry_run", "record_action_dry_run",
]
