"""Bounded read-only view of F111 relevance -> F112 delivery accountability.

F113 follows content-addressed accountability links without exposing raw prompt/source
and without granting relevance, execution, transition, patch, promotion, or truth
authority. Stored child bindings are revalidated so generic-ledger forgery fails closed.
"""
from __future__ import annotations

import hashlib
import json
from typing import Any, Dict, Mapping

from core.accountability_provenance import DELIVERY_ISSUER, RELEVANCE_ISSUER, verify_record
from core.capability_contracts import (
    bounded_text,
    exact_keys,
    is_sha256_id,
    no_effect_authorizations,
)
from core.capability_delivery import (
    ACCOUNTABILITY_RECORD_KEYS as DELIVERY_RECORD_KEYS,
    DECISION_TYPE as DELIVERY_TYPE,
    POLICY_VERSION as DELIVERY_POLICY,
    SCHEMA_VERSION as DELIVERY_SCHEMA,
)
from core.capability_relevance import (
    ACCOUNTABILITY_DECISION_TYPE as RELEVANCE_TYPE,
    ACCOUNTABILITY_POLICY as RELEVANCE_POLICY,
    ACCOUNTABILITY_RECORD_KEYS as RELEVANCE_RECORD_KEYS,
    ACCOUNTABILITY_SCHEMA as RELEVANCE_SCHEMA,
)
from core.context_accountability import list_accountability_decisions, load_accountability

SCHEMA_VERSION = "capability-workflow-accountability-chain-v1"
POLICY_VERSION = "bounded_verified_relevance_delivery_chain_v1"
_REQUIRED_AUTH = {
    "transition_execution", "runtime_execution", "external_patch", "stable_promotion", "truth_commit"
}


def _safe_auth(record: Mapping[str, Any], authority: str) -> bool:
    return record.get("authority") == authority and no_effect_authorizations(record.get("authorizations"))


def _load_relevance(decision_id: str, store_dir: str | None) -> Dict[str, Any]:
    record = load_accountability(decision_id, store_dir=store_dir)
    if not exact_keys(record, RELEVANCE_RECORD_KEYS):
        raise ValueError("relevance accountability schema is not exact")
    if record.get("schema_version") != RELEVANCE_SCHEMA or record.get("policy") != RELEVANCE_POLICY:
        raise ValueError("relevance accountability schema/policy drift")
    if record.get("decision_type") != RELEVANCE_TYPE:
        raise ValueError("accountability id is not an F111 relevance decision")
    if not _safe_auth(record, "workflow_relevance_accountability_only"):
        raise ValueError("relevance accountability authority drift")
    if not verify_record(record, RELEVANCE_ISSUER, store_dir=store_dir):
        raise ValueError("relevance accountability provenance invalid")
    relevant = record.get("relevant")
    if type(relevant) is not bool:
        raise ValueError("relevance accountability decision type drift")
    if relevant is True and (
        record.get("relevance_decision") != "REQUEST_WORKFLOW_CONTEXT"
        or record.get("failed_conditions") != []
    ):
        raise ValueError("positive relevance accountability is internally inconsistent")
    if not bounded_text(record.get("capability_id"), maximum=128):
        raise ValueError("relevance capability id invalid")
    if not is_sha256_id(record.get("request_digest")) or not is_sha256_id(record.get("workflow_evidence_digest")):
        raise ValueError("relevance digest invalid")
    return record


def _validate_delivery(relevance: Mapping[str, Any], delivery: Mapping[str, Any], store_dir: str | None) -> None:
    if not exact_keys(delivery, DELIVERY_RECORD_KEYS):
        raise ValueError("delivery accountability schema is not exact")
    if delivery.get("schema_version") != DELIVERY_SCHEMA or delivery.get("policy") != DELIVERY_POLICY:
        raise ValueError("delivery accountability schema/policy drift")
    if delivery.get("decision_type") != DELIVERY_TYPE:
        raise ValueError("child is not an F112 delivery decision")
    if not _safe_auth(delivery, "workflow_delivery_accountability_only"):
        raise ValueError("delivery accountability authority drift")
    if not verify_record(delivery, DELIVERY_ISSUER, store_dir=store_dir):
        raise ValueError("delivery accountability provenance invalid")
    pairs = (
        ("capability_id", "capability_id"),
        ("request_digest", "request_digest"),
        ("workflow_evidence_digest", "workflow_evidence_digest"),
    )
    if delivery.get("relevance_accountability_id") != relevance.get("decision_id"):
        raise ValueError("delivery parent relevance id mismatch")
    if any(delivery.get(child) != relevance.get(parent) for child, parent in pairs):
        raise ValueError("delivery accountability binding mismatch")
    outcome = delivery.get("delivery_outcome")
    if outcome not in {"INCLUDED", "BUDGET_OMITTED", "DENIED", "INVALID"}:
        raise ValueError("delivery accountability outcome drift")
    if relevance.get("relevant") is False and outcome not in {"DENIED", "INVALID"}:
        raise ValueError("denied relevance cannot have positive delivery outcome")
    if not is_sha256_id(delivery.get("context_block_digest")) or not is_sha256_id(delivery.get("delivery_metadata_digest")):
        raise ValueError("delivery content digest invalid")
    for field in ("context_block_chars", "rendered_chars"):
        value = delivery.get(field)
        if type(value) is not int or value < 0:
            raise ValueError("delivery size metadata invalid")
    if outcome == "INCLUDED" and (
        relevance.get("relevant") is not True
        or delivery.get("delivery_reason") != "explicit_relevant_advisory_envelope"
        or delivery.get("workflow_marker_present") is not True
    ):
        raise ValueError("included delivery proof is internally inconsistent")


def _summary(record: Mapping[str, Any]) -> Dict[str, Any]:
    return {
        "decision_id": record.get("decision_id"),
        "delivery_outcome": record.get("delivery_outcome"),
        "delivery_reason": record.get("delivery_reason"),
        "context_block_digest": record.get("context_block_digest"),
        "context_block_chars": record.get("context_block_chars"),
        "rendered_chars": record.get("rendered_chars"),
        "recorded_at": record.get("recorded_at"),
    }


def query_accountability_chain(
    decision_id: str,
    *,
    store_dir: str | None = None,
    delivery_limit: int = 16,
) -> Dict[str, Any]:
    """Resolve either an F111 relevance id or F112 delivery id into one bounded chain."""
    start = load_accountability(decision_id, store_dir=store_dir)
    start_type = start.get("decision_type")
    selected_delivery_id = None
    if start_type == RELEVANCE_TYPE:
        relevance = _load_relevance(decision_id, store_dir)
    elif start_type == DELIVERY_TYPE:
        if not _safe_auth(start, "workflow_delivery_accountability_only"):
            raise ValueError("delivery accountability authority drift")
        parent_id = str(start.get("relevance_accountability_id") or "")
        relevance = _load_relevance(parent_id, store_dir)
        _validate_delivery(relevance, start, store_dir)
        selected_delivery_id = start.get("decision_id")
    else:
        raise ValueError("accountability id is not a workflow relevance/delivery decision")

    try:
        max_items = min(64, max(1, int(delivery_limit)))
    except (TypeError, ValueError, OverflowError):
        raise ValueError("Invalid delivery limit") from None
    children = []
    # Scan is bounded for audit ergonomics, not used as truth discovery outside the ledger.
    for record in list_accountability_decisions(store_dir=store_dir, decision_type=DELIVERY_TYPE, limit=256):
        if record.get("relevance_accountability_id") != relevance.get("decision_id"):
            continue
        _validate_delivery(relevance, record, store_dir)
        children.append(_summary(record))
    if selected_delivery_id and selected_delivery_id not in {row.get("decision_id") for row in children}:
        children.append(_summary(start))
    children.sort(key=lambda row: (str(row.get("recorded_at") or ""), str(row.get("decision_id") or "")), reverse=True)
    truncated = len(children) > max_items
    if selected_delivery_id and selected_delivery_id not in {row.get("decision_id") for row in children[:max_items]}:
        selected = next(row for row in children if row.get("decision_id") == selected_delivery_id)
        children = [selected] + [row for row in children if row.get("decision_id") != selected_delivery_id]
    children = children[:max_items]

    relevance_view = {
        "decision_id": relevance.get("decision_id"),
        "capability_id": relevance.get("capability_id"),
        "reason_kind": relevance.get("reason_kind"),
        "workflow_state": relevance.get("workflow_state"),
        "workflow_evidence_digest": relevance.get("workflow_evidence_digest"),
        "request_digest": relevance.get("request_digest"),
        "relevant": relevance.get("relevant") is True,
        "relevance_decision": relevance.get("relevance_decision"),
        "failed_conditions": list(relevance.get("failed_conditions") or []),
        "recorded_at": relevance.get("recorded_at"),
    }
    core = {
        "schema_version": SCHEMA_VERSION,
        "policy": POLICY_VERSION,
        "start_decision_id": start.get("decision_id"),
        "start_decision_type": start_type,
        "selected_delivery_id": selected_delivery_id,
        "relevance": relevance_view,
        "deliveries": children,
        "delivery_count": len(children),
        "deliveries_truncated": truncated,
        "authority": "workflow_accountability_query_only",
        "authorizations": {key: False for key in sorted(_REQUIRED_AUTH)},
    }
    return {
        **core,
        "chain_digest": "sha256:" + hashlib.sha256(json.dumps(core, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()).hexdigest(),
        "invariants": {
            "read_only": True,
            "raw_prompt_exposed": False,
            "raw_source_exposed": False,
            "raw_evidence_exposed": False,
            "parent_child_binding_revalidated": True,
            "transition_execution": False,
            "runtime_execution": False,
            "external_patch": False,
            "stable_promotion": False,
            "truth_commit": False,
        },
    }


__all__ = ["SCHEMA_VERSION", "POLICY_VERSION", "query_accountability_chain"]
