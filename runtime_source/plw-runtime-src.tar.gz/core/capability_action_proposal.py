"""F114 typed proposal-only boundary for audited capability workflow actions.

A proposal may be built only from an F112 INCLUDED delivery and an F107 advisory
envelope whose capability/state/evidence bindings match the audited F111->F112 chain.
The result is metadata for a later, separate authorization step; it never executes.
"""
from __future__ import annotations

from typing import Any, Dict, Mapping

from core.accountability_provenance import PROPOSAL_ISSUER, record_provenanced
from core.capability_accountability_chain import query_accountability_chain
from core.capability_contracts import (
    bounded_text,
    is_sha256_id,
    no_effect_authorizations,
    normalize_mapping,
    safe_canonical_digest,
)
from core.capability_workflow import ADAPTER_POLICY, SCHEMA_VERSION as WORKFLOW_SCHEMA

SCHEMA_VERSION = "capability-workflow-action-proposal-v1"
POLICY_VERSION = "verified_workflow_action_proposal_v1"
DECISION_TYPE = "capability_workflow_action_proposal"
ACTION_KIND = "LIFECYCLE_TRANSITION"
_REQUIRED_AUTH = {
    "transition_execution", "runtime_execution", "external_patch", "stable_promotion", "truth_commit"
}
_ALLOWED_REQUEST_KEYS = {
    "schema_version", "policy", "capability_id", "caller_declared_intent", "action_kind",
    "target_state", "delivery_accountability_id", "expected_state", "envelope_evidence_digest",
    "authority", "authorizations",
}
ACCOUNTABILITY_RECORD_KEYS = frozenset({
    "schema_version", "decision_type", "policy", "proposal_ready", "decision",
    "failed_conditions", "request_digest", "chain_digest",
    "delivery_accountability_id", "relevance_accountability_id", "capability_id",
    "workflow_state", "workflow_evidence_digest", "proposed_action",
    "authorization_requirement", "authority", "authorizations", "invariants",
    "provenance", "decision_id", "recorded_at",
})


def _safe_envelope(envelope: Mapping[str, Any]) -> bool:
    allowed = envelope.get("allowed_targets")
    return (
        envelope.get("schema_version") == WORKFLOW_SCHEMA
        and envelope.get("policy") == ADAPTER_POLICY
        and envelope.get("authority") == "advisory_workflow_only"
        and no_effect_authorizations(envelope.get("authorizations"))
        and isinstance(allowed, list)
        and len(allowed) <= 32
        and all(bounded_text(target, maximum=128) for target in allowed)
    )


def build_action_request(
    capability_id: str,
    delivery_accountability_id: str,
    target_state: str,
    expected_state: str,
    envelope_evidence_digest: str,
) -> Dict[str, Any]:
    """Build explicit proposal intent; construction grants no action authority."""
    return {
        "schema_version": SCHEMA_VERSION,
        "policy": POLICY_VERSION,
        "capability_id": str(capability_id or ""),
        "caller_declared_intent": True,
        "action_kind": ACTION_KIND,
        "target_state": str(target_state or ""),
        "delivery_accountability_id": str(delivery_accountability_id or ""),
        "expected_state": str(expected_state or ""),
        "envelope_evidence_digest": str(envelope_evidence_digest or ""),
        "authority": "action_proposal_request_only",
        "authorizations": {key: False for key in sorted(_REQUIRED_AUTH)},
    }


def build_action_proposal(
    request: Mapping[str, Any] | None,
    envelope: Mapping[str, Any] | None,
    *,
    store_dir: str | None = None,
) -> Dict[str, Any]:
    """Validate audited context delivery and return a proposal-only decision."""
    req, request_mapping_valid = normalize_mapping(request)
    env, envelope_mapping_valid = normalize_mapping(envelope)
    failures: list[str] = []
    if not request_mapping_valid: failures.append("request_mapping")
    if not envelope_mapping_valid: failures.append("workflow_envelope_mapping")
    unknown = sorted(set(req) - _ALLOWED_REQUEST_KEYS)
    if unknown: failures.append("unknown_request_fields:" + ",".join(unknown))
    if req.get("schema_version") != SCHEMA_VERSION: failures.append("schema_version")
    if req.get("policy") != POLICY_VERSION: failures.append("policy")
    if req.get("caller_declared_intent") is not True: failures.append("caller_declared_intent_is_true")
    if req.get("action_kind") != ACTION_KIND: failures.append("action_kind")
    if not bounded_text(req.get("capability_id"), maximum=128): failures.append("capability_id")
    if not bounded_text(req.get("target_state"), maximum=128): failures.append("target_state")
    if not bounded_text(req.get("expected_state"), maximum=128): failures.append("expected_state")
    if not is_sha256_id(req.get("envelope_evidence_digest")): failures.append("envelope_evidence_digest")
    if req.get("authority") != "action_proposal_request_only" or not no_effect_authorizations(req.get("authorizations")):
        failures.append("request_authority_proposal_only")
    if not _safe_envelope(env):
        failures.append("workflow_envelope_advisory_only")

    chain: Dict[str, Any] = {}
    delivery_id = str(req.get("delivery_accountability_id") or "")
    if not delivery_id:
        failures.append("delivery_accountability_id")
    else:
        try:
            chain = query_accountability_chain(delivery_id, store_dir=store_dir, delivery_limit=16)
        except (ValueError, FileNotFoundError, OSError, TypeError):
            failures.append("verified_accountability_chain")

    relevance = chain.get("relevance") if isinstance(chain.get("relevance"), dict) else {}
    deliveries = chain.get("deliveries") if isinstance(chain.get("deliveries"), list) else []
    selected = next((row for row in deliveries if row.get("decision_id") == delivery_id), None)
    if chain:
        if chain.get("selected_delivery_id") != delivery_id or not isinstance(selected, dict):
            failures.append("selected_delivery_binding")
        elif selected.get("delivery_outcome") != "INCLUDED":
            failures.append("delivery_outcome_included")
        if relevance.get("relevant") is not True:
            failures.append("relevance_granted")
    if _safe_envelope(env) and relevance:
        bindings = (
            (req.get("capability_id"), relevance.get("capability_id"), env.get("capability_id"), "capability_binding"),
            (req.get("expected_state"), relevance.get("workflow_state"), env.get("state"), "state_binding"),
            (req.get("envelope_evidence_digest"), relevance.get("workflow_evidence_digest"), env.get("evidence_digest"), "evidence_digest_binding"),
        )
        for requested, audited, current, label in bindings:
            if requested != audited or requested != current: failures.append(label)
        if req.get("target_state") not in env["allowed_targets"]:
            failures.append("target_in_allowed_targets")

    request_digest = safe_canonical_digest(req)
    if request_digest is None:
        failures.append("request_bounded_canonical_json")
    if chain and not is_sha256_id(chain.get("chain_digest")):
        failures.append("chain_digest")
    ready = not failures
    return {
        "schema_version": SCHEMA_VERSION,
        "decision_type": DECISION_TYPE,
        "policy": POLICY_VERSION,
        "proposal_ready": ready,
        "decision": "ACTION_PROPOSAL_READY" if ready else "ACTION_PROPOSAL_REJECTED",
        "failed_conditions": failures,
        "request_digest": request_digest or "",
        "chain_digest": chain.get("chain_digest"),
        "delivery_accountability_id": delivery_id,
        "relevance_accountability_id": relevance.get("decision_id"),
        "capability_id": str(req.get("capability_id") or ""),
        "workflow_state": str(req.get("expected_state") or ""),
        "workflow_evidence_digest": str(req.get("envelope_evidence_digest") or ""),
        "proposed_action": {"kind": ACTION_KIND, "target_state": str(req.get("target_state") or "")},
        "authorization_requirement": {
            "required": True,
            "authority_class": "capability_action_execution",
            "granted": False,
        },
        "authority": "workflow_action_proposal_only",
        "authorizations": {key: False for key in sorted(_REQUIRED_AUTH)},
        "invariants": {
            "included_delivery_required": True,
            "verified_chain_required": True,
            "allowed_target_required": True,
            "proposal_is_not_authorization": True,
            "transition_execution": False,
            "runtime_execution": False,
            "external_patch": False,
            "stable_promotion": False,
            "truth_commit": False,
        },
    }


def record_action_proposal(
    request: Mapping[str, Any] | None,
    envelope: Mapping[str, Any] | None,
    *,
    store_dir: str | None = None,
) -> Dict[str, Any]:
    payload = build_action_proposal(request, envelope, store_dir=store_dir)
    receipt = record_provenanced(payload, PROPOSAL_ISSUER, store_dir=store_dir)
    return {
        **receipt,
        "decision_type": DECISION_TYPE,
        "proposal_ready": payload["proposal_ready"],
        "authority": "workflow_action_proposal_reference_only",
    }


__all__ = [
    "SCHEMA_VERSION", "POLICY_VERSION", "DECISION_TYPE", "ACTION_KIND", "ACCOUNTABILITY_RECORD_KEYS",
    "build_action_request", "build_action_proposal", "record_action_proposal",
]
