"""F119 fresh, provenance-bound preflight for one F118 dry-run record.

The preflight consumes no authorization and executes no action.  It requires a
short-lived assertion from the authoritative workflow-state provider, rebuilds
the entire F111->F118 chain against that asserted current envelope, and emits a
bounded handoff that a future atomic executor lease may consume.
"""
from __future__ import annotations

import secrets
import time
from typing import Any, Dict, Mapping

from core.accountability_provenance import (
    DRY_RUN_ISSUER,
    PREFLIGHT_ISSUER,
    PREFLIGHT_RECORD_ISSUER,
    record_provenanced,
    seal_payload,
    verify_payload,
    verify_record,
)
from core.capability_action_authorization import AUTHORITY_CLASS
from core.capability_action_dry_run import (
    ACCOUNTABILITY_RECORD_KEYS as DRY_RUN_RECORD_KEYS,
    DECISION_TYPE as DRY_RUN_DECISION_TYPE,
    POLICY_VERSION as DRY_RUN_POLICY,
    SCHEMA_VERSION as DRY_RUN_SCHEMA,
    evaluate_action_dry_run,
)
from core.capability_contracts import (
    bounded_text,
    exact_keys,
    is_sha256_id,
    no_effect_results,
    no_effect_authorizations,
    normalize_mapping,
    safe_canonical_digest,
)
from core.context_accountability import load_accountability


SCHEMA_VERSION = "capability-workflow-action-preflight-v1"
POLICY_VERSION = "fresh_provenance_bound_action_preflight_v1"
DECISION_TYPE = "capability_workflow_action_preflight"
FRESHNESS_SCHEMA = "capability-workflow-envelope-freshness-assertion-v1"
FRESHNESS_POLICY = "trusted_current_envelope_short_lived_assertion_v1"
MAX_FRESHNESS_TTL_SECONDS = 30
_CLOCK_SKEW_SECONDS = 5
_REQUIRED_EFFECTS = {
    "transition_execution", "runtime_execution", "external_patch", "stable_promotion", "truth_commit"
}
_FRESHNESS_KEYS = frozenset({
    "schema_version", "policy", "source_id", "dry_run_accountability_id",
    "dry_run_request_digest", "capability_id", "workflow_state",
    "workflow_evidence_digest", "envelope_digest", "issued_at_epoch",
    "expires_at_epoch", "nonce", "provenance",
})
_ALLOWED_REQUEST_KEYS = frozenset({
    "schema_version", "policy", "dry_run_accountability_id",
    "dry_run_request_digest", "freshness_assertion_digest", "capability_id",
    "caller_requests_preflight", "authority", "authorizations", "freshness_assertion",
})
ACCOUNTABILITY_RECORD_KEYS = frozenset({
    "schema_version", "decision_type", "policy", "preflight_ready", "decision",
    "failed_conditions", "request_digest", "dry_run_accountability_id",
    "dry_run_request_digest", "plan_digest", "capability_id", "workflow_state",
    "workflow_evidence_digest", "current_envelope_digest",
    "freshness_assertion_digest", "freshness_source", "freshness_nonce",
    "freshness_expires_at_epoch", "executor_handoff", "authority",
    "authorizations", "effects", "invariants", "provenance", "decision_id",
    "recorded_at",
})


def issue_preflight_freshness_assertion(
    dry_run_accountability_id: str,
    dry_run_request: Mapping[str, Any] | None,
    current_envelope: Mapping[str, Any] | None,
    source_id: str,
    *,
    store_dir: str | None = None,
    ttl_seconds: int = 15,
    now_epoch: int | None = None,
    nonce: str | None = None,
) -> Dict[str, Any]:
    """Called by the trusted workflow-state provider after reading current state."""
    dry_req, dry_valid = normalize_mapping(dry_run_request)
    envelope, envelope_valid = normalize_mapping(current_envelope)
    dry_digest = safe_canonical_digest(dry_req)
    envelope_digest = safe_canonical_digest(envelope, max_bytes=65536)
    if not dry_valid or dry_digest is None:
        raise ValueError("Dry-run request is not bounded canonical JSON")
    if not envelope_valid or envelope_digest is None:
        raise ValueError("Current envelope is not bounded canonical JSON")
    if not is_sha256_id(dry_run_accountability_id):
        raise ValueError("Invalid dry-run accountability id")
    if not bounded_text(source_id, maximum=128):
        raise ValueError("Invalid preflight source id")
    if type(ttl_seconds) is not int or not (1 <= ttl_seconds <= MAX_FRESHNESS_TTL_SECONDS):
        raise ValueError("Preflight freshness TTL is outside the allowed bound")
    issued = int(time.time()) if now_epoch is None else now_epoch
    if type(issued) is not int or issued < 0:
        raise ValueError("Invalid preflight issuance time")
    assertion_nonce = secrets.token_hex(16) if nonce is None else nonce
    if (
        not isinstance(assertion_nonce, str)
        or not (32 <= len(assertion_nonce) <= 64)
        or any(ch not in "0123456789abcdef" for ch in assertion_nonce)
    ):
        raise ValueError("Invalid preflight nonce")
    body = {
        "schema_version": FRESHNESS_SCHEMA,
        "policy": FRESHNESS_POLICY,
        "source_id": source_id,
        "dry_run_accountability_id": dry_run_accountability_id,
        "dry_run_request_digest": dry_digest,
        "capability_id": str(envelope.get("capability_id") or ""),
        "workflow_state": str(envelope.get("state") or ""),
        "workflow_evidence_digest": str(envelope.get("evidence_digest") or ""),
        "envelope_digest": envelope_digest,
        "issued_at_epoch": issued,
        "expires_at_epoch": issued + ttl_seconds,
        "nonce": assertion_nonce,
    }
    return {**body, "provenance": seal_payload(body, PREFLIGHT_ISSUER, store_dir=store_dir)}


def _verify_freshness_assertion(
    assertion: Any,
    dry_run_accountability_id: str,
    dry_run_request: Mapping[str, Any],
    current_envelope: Mapping[str, Any],
    *,
    store_dir: str | None,
    now_epoch: int | None = None,
) -> tuple[bool, list[str]]:
    if not exact_keys(assertion, _FRESHNESS_KEYS):
        return False, ["freshness_assertion_exact_schema"]
    assert isinstance(assertion, dict)
    failures: list[str] = []
    dry_digest = safe_canonical_digest(dry_run_request)
    envelope_digest = safe_canonical_digest(current_envelope, max_bytes=65536)
    body = {key: assertion[key] for key in _FRESHNESS_KEYS if key != "provenance"}
    if assertion.get("schema_version") != FRESHNESS_SCHEMA: failures.append("freshness_assertion_schema")
    if assertion.get("policy") != FRESHNESS_POLICY: failures.append("freshness_assertion_policy")
    if not bounded_text(assertion.get("source_id"), maximum=128): failures.append("freshness_assertion_source")
    if assertion.get("dry_run_accountability_id") != dry_run_accountability_id:
        failures.append("freshness_assertion_dry_run_id")
    if dry_digest is None or assertion.get("dry_run_request_digest") != dry_digest:
        failures.append("freshness_assertion_dry_run_digest")
    for asserted, current, label in (
        (assertion.get("capability_id"), current_envelope.get("capability_id"), "capability"),
        (assertion.get("workflow_state"), current_envelope.get("state"), "state"),
        (assertion.get("workflow_evidence_digest"), current_envelope.get("evidence_digest"), "evidence"),
        (assertion.get("envelope_digest"), envelope_digest, "envelope"),
    ):
        if asserted != current: failures.append("freshness_assertion_" + label + "_binding")
    issued, expires = assertion.get("issued_at_epoch"), assertion.get("expires_at_epoch")
    current_time = int(time.time()) if now_epoch is None else now_epoch
    if type(issued) is not int or type(expires) is not int or type(current_time) is not int:
        failures.append("freshness_assertion_time_type")
    elif (
        issued < 0 or expires <= issued or expires - issued > MAX_FRESHNESS_TTL_SECONDS
        or issued > current_time + _CLOCK_SKEW_SECONDS or expires <= current_time
    ):
        failures.append("freshness_assertion_expired_or_future")
    nonce = assertion.get("nonce")
    if (
        not isinstance(nonce, str) or not (32 <= len(nonce) <= 64)
        or any(ch not in "0123456789abcdef" for ch in nonce)
    ):
        failures.append("freshness_assertion_nonce")
    if not verify_payload(body, assertion.get("provenance"), PREFLIGHT_ISSUER, store_dir=store_dir):
        failures.append("freshness_assertion_provenance")
    return not failures, failures


def build_preflight_request(
    dry_run_accountability_id: str,
    dry_run_request: Mapping[str, Any] | None,
    freshness_assertion: Mapping[str, Any] | None,
) -> Dict[str, Any]:
    dry_req, _ = normalize_mapping(dry_run_request)
    freshness, freshness_valid = normalize_mapping(freshness_assertion)
    return {
        "schema_version": SCHEMA_VERSION,
        "policy": POLICY_VERSION,
        "dry_run_accountability_id": str(dry_run_accountability_id or ""),
        "dry_run_request_digest": safe_canonical_digest(dry_req) or "",
        "freshness_assertion_digest": safe_canonical_digest(freshness) or "",
        "capability_id": str(dry_req.get("capability_id") or ""),
        "caller_requests_preflight": freshness_valid and bool(freshness),
        "authority": "authorized_action_preflight_request_only",
        "authorizations": {key: False for key in sorted(_REQUIRED_EFFECTS)},
        "freshness_assertion": freshness,
    }


def evaluate_action_preflight(
    request: Mapping[str, Any] | None,
    dry_run_request: Mapping[str, Any] | None,
    gate_request: Mapping[str, Any] | None,
    authorization_request: Mapping[str, Any] | None,
    proposal_request: Mapping[str, Any] | None,
    current_envelope: Mapping[str, Any] | None,
    *,
    store_dir: str | None = None,
) -> Dict[str, Any]:
    req, req_valid = normalize_mapping(request)
    dry_req, dry_valid = normalize_mapping(dry_run_request)
    gate_req, gate_valid = normalize_mapping(gate_request)
    auth_req, auth_valid = normalize_mapping(authorization_request)
    proposal_req, proposal_valid = normalize_mapping(proposal_request)
    envelope, envelope_valid = normalize_mapping(current_envelope)
    failures: list[str] = []
    for valid, label in (
        (req_valid, "request_mapping"), (dry_valid, "dry_run_request_mapping"),
        (gate_valid, "gate_request_mapping"), (auth_valid, "authorization_request_mapping"),
        (proposal_valid, "proposal_request_mapping"), (envelope_valid, "current_envelope_mapping"),
    ):
        if not valid: failures.append(label)
    unknown = sorted(set(req) - _ALLOWED_REQUEST_KEYS)
    if unknown: failures.append("unknown_request_fields:" + ",".join(unknown))
    if req.get("schema_version") != SCHEMA_VERSION: failures.append("schema_version")
    if req.get("policy") != POLICY_VERSION: failures.append("policy")
    if req.get("caller_requests_preflight") is not True: failures.append("caller_requests_preflight_is_true")
    if req.get("authority") != "authorized_action_preflight_request_only" or not no_effect_authorizations(req.get("authorizations")):
        failures.append("request_has_no_execution_effect")

    request_digest = safe_canonical_digest(req)
    dry_request_digest = safe_canonical_digest(dry_req)
    freshness_digest = safe_canonical_digest(req.get("freshness_assertion"))
    if request_digest is None: failures.append("request_bounded_canonical_json")
    if dry_request_digest is None or req.get("dry_run_request_digest") != dry_request_digest:
        failures.append("dry_run_request_digest")
    if freshness_digest is None or req.get("freshness_assertion_digest") != freshness_digest:
        failures.append("freshness_assertion_digest")

    dry_id = str(req.get("dry_run_accountability_id") or "")
    stored: Dict[str, Any] = {}
    if not is_sha256_id(dry_id):
        failures.append("dry_run_accountability_id")
    else:
        try:
            stored = load_accountability(dry_id, store_dir=store_dir)
        except (ValueError, FileNotFoundError, OSError, TypeError):
            failures.append("dry_run_record")

    recomputed = evaluate_action_dry_run(
        dry_req, gate_req, auth_req, proposal_req, envelope, store_dir=store_dir
    )
    if recomputed.get("dry_run_ready") is not True:
        failures.append("dry_run_revalidation_ready")
    if stored:
        required = (
            exact_keys(stored, DRY_RUN_RECORD_KEYS),
            stored.get("schema_version") == DRY_RUN_SCHEMA,
            stored.get("policy") == DRY_RUN_POLICY,
            stored.get("decision_type") == DRY_RUN_DECISION_TYPE,
            stored.get("dry_run_ready") is True,
            stored.get("decision") == "AUTHORIZED_ACTION_DRY_RUN_READY",
            stored.get("authority") == "workflow_action_executor_dry_run_only",
            no_effect_authorizations(stored.get("authorizations")),
            no_effect_results(stored.get("effects")),
            verify_record(stored, DRY_RUN_ISSUER, store_dir=store_dir),
        )
        if not all(required): failures.append("dry_run_record_contract")
        fields = (
            "request_digest", "gate_accountability_id", "gate_request_digest",
            "authorization_accountability_id", "authorization_request_digest",
            "proposal_accountability_id", "proposal_request_digest", "capability_id",
            "workflow_state", "workflow_evidence_digest", "authority_assertion_digest",
            "authorization_principal", "authorization_nonce", "authorization_expires_at_epoch",
            "execution_plan", "executor_handoff",
        )
        if any(stored.get(key) != recomputed.get(key) for key in fields):
            failures.append("dry_run_revalidation_binding")

    if req.get("capability_id") != recomputed.get("capability_id"):
        failures.append("capability_binding")
    freshness_valid, freshness_failures = _verify_freshness_assertion(
        req.get("freshness_assertion"), dry_id, dry_req, envelope, store_dir=store_dir
    )
    if not freshness_valid: failures.extend(freshness_failures)

    assertion = req.get("freshness_assertion") if isinstance(req.get("freshness_assertion"), dict) else {}
    envelope_digest = safe_canonical_digest(envelope, max_bytes=65536)
    plan = recomputed.get("execution_plan") if isinstance(recomputed.get("execution_plan"), dict) else {}
    ready = not failures
    return {
        "schema_version": SCHEMA_VERSION,
        "decision_type": DECISION_TYPE,
        "policy": POLICY_VERSION,
        "preflight_ready": ready,
        "decision": "AUTHORIZED_ACTION_PREFLIGHT_READY" if ready else "AUTHORIZED_ACTION_PREFLIGHT_REJECTED",
        "failed_conditions": failures,
        "request_digest": request_digest or "",
        "dry_run_accountability_id": dry_id,
        "dry_run_request_digest": dry_request_digest or "",
        "plan_digest": str(plan.get("plan_digest") or ""),
        "capability_id": str(recomputed.get("capability_id") or ""),
        "workflow_state": str(recomputed.get("workflow_state") or ""),
        "workflow_evidence_digest": str(recomputed.get("workflow_evidence_digest") or ""),
        "current_envelope_digest": envelope_digest or "",
        "freshness_assertion_digest": freshness_digest or "",
        "freshness_source": str(assertion.get("source_id") or ""),
        "freshness_nonce": str(assertion.get("nonce") or ""),
        "freshness_expires_at_epoch": assertion.get("expires_at_epoch"),
        "executor_handoff": {
            "eligible": ready,
            "execution_started": False,
            "atomic_lease_and_nonce_consumption_required": True,
            "authority_class": AUTHORITY_CLASS,
        },
        "authority": "workflow_action_preflight_only",
        "authorizations": {key: False for key in sorted(_REQUIRED_EFFECTS)},
        "effects": {
            "transition_executed": False,
            "runtime_executed": False,
            "external_patch_applied": False,
            "stable_promoted": False,
            "truth_committed": False,
        },
        "invariants": {
            "signed_current_envelope_required": True,
            "full_dry_run_chain_revalidated": True,
            "freshness_is_not_execution": True,
            "future_executor_must_atomically_consume_nonce": True,
        },
    }


def record_action_preflight(
    request: Mapping[str, Any] | None,
    dry_run_request: Mapping[str, Any] | None,
    gate_request: Mapping[str, Any] | None,
    authorization_request: Mapping[str, Any] | None,
    proposal_request: Mapping[str, Any] | None,
    current_envelope: Mapping[str, Any] | None,
    *,
    store_dir: str | None = None,
) -> Dict[str, Any]:
    payload = evaluate_action_preflight(
        request, dry_run_request, gate_request, authorization_request,
        proposal_request, current_envelope, store_dir=store_dir
    )
    receipt = record_provenanced(payload, PREFLIGHT_RECORD_ISSUER, store_dir=store_dir)
    return {
        **receipt,
        "decision_type": DECISION_TYPE,
        "preflight_ready": payload["preflight_ready"],
        "authority": "workflow_action_preflight_reference_only",
    }


__all__ = [
    "SCHEMA_VERSION", "POLICY_VERSION", "DECISION_TYPE", "FRESHNESS_SCHEMA",
    "FRESHNESS_POLICY", "MAX_FRESHNESS_TTL_SECONDS", "ACCOUNTABILITY_RECORD_KEYS",
    "issue_preflight_freshness_assertion", "build_preflight_request",
    "evaluate_action_preflight", "record_action_preflight",
]
