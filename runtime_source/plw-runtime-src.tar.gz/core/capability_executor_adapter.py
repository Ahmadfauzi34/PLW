"""F123 lease-bound executor adapter and reconciliation bridge.

F121 owns the single-use execution lease. F122 owns the durable attempt and
terminal executor-observation ledger. F123 connects a concrete host adapter to
that chain while keeping external execution and proof claims distinct:

    F122 ATTEMPT_REGISTERED
        -> DISPATCH_PREPARED
        -> adapter invocation (host effect, if explicitly allowed)
        -> ADAPTER_OBSERVATION_RECORDED
        -> F122 terminal report when the observation is terminal

A committed dispatch preparation is *not* evidence that an external action ran.
An adapter acknowledgement is *not* evidence that the intended postcondition is
true. Missing, pending, and not-found status observations remain unresolved.
F123 deliberately does not claim generic exactly-once external effects.
"""
from __future__ import annotations

import json
import os
import re
import sqlite3
import time
from collections.abc import Mapping, Sequence
from pathlib import Path
from typing import Any, Dict, Protocol, runtime_checkable

from core.accountability_provenance import seal_payload, verify_payload
from core.capability_action_lease import inspect_action_lease
from core.capability_contracts import (
    AUTHORIZATION_KEYS,
    exact_keys,
    is_sha256_id,
    no_effect_authorizations,
    normalize_mapping,
    safe_canonical_digest,
)
from core.capability_executor_outcome import (
    TERMINAL_STATUSES,
    build_executor_outcome_request,
    inspect_executor_outcome,
    record_executor_outcome,
)
from core.context_accountability import DEFAULT_ACCOUNTABILITY_DIR


SCHEMA_VERSION = "capability-workflow-executor-adapter-v1"
POLICY_VERSION = "lease-bound-adapter-reconciliation-v1"
DISPATCH_DECISION_TYPE = "capability_workflow_executor_adapter_dispatch"
OBSERVATION_DECISION_TYPE = "capability_workflow_executor_adapter_observation"
DISPATCH_RECEIPT_SCHEMA = "capability-workflow-adapter-dispatch-receipt-v1"
OBSERVATION_RECEIPT_SCHEMA = "capability-workflow-adapter-observation-receipt-v1"
DISPATCH_RECEIPT_ISSUER = "plw.workflow.executor-adapter-dispatch.v1"
OBSERVATION_RECEIPT_ISSUER = "plw.workflow.executor-adapter-observation.v1"
ADAPTER_DATABASE_SCHEMA_VERSION = 1

DISPATCH_STATES = frozenset({"ACKNOWLEDGED", "REJECTED", "UNKNOWN"})
NONTERMINAL_RECONCILIATION_STATES = frozenset({"PENDING", "NOT_FOUND", "UNKNOWN"})
TERMINAL_RECONCILIATION_STATES = frozenset({"RESOLVED"})

_EXECUTOR_ID = re.compile(r"[A-Za-z0-9][A-Za-z0-9._:/-]{2,127}\Z")
_ADAPTER_ID = re.compile(r"[A-Za-z0-9][A-Za-z0-9._:/-]{2,127}\Z")
_OPERATION_KEY = re.compile(r"[A-Za-z0-9][A-Za-z0-9._:-]{15,127}\Z")
_OBSERVATION_KIND = re.compile(r"[a-z][a-z0-9._:-]{2,63}\Z")

_DISPATCH_REQUEST_KEYS = frozenset({
    "schema_version", "policy", "lease_id", "attempt_id", "executor_id",
    "adapter_id", "operation_key", "caller_prepares_adapter_dispatch",
    "authority", "authorizations",
})
_DISPATCH_BODY_KEYS = frozenset({
    "schema_version", "decision_type", "policy", "dispatch_state",
    "request_digest", "lease_id", "attempt_id", "executor_id", "adapter_id",
    "operation_key", "plan_digest", "capability_id", "workflow_state",
    "workflow_evidence_digest", "attempt_registered_at_epoch",
    "prepared_at_epoch", "authority_class", "scope",
})
_DISPATCH_RECEIPT_KEYS = _DISPATCH_BODY_KEYS | {"dispatch_id", "provenance"}

_OBSERVATION_BODY_KEYS = frozenset({
    "schema_version", "decision_type", "policy", "observation_state",
    "lease_id", "attempt_id", "dispatch_id", "executor_id", "adapter_id",
    "operation_key", "plan_digest", "dispatch_state", "terminal_status",
    "observation_kind", "observation_digest", "observation_key_digest", "evidence_ids",
    "prepared_at_epoch", "observed_at_epoch", "authority_class", "scope",
})
_OBSERVATION_RECEIPT_KEYS = _OBSERVATION_BODY_KEYS | {"observation_id", "provenance"}


@runtime_checkable
class ExecutorAdapter(Protocol):
    """Minimal host adapter contract. No concrete executor is bundled by F123."""

    adapter_id: str
    executor_id: str

    def dispatch(self, context: Mapping[str, Any]) -> Mapping[str, Any]:
        """Perform or submit the bound external action and return an observation."""

    def reconcile(self, context: Mapping[str, Any]) -> Mapping[str, Any]:
        """Query/reconcile a prior dispatch and return an observation."""


def _database_path(store_dir: str | os.PathLike[str] | None) -> Path:
    base = Path(
        store_dir
        or os.environ.get("PLW_ACCOUNTABILITY_DIR")
        or DEFAULT_ACCOUNTABILITY_DIR
    )
    return (base / "executor_adapter_bridge.sqlite3").expanduser().resolve()


def _initialize_database(path: Path) -> sqlite3.Connection:
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    try:
        os.chmod(path.parent, 0o700)
    except OSError:
        pass
    if path.is_symlink():
        raise ValueError("Executor adapter bridge database must not be a symbolic link")
    connection = sqlite3.connect(str(path), timeout=5.0, isolation_level=None)
    try:
        connection.execute("PRAGMA busy_timeout=5000")
        connection.execute("PRAGMA foreign_keys=ON")
        connection.execute("PRAGMA synchronous=FULL")
        connection.execute("PRAGMA journal_mode=DELETE")
        connection.execute("BEGIN IMMEDIATE")
        version = int(connection.execute("PRAGMA user_version").fetchone()[0])
        if version not in (0, ADAPTER_DATABASE_SCHEMA_VERSION):
            raise ValueError("Unsupported executor adapter bridge database schema")
        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS adapter_dispatches (
                lease_id TEXT PRIMARY KEY,
                attempt_id TEXT NOT NULL UNIQUE,
                dispatch_id TEXT NOT NULL UNIQUE,
                operation_key TEXT NOT NULL UNIQUE,
                executor_id TEXT NOT NULL,
                adapter_id TEXT NOT NULL,
                plan_digest TEXT NOT NULL,
                prepared_at_epoch INTEGER NOT NULL,
                dispatch_request_digest TEXT NOT NULL,
                dispatch_receipt_json TEXT NOT NULL
            )
            """
        )
        connection.execute(
            """
            CREATE TABLE IF NOT EXISTS adapter_observations (
                observation_id TEXT PRIMARY KEY,
                dispatch_id TEXT NOT NULL,
                lease_id TEXT NOT NULL,
                ordinal INTEGER NOT NULL,
                observation_digest TEXT NOT NULL,
                observation_key_digest TEXT NOT NULL,
                terminal_status TEXT NOT NULL,
                observed_at_epoch INTEGER NOT NULL,
                observation_receipt_json TEXT NOT NULL,
                UNIQUE(dispatch_id, ordinal),
                UNIQUE(dispatch_id, observation_key_digest),
                UNIQUE(dispatch_id, observation_id),
                FOREIGN KEY(lease_id) REFERENCES adapter_dispatches(lease_id)
            )
            """
        )
        connection.execute(
            "CREATE UNIQUE INDEX IF NOT EXISTS one_terminal_adapter_observation_per_dispatch "
            "ON adapter_observations(dispatch_id) WHERE terminal_status <> ''"
        )
        if version == 0:
            connection.execute(f"PRAGMA user_version={ADAPTER_DATABASE_SCHEMA_VERSION}")
        connection.execute("COMMIT")
        try:
            os.chmod(path, 0o600)
        except OSError:
            pass
        return connection
    except Exception:
        try:
            connection.execute("ROLLBACK")
        except sqlite3.Error:
            pass
        connection.close()
        raise


def _read_connection(path: Path) -> sqlite3.Connection:
    if not path.is_file() or path.is_symlink():
        raise FileNotFoundError("Executor adapter bridge database is unavailable")
    connection = sqlite3.connect(path.as_uri() + "?mode=ro", uri=True, timeout=5.0)
    connection.execute("PRAGMA busy_timeout=5000")
    version = int(connection.execute("PRAGMA user_version").fetchone()[0])
    if version != ADAPTER_DATABASE_SCHEMA_VERSION:
        connection.close()
        raise ValueError("Unsupported executor adapter bridge database schema")
    return connection


def _normalize_evidence_ids(value: Any) -> tuple[list[str], bool]:
    if value is None:
        return [], True
    if isinstance(value, (str, bytes)) or not isinstance(value, Sequence) or len(value) > 16:
        return [], False
    result: list[str] = []
    for item in value:
        if not is_sha256_id(item) or item in result:
            return [], False
        assert isinstance(item, str)
        result.append(item)
    return result, True


def _verify_dispatch_receipt(
    receipt: Any, *, store_dir: str | os.PathLike[str] | None,
) -> bool:
    if not exact_keys(receipt, _DISPATCH_RECEIPT_KEYS):
        return False
    assert isinstance(receipt, dict)
    body = {key: receipt[key] for key in _DISPATCH_BODY_KEYS}
    digest = safe_canonical_digest(body, max_bytes=32768)
    return (
        digest is not None
        and receipt.get("dispatch_id") == digest
        and verify_payload(body, receipt.get("provenance"), DISPATCH_RECEIPT_ISSUER, store_dir=store_dir)
    )


def _verify_observation_receipt(
    receipt: Any, *, store_dir: str | os.PathLike[str] | None,
) -> bool:
    if not exact_keys(receipt, _OBSERVATION_RECEIPT_KEYS):
        return False
    assert isinstance(receipt, dict)
    body = {key: receipt[key] for key in _OBSERVATION_BODY_KEYS}
    digest = safe_canonical_digest(body, max_bytes=32768)
    return (
        digest is not None
        and receipt.get("observation_id") == digest
        and verify_payload(body, receipt.get("provenance"), OBSERVATION_RECEIPT_ISSUER, store_dir=store_dir)
    )


def build_adapter_dispatch_request(
    lease_id: str,
    attempt_id: str,
    executor_id: str,
    adapter_id: str,
    operation_key: str,
) -> Dict[str, Any]:
    """Build a no-effect request for one exact F122 attempt dispatch."""
    return {
        "schema_version": SCHEMA_VERSION,
        "policy": POLICY_VERSION,
        "lease_id": str(lease_id or ""),
        "attempt_id": str(attempt_id or ""),
        "executor_id": str(executor_id or ""),
        "adapter_id": str(adapter_id or ""),
        "operation_key": str(operation_key or ""),
        "caller_prepares_adapter_dispatch": True,
        "authority": "lease_bound_adapter_dispatch_request_only",
        "authorizations": {key: False for key in sorted(AUTHORIZATION_KEYS)},
    }


def evaluate_adapter_dispatch(
    request: Mapping[str, Any] | None,
    *,
    store_dir: str | os.PathLike[str] | None = None,
) -> Dict[str, Any]:
    """Read-only F123 eligibility check; first dispatch still needs an active lease."""
    req, valid = normalize_mapping(request)
    failures: list[str] = []
    if not valid:
        failures.append("request_mapping")
    if not exact_keys(req, _DISPATCH_REQUEST_KEYS):
        failures.append("request_exact_schema")
    unknown = sorted(set(req) - _DISPATCH_REQUEST_KEYS)
    if unknown:
        failures.append("unknown_request_fields:" + ",".join(unknown))
    if req.get("schema_version") != SCHEMA_VERSION:
        failures.append("schema_version")
    if req.get("policy") != POLICY_VERSION:
        failures.append("policy")
    if req.get("caller_prepares_adapter_dispatch") is not True:
        failures.append("caller_prepares_adapter_dispatch_is_true")
    if (
        req.get("authority") != "lease_bound_adapter_dispatch_request_only"
        or not no_effect_authorizations(req.get("authorizations"))
    ):
        failures.append("request_has_no_execution_effect")

    request_digest = safe_canonical_digest(req)
    if request_digest is None:
        failures.append("request_bounded_canonical_json")
    lease_id = req.get("lease_id")
    attempt_id = req.get("attempt_id")
    executor_id = req.get("executor_id")
    adapter_id = req.get("adapter_id")
    operation_key = req.get("operation_key")
    if not is_sha256_id(lease_id):
        failures.append("lease_id")
    if not is_sha256_id(attempt_id):
        failures.append("attempt_id")
    if not isinstance(executor_id, str) or _EXECUTOR_ID.fullmatch(executor_id) is None:
        failures.append("executor_id")
    if not isinstance(adapter_id, str) or _ADAPTER_ID.fullmatch(adapter_id) is None:
        failures.append("adapter_id")
    if not isinstance(operation_key, str) or _OPERATION_KEY.fullmatch(operation_key) is None:
        failures.append("operation_key")

    attempt = inspect_executor_outcome(
        str(lease_id or ""), executor_id=str(executor_id) if isinstance(executor_id, str) else None,
        store_dir=store_dir,
    )
    if attempt.get("attempt_found") is not True:
        failures.append("attempt_verification:" + str(attempt.get("error") or "not_found"))
    elif attempt.get("outcome_terminal") is True:
        failures.append("attempt_already_terminal")
    if attempt.get("attempt_id") != attempt_id:
        failures.append("attempt_id_binding")
    plan_digest = str(attempt.get("plan_digest") or "")
    if not is_sha256_id(plan_digest):
        failures.append("plan_digest_binding")

    lease = inspect_action_lease(
        str(lease_id or ""), executor_id=str(executor_id) if isinstance(executor_id, str) else None,
        store_dir=store_dir,
    )
    if lease.get("lease_found") is not True:
        failures.append("lease_verification:" + str(lease.get("error") or "not_found"))
    elif lease.get("lease_active") is not True:
        failures.append("lease_not_active_at_first_dispatch")
    lease_receipt = lease.get("lease_receipt") if isinstance(lease.get("lease_receipt"), dict) else {}
    if lease_receipt.get("plan_digest") != plan_digest:
        failures.append("lease_attempt_plan_binding")

    receipt = attempt.get("attempt_receipt") if isinstance(attempt.get("attempt_receipt"), dict) else {}
    eligible = not failures
    return {
        "schema_version": SCHEMA_VERSION,
        "decision_type": DISPATCH_DECISION_TYPE,
        "policy": POLICY_VERSION,
        "dispatch_eligible": eligible,
        "decision": "ADAPTER_DISPATCH_ELIGIBLE" if eligible else "ADAPTER_DISPATCH_REJECTED",
        "failed_conditions": failures,
        "request_digest": request_digest or "",
        "lease_id": str(lease_id or ""),
        "attempt_id": str(attempt_id or ""),
        "executor_id": str(executor_id or ""),
        "adapter_id": str(adapter_id or ""),
        "operation_key": str(operation_key or ""),
        "plan_digest": plan_digest,
        "capability_id": str(receipt.get("capability_id") or ""),
        "workflow_state": str(receipt.get("workflow_state") or ""),
        "workflow_evidence_digest": str(receipt.get("workflow_evidence_digest") or ""),
        "attempt_registered_at_epoch": int(attempt.get("registered_at_epoch") or 0),
        "evaluated_at_epoch": int(time.time()),
        "authority": "adapter_dispatch_eligibility_only",
        "authorizations": {key: False for key in sorted(AUTHORIZATION_KEYS)},
        "invariants": {
            "exact_f122_attempt_revalidated": attempt.get("attempt_found") is True,
            "first_dispatch_requires_active_f121_lease": True,
            "eligibility_is_read_only": True,
            "eligibility_is_not_external_execution": True,
        },
    }


def prepare_adapter_dispatch(
    request: Mapping[str, Any] | None,
    *,
    store_dir: str | os.PathLike[str] | None = None,
    _fail_before_commit: bool = False,
) -> Dict[str, Any]:
    """Atomically persist one pre-execution dispatch intent for an F122 attempt."""
    # Exact recovery is allowed after lease expiry. Once a dispatch intent is
    # durable, revalidation must not manufacture a second dispatch permission;
    # it should only recover the existing identity for reconciliation.
    req, req_valid = normalize_mapping(request)
    request_digest = safe_canonical_digest(req) if req_valid else None
    operation_key = req.get("operation_key") if req_valid else None
    if (
        req_valid
        and exact_keys(req, _DISPATCH_REQUEST_KEYS)
        and req.get("schema_version") == SCHEMA_VERSION
        and req.get("policy") == POLICY_VERSION
        and req.get("caller_prepares_adapter_dispatch") is True
        and req.get("authority") == "lease_bound_adapter_dispatch_request_only"
        and no_effect_authorizations(req.get("authorizations"))
        and isinstance(operation_key, str)
        and _OPERATION_KEY.fullmatch(operation_key) is not None
        and request_digest is not None
    ):
        try:
            read = _read_connection(_database_path(store_dir))
            try:
                prior_row = read.execute(
                    "SELECT lease_id, attempt_id, executor_id, adapter_id, dispatch_request_digest, dispatch_receipt_json "
                    "FROM adapter_dispatches WHERE operation_key = ?",
                    (operation_key,),
                ).fetchone()
            finally:
                read.close()
        except (FileNotFoundError, ValueError, sqlite3.Error, OSError):
            prior_row = None
        if prior_row is not None:
            try:
                prior = json.loads(prior_row[5])
            except (TypeError, json.JSONDecodeError):
                prior = {}
            if (
                prior_row[0] == req.get("lease_id")
                and prior_row[1] == req.get("attempt_id")
                and prior_row[2] == req.get("executor_id")
                and prior_row[3] == req.get("adapter_id")
                and prior_row[4] == request_digest
                and _verify_dispatch_receipt(prior, store_dir=store_dir)
            ):
                return {
                    "schema_version": SCHEMA_VERSION,
                    "decision_type": DISPATCH_DECISION_TYPE,
                    "policy": POLICY_VERSION,
                    "dispatch_eligible": False,
                    "dispatch_prepared": False,
                    "idempotent_recovery": True,
                    "decision": "ADAPTER_DISPATCH_RECOVERED_NO_SECOND_INTENT",
                    "failed_conditions": [],
                    "request_digest": request_digest,
                    "lease_id": str(prior.get("lease_id") or ""),
                    "attempt_id": str(prior.get("attempt_id") or ""),
                    "executor_id": str(prior.get("executor_id") or ""),
                    "adapter_id": str(prior.get("adapter_id") or ""),
                    "operation_key": str(prior.get("operation_key") or ""),
                    "plan_digest": str(prior.get("plan_digest") or ""),
                    "dispatch_id": str(prior.get("dispatch_id") or ""),
                    "dispatch_receipt": prior,
                    "external_execution_observed": False,
                    "state_transition": {"from": "DISPATCH_PREPARED", "to": "UNCHANGED", "durable": True},
                    "authority": "workflow_adapter_dispatch_recovery_only",
                    "authorizations": {key: False for key in sorted(AUTHORIZATION_KEYS)},
                    "proof_boundary": {
                        "dispatch_prepared": True,
                        "second_dispatch_authorized": False,
                        "external_execution_started": False,
                        "postcondition_proven": False,
                        "claim_truth_settled": False,
                    },
                }
    eligibility = evaluate_adapter_dispatch(request, store_dir=store_dir)
    if eligibility.get("dispatch_eligible") is not True:
        return {
            **eligibility,
            "dispatch_prepared": False,
            "idempotent_recovery": False,
            "external_execution_observed": False,
        }

    prepared_at = int(time.time())
    body = {
        "schema_version": DISPATCH_RECEIPT_SCHEMA,
        "decision_type": DISPATCH_DECISION_TYPE,
        "policy": POLICY_VERSION,
        "dispatch_state": "PREPARED",
        "request_digest": str(eligibility.get("request_digest") or ""),
        "lease_id": str(eligibility.get("lease_id") or ""),
        "attempt_id": str(eligibility.get("attempt_id") or ""),
        "executor_id": str(eligibility.get("executor_id") or ""),
        "adapter_id": str(eligibility.get("adapter_id") or ""),
        "operation_key": str(eligibility.get("operation_key") or ""),
        "plan_digest": str(eligibility.get("plan_digest") or ""),
        "capability_id": str(eligibility.get("capability_id") or ""),
        "workflow_state": str(eligibility.get("workflow_state") or ""),
        "workflow_evidence_digest": str(eligibility.get("workflow_evidence_digest") or ""),
        "attempt_registered_at_epoch": int(eligibility.get("attempt_registered_at_epoch") or 0),
        "prepared_at_epoch": prepared_at,
        "authority_class": "lease_bound_adapter_dispatch_intent",
        "scope": "single_attempt_single_adapter_operation",
    }
    dispatch_id = safe_canonical_digest(body, max_bytes=32768)
    if dispatch_id is None:
        return {**eligibility, "dispatch_prepared": False, "idempotent_recovery": False,
                "external_execution_observed": False, "failed_conditions": ["dispatch_receipt_bounded_json"]}
    try:
        receipt = {
            "dispatch_id": dispatch_id,
            **body,
            "provenance": seal_payload(body, DISPATCH_RECEIPT_ISSUER, store_dir=store_dir),
        }
        connection = _initialize_database(_database_path(store_dir))
    except Exception as exc:
        return {**eligibility, "dispatch_prepared": False, "idempotent_recovery": False,
                "external_execution_observed": False,
                "failed_conditions": ["adapter_bridge_store_open:" + type(exc).__name__]}

    status = "store_error"
    stored: Dict[str, Any] = {}
    failures: list[str] = []
    try:
        connection.execute("BEGIN IMMEDIATE")
        prior_row = connection.execute(
            "SELECT lease_id, attempt_id, executor_id, adapter_id, dispatch_request_digest, dispatch_receipt_json "
            "FROM adapter_dispatches WHERE operation_key = ?",
            (body["operation_key"],),
        ).fetchone()
        if prior_row is not None:
            connection.execute("COMMIT")
            try:
                prior = json.loads(prior_row[5])
            except (TypeError, json.JSONDecodeError):
                failures = ["dispatch_receipt_corrupt"]
            else:
                if (
                    prior_row[0] == body["lease_id"]
                    and prior_row[1] == body["attempt_id"]
                    and prior_row[2] == body["executor_id"]
                    and prior_row[3] == body["adapter_id"]
                    and prior_row[4] == body["request_digest"]
                    and _verify_dispatch_receipt(prior, store_dir=store_dir)
                ):
                    status = "recovered"
                    stored = prior
                else:
                    status = "conflict"
                    failures = ["operation_key_conflict"]
        else:
            # Recheck the lease under the bridge write lock immediately before
            # making a first dispatch intent durable. Recovery/inspection later
            # does not need an active lease.
            lease = inspect_action_lease(body["lease_id"], executor_id=body["executor_id"], store_dir=store_dir)
            attempt_now = inspect_executor_outcome(body["lease_id"], store_dir=store_dir)
            attempt_receipt_now = attempt_now.get("attempt_receipt") if isinstance(attempt_now.get("attempt_receipt"), dict) else {}
            if lease.get("lease_active") is not True:
                connection.execute("ROLLBACK")
                status = "conflict"
                failures = ["lease_expired_before_dispatch_prepare_commit"]
            elif attempt_now.get("attempt_found") is not True:
                connection.execute("ROLLBACK")
                status = "conflict"
                failures = ["f122_attempt_missing_before_dispatch_prepare_commit"]
            elif attempt_now.get("outcome_terminal") is True:
                connection.execute("ROLLBACK")
                status = "conflict"
                failures = ["f122_terminal_before_dispatch_prepare_commit"]
            elif (
                attempt_now.get("attempt_id") != body["attempt_id"]
                or attempt_now.get("executor_id") != body["executor_id"]
                or attempt_receipt_now.get("plan_digest") != body["plan_digest"]
            ):
                connection.execute("ROLLBACK")
                status = "conflict"
                failures = ["f122_attempt_binding_changed_before_dispatch_prepare_commit"]
            else:
                try:
                    connection.execute(
                        """
                        INSERT INTO adapter_dispatches (
                            lease_id, attempt_id, dispatch_id, operation_key,
                            executor_id, adapter_id, plan_digest, prepared_at_epoch,
                            dispatch_request_digest, dispatch_receipt_json
                        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                        """,
                        (
                            body["lease_id"], body["attempt_id"], dispatch_id,
                            body["operation_key"], body["executor_id"], body["adapter_id"],
                            body["plan_digest"], prepared_at, body["request_digest"],
                            json.dumps(receipt, ensure_ascii=False, sort_keys=True, separators=(",", ":")),
                        ),
                    )
                except sqlite3.IntegrityError:
                    connection.execute("ROLLBACK")
                    status = "conflict"
                    failures = ["attempt_dispatch_already_prepared"]
                else:
                    if _fail_before_commit:
                        raise RuntimeError("injected_precommit_failure")
                    connection.execute("COMMIT")
                    status = "prepared"
                    stored = receipt
    except Exception as exc:
        try:
            connection.execute("ROLLBACK")
        except sqlite3.Error:
            pass
        failures = ["adapter_dispatch_transaction:" + type(exc).__name__]
        status = "store_error"
    finally:
        connection.close()

    prepared = status == "prepared"
    recovered = status == "recovered"
    return {
        **eligibility,
        "dispatch_prepared": prepared,
        "idempotent_recovery": recovered,
        "decision": (
            "ADAPTER_DISPATCH_PREPARED" if prepared
            else "ADAPTER_DISPATCH_RECOVERED_NO_SECOND_INTENT" if recovered
            else "ADAPTER_DISPATCH_REJECTED"
        ),
        "failed_conditions": failures,
        "dispatch_id": str(stored.get("dispatch_id") or ""),
        "dispatch_receipt": stored,
        "external_execution_observed": False,
        "state_transition": {
            "from": "ATTEMPT_REGISTERED",
            "to": "DISPATCH_PREPARED" if prepared else "UNCHANGED",
            "durable": prepared or recovered,
        },
        "authority": "workflow_adapter_dispatch_intent_only",
        "authorizations": {key: False for key in sorted(AUTHORIZATION_KEYS)},
        "proof_boundary": {
            "dispatch_prepared": prepared or recovered,
            "external_execution_started": False,
            "postcondition_proven": False,
            "claim_truth_settled": False,
        },
    }


def _load_dispatch_row(connection: sqlite3.Connection, lease_id: str) -> tuple[Any, ...] | None:
    return connection.execute(
        "SELECT attempt_id, dispatch_id, operation_key, executor_id, adapter_id, plan_digest, "
        "prepared_at_epoch, dispatch_request_digest, dispatch_receipt_json "
        "FROM adapter_dispatches WHERE lease_id = ?",
        (lease_id,),
    ).fetchone()


def _load_observations(connection: sqlite3.Connection, dispatch_id: str) -> list[tuple[Any, ...]]:
    return list(connection.execute(
        "SELECT observation_id, ordinal, terminal_status, observed_at_epoch, observation_receipt_json, "
        "observation_key_digest FROM adapter_observations "
        "WHERE dispatch_id = ? ORDER BY ordinal ASC",
        (dispatch_id,),
    ).fetchall())


def build_adapter_observation(
    *,
    dispatch_receipt: Mapping[str, Any],
    dispatch_state: str,
    observation_kind: str,
    observation: Mapping[str, Any] | None,
    terminal_status: str | None = None,
    evidence_ids: Sequence[str] | None = None,
) -> Dict[str, Any]:
    """Build a normalized adapter observation; raw observation stays transient."""
    observed, valid = normalize_mapping(observation)
    evidence, evidence_valid = _normalize_evidence_ids(evidence_ids)
    digest = safe_canonical_digest(observed) if valid else None
    return {
        "dispatch_id": str(dispatch_receipt.get("dispatch_id") or ""),
        "lease_id": str(dispatch_receipt.get("lease_id") or ""),
        "attempt_id": str(dispatch_receipt.get("attempt_id") or ""),
        "executor_id": str(dispatch_receipt.get("executor_id") or ""),
        "adapter_id": str(dispatch_receipt.get("adapter_id") or ""),
        "operation_key": str(dispatch_receipt.get("operation_key") or ""),
        "dispatch_state": str(dispatch_state or ""),
        "terminal_status": str(terminal_status or ""),
        "observation_kind": str(observation_kind or ""),
        "observation_digest": digest or "",
        "evidence_ids": evidence,
        "observation_valid": valid and evidence_valid and digest is not None,
    }


def record_adapter_observation(
    observation_envelope: Mapping[str, Any] | None,
    observation: Mapping[str, Any] | None,
    *,
    store_dir: str | os.PathLike[str] | None = None,
    _fail_before_commit: bool = False,
) -> Dict[str, Any]:
    """Record one adapter observation and reconcile terminal observations into F122."""
    env, valid = normalize_mapping(observation_envelope)
    observed, observation_valid = normalize_mapping(observation)
    failures: list[str] = []
    required = {
        "dispatch_id", "lease_id", "attempt_id", "executor_id", "adapter_id",
        "operation_key", "dispatch_state", "terminal_status", "observation_kind",
        "observation_digest", "evidence_ids", "observation_valid",
    }
    if not valid or set(env) != required:
        failures.append("observation_envelope_exact_schema")
    if env.get("observation_valid") is not True or not observation_valid:
        failures.append("observation_mapping")
    observation_digest = safe_canonical_digest(observed)
    if observation_digest is None or observation_digest != env.get("observation_digest"):
        failures.append("observation_digest_binding")
    dispatch_state = env.get("dispatch_state")
    if dispatch_state not in DISPATCH_STATES:
        failures.append("dispatch_state")
    terminal_status = str(env.get("terminal_status") or "")
    if terminal_status and terminal_status not in TERMINAL_STATUSES:
        failures.append("terminal_status")
    observation_kind = env.get("observation_kind")
    if not isinstance(observation_kind, str) or _OBSERVATION_KIND.fullmatch(observation_kind) is None:
        failures.append("observation_kind")
    evidence_ids, evidence_valid = _normalize_evidence_ids(env.get("evidence_ids"))
    if not evidence_valid or evidence_ids != env.get("evidence_ids"):
        failures.append("evidence_ids")
    for key in ("dispatch_id", "lease_id", "attempt_id"):
        if not is_sha256_id(env.get(key)):
            failures.append(key)
    for key, pattern in (("executor_id", _EXECUTOR_ID), ("adapter_id", _ADAPTER_ID), ("operation_key", _OPERATION_KEY)):
        value = env.get(key)
        if not isinstance(value, str) or pattern.fullmatch(value) is None:
            failures.append(key)

    stored_dispatch: Dict[str, Any] = {}
    stored_observation: Dict[str, Any] = {}
    status = "store_error"
    observation_key_digest = safe_canonical_digest({
        "dispatch_id": env.get("dispatch_id"),
        "lease_id": env.get("lease_id"),
        "attempt_id": env.get("attempt_id"),
        "executor_id": env.get("executor_id"),
        "adapter_id": env.get("adapter_id"),
        "operation_key": env.get("operation_key"),
        "dispatch_state": dispatch_state,
        "terminal_status": terminal_status,
        "observation_kind": observation_kind,
        "observation_digest": observation_digest or "",
        "evidence_ids": evidence_ids,
    }, max_bytes=32768)
    if observation_key_digest is None:
        failures.append("observation_key_bounded_json")

    # Reject malformed/tampered observations before opening or creating durable
    # bridge state. A validation failure is not allowed to manufacture a store.
    if failures:
        return {
            "schema_version": SCHEMA_VERSION,
            "decision_type": OBSERVATION_DECISION_TYPE,
            "policy": POLICY_VERSION,
            "observation_recorded": False,
            "idempotent_recovery": False,
            "failed_conditions": failures,
            "external_execution_observed": False,
            "authority": "adapter_observation_reconciliation_only",
            "proof_boundary": {
                "durable_observation_created": False,
                "postcondition_proven": False,
                "claim_truth_settled": False,
            },
        }

    path = _database_path(store_dir)
    try:
        connection = _initialize_database(path)
    except Exception as exc:
        return {
            "observation_recorded": False,
            "idempotent_recovery": False,
            "failed_conditions": ["adapter_bridge_store_open:" + type(exc).__name__],
            "authority": "adapter_observation_reconciliation_only",
        }

    try:
        connection.execute("BEGIN IMMEDIATE")
        row = _load_dispatch_row(connection, str(env["lease_id"]))
        if row is None:
            connection.execute("ROLLBACK")
            status = "conflict"
            failures = ["dispatch_not_prepared"]
        else:
            try:
                stored_dispatch = json.loads(row[8])
            except (TypeError, json.JSONDecodeError):
                connection.execute("ROLLBACK")
                status = "store_error"
                failures = ["dispatch_receipt_corrupt"]
            else:
                bindings = (
                    row[0] == env["attempt_id"], row[1] == env["dispatch_id"],
                    row[2] == env["operation_key"], row[3] == env["executor_id"],
                    row[4] == env["adapter_id"],
                )
                if not _verify_dispatch_receipt(stored_dispatch, store_dir=store_dir):
                    connection.execute("ROLLBACK")
                    status = "store_error"
                    failures = ["dispatch_receipt_verification_failed"]
                elif not all(bindings):
                    connection.execute("ROLLBACK")
                    status = "conflict"
                    failures = ["adapter_observation_binding_mismatch"]
                else:
                    prior_rows = _load_observations(connection, str(env["dispatch_id"]))
                    exact_prior = next(
                        (item for item in prior_rows if item[5] == observation_key_digest),
                        None,
                    )
                    if exact_prior is not None:
                        connection.execute("COMMIT")
                        try:
                            prior = json.loads(exact_prior[4])
                        except (TypeError, json.JSONDecodeError):
                            failures = ["observation_receipt_corrupt"]
                        else:
                            if _verify_observation_receipt(prior, store_dir=store_dir):
                                status = "recovered"
                                stored_observation = prior
                            else:
                                status = "store_error"
                                failures = ["observation_receipt_verification_failed"]
                    else:
                        f122_state = inspect_executor_outcome(str(env["lease_id"]), store_dir=store_dir)
                        if f122_state.get("outcome_terminal") is True:
                            connection.execute("ROLLBACK")
                            status = "conflict"
                            failures = ["f122_terminal_already_set"]
                        else:
                            observed_at = int(time.time())
                            ordinal = len(prior_rows) + 1
                            body = {
                                "schema_version": OBSERVATION_RECEIPT_SCHEMA,
                                "decision_type": OBSERVATION_DECISION_TYPE,
                                "policy": POLICY_VERSION,
                                "observation_state": "RECORDED",
                                "lease_id": str(env["lease_id"]),
                                "attempt_id": str(env["attempt_id"]),
                                "dispatch_id": str(env["dispatch_id"]),
                                "executor_id": str(env["executor_id"]),
                                "adapter_id": str(env["adapter_id"]),
                                "operation_key": str(env["operation_key"]),
                                "plan_digest": str(row[5]),
                                "dispatch_state": str(dispatch_state),
                                "terminal_status": terminal_status,
                                "observation_kind": str(observation_kind),
                                "observation_digest": str(observation_digest),
                                "observation_key_digest": str(observation_key_digest),
                                "evidence_ids": evidence_ids,
                                "prepared_at_epoch": int(row[6]),
                                "observed_at_epoch": observed_at,
                                "authority_class": "adapter_observation",
                                "scope": "single_prepared_dispatch",
                            }
                            observation_id = safe_canonical_digest(body, max_bytes=32768)
                            if observation_id is None:
                                connection.execute("ROLLBACK")
                                status = "store_error"
                                failures = ["observation_receipt_bounded_json"]
                            else:
                                receipt = {
                                    "observation_id": observation_id,
                                    **body,
                                    "provenance": seal_payload(body, OBSERVATION_RECEIPT_ISSUER, store_dir=store_dir),
                                }
                                try:
                                    connection.execute(
                                        "INSERT INTO adapter_observations ("
                                        "observation_id, dispatch_id, lease_id, ordinal, observation_digest, "
                                        "observation_key_digest, terminal_status, observed_at_epoch, observation_receipt_json"
                                        ") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                                        (
                                            observation_id, env["dispatch_id"], env["lease_id"], ordinal,
                                            observation_digest, observation_key_digest, terminal_status, observed_at,
                                            json.dumps(receipt, ensure_ascii=False, sort_keys=True, separators=(",", ":")),
                                        ),
                                    )
                                except sqlite3.IntegrityError:
                                    connection.execute("ROLLBACK")
                                    status = "conflict"
                                    failures = ["adapter_observation_race_lost"]
                                else:
                                    if _fail_before_commit:
                                        raise RuntimeError("injected_precommit_failure")
                                    connection.execute("COMMIT")
                                    status = "recorded"
                                    stored_observation = receipt
    except Exception as exc:
        try:
            connection.execute("ROLLBACK")
        except sqlite3.Error:
            pass
        status = "store_error"
        failures = ["adapter_observation_transaction:" + type(exc).__name__]
    connection.close()

    recorded = status == "recorded"
    recovered = status == "recovered"
    reconciliation: Dict[str, Any] = {
        "reconciliation_state": "NOT_RUN",
        "terminal_recorded": False,
    }
    if (recorded or recovered) and stored_observation:
        terminal = str(stored_observation.get("terminal_status") or "")
        if terminal in TERMINAL_STATUSES:
            f122_request = build_executor_outcome_request(
                str(stored_observation["lease_id"]),
                str(stored_observation["executor_id"]),
                str(stored_observation["attempt_id"]),
                terminal,
                "adapter_reconciliation",
                {
                    "adapter_id": stored_observation["adapter_id"],
                    "dispatch_id": stored_observation["dispatch_id"],
                    "operation_key": stored_observation["operation_key"],
                    "adapter_observation_id": stored_observation["observation_id"],
                    "adapter_observation_digest": stored_observation["observation_digest"],
                },
                evidence_ids=stored_observation.get("evidence_ids") or [],
            )
            reconciliation_observation = {
                "adapter_id": stored_observation["adapter_id"],
                "dispatch_id": stored_observation["dispatch_id"],
                "operation_key": stored_observation["operation_key"],
                "adapter_observation_id": stored_observation["observation_id"],
                "adapter_observation_digest": stored_observation["observation_digest"],
            }
            f122 = record_executor_outcome(
                f122_request, reconciliation_observation, store_dir=store_dir,
            )
            reconciliation = {
                "reconciliation_state": (
                    "TERMINAL_RECORDED" if f122.get("outcome_recorded") is True
                    else "TERMINAL_RECOVERED" if f122.get("idempotent_recovery") is True
                    else "TERMINAL_CONFLICT"
                ),
                "terminal_recorded": f122.get("outcome_recorded") is True,
                "terminal_recovered": f122.get("idempotent_recovery") is True,
                "f122_outcome_id": str(f122.get("outcome_id") or ""),
                "f122_decision": str(f122.get("decision") or ""),
                "f122_failed_conditions": list(f122.get("failed_conditions") or []),
            }
        else:
            reconciliation = {
                "reconciliation_state": "STILL_UNRESOLVED",
                "terminal_recorded": False,
                "reason": "adapter_observation_is_nonterminal",
            }

    return {
        "schema_version": SCHEMA_VERSION,
        "decision_type": OBSERVATION_DECISION_TYPE,
        "policy": POLICY_VERSION,
        "observation_recorded": recorded,
        "idempotent_recovery": recovered,
        "decision": (
            "ADAPTER_OBSERVATION_RECORDED" if recorded
            else "ADAPTER_OBSERVATION_RECOVERED" if recovered
            else "ADAPTER_OBSERVATION_REJECTED"
        ),
        "failed_conditions": failures,
        "observation_id": str(stored_observation.get("observation_id") or ""),
        "observation_receipt": stored_observation,
        "reconciliation": reconciliation,
        "authority": "adapter_observation_reconciliation_only",
        "effects": {
            "adapter_bridge_state_changed": recorded,
            "external_execution_performed_by_this_record_call": False,
            "postcondition_proven": False,
            "truth_committed": False,
        },
        "proof_boundary": {
            "adapter_observation_recorded": recorded or recovered,
            "terminal_executor_report_may_have_been_forwarded": reconciliation.get("reconciliation_state") in {"TERMINAL_RECORDED", "TERMINAL_RECOVERED"},
            "postcondition_proven": False,
            "claim_truth_settled": False,
        },
    }


def inspect_adapter_dispatch(
    lease_id: str,
    *,
    store_dir: str | os.PathLike[str] | None = None,
) -> Dict[str, Any]:
    """Read dispatch/observation state without executing or reconciling anything."""
    if not is_sha256_id(lease_id):
        return {"dispatch_found": False, "error": "invalid_lease_id"}
    try:
        connection = _read_connection(_database_path(store_dir))
        try:
            row = _load_dispatch_row(connection, lease_id)
            observation_rows = _load_observations(connection, str(row[1])) if row is not None else []
        finally:
            connection.close()
    except (FileNotFoundError, ValueError, sqlite3.Error, OSError) as exc:
        return {"dispatch_found": False, "error": "adapter_bridge_store_read:" + type(exc).__name__}
    if row is None:
        return {"dispatch_found": False, "error": "adapter_dispatch_not_found"}
    try:
        dispatch = json.loads(row[8])
    except (TypeError, json.JSONDecodeError):
        return {"dispatch_found": False, "error": "dispatch_receipt_corrupt"}
    if not _verify_dispatch_receipt(dispatch, store_dir=store_dir):
        return {"dispatch_found": False, "error": "dispatch_receipt_verification_failed"}
    observations: list[Dict[str, Any]] = []
    for observation_row in observation_rows:
        try:
            observation = json.loads(observation_row[4])
        except (TypeError, json.JSONDecodeError):
            return {"dispatch_found": False, "error": "observation_receipt_corrupt"}
        if not _verify_observation_receipt(observation, store_dir=store_dir):
            return {"dispatch_found": False, "error": "observation_receipt_verification_failed"}
        observations.append(observation)
    latest_observation: Dict[str, Any] = observations[-1] if observations else {}
    f122 = inspect_executor_outcome(lease_id, store_dir=store_dir)
    return {
        "dispatch_found": True,
        "decision": "ADAPTER_OBSERVATION_AVAILABLE" if latest_observation else "ADAPTER_DISPATCH_UNRESOLVED",
        "lease_id": lease_id,
        "attempt_id": str(row[0]),
        "dispatch_id": str(row[1]),
        "operation_key": str(row[2]),
        "executor_id": str(row[3]),
        "adapter_id": str(row[4]),
        "plan_digest": str(row[5]),
        "prepared_at_epoch": int(row[6]),
        "dispatch_receipt": dispatch,
        "observation_count": len(observations),
        "observation_ids": [item["observation_id"] for item in observations],
        "observation_receipt": latest_observation,
        "f122_terminal_status": f122.get("terminal_status") if f122.get("attempt_found") else None,
        "authority": "adapter_dispatch_inspection_only",
        "proof_boundary": {
            "external_execution_proven": False,
            "postcondition_proven": False,
            "claim_truth_settled": False,
            "missing_observation_remains_unresolved": not bool(latest_observation),
        },
    }


def inspect_adapter_observation(
    lease_id: str,
    observation_id: str,
    *,
    store_dir: str | os.PathLike[str] | None = None,
) -> Dict[str, Any]:
    """Read one exact sealed observation receipt without dispatching work.

    ``inspect_adapter_dispatch`` intentionally exposes only the latest receipt
    plus the observation-id history.  Evidence binders need a narrower lookup:
    verify one claimed historical receipt and recover its content digest without
    treating membership in the lease as proof that arbitrary caller content was
    observed.
    """
    if not is_sha256_id(lease_id):
        return {"observation_found": False, "error": "invalid_lease_id"}
    if not is_sha256_id(observation_id):
        return {"observation_found": False, "error": "invalid_observation_id"}
    try:
        connection = _read_connection(_database_path(store_dir))
        try:
            dispatch_row = _load_dispatch_row(connection, lease_id)
            observation_rows = (
                _load_observations(connection, str(dispatch_row[1]))
                if dispatch_row is not None
                else []
            )
        finally:
            connection.close()
    except (FileNotFoundError, ValueError, sqlite3.Error, OSError) as exc:
        return {
            "observation_found": False,
            "error": "adapter_bridge_store_read:" + type(exc).__name__,
        }
    if dispatch_row is None:
        return {"observation_found": False, "error": "adapter_dispatch_not_found"}
    matched = next((row for row in observation_rows if row[0] == observation_id), None)
    if matched is None:
        return {"observation_found": False, "error": "adapter_observation_not_found"}
    try:
        receipt = json.loads(matched[4])
    except (TypeError, json.JSONDecodeError):
        return {"observation_found": False, "error": "observation_receipt_corrupt"}
    if not _verify_observation_receipt(receipt, store_dir=store_dir):
        return {
            "observation_found": False,
            "error": "observation_receipt_verification_failed",
        }
    if receipt.get("lease_id") != lease_id or receipt.get("observation_id") != observation_id:
        return {"observation_found": False, "error": "observation_receipt_binding_mismatch"}
    return {
        "schema_version": SCHEMA_VERSION,
        "observation_found": True,
        "lease_id": lease_id,
        "observation_id": observation_id,
        "observation_digest": receipt.get("observation_digest"),
        "observation_kind": receipt.get("observation_kind"),
        "dispatch_id": receipt.get("dispatch_id"),
        "adapter_id": receipt.get("adapter_id"),
        "receipt": receipt,
        "authority": "adapter_observation_inspection_only",
        "proof_boundary": {
            "receipt_integrity_verified": True,
            "caller_content_binding_not_inferred": True,
            "external_execution_proven": False,
            "postcondition_proven": False,
            "claim_truth_settled": False,
        },
    }


def _validate_adapter(adapter: Any, *, executor_id: str, adapter_id: str) -> list[str]:
    failures: list[str] = []
    if not isinstance(getattr(adapter, "adapter_id", None), str) or adapter.adapter_id != adapter_id:
        failures.append("adapter_id_binding")
    if not isinstance(getattr(adapter, "executor_id", None), str) or adapter.executor_id != executor_id:
        failures.append("adapter_executor_binding")
    if not callable(getattr(adapter, "dispatch", None)):
        failures.append("adapter_dispatch_callable")
    if not callable(getattr(adapter, "reconcile", None)):
        failures.append("adapter_reconcile_callable")
    return failures


def invoke_executor_adapter(
    request: Mapping[str, Any] | None,
    adapter: ExecutorAdapter,
    *,
    allow_external_execution: bool = False,
    store_dir: str | os.PathLike[str] | None = None,
) -> Dict[str, Any]:
    """Prepare then invoke one host adapter; never retries an ambiguous invocation.

    This is a host/library API, intentionally not a generic CLI shell surface.
    The adapter controls the domain-specific effect. F123 only binds context and
    records the adapter's returned observation.
    """
    if allow_external_execution is not True:
        return {
            "adapter_invoked": False,
            "error": "explicit_external_execution_acknowledgement_required",
            "authority": "no_external_execution_without_literal_acknowledgement",
        }
    req, _ = normalize_mapping(request)
    failures = _validate_adapter(
        adapter,
        executor_id=str(req.get("executor_id") or ""),
        adapter_id=str(req.get("adapter_id") or ""),
    )
    if failures:
        return {"adapter_invoked": False, "failed_conditions": failures, "authority": "adapter_binding_rejected"}
    prepared = prepare_adapter_dispatch(req, store_dir=store_dir)
    if not (prepared.get("dispatch_prepared") is True or prepared.get("idempotent_recovery") is True):
        return {"adapter_invoked": False, "dispatch": prepared, "authority": "adapter_dispatch_not_prepared"}
    # Never invoke on an idempotent recovery: after a process crash, the machine
    # cannot know whether the previous host call happened. Reconciliation must be
    # used instead of blind re-dispatch.
    if prepared.get("idempotent_recovery") is True:
        return {
            "adapter_invoked": False,
            "dispatch": prepared,
            "reconciliation_required": True,
            "authority": "ambiguous_prior_dispatch_requires_reconciliation",
        }
    dispatch_receipt = prepared.get("dispatch_receipt")
    context = {
        "schema_version": "plw-executor-adapter-context-v1",
        "lease_id": prepared.get("lease_id"),
        "attempt_id": prepared.get("attempt_id"),
        "dispatch_id": prepared.get("dispatch_id"),
        "executor_id": prepared.get("executor_id"),
        "adapter_id": prepared.get("adapter_id"),
        "operation_key": prepared.get("operation_key"),
        "plan_digest": prepared.get("plan_digest"),
        "authority": "execute_exact_bound_plan_only",
    }
    try:
        raw = adapter.dispatch(context)
    except Exception as exc:
        return {
            "adapter_invoked": True,
            "dispatch": prepared,
            "adapter_returned": False,
            "reconciliation_required": True,
            "adapter_exception_type": type(exc).__name__,
            "authority": "external_invocation_outcome_unknown",
        }
    if not isinstance(raw, Mapping):
        return {
            "adapter_invoked": True,
            "dispatch": prepared,
            "adapter_returned": True,
            "reconciliation_required": True,
            "failed_conditions": ["adapter_observation_mapping"],
            "authority": "external_invocation_observation_invalid",
        }
    observation = raw.get("observation") if isinstance(raw.get("observation"), Mapping) else {}
    envelope = build_adapter_observation(
        dispatch_receipt=dispatch_receipt if isinstance(dispatch_receipt, Mapping) else {},
        dispatch_state=str(raw.get("dispatch_state") or "UNKNOWN"),
        terminal_status=str(raw.get("terminal_status") or "") or None,
        observation_kind=str(raw.get("observation_kind") or "adapter_dispatch"),
        observation=observation,
        evidence_ids=raw.get("evidence_ids") if isinstance(raw.get("evidence_ids"), Sequence) and not isinstance(raw.get("evidence_ids"), (str, bytes)) else None,
    )
    recorded = record_adapter_observation(envelope, observation, store_dir=store_dir)
    return {
        "adapter_invoked": True,
        "adapter_returned": True,
        "dispatch": prepared,
        "observation": recorded,
        "reconciliation_required": recorded.get("reconciliation", {}).get("reconciliation_state") == "STILL_UNRESOLVED",
        "authority": "adapter_invocation_bridge_only",
        "proof_boundary": {
            "external_invocation_was_attempted": True,
            "postcondition_proven": False,
            "claim_truth_settled": False,
        },
    }


def reconcile_executor_adapter(
    lease_id: str,
    adapter: ExecutorAdapter,
    *,
    store_dir: str | os.PathLike[str] | None = None,
) -> Dict[str, Any]:
    """Query a concrete adapter for an unresolved prepared dispatch.

    Reconciliation may run after lease expiry. NOT_FOUND/PENDING/UNKNOWN never
    prove absence of side effects and therefore remain unresolved.
    """
    state = inspect_adapter_dispatch(lease_id, store_dir=store_dir)
    if state.get("dispatch_found") is not True:
        return {"reconciled": False, "state": state, "authority": "adapter_reconciliation_only"}
    failures = _validate_adapter(
        adapter,
        executor_id=str(state.get("executor_id") or ""),
        adapter_id=str(state.get("adapter_id") or ""),
    )
    if failures:
        return {"reconciled": False, "failed_conditions": failures, "authority": "adapter_binding_rejected"}
    if state.get("f122_terminal_status") in TERMINAL_STATUSES:
        return {
            "reconciled": False,
            "already_terminal": True,
            "state": state,
            "authority": "adapter_reconciliation_read_only_terminal_state",
        }
    context = {
        "schema_version": "plw-executor-adapter-context-v1",
        "lease_id": state["lease_id"],
        "attempt_id": state["attempt_id"],
        "dispatch_id": state["dispatch_id"],
        "executor_id": state["executor_id"],
        "adapter_id": state["adapter_id"],
        "operation_key": state["operation_key"],
        "plan_digest": state["plan_digest"],
        "authority": "reconcile_exact_bound_operation_only",
    }
    try:
        raw = adapter.reconcile(context)
    except Exception as exc:
        return {
            "reconciled": False,
            "adapter_queried": True,
            "reconciliation_required": True,
            "adapter_exception_type": type(exc).__name__,
            "authority": "adapter_reconciliation_outcome_unknown",
        }
    if not isinstance(raw, Mapping):
        return {"reconciled": False, "adapter_queried": True,
                "failed_conditions": ["adapter_observation_mapping"],
                "authority": "adapter_reconciliation_observation_invalid"}
    reconciliation_state = str(raw.get("reconciliation_state") or "UNKNOWN")
    terminal_status = str(raw.get("terminal_status") or "")
    allowed_reconciliation_states = NONTERMINAL_RECONCILIATION_STATES | TERMINAL_RECONCILIATION_STATES
    if reconciliation_state not in allowed_reconciliation_states:
        return {"reconciled": False, "adapter_queried": True,
                "failed_conditions": ["reconciliation_state"],
                "authority": "adapter_reconciliation_observation_invalid"}
    if reconciliation_state in NONTERMINAL_RECONCILIATION_STATES and terminal_status:
        return {"reconciled": False, "adapter_queried": True,
                "failed_conditions": ["nonterminal_reconciliation_cannot_claim_terminal"],
                "authority": "adapter_reconciliation_observation_invalid"}
    if reconciliation_state in TERMINAL_RECONCILIATION_STATES and terminal_status not in TERMINAL_STATUSES:
        return {"reconciled": False, "adapter_queried": True,
                "failed_conditions": ["terminal_reconciliation_status_required"],
                "authority": "adapter_reconciliation_observation_invalid"}
    observation = raw.get("observation") if isinstance(raw.get("observation"), Mapping) else {}
    envelope = build_adapter_observation(
        dispatch_receipt=state.get("dispatch_receipt") if isinstance(state.get("dispatch_receipt"), Mapping) else {},
        dispatch_state=str(raw.get("dispatch_state") or "UNKNOWN"),
        terminal_status=terminal_status or None,
        observation_kind=str(raw.get("observation_kind") or "adapter_reconciliation"),
        observation=observation,
        evidence_ids=raw.get("evidence_ids") if isinstance(raw.get("evidence_ids"), Sequence) and not isinstance(raw.get("evidence_ids"), (str, bytes)) else None,
    )
    recorded = record_adapter_observation(envelope, observation, store_dir=store_dir)
    return {
        "reconciled": recorded.get("observation_recorded") is True or recorded.get("idempotent_recovery") is True,
        "adapter_queried": True,
        "adapter_reconciliation_state": reconciliation_state,
        "observation": recorded,
        "authority": "adapter_reconciliation_bridge_only",
        "proof_boundary": {
            "not_found_proves_no_effect": False,
            "pending_proves_failure": False,
            "postcondition_proven": False,
            "claim_truth_settled": False,
        },
    }


__all__ = [
    "SCHEMA_VERSION", "POLICY_VERSION", "DISPATCH_STATES",
    "NONTERMINAL_RECONCILIATION_STATES", "TERMINAL_RECONCILIATION_STATES", "ExecutorAdapter",
    "build_adapter_dispatch_request", "evaluate_adapter_dispatch",
    "prepare_adapter_dispatch", "build_adapter_observation",
    "record_adapter_observation", "inspect_adapter_dispatch", "inspect_adapter_observation",
    "invoke_executor_adapter", "reconcile_executor_adapter",
]
