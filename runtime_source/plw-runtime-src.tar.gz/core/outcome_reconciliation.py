"""Delayed behavioral-cost reconciliation for proof transition outcomes.

A transition may look cheap at settlement time and later cause recovery/rerun
work because evidence was compacted or externalized.  This module attributes
those *post-settlement* costs back to the original transition outcome without
mutating truth, settlement, or transition legality.

Reconciliation is procedural policy bookkeeping only:
- baseline counters come from the immutable transition outcome;
- current counters come from privacy-bounded command telemetry;
- delayed cost is the non-negative delta between them;
- representation accountability is linked by exact output_id when available.

Raw commands, stdout, queries, target paths and truth scopes are never stored or
returned here.
"""
from __future__ import annotations

import hashlib
import json
from typing import Any, Dict, List, Optional, Sequence

from core.command_output import get_output_behavior_metrics, get_output_behavior_metrics_batch
from core.context_accountability import list_accountability_decisions, record_accountability
from core.decision_lineage import build_lineage_index, descendants_from_index
from memory.transition_outcomes import load_transition_outcomes
from memory.delayed_costs import record_delayed_cost_reconciliations

SCHEMA_VERSION = "delayed-outcome-reconciliation-v2"
POLICY_VERSION = "post_settlement_behavioral_cost_reconciliation_v2_explicit_lineage"
RESPONSIBLE_ROLE = "delayed_outcome_reconciliation_custodian"


def _nonneg_delta(current: Any, baseline: Any) -> int:
    try:
        return max(0, int(current or 0) - int(baseline or 0))
    except (TypeError, ValueError):
        return 0


def _fingerprint(payload: Dict[str, Any]) -> str:
    raw = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return "sha256:" + hashlib.sha256(raw).hexdigest()


def _representation_accountability_index() -> Dict[str, Dict[str, Any]]:
    index: Dict[str, Dict[str, Any]] = {}
    for item in list_accountability_decisions(
        decision_type="command_output_representation", limit=256, newest_first=True
    ):
        recovery = item.get("recovery_obligation", {}) or {}
        input_state = item.get("input_state", {}) or {}
        keys = {str(recovery.get("output_id") or ""), str(input_state.get("raw_sha256") or "")}
        ref = {
            "available": True,
            "decision_id": item.get("decision_id"),
            "responsible_component": item.get("responsible_component"),
            "responsible_role": item.get("responsible_role"),
            "policy": item.get("policy"),
            "authority": "representation_decision_only",
        }
        for key in keys:
            if key and key not in index:
                index[key] = ref
    return index


def _representation_accountability(
    output_id: str, *, index: Optional[Dict[str, Dict[str, Any]]] = None
) -> Dict[str, Any]:
    output = str(output_id or "")
    if not output:
        return {"available": False}
    if index is not None:
        return dict(index.get(output) or {"available": False})
    return dict(_representation_accountability_index().get(output) or {"available": False})



def _causal_lineage_cost(outcome: Dict[str, Any], lineage_index: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    attestation_id = str(outcome.get("attestation_id") or "")
    if not attestation_id or not lineage_index:
        return {"available": False, "reason": "attestation_lineage_unavailable", "context_reexpansion_tokens": 0}
    refs = (lineage_index.get("references", {}) or {}).get(("attestation_id", attestation_id), []) or []
    roots = sorted(set(str(v) for v in refs if v))
    if len(roots) != 1:
        return {
            "available": False,
            "reason": "ambiguous_or_missing_attestation_lineage",
            "root_count": len(roots),
            "context_reexpansion_tokens": 0,
            "causality_not_inferred": True,
        }
    descendants = descendants_from_index(roots[0], lineage_index)
    context_nodes = [n for n in descendants if n.get("node_type") == "context_projection"]
    command_nodes = [n for n in descendants if n.get("node_type") == "command_output_representation"]
    recovery_nodes = [n for n in descendants if n.get("node_type") == "output_recovery"]
    context_tokens = sum(max(0, int((n.get("metadata", {}) or {}).get("estimated_tokens") or 0)) for n in context_nodes)
    followup_command_tokens = sum(max(0, int((n.get("metadata", {}) or {}).get("compacted_estimated_tokens") or 0)) for n in command_nodes)
    return {
        "available": True,
        "root_lineage_id": roots[0],
        "descendant_count": len(descendants),
        "explicit_context_reexpansion_count": len(context_nodes),
        "context_reexpansion_tokens": context_tokens,
        "explicit_followup_command_representation_count": len(command_nodes),
        "followup_command_compacted_tokens": followup_command_tokens,
        "explicit_output_recovery_count": len(recovery_nodes),
        "attribution_basis": "explicit_parent_lineage_only",
        "semantic_similarity_used": False,
        "temporal_proximity_used": False,
        "authority": "strategy_cost_causal_lineage_only",
    }

def reconcile_transition_outcome(
    outcome: Dict[str, Any], *, output_store_dir: Optional[str] = None,
    current_behavior: Optional[Dict[str, Any]] = None,
    accountability_index: Optional[Dict[str, Dict[str, Any]]] = None,
    lineage_index: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    """Compute current delayed behavioral cost for one immutable outcome."""
    baseline = outcome.get("policy_cost_observation", {}) or {}
    evidence_id = str(outcome.get("evidence_id") or "")
    command_fp = str(outcome.get("command_fingerprint") or "")
    current = current_behavior if current_behavior is not None else (
        get_output_behavior_metrics(
            evidence_id,
            command_fingerprint_value=command_fp or None,
            store_dir=output_store_dir,
        ) if evidence_id else {"available": False}
    )

    causal_lineage = _causal_lineage_cost(outcome, lineage_index)
    delayed = {
        "repeat_observations": _nonneg_delta(current.get("repeat_observations"), baseline.get("repeat_observations")),
        "output_recoveries": _nonneg_delta(current.get("output_recoveries"), baseline.get("output_recoveries")),
        "same_command_observations": _nonneg_delta(current.get("same_command_observations"), baseline.get("same_command_observations")),
        "raw_tokens_observed": _nonneg_delta(current.get("same_command_raw_tokens_total"), baseline.get("same_command_raw_tokens_total")),
        "compacted_tokens_observed": _nonneg_delta(current.get("same_command_compacted_tokens_total"), baseline.get("same_command_compacted_tokens_total")),
        "tokens_saved_observed": _nonneg_delta(current.get("same_command_tokens_saved_total"), baseline.get("same_command_tokens_saved_total")),
        "context_reexpansion_tokens": max(0, int(causal_lineage.get("context_reexpansion_tokens") or 0)),
    }
    delayed["has_delayed_cost"] = any(
        int(delayed[key] or 0) > 0
        for key in ("repeat_observations", "output_recoveries", "compacted_tokens_observed", "context_reexpansion_tokens")
    )

    stable = {
        "schema_version": SCHEMA_VERSION,
        "policy": POLICY_VERSION,
        "outcome_id": outcome.get("outcome_id"),
        "transition_id": outcome.get("transition_id"),
        "transition_type": outcome.get("transition_type"),
        "claim_type": outcome.get("claim_type"),
        "evidence_id": evidence_id or None,
        "baseline": {
            "repeat_observations": int(baseline.get("repeat_observations", 0) or 0),
            "output_recoveries": int(baseline.get("output_recoveries", 0) or 0),
            "same_command_observations": int(baseline.get("same_command_observations", 0) or 0),
            "same_command_raw_tokens_total": int(baseline.get("same_command_raw_tokens_total", 0) or 0),
            "same_command_compacted_tokens_total": int(baseline.get("same_command_compacted_tokens_total", 0) or 0),
            "same_command_tokens_saved_total": int(baseline.get("same_command_tokens_saved_total", 0) or 0),
        },
        "current": {
            "available": bool(current.get("available")),
            "repeat_observations": int(current.get("repeat_observations", 0) or 0),
            "output_recoveries": int(current.get("output_recoveries", 0) or 0),
            "same_command_observations": int(current.get("same_command_observations", 0) or 0),
            "same_command_raw_tokens_total": int(current.get("same_command_raw_tokens_total", 0) or 0),
            "same_command_compacted_tokens_total": int(current.get("same_command_compacted_tokens_total", 0) or 0),
            "same_command_tokens_saved_total": int(current.get("same_command_tokens_saved_total", 0) or 0),
        },
        "delayed_cost": delayed,
        "representation_accountability": _representation_accountability(evidence_id, index=accountability_index),
        "causal_lineage": causal_lineage,
        "authority": "strategy_cost_reconciliation_only",
        "invariants": {
            "does_not_change_settlement": True,
            "does_not_change_transition_legality": True,
            "does_not_commit_proof_state": True,
            "does_not_assert_claim_truth": True,
            "raw_command_not_stored": True,
            "raw_output_not_stored": True,
            "raw_query_not_stored": True,
            "raw_target_path_not_stored": True,
            "negative_deltas_clamped_to_zero": True,
            "absence_of_later_activity_is_not_success": True,
            "only_explicit_parent_links_count_as_cross_step_causality": True,
            "semantic_similarity_is_not_causal_attribution": True,
        },
    }
    stable["reconciliation_id"] = _fingerprint(stable)
    return stable


def summarize_outcome_reconciliation(
    *, limit: int = 256, output_store_dir: Optional[str] = None
) -> Dict[str, Any]:
    outcomes = [item for item in load_transition_outcomes(limit=limit) if item.get("evidence_id")]
    requests = [
        {
            "output_id": str(item.get("evidence_id") or ""),
            "command_fingerprint": str(item.get("command_fingerprint") or ""),
        }
        for item in outcomes
    ]
    behaviors = get_output_behavior_metrics_batch(requests, store_dir=output_store_dir) if requests else []
    accountability_index = _representation_accountability_index() if outcomes else {}
    lineage_index = build_lineage_index() if outcomes else {"nodes": {}, "children": {}, "references": {}, "node_count": 0}
    rows = [
        reconcile_transition_outcome(
            item,
            output_store_dir=output_store_dir,
            current_behavior=behaviors[idx] if idx < len(behaviors) else {"available": False},
            accountability_index=accountability_index,
            lineage_index=lineage_index,
        )
        for idx, item in enumerate(outcomes)
    ]
    rows.sort(key=lambda x: (str(x.get("claim_type")), str(x.get("transition_type")), str(x.get("outcome_id"))))
    return {
        "schema_version": SCHEMA_VERSION,
        "policy": POLICY_VERSION,
        "authority": "strategy_cost_reconciliation_only",
        "outcome_count": len(rows),
        "with_delayed_cost": sum(1 for row in rows if row.get("delayed_cost", {}).get("has_delayed_cost")),
        "reconciliations": rows,
        "performance": {
            "telemetry_snapshot_reads": 1 if requests else 0,
            "accountability_index_builds": 1 if outcomes else 0,
            "lineage_index_builds": 1 if outcomes else 0,
            "per_outcome_store_rescans": False,
        },
        "coverage": {
            "command_output_recovery_and_same_command_rerun": True,
            "context_reexpansion_attribution": "explicit_parent_lineage_only",
            "cross_command_explicit_lineage_attribution": True,
            "cross_command_semantic_search_attribution": False,
            "note": "v2 attributes exact recovery/rerun plus explicitly parent-linked downstream context/actions; semantic similarity or timing alone never establish causality.",
        },
        "invariants": {
            "reconciliation_is_not_truth_evidence": True,
            "does_not_mutate_original_outcome": True,
            "does_not_retroactively_change_claim_settlement": True,
            "delayed_cost_is_policy_signal_only": True,
        },
    }


def reconciliation_for_outcome(
    outcome_id: str, *, output_store_dir: Optional[str] = None
) -> Dict[str, Any]:
    wanted = str(outcome_id or "")
    for item in load_transition_outcomes():
        if str(item.get("outcome_id") or "") == wanted:
            return reconcile_transition_outcome(
                item, output_store_dir=output_store_dir, lineage_index=build_lineage_index()
            )
    return {"available": False, "outcome_id": wanted, "error": "outcome_not_found"}


def refresh_outcome_reconciliation(*, output_store_dir: Optional[str] = None, limit: int = 256) -> Dict[str, Any]:
    """Refresh sanitized procedural delayed-cost memory from current telemetry."""
    summary = summarize_outcome_reconciliation(limit=limit, output_store_dir=output_store_dir)
    memory_result = record_delayed_cost_reconciliations(summary.get("reconciliations", []) or [])
    return {**summary, "memory": memory_result}


def record_reconciliation_accountability(
    *, output_store_dir: Optional[str] = None, limit: int = 256
) -> Dict[str, Any]:
    """Persist one privacy-bounded audit decision for the current reconciliation snapshot."""
    summary = summarize_outcome_reconciliation(limit=limit, output_store_dir=output_store_dir)
    decision = {
        "decision_type": "delayed_outcome_cost_reconciliation",
        "responsible_component": "core.outcome_reconciliation.record_reconciliation_accountability",
        "responsible_role": RESPONSIBLE_ROLE,
        "policy": POLICY_VERSION,
        "outcome_count": summary.get("outcome_count"),
        "with_delayed_cost": summary.get("with_delayed_cost"),
        "reconciliations": [
            {
                "reconciliation_id": row.get("reconciliation_id"),
                "outcome_id": row.get("outcome_id"),
                "transition_id": row.get("transition_id"),
                "evidence_id": row.get("evidence_id"),
                "delayed_cost": row.get("delayed_cost"),
                "representation_accountability": row.get("representation_accountability"),
                "causal_lineage": row.get("causal_lineage"),
            }
            for row in summary.get("reconciliations", [])
        ],
        "coverage": summary.get("coverage"),
        "invariants": summary.get("invariants"),
    }
    return record_accountability(decision)


__all__ = [
    "SCHEMA_VERSION",
    "POLICY_VERSION",
    "RESPONSIBLE_ROLE",
    "reconcile_transition_outcome",
    "summarize_outcome_reconciliation",
    "reconciliation_for_outcome",
    "refresh_outcome_reconciliation",
    "record_reconciliation_accountability",
]
