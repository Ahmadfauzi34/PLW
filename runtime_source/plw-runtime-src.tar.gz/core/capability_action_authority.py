"""Explicit principal-bound authority assertion for one capability proposal.

Issuance is intentionally separate from request construction.  A host should
expose ``issue_authorization_assertion`` only after its own user/policy approval
ceremony.  The resulting assertion is short-lived, nonce-bearing, store-bound,
and cryptographically tied to one exact proposal request.
"""
from __future__ import annotations

import secrets
import time
from typing import Any, Dict, Mapping

from core.accountability_provenance import AUTHORITY_ISSUER, seal_payload, verify_payload
from core.capability_contracts import (
    bounded_text,
    exact_keys,
    is_sha256_id,
    safe_canonical_digest,
)


SCHEMA_VERSION = "capability-action-authority-assertion-v1"
POLICY_VERSION = "principal_bound_short_lived_single_proposal_grant_v1"
AUTHORITY_CLASS = "capability_action_execution"
MAX_TTL_SECONDS = 900
_CLOCK_SKEW_SECONDS = 5
_ASSERTION_KEYS = frozenset({
    "schema_version", "policy", "principal_id", "proposal_accountability_id",
    "proposal_request_digest", "capability_id", "action_kind", "target_state",
    "expected_state", "envelope_evidence_digest", "authority_class", "scope",
    "grant", "issued_at_epoch", "expires_at_epoch", "nonce", "provenance",
})


def issue_authorization_assertion(
    proposal_accountability_id: str,
    proposal_request: Mapping[str, Any] | None,
    principal_id: str,
    *,
    store_dir: str | None = None,
    ttl_seconds: int = 300,
    now_epoch: int | None = None,
    nonce: str | None = None,
) -> Dict[str, Any]:
    """Issue one signed assertion after an external authority has approved it."""
    request = dict(proposal_request or {})
    request_digest = safe_canonical_digest(request)
    if not is_sha256_id(proposal_accountability_id):
        raise ValueError("Invalid proposal accountability id")
    if request_digest is None:
        raise ValueError("Proposal request is not bounded canonical JSON")
    if not bounded_text(principal_id, maximum=128):
        raise ValueError("Invalid authority principal id")
    if type(ttl_seconds) is not int or not (1 <= ttl_seconds <= MAX_TTL_SECONDS):
        raise ValueError("Authorization assertion TTL is outside the allowed bound")
    issued = int(time.time()) if now_epoch is None else now_epoch
    if type(issued) is not int or issued < 0:
        raise ValueError("Invalid authorization issuance time")
    assertion_nonce = secrets.token_hex(16) if nonce is None else nonce
    if (
        not isinstance(assertion_nonce, str)
        or not (32 <= len(assertion_nonce) <= 64)
        or any(ch not in "0123456789abcdef" for ch in assertion_nonce)
    ):
        raise ValueError("Invalid authorization nonce")

    body = {
        "schema_version": SCHEMA_VERSION,
        "policy": POLICY_VERSION,
        "principal_id": principal_id,
        "proposal_accountability_id": proposal_accountability_id,
        "proposal_request_digest": request_digest,
        "capability_id": str(request.get("capability_id") or ""),
        "action_kind": str(request.get("action_kind") or ""),
        "target_state": str(request.get("target_state") or ""),
        "expected_state": str(request.get("expected_state") or ""),
        "envelope_evidence_digest": str(request.get("envelope_evidence_digest") or ""),
        "authority_class": AUTHORITY_CLASS,
        "scope": "single_proposal",
        "grant": True,
        "issued_at_epoch": issued,
        "expires_at_epoch": issued + ttl_seconds,
        "nonce": assertion_nonce,
    }
    return {**body, "provenance": seal_payload(body, AUTHORITY_ISSUER, store_dir=store_dir)}


def verify_authorization_assertion(
    assertion: Any,
    proposal_accountability_id: str,
    proposal_request: Mapping[str, Any] | None,
    *,
    store_dir: str | None = None,
    now_epoch: int | None = None,
) -> tuple[bool, list[str]]:
    """Verify shape, signature, proposal binding, principal, nonce, and freshness."""
    failures: list[str] = []
    if not exact_keys(assertion, _ASSERTION_KEYS):
        return False, ["authority_assertion_exact_schema"]
    assert isinstance(assertion, dict)
    request = dict(proposal_request or {})
    request_digest = safe_canonical_digest(request)
    body = {key: assertion[key] for key in _ASSERTION_KEYS if key != "provenance"}

    if assertion.get("schema_version") != SCHEMA_VERSION:
        failures.append("authority_assertion_schema_version")
    if assertion.get("policy") != POLICY_VERSION:
        failures.append("authority_assertion_policy")
    if not bounded_text(assertion.get("principal_id"), maximum=128):
        failures.append("authority_assertion_principal")
    if assertion.get("authority_class") != AUTHORITY_CLASS:
        failures.append("authority_assertion_class")
    if assertion.get("scope") != "single_proposal" or assertion.get("grant") is not True:
        failures.append("authority_assertion_grant")
    if assertion.get("proposal_accountability_id") != proposal_accountability_id:
        failures.append("authority_assertion_proposal_id")
    if request_digest is None or assertion.get("proposal_request_digest") != request_digest:
        failures.append("authority_assertion_proposal_digest")

    for key in (
        "capability_id", "action_kind", "target_state", "expected_state",
        "envelope_evidence_digest",
    ):
        if assertion.get(key) != request.get(key):
            failures.append("authority_assertion_" + key)

    nonce = assertion.get("nonce")
    if (
        not isinstance(nonce, str)
        or not (32 <= len(nonce) <= 64)
        or any(ch not in "0123456789abcdef" for ch in nonce)
    ):
        failures.append("authority_assertion_nonce")
    issued, expires = assertion.get("issued_at_epoch"), assertion.get("expires_at_epoch")
    current = int(time.time()) if now_epoch is None else now_epoch
    if type(issued) is not int or type(expires) is not int or type(current) is not int:
        failures.append("authority_assertion_time_type")
    elif (
        issued < 0
        or expires <= issued
        or expires - issued > MAX_TTL_SECONDS
        or issued > current + _CLOCK_SKEW_SECONDS
        or expires <= current
    ):
        failures.append("authority_assertion_freshness")

    if not verify_payload(body, assertion.get("provenance"), AUTHORITY_ISSUER, store_dir=store_dir):
        failures.append("authority_assertion_provenance")
    return not failures, failures


__all__ = [
    "SCHEMA_VERSION", "POLICY_VERSION", "AUTHORITY_CLASS", "MAX_TTL_SECONDS",
    "issue_authorization_assertion", "verify_authorization_assertion",
]
