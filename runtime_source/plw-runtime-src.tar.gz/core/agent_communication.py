"""Agent-facing communication contract for bounded PLW orchestration.

This module does not select capabilities or widen authority. It projects already
computed target/evidence/capability/proof state into a small decision frame and
attaches the critical part of the exact skill handoff inline so an unfamiliar
agent cannot miss the semantic contract merely because it skipped a Markdown
read.
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Any, Dict, Mapping

SCHEMA_VERSION = "agent-tool-communication-contract-v1"
POLICY = "decision-frame-before-detail-v1"
_INTERNAL_STAGES = {"resolve-target", "evidence-needs", "capability-match"}


def _skill_contract(skill_path: str | None) -> Dict[str, Any]:
    if not skill_path:
        return {"delivery_status": "NO_SKILL_PATH"}
    root = Path(__file__).resolve().parents[1]
    path = root / str(skill_path)
    if not path.is_file():
        return {"delivery_status": "SKILL_NOT_FOUND", "skill_path": str(skill_path)}
    text = path.read_text(encoding="utf-8")
    def field(label: str) -> str | None:
        m = re.search(rf"^\*\*{re.escape(label)}:\*\*\s*(.+)$", text, re.M)
        return m.group(1).strip() if m else None
    return {
        "delivery_status": "INLINE_CRITICAL_CONTRACT_ATTACHED",
        "skill_path": str(skill_path),
        "load_when": field("Load when"),
        "provides": field("Provides"),
        "return_to": field("Return to"),
        "critical_rules": [
            "This inline contract is sufficient to understand why the handoff exists before any next call.",
            "A handoff never grants execution, mutation, state-change, or truth authority.",
            "Read the full skill only when its detailed workflow is needed beyond this critical contract.",
        ],
    }


def normalize_skill_handoff(
    handoff: Mapping[str, Any] | None,
    *, capability_selection_stage: str = "",
    target_resolution_state: str = "",
) -> Dict[str, Any]:
    value = dict(handoff or {})
    capability = str(value.get("capability") or "")
    selection_done = str(capability_selection_stage) == "CAPABILITY_CANDIDATES_PROJECTED"
    target_state = str(target_resolution_state or "").upper()
    internal_done = capability in _INTERNAL_STAGES and (
        capability != "capability-match" or selection_done
    )
    value["handoff_type"] = "READ_SKILL_ONLY" if internal_done else "CALL_CAPABILITY_AFTER_READ"
    value["stage_completed"] = capability if internal_done else None
    value["do_not_repeat_stage"] = bool(internal_done and capability == "capability-match")
    if capability == "resolve-target" and target_state in {"AMBIGUOUS", "UNRESOLVED"}:
        value["do_not_repeat_stage"] = True
        value["repeat_condition"] = "only_after_additional_target_evidence_or_explicit_target_is_available"
        value["next_decision"] = "obtain target evidence or an explicit target; do not choose a specialized capability"
    elif capability == "capability-match" and selection_done:
        value["repeat_condition"] = "only_after_evidence_needs_change"
        value["next_decision"] = "inspect uncovered needs and candidate information roles; choose whether any candidate call is justified"
    elif capability == "evidence-needs":
        value["next_decision"] = "make evidence requirements explicit before capability matching"
    else:
        value["next_decision"] = value.get("after_read") or "decide whether the capability is justified"
    value["inline_contract"] = _skill_contract(value.get("skill_path"))
    # The inline contract supersedes verbose duplicate explanation fields in the
    # top-level handoff while retaining routing/authority compatibility fields.
    value.pop("canonical_concepts", None)
    value.pop("why_read", None)
    value.pop("after_read", None)
    return value


def build_agent_decision_frame(
    *,
    work_status: str,
    target_resolution: Mapping[str, Any],
    evidence_need_derivation: Mapping[str, Any],
    capability_selection: Mapping[str, Any],
    proof_gate: Mapping[str, Any],
    skill_handoff: Mapping[str, Any],
) -> Dict[str, Any]:
    resolution = target_resolution.get("resolution", {}) or {}
    target_state = str(resolution.get("state") or "UNKNOWN")
    selected_targets = list(resolution.get("selected_targets", []) or [])
    evidence_stage = str(evidence_need_derivation.get("stage") or "UNKNOWN")
    needs = [x for x in evidence_need_derivation.get("evidence_needed", []) or [] if isinstance(x, Mapping)]
    unknown = [x for x in evidence_need_derivation.get("unknown", []) or [] if isinstance(x, Mapping)]
    selection_stage = str(capability_selection.get("stage") or "UNKNOWN")
    uncovered = [x for x in capability_selection.get("uncovered_needs", []) or [] if isinstance(x, Mapping)]
    candidates = []
    for row in capability_selection.get("candidate_capabilities", []) or []:
        if not isinstance(row, Mapping):
            continue
        candidates.append({
            "capability": row.get("capability"),
            "coverage_role": row.get("coverage"),
            "covers_evidence_classes": row.get("covers_evidence_classes", []),
            "state_change": bool(row.get("state_change", False)),
            "skill_path": row.get("skill_path"),
        })
        if len(candidates) >= 4:
            break

    postcondition_requested = any(str(x.get("evidence_class")) == "postcondition_observation" for x in needs)
    if target_state not in {"RESOLVED", "MULTI_TARGET_RESOLVED"}:
        orchestration = "BLOCKED_TARGET_UNRESOLVED"
        action_readiness = "NOT_READY"
    elif str(work_status) == "recovery_required":
        orchestration = "RECOVERY_REQUIRED"
        action_readiness = "NOT_READY"
    elif selection_stage == "CAPABILITY_CANDIDATES_PROJECTED":
        orchestration = "READY_FOR_AGENT_DECISION"
        action_readiness = "NOT_ESTABLISHED" if (uncovered or postcondition_requested) else "AGENT_DECISION_REQUIRED"
    else:
        orchestration = "INFORMATION_DERIVATION_INCOMPLETE"
        action_readiness = "NOT_READY"

    task_postcondition_status = "UNPROVEN" if postcondition_requested else "NOT_EXPLICITLY_REQUESTED_OR_DERIVED"
    return {
        "schema_version": SCHEMA_VERSION,
        "policy": POLICY,
        "orchestration_status": orchestration,
        "legacy_work_status_scope": "reference_pack_status_only",
        "target": {"state": target_state, "selected_targets": selected_targets},
        "evidence": {
            "stage": evidence_stage,
            "need_count": len(needs),
            "unknown_count": len(unknown),
            "uncovered_need_count": len(uncovered),
            "uncovered_needs": [
                {"evidence_class": x.get("evidence_class"), "need": x.get("need"), "reason": x.get("reason")}
                for x in uncovered[:6]
            ],
        },
        "capability_projection": {
            "stage": selection_stage,
            "action_priority_computed": False,
            "ranking_is_not_recommendation": True,
            "candidates": candidates,
        },
        "action_readiness": action_readiness,
        "task_postcondition_status": task_postcondition_status,
        "proof_scope": {
            "current_reference_pack_status": str(work_status),
            "task_postcondition_settled": False,
            "warning": "proof-gate satisfaction for current source/reference claims does not settle the user's task postcondition",
        },
        "next_decision": skill_handoff.get("next_decision"),
        "skill_handoff": {
            "handoff_type": skill_handoff.get("handoff_type"),
            "skill_path": skill_handoff.get("skill_path"),
            "stage_completed": skill_handoff.get("stage_completed"),
            "do_not_repeat_stage": skill_handoff.get("do_not_repeat_stage"),
            "repeat_condition": skill_handoff.get("repeat_condition"),
            "inline_contract_delivery": {
                "status": (skill_handoff.get("inline_contract") or {}).get("delivery_status"),
                "skill_path": (skill_handoff.get("inline_contract") or {}).get("skill_path"),
                "detail_location": "top_level.skill_handoff.inline_contract",
            },
        },
        "authority": {
            "chooses_agent_action": False,
            "executes_capability": False,
            "mutate_source": False,
            "execute_runtime": False,
            "commit_truth": False,
        },
    }


__all__ = ["SCHEMA_VERSION", "POLICY", "normalize_skill_handoff", "build_agent_decision_frame"]
