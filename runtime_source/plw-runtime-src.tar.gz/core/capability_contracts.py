"""Strict, bounded helpers for capability-governance proof boundaries.

The workflow action chain accepts untrusted mappings at each public boundary.
These helpers keep validation exact and make malformed input a rejected proof
state instead of an exception or a permissive, partially checked structure.
"""
from __future__ import annotations

import hashlib
import json
import re
from collections.abc import Mapping
from typing import Any, Dict, Iterable


AUTHORIZATION_KEYS = frozenset({
    "transition_execution",
    "runtime_execution",
    "external_patch",
    "stable_promotion",
    "truth_commit",
})
EFFECT_KEYS = frozenset({
    "transition_executed",
    "runtime_executed",
    "external_patch_applied",
    "stable_promoted",
    "truth_committed",
})

_SHA256_RE = re.compile(r"sha256:[0-9a-f]{64}\Z")


def normalize_mapping(value: Any) -> tuple[Dict[str, Any], bool]:
    """Return a plain dict and whether normalization was structurally valid."""
    if not isinstance(value, Mapping):
        return {}, value is None
    try:
        result = dict(value)
    except Exception:
        return {}, False
    return result, all(isinstance(key, str) for key in result)


def exact_keys(value: Any, required: Iterable[str]) -> bool:
    return isinstance(value, dict) and set(value) == set(required)


def exact_false_map(value: Any, required: Iterable[str]) -> bool:
    keys = set(required)
    return isinstance(value, dict) and set(value) == keys and all(value[key] is False for key in keys)


def no_effect_authorizations(value: Any) -> bool:
    return exact_false_map(value, AUTHORIZATION_KEYS)


def no_effect_results(value: Any) -> bool:
    return exact_false_map(value, EFFECT_KEYS)


def bounded_text(value: Any, *, minimum: int = 1, maximum: int = 256) -> bool:
    return isinstance(value, str) and minimum <= len(value) <= maximum


def is_sha256_id(value: Any) -> bool:
    return isinstance(value, str) and _SHA256_RE.fullmatch(value) is not None


def _bounded_json(value: Any, *, max_bytes: int) -> bool:
    """Cheap structural bound before canonical JSON serialization."""
    stack = [(value, 0)]
    nodes = 0
    text_bytes = 0
    while stack:
        current, depth = stack.pop()
        nodes += 1
        if nodes > 512 or depth > 8:
            return False
        if current is None or type(current) is bool:
            continue
        if type(current) is int:
            if current.bit_length() > 128:
                return False
            continue
        if isinstance(current, str):
            encoded = current.encode("utf-8")
            if len(encoded) > 2048:
                return False
            text_bytes += len(encoded)
            if text_bytes > max_bytes:
                return False
            continue
        if isinstance(current, list):
            if len(current) > 128:
                return False
            stack.extend((item, depth + 1) for item in current)
            continue
        if isinstance(current, dict):
            if len(current) > 128 or any(not isinstance(key, str) or len(key) > 128 for key in current):
                return False
            stack.extend((item, depth + 1) for item in current.values())
            continue
        return False
    return True


def safe_canonical_digest(value: Any, *, max_bytes: int = 16384) -> str | None:
    """Return a bounded canonical digest, or ``None`` for malformed input."""
    if not _bounded_json(value, max_bytes=max_bytes):
        return None
    try:
        raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    except (TypeError, ValueError, OverflowError, RecursionError, UnicodeError):
        return None
    if len(raw) > max_bytes:
        return None
    return "sha256:" + hashlib.sha256(raw).hexdigest()


__all__ = [
    "AUTHORIZATION_KEYS",
    "EFFECT_KEYS",
    "normalize_mapping",
    "exact_keys",
    "exact_false_map",
    "no_effect_authorizations",
    "no_effect_results",
    "bounded_text",
    "is_sha256_id",
    "safe_canonical_digest",
]
