"""Graph-grounded target resolution for unfamiliar target repositories.

Task text is used only as a retrieval seed. Resolution authority comes from
explicit path identity and structural evidence in the existing SharedGraph.
This module does not select PLW capabilities, mutate source, execute runtime
code, or claim semantic ownership/behavioral correctness.
"""
from __future__ import annotations

import os
import re
from collections import deque
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

SCHEMA_VERSION = "target-resolution-structural-relevance-v1"
POLICY = "task-seed-plus-graph-evidence-not-ownership-proof-v1"
DEFAULT_TOP_N = 8
MAX_TOP_N = 24

_TOKEN_RE = re.compile(r"[A-Za-z_][A-Za-z0-9_./\\-]*")
_IDENTIFIER_RE = re.compile(r"\b[A-Za-z_][A-Za-z0-9_]{2,}\b")
_STOP = {
    "the", "and", "for", "with", "from", "into", "this", "that", "then", "when",
    "ubah", "ganti", "perbaiki", "cek", "lihat", "audit", "pastikan", "agar", "supaya",
    "file", "code", "kode", "repo", "repository", "target", "service", "module", "modul",
    "function", "fungsi", "class", "kelas", "test", "tests", "impact", "dampak",
}


def _norm(value: str) -> str:
    return os.path.normpath(str(value)).replace("\\", "/")


def _display(path: str, scan_root: str) -> str:
    value = _norm(path)
    root = _norm(scan_root or ".")
    try:
        if os.path.isabs(value) and os.path.isabs(root):
            rel = _norm(os.path.relpath(value, root))
            if rel != ".." and not rel.startswith("../"):
                return rel
    except (OSError, ValueError):
        pass
    prefix = root.rstrip("/") + "/"
    return value[len(prefix):] if root and value.startswith(prefix) else value


def _task_terms(task: str) -> Tuple[List[str], List[str]]:
    raw = [_norm(token).lower() for token in _TOKEN_RE.findall(task)]
    path_hints = [token for token in raw if "/" in token or "." in os.path.basename(token)]
    terms: List[str] = []
    for token in raw:
        for part in re.split(r"[./\\_-]+", token):
            part = part.strip().lower()
            if len(part) >= 3 and part not in _STOP and part not in terms:
                terms.append(part)
    identifiers = []
    for token in _IDENTIFIER_RE.findall(task):
        lowered = token.lower()
        if lowered not in _STOP and len(lowered) >= 3 and lowered not in identifiers:
            identifiers.append(lowered)
    return terms[:24], path_hints[:8] + [x for x in identifiers[:12] if x not in path_hints]


def _resolve_explicit(value: str, vertices: Sequence[str], scan_root: str) -> Tuple[Optional[str], List[str], str]:
    requested = _norm(value)
    vertex_norm = {_norm(v): str(v) for v in vertices}
    if requested in vertex_norm:
        return vertex_norm[requested], [], "exact"
    if not os.path.isabs(requested):
        root_joined = _norm(os.path.join(scan_root, requested))
        if root_joined in vertex_norm:
            return vertex_norm[root_joined], [], "root_relative"
        suffix = "/" + requested.lstrip("/")
        matches = sorted(original for normed, original in vertex_norm.items() if normed.endswith(suffix))
        if len(matches) == 1:
            return matches[0], [], "unique_suffix"
        if len(matches) > 1:
            return None, matches, "ambiguous"
    return None, [], "unresolved"


def _adjacency(edges: Sequence[Sequence[str]]) -> Tuple[Dict[str, List[str]], Dict[str, List[str]]]:
    up: Dict[str, set[str]] = {}
    down: Dict[str, set[str]] = {}
    for edge in edges:
        if len(edge) != 2:
            continue
        src, dst = str(edge[0]), str(edge[1])
        up.setdefault(src, set()).add(dst)
        down.setdefault(dst, set()).add(src)
    return ({k: sorted(v) for k, v in up.items()}, {k: sorted(v) for k, v in down.items()})


def _walk(start: str, adjacency: Mapping[str, Sequence[str]], limit: int = 512) -> List[str]:
    seen = {start}
    queue = deque([start])
    result: List[str] = []
    while queue and len(seen) <= limit:
        node = queue.popleft()
        for nxt in adjacency.get(node, ()):
            if nxt in seen:
                continue
            seen.add(nxt)
            result.append(nxt)
            queue.append(nxt)
    return result


def _bounded_display(values: Iterable[str], scan_root: str, limit: int) -> Tuple[List[str], int]:
    ordered = sorted({_display(value, scan_root) for value in values})
    return ordered[:limit], max(0, len(ordered) - limit)


def _structural_context(
    node: str,
    *,
    shared_graph: Mapping[str, Any],
    up: Mapping[str, Sequence[str]],
    down: Mapping[str, Sequence[str]],
    limit: int,
) -> Dict[str, Any]:
    scan_root = str(shared_graph.get("scan_root") or ".")
    meta = (shared_graph.get("node_metadata") or {}).get(node, {}) or {}
    downstream = _walk(node, down)
    upstream = _walk(node, up)
    node_meta = shared_graph.get("node_metadata", {}) or {}
    entrypoints = [item for item in downstream if (node_meta.get(item) or {}).get("is_entrypoint")]
    tests = [item for item in downstream if (node_meta.get(item) or {}).get("is_test")]
    direct_up, direct_up_omitted = _bounded_display(up.get(node, ()), scan_root, limit)
    direct_down, direct_down_omitted = _bounded_display(down.get(node, ()), scan_root, limit)
    affected_ep, ep_omitted = _bounded_display(entrypoints, scan_root, limit)
    reachable_tests, tests_omitted = _bounded_display(tests, scan_root, limit)
    return {
        "boundary": _display(str((shared_graph.get("file_to_boundary") or {}).get(node, "")), scan_root) or None,
        "fan_in": int(meta.get("fan_in", 0) or 0),
        "fan_out": int(meta.get("fan_out", 0) or 0),
        "is_entrypoint": bool(meta.get("is_entrypoint")),
        "is_test": bool(meta.get("is_test")),
        "direct_imports": direct_up,
        "direct_imports_omitted": direct_up_omitted,
        "direct_importers": direct_down,
        "direct_importers_omitted": direct_down_omitted,
        "transitive_upstream_count": len(upstream),
        "transitive_downstream_count": len(downstream),
        "affected_entrypoints": affected_ep,
        "affected_entrypoints_omitted": ep_omitted,
        "reachable_tests": reachable_tests,
        "reachable_tests_omitted": tests_omitted,
    }


def build_target_resolution(
    shared_graph: Mapping[str, Any],
    task: str,
    *,
    explicit_targets: Optional[Sequence[str]] = None,
    top_n: int = DEFAULT_TOP_N,
    neighborhood_limit: int = 8,
) -> Dict[str, Any]:
    if not isinstance(task, str) or not task.strip():
        raise ValueError("task must be a non-empty string")
    if isinstance(top_n, bool) or not isinstance(top_n, int) or not 1 <= top_n <= MAX_TOP_N:
        raise ValueError(f"top_n must be an integer between 1 and {MAX_TOP_N}")
    if isinstance(neighborhood_limit, bool) or not isinstance(neighborhood_limit, int) or not 1 <= neighborhood_limit <= 32:
        raise ValueError("neighborhood_limit must be an integer between 1 and 32")

    scan_root = str(shared_graph.get("scan_root") or ".")
    vertices = [str(v) for v in shared_graph.get("vertices", []) or []]
    edges = [list(edge) for edge in shared_graph.get("edges", []) or [] if len(edge) == 2]
    file_map = shared_graph.get("file_map", {}) or {}
    node_metadata = shared_graph.get("node_metadata", {}) or {}
    up, down = _adjacency(edges)
    terms, hints = _task_terms(task)

    explicit_rows: List[Dict[str, Any]] = []
    resolved_explicit: List[str] = []
    explicit_ambiguities: List[Dict[str, Any]] = []
    explicit_unresolved: List[Dict[str, Any]] = []
    for requested in list(explicit_targets or []):
        resolved, candidates, mode = _resolve_explicit(str(requested), vertices, scan_root)
        row = {
            "requested": str(requested),
            "resolution": mode,
            "resolved": _display(resolved, scan_root) if resolved else None,
            "candidates": [_display(item, scan_root) for item in candidates[:top_n]],
        }
        explicit_rows.append(row)
        if resolved:
            resolved_explicit.append(resolved)
        elif candidates:
            explicit_ambiguities.append(row)
        else:
            explicit_unresolved.append(row)

    candidate_rows: List[Dict[str, Any]] = []
    task_lower = task.lower().replace("\\", "/")
    for vertex in vertices:
        display = _display(vertex, scan_root)
        display_lower = display.lower()
        basename = os.path.basename(display_lower)
        stem = os.path.splitext(basename)[0]
        path_parts = [part for part in re.split(r"[/_.-]+", display_lower) if part]
        evidence: List[Dict[str, Any]] = []
        seed_score = 0

        if vertex in resolved_explicit:
            seed_score += 100
            evidence.append({"kind": "explicit_target", "weight": 100})
        for hint in hints:
            h = hint.lower().replace("\\", "/")
            if h == display_lower or display_lower.endswith("/" + h):
                seed_score += 40
                evidence.append({"kind": "task_path_match", "value": hint, "weight": 40})
                break
            if h == basename or h == stem:
                seed_score += 24
                evidence.append({"kind": "task_basename_match", "value": hint, "weight": 24})
                break

        stem_tokens = {part for part in re.split(r"[_-]+", stem) if len(part) >= 3}
        stem_overlap = sorted(stem_tokens & set(terms))
        if stem_overlap:
            weight = min(18, 9 * len(stem_overlap))
            seed_score += weight
            evidence.append({"kind": "filename_token_match", "values": stem_overlap, "weight": weight})

        path_overlap = sorted(set(path_parts) & set(terms))
        if path_overlap:
            weight = min(12, 3 * len(path_overlap))
            seed_score += weight
            evidence.append({"kind": "path_segment_match", "values": path_overlap, "weight": weight})

        # Content identifiers are hints only; they never establish ownership.
        content = str(file_map.get(vertex, ""))
        if content and terms:
            content_lower = content.lower()
            content_hits = [term for term in terms if re.search(r"\b" + re.escape(term) + r"\b", content_lower)]
            if content_hits:
                weight = min(9, 3 * len(content_hits))
                seed_score += weight
                evidence.append({"kind": "content_identifier_hint", "values": content_hits[:4], "weight": weight})

        if seed_score <= 0:
            continue
        meta = node_metadata.get(vertex, {}) or {}
        structural_tiebreak = min(3, int(meta.get("fan_in", 0) or 0))
        score = seed_score + structural_tiebreak
        if structural_tiebreak:
            evidence.append({"kind": "fan_in_tiebreak_only", "weight": structural_tiebreak})
        candidate_rows.append({
            "file": display,
            "score": score,
            "seed_score": seed_score,
            "evidence": evidence,
            "structural_context": _structural_context(
                vertex, shared_graph=shared_graph, up=up, down=down, limit=neighborhood_limit,
            ),
        })

    candidate_rows.sort(key=lambda row: (-int(row["score"]), row["file"]))
    candidate_rows = candidate_rows[:top_n]

    if explicit_ambiguities:
        state = "AMBIGUOUS"
        reason = "explicit_target_ambiguous"
    elif explicit_unresolved:
        state = "UNRESOLVED"
        reason = "explicit_target_unresolved"
    elif resolved_explicit:
        state = "RESOLVED" if len(set(resolved_explicit)) == 1 else "MULTI_TARGET_RESOLVED"
        reason = "explicit_target_identity"
    elif not candidate_rows:
        state = "UNRESOLVED"
        reason = "no_task_seed_matched_graph_node"
    else:
        top_score = int(candidate_rows[0]["score"])
        second_score = int(candidate_rows[1]["score"]) if len(candidate_rows) > 1 else -1
        if top_score >= 12 and top_score - second_score >= 4:
            state = "RESOLVED"
            reason = "unique_high_margin_candidate"
        else:
            state = "AMBIGUOUS"
            reason = "multiple_or_low_margin_candidates"

    selected = []
    if state == "RESOLVED" and candidate_rows:
        selected = [candidate_rows[0]["file"]]
    elif state == "MULTI_TARGET_RESOLVED":
        selected = sorted({_display(v, scan_root) for v in resolved_explicit})

    return {
        "schema_version": SCHEMA_VERSION,
        "policy": POLICY,
        "stage": "TARGET_RESOLUTION_" + state,
        "task": task,
        "scan_root": scan_root,
        "resolution": {
            "state": state,
            "reason": reason,
            "selected_targets": selected,
            "candidate_count": len(candidate_rows),
            "explicit_targets": explicit_rows,
        },
        "task_seed": {
            "terms": terms,
            "path_or_identifier_hints": hints,
            "warning": "task text seeds retrieval only; similarity is not semantic ownership proof",
        },
        "candidate_targets": candidate_rows,
        "technical_model": {
            "canonical_concepts": [
                "entity resolution", "information retrieval", "dependency graph neighborhood",
                "reverse dependency reachability", "test/entrypoint reachability",
            ],
            "different_from": [
                "semantic ownership proof", "runtime call graph", "behavioral correctness",
                "PLW capability selection",
            ],
        },
        "next_reasoning": {
            "when_resolved": "derive task-specific unknowns/evidence needs from the resolved target and its structural neighborhood",
            "when_ambiguous": "inspect the bounded candidate evidence or provide an explicit target; do not guess ownership",
            "when_unresolved": "widen source evidence or provide a path/symbol hint; do not select a capability from task wording alone",
        },
        "authority": {
            "semantic_ownership_proven": False,
            "selects_PLW_capability": False,
            "execute_runtime": False,
            "mutate_source": False,
            "commit_truth": False,
        },
    }


__all__ = ["build_target_resolution", "SCHEMA_VERSION", "POLICY"]
