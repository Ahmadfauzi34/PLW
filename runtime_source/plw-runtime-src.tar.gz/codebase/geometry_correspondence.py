"""Scenario-identified geometry snapshots and Angular UI-code correspondence.

F125 keeps rendered-space authority separate from code topology and static Angular
ownership.  The module validates a bounded runtime-supplied geometry payload,
normalizes it into a deterministic snapshot, and projects explicit runtime owner
claims onto F124 Angular anchors.

No DOM/browser execution occurs here.  No selector/name similarity is used.
Correspondence proof classes are EXACT, STRUCTURAL, or UNRESOLVED; INFERRED is
never emitted and may not authorize mutation.
"""
from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

GEOMETRY_SCHEMA_VERSION = "geometry-snapshot-v1"
REFERENCE_SCHEMA_VERSION = "ui-reference-v1"
MAX_SNAPSHOT_BYTES = 4 * 1024 * 1024
MAX_GEOMETRY_NODES = 50_000
_MAX_TEXT = 2048


class GeometrySnapshotError(ValueError):
    """Raised when a supplied geometry payload violates the bounded contract."""


def _sha256_text(value: str) -> str:
    digest = hashlib.sha256()
    digest.update(value.encode("utf-8"))
    return "sha256:" + digest.hexdigest()


def _canonical_digest(value: Any) -> str:
    payload = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    return "sha256:" + hashlib.sha256(payload).hexdigest()


def _bounded_text(value: Any, field: str, *, required: bool = False) -> Optional[str]:
    if value is None:
        if required:
            raise GeometrySnapshotError(f"{field} is required")
        return None
    if not isinstance(value, str):
        raise GeometrySnapshotError(f"{field} must be a string")
    value = value.strip()
    if required and not value:
        raise GeometrySnapshotError(f"{field} must be non-empty")
    if len(value) > _MAX_TEXT:
        raise GeometrySnapshotError(f"{field} exceeds {_MAX_TEXT} characters")
    return value or None


def _number(value: Any, field: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise GeometrySnapshotError(f"{field} must be a finite number")
    result = float(value)
    if not math.isfinite(result):
        raise GeometrySnapshotError(f"{field} must be a finite number")
    return result


def _viewport(value: Any) -> Dict[str, float]:
    if isinstance(value, (list, tuple)) and len(value) == 2:
        width = _number(value[0], "scenario.viewport.width")
        height = _number(value[1], "scenario.viewport.height")
        scale = 1.0
    elif isinstance(value, dict):
        width = _number(value.get("width"), "scenario.viewport.width")
        height = _number(value.get("height"), "scenario.viewport.height")
        scale = _number(value.get("device_scale_factor", 1.0), "scenario.viewport.device_scale_factor")
    else:
        raise GeometrySnapshotError("scenario.viewport must be [width,height] or an object")
    if width <= 0 or height <= 0 or scale <= 0:
        raise GeometrySnapshotError("scenario viewport dimensions and device scale must be > 0")
    return {"width": width, "height": height, "device_scale_factor": scale}


def _bbox(value: Any, field: str) -> Dict[str, float]:
    if isinstance(value, (list, tuple)) and len(value) == 4:
        x, y, width, height = (_number(item, field) for item in value)
    elif isinstance(value, dict):
        x = _number(value.get("x"), f"{field}.x")
        y = _number(value.get("y"), f"{field}.y")
        width = _number(value.get("width"), f"{field}.width")
        height = _number(value.get("height"), f"{field}.height")
    else:
        raise GeometrySnapshotError(f"{field} must be [x,y,width,height] or an object")
    if width < 0 or height < 0:
        raise GeometrySnapshotError(f"{field} width/height must be >= 0")
    return {"x": x, "y": y, "width": width, "height": height}


def _transform(value: Any, field: str) -> Optional[List[float]]:
    if value is None:
        return None
    if not isinstance(value, (list, tuple)) or len(value) != 6:
        raise GeometrySnapshotError(f"{field} must be a 6-number affine matrix")
    return [_number(item, field) for item in value]


def _safe_digest_claim(value: Any, field: str) -> Optional[str]:
    text = _bounded_text(value, field)
    if text is None:
        return None
    if not text.startswith("sha256:") or len(text) != 71:
        raise GeometrySnapshotError(f"{field} must be a sha256:<64-hex> identifier")
    try:
        int(text[7:], 16)
    except ValueError as exc:
        raise GeometrySnapshotError(f"{field} must be a sha256:<64-hex> identifier") from exc
    return text.lower()


def load_geometry_snapshot(path: str, *, max_bytes: int = MAX_SNAPSHOT_BYTES) -> Dict[str, Any]:
    """Load one bounded JSON geometry payload.  The raw document is never returned."""
    target = Path(path)
    try:
        stat = target.stat()
    except OSError as exc:
        raise GeometrySnapshotError(f"snapshot unavailable: {type(exc).__name__}") from exc
    if stat.st_size > max_bytes:
        raise GeometrySnapshotError(f"snapshot exceeds {max_bytes} bytes")
    try:
        raw = target.read_bytes()
        if len(raw) > max_bytes:
            raise GeometrySnapshotError(f"snapshot exceeds {max_bytes} bytes")
        payload = json.loads(raw.decode("utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise GeometrySnapshotError(f"snapshot is not valid bounded UTF-8 JSON: {type(exc).__name__}") from exc
    if not isinstance(payload, dict):
        raise GeometrySnapshotError("snapshot root must be a JSON object")
    return payload


def _normalize_static_context(value: Any) -> Dict[str, Optional[str]]:
    if value is None:
        value = {}
    if not isinstance(value, dict):
        raise GeometrySnapshotError("static_context must be an object")
    return {
        "graph_content_signature": _safe_digest_claim(value.get("graph_content_signature"), "static_context.graph_content_signature"),
        "angular_ownership_digest": _safe_digest_claim(value.get("angular_ownership_digest"), "static_context.angular_ownership_digest"),
    }


def _normalize_capture(value: Any) -> Dict[str, Optional[str]]:
    if value is None:
        value = {}
    if not isinstance(value, dict):
        raise GeometrySnapshotError("capture must be an object")
    # Deliberately retain provenance labels only. Raw DOM/screenshot/text content is
    # outside this reference-state contract.
    return {
        "source": _bounded_text(value.get("source"), "capture.source"),
        "captured_at": _bounded_text(value.get("captured_at"), "capture.captured_at"),
        "adapter_observation_id": _safe_digest_claim(value.get("adapter_observation_id"), "capture.adapter_observation_id"),
        "runtime_id": _bounded_text(value.get("runtime_id"), "capture.runtime_id"),
    }


def _normalize_owner(value: Any, field: str) -> Dict[str, Optional[str]]:
    if value is None:
        value = {}
    if not isinstance(value, dict):
        raise GeometrySnapshotError(f"{field} must be an object")
    return {
        "component_id": _safe_digest_claim(value.get("component_id"), f"{field}.component_id"),
        "component_selector": _bounded_text(value.get("component_selector"), f"{field}.component_selector"),
        "ownership_digest": _safe_digest_claim(value.get("ownership_digest"), f"{field}.ownership_digest"),
        "graph_content_signature": _safe_digest_claim(value.get("graph_content_signature"), f"{field}.graph_content_signature"),
    }


def _normalize_node(value: Any, index: int, viewport: Dict[str, float]) -> Dict[str, Any]:
    field = f"nodes[{index}]"
    if not isinstance(value, dict):
        raise GeometrySnapshotError(f"{field} must be an object")
    ui_id = _bounded_text(value.get("ui_id"), f"{field}.ui_id", required=True)
    box = _bbox(value.get("bbox"), f"{field}.bbox")
    visible = value.get("visible")
    if visible is not None and not isinstance(visible, bool):
        raise GeometrySnapshotError(f"{field}.visible must be boolean when supplied")
    z_index = value.get("z_index")
    z_value = _number(z_index, f"{field}.z_index") if z_index is not None else None
    opacity = value.get("opacity")
    opacity_value = _number(opacity, f"{field}.opacity") if opacity is not None else None
    if opacity_value is not None and not 0.0 <= opacity_value <= 1.0:
        raise GeometrySnapshotError(f"{field}.opacity must be between 0 and 1")
    transform = _transform(value.get("transform"), f"{field}.transform")
    tag_name = _bounded_text(value.get("tag_name"), f"{field}.tag_name")
    if tag_name is not None:
        tag_name = tag_name.lower()
    parent_ui_id = _bounded_text(value.get("parent_ui_id"), f"{field}.parent_ui_id")
    owner = _normalize_owner(value.get("owner"), f"{field}.owner")
    dom_path = _bounded_text(value.get("dom_path"), f"{field}.dom_path")

    right = box["x"] + box["width"]
    bottom = box["y"] + box["height"]
    intersects = not (
        right <= 0
        or bottom <= 0
        or box["x"] >= viewport["width"]
        or box["y"] >= viewport["height"]
    )
    fully_inside = (
        box["x"] >= 0
        and box["y"] >= 0
        and right <= viewport["width"]
        and bottom <= viewport["height"]
    )
    geometry = {
        "bbox": box,
        "right": right,
        "bottom": bottom,
        "center": {
            "x": box["x"] + box["width"] / 2.0,
            "y": box["y"] + box["height"] / 2.0,
        },
        "area": box["width"] * box["height"],
        "intersects_viewport": intersects,
        "fully_inside_viewport": fully_inside,
        "transform": transform,
        "z_index": z_value,
        "visible": visible,
        "opacity": opacity_value,
    }
    result: Dict[str, Any] = {
        "ui_id": ui_id,
        "tag_name": tag_name,
        "parent_ui_id": parent_ui_id,
        "dom_path_digest": _sha256_text(dom_path) if dom_path is not None else None,
        "owner": owner,
        "geometry": geometry,
    }
    result["geometry_digest"] = _canonical_digest({"ui_id": ui_id, "geometry": geometry})
    return result


def normalize_geometry_snapshot(snapshot: Dict[str, Any]) -> Dict[str, Any]:
    """Validate and normalize one externally supplied geometry state."""
    if not isinstance(snapshot, dict):
        raise GeometrySnapshotError("snapshot must be an object")
    schema_version = snapshot.get("schema_version", GEOMETRY_SCHEMA_VERSION)
    if schema_version != GEOMETRY_SCHEMA_VERSION:
        raise GeometrySnapshotError(f"unsupported geometry schema_version: {schema_version}")
    scenario = snapshot.get("scenario")
    if not isinstance(scenario, dict):
        raise GeometrySnapshotError("scenario must be an object")
    viewport = _viewport(scenario.get("viewport"))
    normalized_scenario = {
        "code_revision": _bounded_text(scenario.get("code_revision"), "scenario.code_revision", required=True),
        "route": _bounded_text(scenario.get("route"), "scenario.route", required=True),
        "viewport": viewport,
        "ui_state": _bounded_text(scenario.get("ui_state"), "scenario.ui_state", required=True),
        "data_fixture": _bounded_text(scenario.get("data_fixture"), "scenario.data_fixture", required=True),
    }
    scenario_id = _canonical_digest(normalized_scenario)
    static_context = _normalize_static_context(snapshot.get("static_context"))
    capture = _normalize_capture(snapshot.get("capture"))
    raw_nodes = snapshot.get("nodes")
    if not isinstance(raw_nodes, list):
        raise GeometrySnapshotError("nodes must be an array")
    if len(raw_nodes) > MAX_GEOMETRY_NODES:
        raise GeometrySnapshotError(f"nodes exceeds {MAX_GEOMETRY_NODES}")
    nodes: List[Dict[str, Any]] = []
    seen: set[str] = set()
    for index, raw in enumerate(raw_nodes):
        node = _normalize_node(raw, index, viewport)
        ui_id = node["ui_id"]
        if ui_id in seen:
            raise GeometrySnapshotError(f"duplicate ui_id: {ui_id}")
        seen.add(ui_id)
        nodes.append(node)
    parent_missing = sorted(
        node["ui_id"]
        for node in nodes
        if node.get("parent_ui_id") and node.get("parent_ui_id") not in seen
    )
    normalized = {
        "schema_version": GEOMETRY_SCHEMA_VERSION,
        "scenario": normalized_scenario,
        "scenario_id": scenario_id,
        "static_context": static_context,
        "capture": capture,
        "nodes": nodes,
        "summary": {
            "node_count": len(nodes),
            "visible_node_count": sum(1 for row in nodes if row["geometry"].get("visible") is True),
            "viewport_intersection_count": sum(1 for row in nodes if row["geometry"]["intersects_viewport"]),
            "fully_inside_viewport_count": sum(1 for row in nodes if row["geometry"]["fully_inside_viewport"]),
            "missing_parent_node_ids": parent_missing,
        },
        "authority": {
            "runtime_payload_validated": True,
            "runtime_capture_attested": False,
            "browser_invoked": False,
            "screenshot_interpreted": False,
            "geometric_correctness_proven": False,
            "source_mutated": False,
            "truth_committed": False,
        },
    }
    normalized["geometry_snapshot_digest"] = _canonical_digest({
        "scenario": normalized_scenario,
        "static_context": static_context,
        "capture": capture,
        "nodes": nodes,
    })
    return normalized


def _component_indexes(ownership: Dict[str, Any]) -> Tuple[Dict[str, Dict[str, Any]], Dict[str, List[str]]]:
    by_id: Dict[str, Dict[str, Any]] = {}
    for row in ownership.get("components", []):
        if isinstance(row, dict) and isinstance(row.get("component_id"), str):
            by_id[row["component_id"]] = row
    selector_index = ownership.get("selector_index")
    if not isinstance(selector_index, dict):
        selector_index = {}
    clean_index: Dict[str, List[str]] = {}
    for selector, ids in selector_index.items():
        if isinstance(selector, str) and isinstance(ids, list):
            clean_index[selector] = [item for item in ids if isinstance(item, str)]
    return by_id, clean_index


def _static_context_status(geometry: Dict[str, Any], ownership: Dict[str, Any]) -> Dict[str, Any]:
    supplied = geometry.get("static_context", {})
    expected_graph = ownership.get("graph_content_signature")
    expected_ownership = ownership.get("ownership_digest")
    graph_claim = supplied.get("graph_content_signature")
    ownership_claim = supplied.get("angular_ownership_digest")
    graph_match = bool(graph_claim and expected_graph and graph_claim == expected_graph)
    ownership_match = bool(ownership_claim and expected_ownership and ownership_claim == expected_ownership)
    missing = []
    if not graph_claim:
        missing.append("graph_content_signature")
    if not ownership_claim:
        missing.append("angular_ownership_digest")
    return {
        "graph_content_signature_claim": graph_claim,
        "graph_content_signature_current": expected_graph,
        "graph_content_signature_match": graph_match,
        "angular_ownership_digest_claim": ownership_claim,
        "angular_ownership_digest_current": expected_ownership,
        "angular_ownership_digest_match": ownership_match,
        "static_snapshot_bound": graph_match and ownership_match,
        "missing_claims": missing,
        "proof_class": "EXACT" if graph_match and ownership_match else "UNRESOLVED",
    }


def correspond_geometry_to_angular(
    geometry: Dict[str, Any],
    ownership: Dict[str, Any],
) -> Dict[str, Any]:
    """Project explicit runtime owner claims onto current F124 Angular anchors."""
    by_id, selector_index = _component_indexes(ownership)
    static_status = _static_context_status(geometry, ownership)
    mappings: List[Dict[str, Any]] = []
    exact_count = structural_count = unresolved_count = 0

    for node in geometry.get("nodes", []):
        owner = node.get("owner", {})
        claimed_id = owner.get("component_id")
        claimed_selector = owner.get("component_selector")
        relation_class = "UNRESOLVED"
        reason = "owner_claim_missing"
        component: Optional[Dict[str, Any]] = None
        candidates: List[str] = []

        if claimed_id:
            component = by_id.get(claimed_id)
            if component is None:
                reason = "component_id_not_found"
            else:
                actual_selector = component.get("selector", {}).get("value")
                if claimed_selector and actual_selector != claimed_selector:
                    component = None
                    reason = "component_id_selector_conflict"
                else:
                    relation_class = "EXACT"
                    reason = "component_id_match"
        elif claimed_selector:
            candidates = list(selector_index.get(claimed_selector, []))
            if len(candidates) == 1:
                component = by_id.get(candidates[0])
                if component is not None:
                    relation_class = "STRUCTURAL"
                    reason = "unique_selector_match"
            elif len(candidates) > 1:
                reason = "ambiguous_selector"
            else:
                reason = "selector_not_found"

        node_claim_match = True
        owner_digest = owner.get("ownership_digest")
        owner_graph = owner.get("graph_content_signature")
        if owner_digest is not None and owner_digest != ownership.get("ownership_digest"):
            node_claim_match = False
            reason = "node_ownership_digest_mismatch"
        if owner_graph is not None and owner_graph != ownership.get("graph_content_signature"):
            node_claim_match = False
            reason = "node_graph_signature_mismatch"

        proof_class = relation_class if static_status["static_snapshot_bound"] and node_claim_match else "UNRESOLVED"
        if proof_class == "EXACT":
            exact_count += 1
        elif proof_class == "STRUCTURAL":
            structural_count += 1
        else:
            unresolved_count += 1
        if relation_class != "UNRESOLVED" and not static_status["static_snapshot_bound"]:
            final_reason = "static_context_unbound"
        elif relation_class != "UNRESOLVED" and not node_claim_match:
            final_reason = reason
        elif proof_class == "UNRESOLVED":
            final_reason = reason
        else:
            final_reason = relation_class.lower() + "_correspondence"

        mappings.append({
            "ui_id": node.get("ui_id"),
            "geometry_digest": node.get("geometry_digest"),
            "claimed_component_id": claimed_id,
            "claimed_selector": claimed_selector,
            "candidate_component_ids": candidates,
            "component_id": component.get("component_id") if component else None,
            "component_file": component.get("file") if component else None,
            "component_class": component.get("class_name") if component else None,
            "component_selector": component.get("selector", {}).get("value") if component else None,
            "relation_class": relation_class,
            "relation_reason": reason,
            "freshness_class": static_status["proof_class"],
            "proof_class": proof_class,
            "reason": final_reason,
            "mutation_authority": False,
        })

    result = {
        "schema_version": "ui-angular-correspondence-v1",
        "scenario_id": geometry.get("scenario_id"),
        "geometry_snapshot_digest": geometry.get("geometry_snapshot_digest"),
        "angular_ownership_digest": ownership.get("ownership_digest"),
        "graph_content_signature": ownership.get("graph_content_signature"),
        "static_context": static_status,
        "mappings": mappings,
        "summary": {
            "mapping_count": len(mappings),
            "exact_count": exact_count,
            "structural_count": structural_count,
            "unresolved_count": unresolved_count,
            "fully_bound": bool(mappings) and unresolved_count == 0,
        },
        "authority": {
            "inferred_mapping_emitted": False,
            "mutation_authority": False,
            "runtime_behavior_proven": False,
            "geometry_correctness_proven": False,
            "truth_committed": False,
        },
    }
    result["correspondence_digest"] = _canonical_digest({
        "scenario_id": result["scenario_id"],
        "geometry_snapshot_digest": result["geometry_snapshot_digest"],
        "angular_ownership_digest": result["angular_ownership_digest"],
        "mappings": mappings,
    })
    return result


def build_ui_reference_state(snapshot: Dict[str, Any], angular_ownership: Dict[str, Any]) -> Dict[str, Any]:
    """Build one full-stack read-only reference state without merging authorities."""
    geometry = normalize_geometry_snapshot(snapshot)
    correspondence = correspond_geometry_to_angular(geometry, angular_ownership)
    result = {
        "schema_version": REFERENCE_SCHEMA_VERSION,
        "scenario_id": geometry["scenario_id"],
        "geometry": geometry,
        "angular_ownership": {
            "schema_version": angular_ownership.get("schema_version"),
            "graph_content_signature": angular_ownership.get("graph_content_signature"),
            "ownership_digest": angular_ownership.get("ownership_digest"),
            "component_count": angular_ownership.get("summary", {}).get("component_count", 0),
            "ambiguous_selectors": angular_ownership.get("summary", {}).get("ambiguous_selectors", []),
        },
        "correspondence": correspondence,
        "proof_boundary": {
            "geometry_payload_validated_is_runtime_attestation": False,
            "rendered_is_geometrically_valid": False,
            "static_owner_is_runtime_instance": False,
            "correspondence_is_behavior_proof": False,
            "correspondence_is_mutation_authority": False,
            "unresolved_is_not_irrelevant": True,
            "topology_geometry_authorities_merged": False,
        },
        "authority": {
            "topology_authority": "core.shared_graph",
            "static_angular_authority": "codebase.angular_semantics",
            "rendered_space_authority": "GeometrySnapshot",
            "correspondence_authority": "UIAngularCorrespondence",
            "source_mutated": False,
            "runtime_executed": False,
            "truth_committed": False,
        },
    }
    result["reference_state_digest"] = _canonical_digest({
        "geometry_snapshot_digest": geometry["geometry_snapshot_digest"],
        "angular_ownership_digest": angular_ownership.get("ownership_digest"),
        "correspondence_digest": correspondence["correspondence_digest"],
    })
    return result


__all__ = [
    "GEOMETRY_SCHEMA_VERSION",
    "REFERENCE_SCHEMA_VERSION",
    "MAX_SNAPSHOT_BYTES",
    "MAX_GEOMETRY_NODES",
    "GeometrySnapshotError",
    "load_geometry_snapshot",
    "normalize_geometry_snapshot",
    "correspond_geometry_to_angular",
    "build_ui_reference_state",
]
