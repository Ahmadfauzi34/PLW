"""Source-grounded Angular semantic ownership anchors.

F124 deliberately keeps Angular ownership out of ``SharedGraph`` topology.
The analyzer consumes one canonical SharedGraph source snapshot and emits a
separate, deterministic ownership sidecar.  Declared external templates/styles
are read only by exact metadata path (never by filesystem scan) and are bound by
content digests when available.

Proof classes:
- EXACT: exact source/resource bytes were observed and hashed.
- STRUCTURAL: relation follows from Angular import/decorator/class structure.
- UNRESOLVED: source expression is dynamic or outside this static contract.

No INFERRED anchor is emitted by this module.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

from language_semantics import normalize_path

SCHEMA_VERSION = "angular-ownership-v1"
MAX_RESOURCE_BYTES = 1_048_576
_ANGULAR_CORE = "@angular/core"
_LIFECYCLE_METHODS = {
    "ngOnChanges": "OnChanges",
    "ngOnInit": "OnInit",
    "ngDoCheck": "DoCheck",
    "ngAfterContentInit": "AfterContentInit",
    "ngAfterContentChecked": "AfterContentChecked",
    "ngAfterViewInit": "AfterViewInit",
    "ngAfterViewChecked": "AfterViewChecked",
    "ngOnDestroy": "OnDestroy",
}
_IDENTIFIER = re.compile(r"^[A-Za-z_$][A-Za-z0-9_$]*$")


def _sha256_text(value: str) -> str:
    digest = hashlib.sha256(value.encode("utf-8"))
    return f"sha256:{digest.hexdigest()}"


def _canonical_digest(value: Any) -> str:
    encoded = json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    return _sha256_text(encoded)


def _line_col(text: str, index: int) -> Dict[str, int]:
    index = max(0, min(len(text), index))
    line = text.count("\n", 0, index) + 1
    prev = text.rfind("\n", 0, index)
    return {"line": line, "column": index - prev}


def _span(text: str, start: int, end: int) -> Dict[str, Any]:
    return {
        "start": int(start),
        "end": int(end),
        "start_position": _line_col(text, start),
        "end_position": _line_col(text, end),
    }


def _skip_ws_comments(text: str, index: int) -> int:
    n = len(text)
    while index < n:
        if text[index].isspace():
            index += 1
            continue
        if text.startswith("//", index):
            newline = text.find("\n", index + 2)
            return n if newline < 0 else _skip_ws_comments(text, newline + 1)
        if text.startswith("/*", index):
            close = text.find("*/", index + 2)
            return n if close < 0 else _skip_ws_comments(text, close + 2)
        break
    return index


def _mask_js_noncode(text: str) -> str:
    """Mask JS/TS comments and string literals while preserving offsets."""
    chars = list(text)
    quote: Optional[str] = None
    escaped = False
    line_comment = False
    block_comment = False
    i = 0
    while i < len(chars):
        ch = text[i]
        nxt = text[i + 1] if i + 1 < len(text) else ""
        if line_comment:
            if ch == "\n":
                line_comment = False
            else:
                chars[i] = " "
            i += 1
            continue
        if block_comment:
            chars[i] = "\n" if ch == "\n" else " "
            if ch == "*" and nxt == "/":
                if i + 1 < len(chars):
                    chars[i + 1] = " "
                block_comment = False
                i += 2
            else:
                i += 1
            continue
        if quote is not None:
            chars[i] = "\n" if ch == "\n" else " "
            if escaped:
                escaped = False
            elif ch == "\\":
                escaped = True
            elif ch == quote:
                quote = None
            i += 1
            continue
        if ch == "/" and nxt == "/":
            chars[i] = chars[i + 1] = " "
            line_comment = True
            i += 2
            continue
        if ch == "/" and nxt == "*":
            chars[i] = chars[i + 1] = " "
            block_comment = True
            i += 2
            continue
        if ch in ("'", '"', "`"):
            chars[i] = " "
            quote = ch
            i += 1
            continue
        i += 1
    return "".join(chars)


def _scan_balanced(text: str, start: int, opening: str, closing: str) -> int:
    """Return matching closing delimiter, ignoring JS strings/comments."""
    if start < 0 or start >= len(text) or text[start] != opening:
        return -1
    masked = _mask_js_noncode(text)
    depth = 0
    for i in range(start, len(masked)):
        ch = masked[i]
        if ch == opening:
            depth += 1
        elif ch == closing:
            depth -= 1
            if depth == 0:
                return i
    return -1

def _top_level_split(text: str, separator: str = ",") -> List[Tuple[str, int, int]]:
    parts: List[Tuple[str, int, int]] = []
    masked = _mask_js_noncode(text)
    start = 0
    stack: List[str] = []
    matching = {")": "(", "]": "[", "}": "{"}
    for i, ch in enumerate(masked):
        if ch in "([{":
            stack.append(ch)
        elif ch in ")]}" and stack and stack[-1] == matching[ch]:
            stack.pop()
        elif ch == separator and not stack:
            parts.append((text[start:i], start, i))
            start = i + 1
    parts.append((text[start:], start, len(text)))
    return parts

def _top_level_colon(text: str) -> int:
    for part, start, _ in _top_level_split(text, separator=":"):
        # _top_level_split returns all chunks. The first boundary is len(first chunk)
        return start + len(part) if len(part) < len(text) else -1
    return -1


def _split_property(fragment: str) -> Optional[Tuple[str, str, int]]:
    masked = _mask_js_noncode(fragment)
    stack: List[str] = []
    matching = {")": "(", "]": "[", "}": "{"}
    for i, ch in enumerate(masked):
        if ch in "([{":
            stack.append(ch)
        elif ch in ")]}" and stack and stack[-1] == matching[ch]:
            stack.pop()
        elif ch == ":" and not stack:
            raw_key = fragment[:i].strip()
            raw_value = fragment[i + 1 :].strip()
            if not raw_key or not raw_value:
                return None
            key = _string_literal(raw_key)
            if key is None and _IDENTIFIER.fullmatch(raw_key):
                key = raw_key
            return (key, raw_value, i) if key is not None else None
    return None

def _string_literal(expr: str) -> Optional[str]:
    value = expr.strip()
    if len(value) < 2 or value[0] not in ("'", '"', "`") or value[-1] != value[0]:
        return None
    if value[0] == "`" and "${" in value:
        return None
    body = value[1:-1]
    # Decode only common JS escapes without evaluating arbitrary source.
    replacements = {
        r"\\": "\\",
        r"\n": "\n",
        r"\r": "\r",
        r"\t": "\t",
        r"\'": "'",
        r'\"': '"',
        r"\`": "`",
    }
    for source, target in replacements.items():
        body = body.replace(source, target)
    return body


def _array_items(expr: str) -> Optional[List[str]]:
    value = expr.strip()
    if not value.startswith("["):
        return None
    end = _scan_balanced(value, 0, "[", "]")
    if end != len(value) - 1:
        return None
    items = []
    for item, _, _ in _top_level_split(value[1:-1]):
        item = item.strip()
        if item:
            items.append(item)
    return items


def _object_properties(expr: str) -> Optional[Dict[str, str]]:
    value = expr.strip()
    if not value.startswith("{"):
        return None
    end = _scan_balanced(value, 0, "{", "}")
    if end != len(value) - 1:
        return None
    result: Dict[str, str] = {}
    for fragment, _, _ in _top_level_split(value[1:-1]):
        parsed = _split_property(fragment)
        if parsed:
            key, raw_value, _ = parsed
            result[key] = raw_value
    return result


def _angular_core_imports(content: str) -> Dict[str, str]:
    """Map local import name -> original @angular/core symbol."""
    result: Dict[str, str] = {}
    pattern = re.compile(
        r"import\s+(?:type\s+)?\{(?P<body>[\s\S]*?)\}\s+from\s+['\"]@angular/core['\"]\s*;?"
    )
    for match in pattern.finditer(content):
        for raw in match.group("body").split(","):
            item = raw.strip()
            if not item:
                continue
            item = re.sub(r"^type\s+", "", item).strip()
            alias = re.fullmatch(r"([A-Za-z_$][\w$]*)(?:\s+as\s+([A-Za-z_$][\w$]*))?", item)
            if not alias:
                continue
            original = alias.group(1)
            local = alias.group(2) or original
            result[local] = original
    return result


def _resolve_resource_path(source_file: str, literal_path: str) -> str:
    return normalize_path(os.path.join(os.path.dirname(source_file), literal_path))


def _read_exact_resource(path: str, max_bytes: int = MAX_RESOURCE_BYTES) -> Dict[str, Any]:
    try:
        stat = os.stat(path)
    except OSError as exc:
        return {
            "available": False,
            "proof_class": "UNRESOLVED",
            "reason": "resource_unavailable",
            "error_type": type(exc).__name__,
        }
    if stat.st_size > max_bytes:
        return {
            "available": False,
            "proof_class": "UNRESOLVED",
            "reason": "resource_too_large",
            "size_bytes": int(stat.st_size),
            "max_bytes": int(max_bytes),
        }
    try:
        raw = Path(path).read_bytes()
        text = raw.decode("utf-8")
    except (OSError, UnicodeDecodeError) as exc:
        return {
            "available": False,
            "proof_class": "UNRESOLVED",
            "reason": "resource_read_failed",
            "error_type": type(exc).__name__,
        }
    return {
        "available": True,
        "proof_class": "EXACT",
        "size_bytes": len(raw),
        "sha256": "sha256:" + hashlib.sha256(raw).hexdigest(),
        "text": text,
    }


def _resource_anchor(
    source_file: str,
    metadata_key: str,
    expression: Optional[str],
    *,
    read_resource: bool,
    resource_root: Optional[str],
) -> Dict[str, Any]:
    if expression is None:
        return {"kind": "absent", "proof_class": "UNRESOLVED"}
    literal = _string_literal(expression)
    if literal is None:
        return {
            "kind": "dynamic",
            "expression_digest": _sha256_text(expression.strip()),
            "proof_class": "UNRESOLVED",
            "reason": f"{metadata_key}_is_not_static_string_literal",
        }
    resource_path = _resolve_resource_path(source_file, literal)
    anchor: Dict[str, Any] = {
        "kind": "external",
        "declared_path": literal,
        "resolved_path": resource_path,
        "ownership_proof_class": "STRUCTURAL",
        "content_proof_class": "UNRESOLVED",
    }
    if read_resource:
        if resource_root is not None:
            root_real = os.path.realpath(os.path.abspath(resource_root))
            path_real = os.path.realpath(os.path.abspath(resource_path))
            try:
                inside_root = os.path.commonpath([root_real, path_real]) == root_real
            except ValueError:
                inside_root = False
            if not inside_root:
                anchor["resource"] = {
                    "available": False,
                    "proof_class": "UNRESOLVED",
                    "reason": "resource_outside_scan_root",
                }
                return anchor
        read = _read_exact_resource(resource_path)
        text = read.pop("text", None)
        anchor["resource"] = read
        if read.get("available"):
            anchor["content_proof_class"] = "EXACT"
            if isinstance(text, str):
                anchor["_content"] = text
    else:
        anchor["resource"] = {
            "available": None,
            "proof_class": "UNRESOLVED",
            "reason": "resource_read_disabled",
        }
    return anchor


def _inline_template_anchor(expression: str) -> Dict[str, Any]:
    literal = _string_literal(expression)
    if literal is None:
        return {
            "kind": "dynamic",
            "expression_digest": _sha256_text(expression.strip()),
            "proof_class": "UNRESOLVED",
            "reason": "template_is_not_static_string_literal",
        }
    return {
        "kind": "inline",
        "proof_class": "EXACT",
        "size_chars": len(literal),
        "sha256": _sha256_text(literal),
        "_content": literal,
    }


def _literal_list(expr: Optional[str]) -> Tuple[List[str], bool]:
    if expr is None:
        return [], True
    items = _array_items(expr)
    if items is None:
        return [], False
    values: List[str] = []
    complete = True
    for item in items:
        literal = _string_literal(item)
        if literal is None:
            complete = False
        else:
            values.append(literal)
    return values, complete


def _identifier_list(expr: Optional[str]) -> Tuple[List[str], bool]:
    if expr is None:
        return [], True
    items = _array_items(expr)
    if items is None:
        return [], False
    values: List[str] = []
    complete = True
    for item in items:
        normalized = " ".join(item.strip().split())
        if re.fullmatch(r"[A-Za-z_$][\w$]*(?:\.[A-Za-z_$][\w$]*)?", normalized):
            values.append(normalized)
        else:
            complete = False
    return values, complete


def _class_depths(body: str) -> List[int]:
    """Curly depth at each offset, ignoring strings/comments."""
    masked = _mask_js_noncode(body)
    depths = [0] * (len(body) + 1)
    depth = 0
    for i, ch in enumerate(masked):
        depths[i] = depth
        if ch == "{":
            depth += 1
        elif ch == "}":
            depth = max(0, depth - 1)
    depths[len(body)] = depth
    return depths

def _class_members(body: str) -> Dict[str, Dict[str, Any]]:
    depths = _class_depths(body)
    members: Dict[str, Dict[str, Any]] = {}
    # Method declarations at class top-level.
    method_pattern = re.compile(
        r"(?:^|[;\n])\s*(?:public\s+|protected\s+|private\s+|readonly\s+|static\s+|async\s+|override\s+|abstract\s+)*"
        r"([A-Za-z_$][\w$]*)\s*(?:<[^>{};]*>)?\s*\([^;{}]*\)\s*(?::\s*[^={;]+)?\s*\{",
        re.MULTILINE,
    )
    for match in method_pattern.finditer(body):
        name = match.group(1)
        name_pos = match.start(1)
        if depths[name_pos] != 0 or name == "constructor":
            continue
        members.setdefault(name, {"name": name, "kind": "method", "proof_class": "STRUCTURAL"})

    # Fields whose declaration starts at top-level. This intentionally does not
    # attempt to parse every TypeScript member form; unresolved bindings remain
    # visible instead of being guessed.
    field_pattern = re.compile(
        r"(?:^|[;\n])\s*(?:public\s+|protected\s+|private\s+|readonly\s+|static\s+|declare\s+|override\s+)*"
        r"([A-Za-z_$][\w$]*)\s*(?:[!?])?\s*(?::[^=;\n]+)?\s*=",
        re.MULTILINE,
    )
    for match in field_pattern.finditer(body):
        name = match.group(1)
        if depths[match.start(1)] != 0:
            continue
        members.setdefault(name, {"name": name, "kind": "field", "proof_class": "STRUCTURAL"})
    return members


def _static_alias_from_args(args: str) -> Tuple[Optional[str], bool]:
    value = args.strip()
    if not value:
        return None, True
    first = _top_level_split(value)[0][0].strip()
    literal = _string_literal(first)
    if literal is not None:
        return literal, True
    props = _object_properties(first)
    if props is not None and "alias" in props:
        alias = _string_literal(props["alias"])
        return alias, alias is not None
    return None, False


def _decorated_members(body: str, imports: Dict[str, str]) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]], List[Dict[str, Any]]]:
    depths = _class_depths(body)
    inputs: List[Dict[str, Any]] = []
    outputs: List[Dict[str, Any]] = []
    host_bindings: List[Dict[str, Any]] = []
    decorator_pattern = re.compile(r"@([A-Za-z_$][\w$]*)\s*(?:\(([^)]*)\))?\s*([A-Za-z_$][\w$]*)", re.MULTILINE)
    for match in decorator_pattern.finditer(body):
        if depths[match.start()] != 0:
            continue
        local_dec, args, member = match.group(1), (match.group(2) or "").strip(), match.group(3)
        original = imports.get(local_dec)
        alias, alias_static = _static_alias_from_args(args)
        if original == "Input":
            inputs.append({"name": member, "alias": alias if alias_static and alias is not None else (member if not args else None), "source": "@Input", "proof_class": "STRUCTURAL" if alias_static else "UNRESOLVED"})
        elif original == "Output":
            outputs.append({"name": member, "alias": alias if alias_static and alias is not None else (member if not args else None), "source": "@Output", "proof_class": "STRUCTURAL" if alias_static else "UNRESOLVED"})
        elif original == "HostBinding":
            host_bindings.append({"kind": "host_property", "name": alias if alias_static and alias else member, "owner_member": member, "proof_class": "STRUCTURAL" if alias_static else "UNRESOLVED"})
        elif original == "HostListener":
            host_bindings.append({"kind": "host_event", "name": alias if alias_static and alias else (member if not args else None), "owner_member": member, "proof_class": "STRUCTURAL" if alias_static else "UNRESOLVED"})
    return inputs, outputs, host_bindings


def _signal_members(body: str, imports: Dict[str, str]) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]], List[Dict[str, Any]]]:
    depths = _class_depths(body)
    outputs: List[Dict[str, Any]] = []
    inputs: List[Dict[str, Any]] = []
    models: List[Dict[str, Any]] = []
    local_by_original: Dict[str, List[str]] = {}
    for local, original in imports.items():
        local_by_original.setdefault(original, []).append(local)
    for original, target in (("input", inputs), ("output", outputs), ("model", models)):
        for local in local_by_original.get(original, []):
            pattern = re.compile(
                rf"(?:^|[;\n])\s*(?:public\s+|protected\s+|private\s+|readonly\s+|static\s+)*"
                rf"([A-Za-z_$][\w$]*)\s*(?:[!?])?\s*(?::[^=;\n]+)?\s*=\s*{re.escape(local)}(?:\.required)?(?:\s*<[^;=()]+>)?\s*\(",
                re.MULTILINE,
            )
            for match in pattern.finditer(body):
                if depths[match.start(1)] != 0:
                    continue
                name = match.group(1)
                open_idx = match.end() - 1
                close_idx = _scan_balanced(body, open_idx, "(", ")")
                alias: Optional[str] = name
                alias_static = True
                if close_idx >= 0:
                    args = [part[0].strip() for part in _top_level_split(body[open_idx + 1 : close_idx]) if part[0].strip()]
                    option_candidates = [arg for arg in args if arg.startswith("{")]
                    if option_candidates:
                        props = _object_properties(option_candidates[-1])
                        if props is not None and "alias" in props:
                            parsed_alias = _string_literal(props["alias"])
                            if parsed_alias is None:
                                alias = None
                                alias_static = False
                            else:
                                alias = parsed_alias
                item = {"name": name, "alias": alias, "source": original, "proof_class": "STRUCTURAL" if alias_static else "UNRESOLVED"}
                target.append(item)
    return inputs, outputs, models

def _metadata_io(values: Sequence[str], source: str) -> List[Dict[str, Any]]:
    result = []
    for value in values:
        public, internal = value, value
        if ":" in value:
            internal, public = [part.strip() for part in value.split(":", 1)]
        if internal:
            result.append({"name": internal, "alias": public or internal, "source": source, "proof_class": "STRUCTURAL"})
    return result


def _dedupe_io(items: Iterable[Dict[str, Any]]) -> List[Dict[str, Any]]:
    seen = set()
    result = []
    for item in items:
        key = (item.get("name"), item.get("alias"), item.get("source"))
        if key not in seen:
            seen.add(key)
            result.append(item)
    return sorted(result, key=lambda row: (str(row.get("alias")), str(row.get("name")), str(row.get("source"))))


def _template_bindings(template: str, members: Dict[str, Dict[str, Any]], source: str, source_digest: str) -> Dict[str, Any]:
    """Extract bounded Angular template-binding witnesses, not an HTML AST."""
    records: List[Dict[str, Any]] = []
    patterns = (
        ("two_way", re.compile(r"\[\(([^)]+)\)\]\s*=\s*([\"'])(.*?)\2", re.S)),
        ("event", re.compile(r"\(([^)]+)\)\s*=\s*([\"'])(.*?)\2", re.S)),
        ("property", re.compile(r"\[([^\]]+)\]\s*=\s*([\"'])(.*?)\2", re.S)),
        ("interpolation", re.compile(r"\{\{([\s\S]*?)\}\}")),
    )
    reserved = {
        "true", "false", "null", "undefined", "this", "$event", "as", "let",
        "if", "else", "return", "new", "typeof", "void",
    }
    for kind, pattern in patterns:
        for match in pattern.finditer(template):
            if kind == "interpolation":
                name = None
                expression = match.group(1).strip()
            else:
                name = match.group(1).strip()
                expression = match.group(3).strip()
            refs = []
            for token in re.findall(r"\b[A-Za-z_$][A-Za-z0-9_$]*\b", expression):
                if token in reserved or token.isdigit() or token in refs:
                    continue
                refs.append(token)
            owned = [token for token in refs if token in members]
            unresolved = [token for token in refs if token not in members]
            records.append({
                "kind": kind,
                "binding": name,
                "expression_digest": _sha256_text(expression),
                "owned_members": owned,
                "unresolved_identifiers": unresolved,
                "proof_class": "STRUCTURAL" if owned else "UNRESOLVED",
            })
    records.sort(key=lambda row: (str(row.get("kind")), str(row.get("binding")), row.get("expression_digest", "")))
    return {
        "source": source,
        "source_sha256": source_digest,
        "binding_count": len(records),
        "bindings": records,
    }


def _host_bindings(expr: Optional[str], members: Dict[str, Dict[str, Any]]) -> Tuple[List[Dict[str, Any]], bool]:
    if expr is None:
        return [], True
    props = _object_properties(expr)
    if props is None:
        return [], False
    result = []
    for key, raw_value in props.items():
        expression = _string_literal(raw_value)
        if expression is None:
            result.append({"kind": "host", "binding": key, "proof_class": "UNRESOLVED", "reason": "dynamic_host_expression"})
            continue
        refs = [token for token in re.findall(r"\b[A-Za-z_$][A-Za-z0-9_$]*\b", expression) if token in members]
        result.append({
            "kind": "host_event" if key.startswith("(") else "host_property" if key.startswith("[") else "host_attribute",
            "binding": key,
            "expression_digest": _sha256_text(expression),
            "owned_members": sorted(set(refs)),
            "proof_class": "STRUCTURAL" if refs else "UNRESOLVED",
        })
    return sorted(result, key=lambda row: str(row.get("binding"))), True


def _parse_component_at(
    file_path: str,
    content: str,
    decorator_start: int,
    decorator_local: str,
    angular_imports: Dict[str, str],
    *,
    read_resources: bool,
    resource_root: Optional[str],
) -> Optional[Dict[str, Any]]:
    paren_start = content.find("(", decorator_start)
    if paren_start < 0:
        return None
    paren_end = _scan_balanced(content, paren_start, "(", ")")
    if paren_end < 0:
        return None
    arg_start = _skip_ws_comments(content, paren_start + 1)
    if arg_start >= paren_end or content[arg_start] != "{":
        return None
    obj_end = _scan_balanced(content, arg_start, "{", "}")
    if obj_end < 0 or obj_end > paren_end:
        return None
    metadata_expr = content[arg_start : obj_end + 1]
    metadata = _object_properties(metadata_expr) or {}

    # Bind to the next class declaration after the decorator. This is structural
    # only because the decorator itself is proven to be imported Component.
    class_match = re.search(
        r"(?:export\s+)?(?:default\s+)?(?:abstract\s+)?class\s+([A-Za-z_$][\w$]*)"
        r"(?:\s+extends\s+[^\{]+)?(?:\s+implements\s+([^\{]+))?\s*\{",
        content[paren_end + 1 :],
    )
    if not class_match:
        return None
    class_abs_start = paren_end + 1 + class_match.start()
    # Refuse to jump across another decorator or statement block accidentally.
    bridge = content[paren_end + 1 : class_abs_start]
    if ";" in bridge or re.search(r"\b(class|function|const|let|var)\b", bridge):
        return None
    class_name = class_match.group(1)
    class_open = paren_end + 1 + class_match.end() - 1
    class_close = _scan_balanced(content, class_open, "{", "}")
    if class_close < 0:
        return None
    body = content[class_open + 1 : class_close]
    members = _class_members(body)

    selector_expr = metadata.get("selector")
    selector = _string_literal(selector_expr) if selector_expr is not None else None
    selector_anchor: Dict[str, Any]
    if selector is not None:
        selector_anchor = {"value": selector, "proof_class": "STRUCTURAL"}
    elif selector_expr is not None:
        selector_anchor = {
            "value": None,
            "proof_class": "UNRESOLVED",
            "expression_digest": _sha256_text(selector_expr.strip()),
            "reason": "selector_is_not_static_string_literal",
        }
    else:
        selector_anchor = {"value": None, "proof_class": "UNRESOLVED", "reason": "selector_absent"}

    if "templateUrl" in metadata:
        template = _resource_anchor(file_path, "templateUrl", metadata.get("templateUrl"), read_resource=read_resources, resource_root=resource_root)
    elif "template" in metadata:
        template = _inline_template_anchor(metadata["template"])
    else:
        template = {"kind": "absent", "proof_class": "UNRESOLVED", "reason": "template_metadata_absent"}

    styles: List[Dict[str, Any]] = []
    if "styleUrl" in metadata:
        styles.append(_resource_anchor(file_path, "styleUrl", metadata.get("styleUrl"), read_resource=read_resources, resource_root=resource_root))
    if "styleUrls" in metadata:
        items = _array_items(metadata["styleUrls"])
        if items is None:
            styles.append({
                "kind": "dynamic",
                "proof_class": "UNRESOLVED",
                "reason": "styleUrls_is_not_static_array",
                "expression_digest": _sha256_text(metadata["styleUrls"].strip()),
            })
        else:
            for item in items:
                styles.append(_resource_anchor(file_path, "styleUrls", item, read_resource=read_resources, resource_root=resource_root))
    if "styles" in metadata:
        items = _array_items(metadata["styles"])
        if items is None:
            styles.append({"kind": "dynamic_inline", "proof_class": "UNRESOLVED", "reason": "styles_is_not_static_array"})
        else:
            for item in items:
                literal = _string_literal(item)
                if literal is None:
                    styles.append({"kind": "dynamic_inline", "proof_class": "UNRESOLVED", "expression_digest": _sha256_text(item.strip())})
                else:
                    styles.append({"kind": "inline", "proof_class": "EXACT", "size_chars": len(literal), "sha256": _sha256_text(literal)})

    meta_inputs, meta_inputs_complete = _literal_list(metadata.get("inputs"))
    meta_outputs, meta_outputs_complete = _literal_list(metadata.get("outputs"))
    dec_inputs, dec_outputs, dec_host = _decorated_members(body, angular_imports)
    for decorated in [*dec_inputs, *dec_outputs, *dec_host]:
        owner_name = decorated.get("owner_member") or decorated.get("name")
        if isinstance(owner_name, str) and _IDENTIFIER.fullmatch(owner_name):
            members.setdefault(owner_name, {"name": owner_name, "kind": "decorated_member", "proof_class": "STRUCTURAL"})
    sig_inputs, sig_outputs, models = _signal_members(body, angular_imports)
    inputs = _dedupe_io([*_metadata_io(meta_inputs, "component_metadata"), *dec_inputs, *sig_inputs])
    outputs = _dedupe_io([*_metadata_io(meta_outputs, "component_metadata"), *dec_outputs, *sig_outputs])
    models = _dedupe_io(models)

    implements_raw = (class_match.group(2) or "").strip()
    implements = []
    if implements_raw:
        for raw in _top_level_split(implements_raw):
            item = raw[0].strip().split("<", 1)[0].strip()
            if item:
                implements.append(item)
    lifecycle = []
    for method, interface in _LIFECYCLE_METHODS.items():
        method_present = method in members and members[method].get("kind") == "method"
        interface_present = any(angular_imports.get(local) == interface for local in implements) or interface in implements
        if method_present or interface_present:
            lifecycle.append({
                "hook": method,
                "interface": interface,
                "method_present": method_present,
                "interface_declared": interface_present,
                "proof_class": "STRUCTURAL" if method_present else "UNRESOLVED",
            })

    component_imports, component_imports_complete = _identifier_list(metadata.get("imports"))
    host_meta, host_complete = _host_bindings(metadata.get("host"), members)
    host_evidence = [*dec_host, *host_meta]

    binding_evidence: List[Dict[str, Any]] = []
    template_content = template.pop("_content", None)
    if isinstance(template_content, str):
        if template.get("kind") == "inline":
            source_label = f"{file_path}#inline-template"
            digest = template.get("sha256", _sha256_text(template_content))
        else:
            source_label = str(template.get("resolved_path"))
            digest = str(template.get("resource", {}).get("sha256") or _sha256_text(template_content))
        binding_evidence.append(_template_bindings(template_content, members, source_label, digest))
    for style in styles:
        style.pop("_content", None)

    unresolved: List[str] = []
    if selector_anchor.get("proof_class") == "UNRESOLVED":
        unresolved.append("selector")
    if template.get("proof_class") == "UNRESOLVED" or template.get("content_proof_class") == "UNRESOLVED":
        if template.get("kind") not in ("absent", "inline"):
            unresolved.append("template_content")
    if not meta_inputs_complete:
        unresolved.append("metadata_inputs")
    if not meta_outputs_complete:
        unresolved.append("metadata_outputs")
    if not component_imports_complete:
        unresolved.append("component_imports")
    if not host_complete:
        unresolved.append("host_bindings")
    if any(row.get("proof_class") == "UNRESOLVED" for row in [*inputs, *outputs, *models]):
        unresolved.append("input_output_alias")

    component_key = {
        "file": normalize_path(file_path),
        "class_name": class_name,
        "decorator_start": decorator_start,
    }
    return {
        "component_id": _canonical_digest(component_key),
        "file": normalize_path(file_path),
        "class_name": class_name,
        "proof_class": "STRUCTURAL",
        "framework": "angular",
        "decorator": {
            "local_name": decorator_local,
            "imported_symbol": "Component",
            "module": _ANGULAR_CORE,
            "proof_class": "EXACT",
            "span": _span(content, decorator_start, paren_end + 1),
        },
        "class": {
            "span": _span(content, class_abs_start, class_close + 1),
            "members": sorted(members.values(), key=lambda row: row["name"]),
        },
        "selector": selector_anchor,
        "template": template,
        "styles": styles,
        "component_imports": component_imports,
        "component_imports_complete": component_imports_complete,
        "inputs": inputs,
        "outputs": outputs,
        "models": models,
        "lifecycle": lifecycle,
        "host_bindings": host_evidence,
        "binding_evidence": binding_evidence,
        "unresolved": sorted(set(unresolved)),
    }


def extract_angular_components(
    file_path: str,
    content: str,
    *,
    read_resources: bool = True,
    resource_root: Optional[str] = None,
) -> List[Dict[str, Any]]:
    """Extract Angular components only when Component is imported from @angular/core."""
    imports = _angular_core_imports(content)
    component_locals = sorted(local for local, original in imports.items() if original == "Component")
    if not component_locals:
        return []
    components: List[Dict[str, Any]] = []
    for local in component_locals:
        pattern = re.compile(rf"@{re.escape(local)}\s*\(")
        for match in pattern.finditer(content):
            parsed = _parse_component_at(
                file_path,
                content,
                match.start(),
                local,
                imports,
                read_resources=read_resources,
                resource_root=resource_root,
            )
            if parsed:
                components.append(parsed)
    components.sort(key=lambda row: (row["file"], row["class_name"], row["component_id"]))
    return components


def analyze_angular_ownership(
    shared_graph: Dict[str, Any],
    *,
    file_filter: Optional[str] = None,
    selector_filter: Optional[str] = None,
    read_resources: bool = True,
) -> Dict[str, Any]:
    """Build Angular ownership sidecar from an existing canonical graph snapshot."""
    file_map = shared_graph.get("file_map", {}) if isinstance(shared_graph, dict) else {}
    vertices = set(shared_graph.get("vertices", [])) if isinstance(shared_graph, dict) else set()
    normalized_file_filter = normalize_path(file_filter) if file_filter else None
    components: List[Dict[str, Any]] = []
    files_considered = 0
    for file_path in sorted(file_map):
        if vertices and file_path not in vertices:
            continue
        if normalized_file_filter and normalize_path(file_path) != normalized_file_filter:
            # Also allow caller-relative suffix to avoid forcing absolute roots.
            if not normalize_path(file_path).endswith("/" + normalized_file_filter) and normalize_path(file_path) != normalized_file_filter:
                continue
        content = file_map.get(file_path)
        if not isinstance(content, str):
            continue
        files_considered += 1
        components.extend(extract_angular_components(file_path, content, read_resources=read_resources, resource_root=shared_graph.get("scan_root")))
    if selector_filter is not None:
        components = [row for row in components if row.get("selector", {}).get("value") == selector_filter]

    by_selector: Dict[str, List[str]] = {}
    for row in components:
        selector = row.get("selector", {}).get("value")
        if isinstance(selector, str) and selector:
            by_selector.setdefault(selector, []).append(row["component_id"])
    ambiguous_selectors = sorted(selector for selector, ids in by_selector.items() if len(ids) > 1)
    unresolved_components = sum(1 for row in components if row.get("unresolved"))
    resource_exact = 0
    resource_unresolved = 0
    binding_count = 0
    for row in components:
        template = row.get("template", {})
        if template.get("kind") == "external":
            if template.get("content_proof_class") == "EXACT":
                resource_exact += 1
            else:
                resource_unresolved += 1
        for style in row.get("styles", []):
            if style.get("kind") == "external":
                if style.get("content_proof_class") == "EXACT":
                    resource_exact += 1
                else:
                    resource_unresolved += 1
        binding_count += sum(int(block.get("binding_count", 0)) for block in row.get("binding_evidence", []))

    graph_signature = shared_graph.get("cache", {}).get("graph_content_signature")
    if not graph_signature:
        # Lazy import keeps module loading acyclic while still binding direct
        # build_shared_graph callers to the exact semantic snapshot.
        try:
            from core.shared_graph import graph_content_signature as _graph_signature
            graph_signature = _graph_signature(shared_graph)
        except Exception:
            graph_signature = None
    result = {
        "schema_version": SCHEMA_VERSION,
        "scan_root": shared_graph.get("scan_root"),
        "graph_content_signature": graph_signature,
        "authority": {
            "inventory_authority": "core.shared_graph",
            "source_snapshot_reused": True,
            "additional_filesystem_scan": False,
            "declared_resource_reads_only": bool(read_resources),
            "runtime_observed": False,
            "geometry_observed": False,
            "mutation_authority": False,
            "inferred_anchor_emitted": False,
        },
        "filters": {
            "file": normalized_file_filter,
            "selector": selector_filter,
        },
        "components": components,
        "selector_index": {key: sorted(values) for key, values in sorted(by_selector.items())},
        "summary": {
            "files_considered": files_considered,
            "component_count": len(components),
            "selector_count": len(by_selector),
            "ambiguous_selectors": ambiguous_selectors,
            "unresolved_component_count": unresolved_components,
            "exact_external_resource_count": resource_exact,
            "unresolved_external_resource_count": resource_unresolved,
            "template_binding_count": binding_count,
        },
        "proof_boundary": {
            "component_decorator_structural": True,
            "selector_literal_is_runtime_render_proof": False,
            "template_ownership_is_geometry_proof": False,
            "template_binding_is_behavior_proof": False,
            "resource_digest_is_runtime_freshness_proof": False,
            "unresolved_is_not_irrelevant": True,
        },
    }
    result["ownership_digest"] = _canonical_digest({
        "components": components,
        "selector_index": result["selector_index"],
        "scan_root": result["scan_root"],
    })
    return result


__all__ = [
    "SCHEMA_VERSION",
    "MAX_RESOURCE_BYTES",
    "extract_angular_components",
    "analyze_angular_ownership",
]
